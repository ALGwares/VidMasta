/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.ImagePainter;
/*     */ import de.javasoft.plaf.synthetica.painter.TabbedPanePainter;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import de.javasoft.util.java2d.DropShadow;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthGraphicsUtils;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.plaf.synth.SynthStyleFactory;
/*     */ 
/*     */ public class GraphicsUtils extends SynthGraphicsUtils {
/*     */   public void paintText(SynthContext paramSynthContext, Graphics paramGraphics, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/*  63 */     JComponent jComponent = paramSynthContext.getComponent();
/*  64 */     Region region = paramSynthContext.getRegion();
/*  66 */     if (region == Region.BUTTON || region == Region.TOGGLE_BUTTON) {
/*  68 */       if (!SyntheticaLookAndFeel.getBoolean("Button.showMnemonics", jComponent, getPaintButtonMnemonics()))
/*  69 */         paramInt3 = -1; 
/*  71 */       String str = (String)SyntheticaLookAndFeel.get("Synthetica.button.textBackground", jComponent);
/*  72 */       if (str != null && str.length() > 0 && paramString != null && paramString.trim().length() > 0) {
/*  74 */         Insets insets1 = (Insets)SyntheticaLookAndFeel.get("Synthetica.button.textBackground.insets", jComponent);
/*  75 */         Insets insets2 = insets1;
/*  76 */         FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/*  77 */         int i = fontMetrics.getHeight();
/*  78 */         int j = fontMetrics.stringWidth(paramString);
/*  79 */         ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1 - 2, paramInt2, j + 4, i, str, insets1, insets2, 0, 0);
/*  80 */         imagePainter.draw();
/*     */       } 
/*  83 */     } else if (region == Region.TABBED_PANE_TAB) {
/*  85 */       JTabbedPane jTabbedPane = (JTabbedPane)jComponent;
/*  88 */       int i = jTabbedPane.getSelectedIndex();
/*  89 */       int j = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.tabbedPane.tabIndex", jTabbedPane, Integer.valueOf(-1))).intValue();
/*  92 */       Color color = (j >= 0) ? jTabbedPane.getForegroundAt(j) : null;
/*  93 */       if (color != null && !(color instanceof javax.swing.plaf.UIResource))
/*  94 */         paramGraphics.setColor(color); 
/*  96 */       if (i != j && SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.selected.bold", jTabbedPane)) {
/*  98 */         int k = paramGraphics.getFontMetrics().stringWidth(paramString);
/* 100 */         paramGraphics.setFont(paramGraphics.getFont().deriveFont(0));
/* 101 */         int m = paramGraphics.getFontMetrics().stringWidth(paramString);
/* 102 */         paramInt1 += (k - m) / 2;
/*     */       } 
/* 105 */       Object object = SyntheticaLookAndFeel.get("Synthetica.TabbedPanePainter", jComponent);
/* 106 */       if (object instanceof TabbedPanePainter) {
/* 108 */         TabbedPanePainter tabbedPanePainter = (TabbedPanePainter)object;
/* 109 */         if (!tabbedPanePainter.paintTabbedPaneTabText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3))
/*     */           return; 
/*     */       } 
/* 113 */     } else if (region == Region.PROGRESS_BAR) {
/* 115 */       String str = (String)SyntheticaLookAndFeel.get("Synthetica.progressBar.textBackground", jComponent);
/* 116 */       if (str != null && str.length() > 0 && paramString != null && paramString.trim().length() > 0) {
/* 118 */         Insets insets1 = (Insets)SyntheticaLookAndFeel.get("Synthetica.progressBar.textBackground.insets", jComponent);
/* 119 */         Insets insets2 = insets1;
/* 120 */         FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/* 121 */         int i = fontMetrics.getHeight();
/* 122 */         int j = fontMetrics.stringWidth(paramString);
/* 123 */         ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1 - 2, paramInt2, j + 4, i, str, insets1, insets2, 0, 0);
/* 124 */         imagePainter.draw();
/*     */       } 
/* 126 */       Color color = SyntheticaLookAndFeel.getColor("Synthetica.progressBar.textFillColor", jComponent);
/* 127 */       if (color != null) {
/* 129 */         paintProgressFillText(paramSynthContext, paramGraphics, paramString, color, paramInt1, paramInt2, paramInt3);
/*     */         return;
/*     */       } 
/* 133 */     } else if (region == Region.INTERNAL_FRAME_TITLE_PANE) {
/* 138 */       if (!JavaVersion.JAVA5 && paramInt3 == -1)
/*     */         return; 
/* 141 */     } else if ((region == Region.MENU || region == Region.MENU_ITEM || region == Region.CHECK_BOX_MENU_ITEM || region == Region.RADIO_BUTTON_MENU_ITEM) && !getPaintMenuMnemonics()) {
/* 142 */       paramInt3 = -1;
/* 144 */     } else if (region == Region.MENU_ITEM_ACCELERATOR && UIManager.get("MenuItem.acceleratorDelimiter") != null) {
/* 145 */       paramString = paramString.replace("+", UIManager.getString("MenuItem.acceleratorDelimiter"));
/*     */     } 
/* 172 */     if (SyntheticaLookAndFeel.getAntiAliasEnabled() || SyntheticaLookAndFeel.getBoolean("Synthetica.text.antialias", jComponent)) {
/* 174 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 175 */       Object object = graphics2D.getRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING);
/* 176 */       if (JavaVersion.JAVA5) {
/* 177 */         graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */       } else {
/* 179 */         graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
/*     */       } 
/* 180 */       super.paintText(paramSynthContext, graphics2D, paramString, paramInt1, paramInt2, paramInt3);
/* 181 */       graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, object);
/*     */     } else {
/* 184 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintText(SynthContext paramSynthContext, Graphics paramGraphics, String paramString, Icon paramIcon, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
/* 191 */     if (SyntheticaLookAndFeel.getAntiAliasEnabled() || SyntheticaLookAndFeel.getBoolean("Synthetica.text.antialias", paramSynthContext.getComponent())) {
/* 193 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 194 */       Object object = graphics2D.getRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING);
/* 195 */       if (JavaVersion.JAVA5) {
/* 196 */         graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */       } else {
/* 198 */         graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
/*     */       } 
/* 199 */       super.paintText(paramSynthContext, graphics2D, paramString, paramIcon, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
/* 200 */       graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, object);
/*     */     } else {
/* 203 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramIcon, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintProgressFillText(SynthContext paramSynthContext, Graphics paramGraphics, String paramString, Color paramColor, int paramInt1, int paramInt2, int paramInt3) {
/* 208 */     JProgressBar jProgressBar = (JProgressBar)paramSynthContext.getComponent();
/* 209 */     int i = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.progressBar.textFillStart", jProgressBar, Integer.valueOf(0))).intValue();
/* 210 */     int j = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.progressBar.textFillAmount", jProgressBar, Integer.valueOf(0))).intValue();
/* 211 */     Rectangle rectangle = paramGraphics.getClipBounds();
/* 213 */     FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/* 214 */     int k = fontMetrics.getHeight();
/* 215 */     int m = fontMetrics.stringWidth(paramString);
/* 216 */     if (jProgressBar.getOrientation() == 0) {
/* 218 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3);
/* 219 */       paramGraphics.setColor(paramColor);
/* 220 */       paramGraphics.clipRect(i, paramInt2, j, k);
/* 221 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 229 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3);
/* 230 */       paramGraphics.setColor(paramColor);
/* 231 */       paramGraphics.clipRect(paramInt1, i, m, j);
/* 232 */       super.paintText(paramSynthContext, paramGraphics, paramString, paramInt1, paramInt2, paramInt3);
/*     */     } 
/* 234 */     paramGraphics.setClip(rectangle);
/*     */   }
/*     */   
/*     */   protected boolean getPaintMnemonics() {
/* 242 */     return getPaintMenuMnemonics();
/*     */   }
/*     */   
/*     */   protected boolean getPaintMenuMnemonics() {
/* 247 */     if (ExtKeyEventProcessor.showMnemonicsOnAltKeyOnly())
/* 248 */       return ExtKeyEventProcessor.isMenuActive(); 
/* 249 */     return true;
/*     */   }
/*     */   
/*     */   protected boolean getPaintButtonMnemonics() {
/* 254 */     if (ExtKeyEventProcessor.showMnemonicsOnAltKeyOnly())
/* 255 */       return ExtKeyEventProcessor.isAltKeyPressed(); 
/* 256 */     return true;
/*     */   }
/*     */   
/*     */   public void drawLine(SynthContext paramSynthContext, Object paramObject, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 266 */     JComponent jComponent = paramSynthContext.getComponent();
/* 267 */     if (paramObject instanceof String && ((String)paramObject).startsWith("Tree.")) {
/* 269 */       Color color = null;
/* 270 */       if (paramObject.equals("Tree.horizontalLine")) {
/* 271 */         color = SyntheticaLookAndFeel.getColor("Synthetica.tree.line.color.horizontal", jComponent);
/* 272 */       } else if (paramObject.equals("Tree.verticalLine")) {
/* 273 */         color = SyntheticaLookAndFeel.getColor("Synthetica.tree.line.color.vertical", jComponent);
/*     */       } 
/* 274 */       if (color != null)
/* 275 */         paramGraphics.setColor(color); 
/* 278 */       String str = SyntheticaLookAndFeel.getString("Synthetica.tree.line.type", jComponent);
/* 279 */       if ("SOLID".equals(str)) {
/* 280 */         paramGraphics.drawLine(paramInt1, paramInt2, paramInt3, paramInt4);
/* 281 */       } else if ("DASHED".equals(str)) {
/* 283 */         int i = SyntheticaLookAndFeel.getInt("Synthetica.tree.line.dashed.line", jComponent);
/* 284 */         if (i <= 0)
/* 284 */           i = 2; 
/* 285 */         int j = SyntheticaLookAndFeel.getInt("Synthetica.tree.line.dashed.space", jComponent);
/* 286 */         if (j <= 0)
/* 286 */           j = 1; 
/* 287 */         if (paramObject.equals("Tree.horizontalLine")) {
/* 289 */           for (int k = paramInt1; k < paramInt3; k += i + j)
/* 290 */             paramGraphics.drawLine(k, paramInt2, Math.min(k + i - 1, paramInt3), paramInt4); 
/*     */         } else {
/* 294 */           for (int k = paramInt2; k < paramInt4; k += i + j)
/* 295 */             paramGraphics.drawLine(paramInt1, k, paramInt1, Math.min(k + i - 1, paramInt4)); 
/*     */         } 
/*     */       } 
/*     */       return;
/*     */     } 
/* 301 */     if (paramInt1 == paramInt3 && paramObject instanceof String && ((String)paramObject).equals("Table.grid") && 
/* 302 */       SyntheticaLookAndFeel.getInt("Synthetica.table.columnMargin", paramSynthContext.getComponent(), 1) == 0)
/*     */       return; 
/* 307 */     if (paramInt2 == paramInt4 && paramObject instanceof String && ((String)paramObject).equals("Table.grid") && 
/* 308 */       SyntheticaLookAndFeel.getInt("Synthetica.table.rowMargin", paramSynthContext.getComponent(), 1) == 0)
/*     */       return; 
/* 312 */     super.drawLine(paramSynthContext, paramObject, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public String layoutText(SynthContext paramSynthContext, FontMetrics paramFontMetrics, String paramString, Icon paramIcon, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Rectangle paramRectangle1, Rectangle paramRectangle2, Rectangle paramRectangle3, int paramInt5) {
/* 320 */     JComponent jComponent = paramSynthContext.getComponent();
/* 321 */     if (jComponent instanceof JTabbedPane) {
/* 324 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.text.position.leading", jComponent)) {
/* 325 */         paramInt3 = 10;
/*     */       } else {
/* 327 */         paramInt3 = 11;
/*     */       } 
/* 329 */       SynthStyleFactory synthStyleFactory = SynthLookAndFeel.getStyleFactory();
/* 330 */       if (synthStyleFactory != null) {
/* 332 */         SynthStyle synthStyle = synthStyleFactory.getStyle(paramSynthContext.getComponent(), Region.TABBED_PANE);
/* 333 */         if (synthStyle.get(paramSynthContext, "TabbedPane.textIconGap") == null)
/* 334 */           paramInt5 = 4; 
/*     */       } 
/*     */     } 
/* 338 */     String str = super.layoutText(paramSynthContext, paramFontMetrics, paramString, paramIcon, paramInt1, paramInt2, paramInt3, paramInt4, paramRectangle1, paramRectangle2, paramRectangle3, paramInt5);
/* 340 */     if (jComponent instanceof JTabbedPane && ((JTabbedPane)jComponent).getTabCount() > 0)
/* 341 */       tabbedPaneTabCorrection(paramSynthContext, (JTabbedPane)jComponent, paramFontMetrics, paramString, paramIcon, paramRectangle1, paramRectangle3, paramRectangle2); 
/* 343 */     return str;
/*     */   }
/*     */   
/*     */   private void tabbedPaneTabCorrection(SynthContext paramSynthContext, JTabbedPane paramJTabbedPane, FontMetrics paramFontMetrics, String paramString, Icon paramIcon, Rectangle paramRectangle1, Rectangle paramRectangle2, Rectangle paramRectangle3) {
/* 348 */     int i = paramJTabbedPane.getSelectedIndex();
/* 349 */     int j = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.tabbedPane.tabIndex", paramJTabbedPane, Integer.valueOf(-1))).intValue();
/* 351 */     boolean bool = (i == j) ? true : false;
/* 352 */     int k = paramJTabbedPane.getTabPlacement();
/* 355 */     if (j >= 0 && paramJTabbedPane.getIconAt(j) != null) {
/* 358 */       int m = paramFontMetrics.getHeight();
/* 359 */       int n = Math.max(m, paramJTabbedPane.getIconAt(j).getIconHeight());
/* 360 */       paramRectangle2.y += (m - n) / 2;
/*     */     } 
/* 365 */     String str1 = "tabbedPane.tab";
/* 366 */     if (bool)
/* 367 */       str1 = String.valueOf(str1) + ".selected"; 
/* 369 */     if (k == 1) {
/* 370 */       str1 = String.valueOf(str1) + ".top";
/* 371 */     } else if (k == 2) {
/* 372 */       str1 = String.valueOf(str1) + ".left";
/* 373 */     } else if (k == 3) {
/* 374 */       str1 = String.valueOf(str1) + ".bottom";
/* 375 */     } else if (k == 4) {
/* 376 */       str1 = String.valueOf(str1) + ".right";
/*     */     } 
/* 378 */     String str2 = SyntheticaLookAndFeel.getStyleName(paramJTabbedPane);
/* 379 */     Insets insets = SyntheticaLookAndFeel.getInsets(str1, "text.insets", str2, true);
/* 380 */     if (insets != null) {
/* 382 */       paramRectangle2.x += insets.left;
/* 383 */       switch (paramJTabbedPane.getTabPlacement()) {
/*     */         case 1:
/* 386 */           paramRectangle2.y += insets.top;
/*     */           break;
/*     */         case 3:
/* 389 */           paramRectangle2.y -= insets.bottom;
/*     */           break;
/*     */       } 
/*     */     } 
/* 394 */     if (paramIcon != null) {
/* 396 */       insets = SyntheticaLookAndFeel.getInsets(str1, "icon.insets", str2, true);
/* 397 */       if (insets == null)
/* 398 */         insets = new Insets(0, 0, 0, 0); 
/* 399 */       paramRectangle3.x += insets.left;
/* 400 */       if (paramJTabbedPane.getTabPlacement() == 1) {
/* 401 */         paramRectangle3.y += insets.top;
/* 402 */       } else if (paramJTabbedPane.getTabPlacement() == 3) {
/* 403 */         paramRectangle3.y -= insets.bottom;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Image iconToImage(SynthContext paramSynthContext, Icon paramIcon) {
/* 416 */     BufferedImage bufferedImage = new BufferedImage(paramIcon.getIconWidth(), paramIcon.getIconHeight(), 2);
/* 417 */     Graphics graphics = bufferedImage.getGraphics();
/* 418 */     JComponent jComponent = (paramSynthContext == null) ? null : paramSynthContext.getComponent();
/* 419 */     paramIcon.paintIcon(jComponent, graphics, 0, 0);
/* 420 */     graphics.dispose();
/* 421 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public void paintListCellRendererSelectionBackground(JList paramJList, Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 426 */     boolean bool = cellRendererRespectsFocus(paramComponent) ? paramJList.hasFocus() : true;
/* 427 */     String str = SyntheticaLookAndFeel.getString(bool ? "Synthetica.list.selectionBackground" : "Synthetica.list.selectionBackground.inactive", paramComponent);
/* 428 */     if (str != null) {
/* 430 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.list.selectionBackground.insets", paramComponent, false);
/* 431 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 432 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintTreeCellRendererSelectionBackground(JTree paramJTree, Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 438 */     boolean bool = true;
/* 439 */     if (cellRendererRespectsFocus(paramComponent))
/* 442 */       if (paramJTree.getParent() instanceof javax.swing.CellRendererPane) {
/* 443 */         bool = paramJTree.getParent().getParent().hasFocus();
/*     */       } else {
/* 445 */         bool = paramJTree.hasFocus();
/*     */       }  
/* 447 */     String str = SyntheticaLookAndFeel.getString(bool ? "Synthetica.tree.selectionBackground" : "Synthetica.tree.selectionBackground.inactive", paramComponent);
/* 448 */     if (str != null) {
/* 450 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.tree.selectionBackground.insets", paramComponent, false);
/* 451 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 452 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintTableCellRendererSelectionBackground(JTable paramJTable, Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 458 */     boolean bool = cellRendererRespectsFocus(paramComponent) ? paramJTable.hasFocus() : true;
/* 460 */     if (paramJTable.getCellEditor() != null)
/* 461 */       bool = true; 
/* 462 */     String str = SyntheticaLookAndFeel.getString(bool ? "Synthetica.table.selectionBackground" : "Synthetica.table.selectionBackground.inactive", paramComponent);
/* 463 */     if (str != null) {
/* 465 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.table.selectionBackground.insets", paramComponent, false);
/* 466 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 467 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean cellRendererRespectsFocus(Component paramComponent) {
/* 473 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.respectFocus", paramComponent, false);
/*     */   }
/*     */   
/*     */   protected void paintTextShadow(JComponent paramJComponent, Graphics paramGraphics, int paramInt1, int paramInt2, String paramString, boolean paramBoolean1, int paramInt3, int paramInt4, float paramFloat, Color paramColor, int paramInt5, int paramInt6, boolean paramBoolean2, int paramInt7) {
/* 478 */     if (paramString == null || paramString.length() == 0)
/*     */       return; 
/* 481 */     Font font = paramBoolean2 ? paramGraphics.getFont() : paramJComponent.getFont();
/* 482 */     FontMetrics fontMetrics = paramGraphics.getFontMetrics(font);
/* 483 */     int i = fontMetrics.stringWidth(paramString);
/* 484 */     int j = fontMetrics.getHeight() + paramInt3 * 2;
/* 486 */     BufferedImage bufferedImage = createCompatibleImage(i, j);
/* 487 */     Graphics2D graphics2D = bufferedImage.createGraphics();
/* 488 */     graphics2D.setFont(font);
/* 489 */     graphics2D.drawString(paramString, 0, fontMetrics.getAscent());
/* 490 */     if (getPaintMenuMnemonics() && paramInt7 >= 0 && paramInt7 < paramString.length()) {
/* 492 */       int k = fontMetrics.stringWidth(paramString.substring(0, paramInt7));
/* 493 */       int m = fontMetrics.getHeight() - 1;
/* 494 */       int n = fontMetrics.charWidth(paramString.charAt(paramInt7));
/* 495 */       graphics2D.fillRect(k, m, n, 1);
/*     */     } 
/* 497 */     graphics2D.dispose();
/* 499 */     DropShadow dropShadow = new DropShadow(bufferedImage);
/* 500 */     dropShadow.setQuality(paramBoolean1);
/* 501 */     dropShadow.setShadowSize(paramInt3);
/* 502 */     dropShadow.setDistance(paramInt4);
/* 503 */     dropShadow.setShadowOpacity(paramFloat);
/* 504 */     dropShadow.setShadowColor(paramColor);
/* 505 */     dropShadow.paintShadow(paramGraphics, paramInt1 + paramInt5, paramInt2 + paramInt6);
/*     */   }
/*     */   
/*     */   private BufferedImage createCompatibleImage(int paramInt1, int paramInt2) {
/* 510 */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 511 */     GraphicsConfiguration graphicsConfiguration = graphicsEnvironment.getDefaultScreenDevice().getDefaultConfiguration();
/* 512 */     return graphicsConfiguration.createCompatibleImage(paramInt1, paramInt2, 3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\GraphicsUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */