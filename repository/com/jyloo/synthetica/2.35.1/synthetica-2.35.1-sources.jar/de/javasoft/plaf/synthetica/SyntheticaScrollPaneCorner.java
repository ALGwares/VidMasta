/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.painter.ScrollPanePainter;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ public class SyntheticaScrollPaneCorner extends JComponent {
/*    */   private String cornerID;
/*    */   
/*    */   public SyntheticaScrollPaneCorner(String paramString) {
/* 32 */     this.cornerID = paramString;
/* 33 */     setOpaque(false);
/*    */   }
/*    */   
/*    */   protected void paintComponent(Graphics paramGraphics) {
/* 39 */     JScrollPane jScrollPane = (JScrollPane)getParent();
/* 40 */     ScrollPanePainter.getInstance().paintScrollPaneCorner(jScrollPane, paramGraphics, 0, 0, getWidth(), getHeight(), this.cornerID);
/*    */   }
/*    */   
/*    */   public static class UIResource extends SyntheticaScrollPaneCorner implements javax.swing.plaf.UIResource {
/*    */     public UIResource(String param1String) {
/* 47 */       super(param1String);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class TableUpperTrailingCorner extends SyntheticaScrollPaneCorner {
/*    */     public TableUpperTrailingCorner() {
/* 56 */       super("UPPER_TRAILING_CORNER");
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaScrollPaneCorner.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */