/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollPane;
/*     */ 
/*     */ public class AnimationThreadFactory {
/*     */   public static final int DISABLED_TYPE = -1;
/*     */   
/*     */   public static final int DEFAULT_TYPE = 0;
/*     */   
/*     */   public static final int HOVER_IN_TYPE = 1;
/*     */   
/*     */   public static final int HOVER_OUT_TYPE = 2;
/*     */   
/*     */   public static final int FOCUSED_TYPE = 3;
/*     */   
/*     */   public static final int DISPOSABLE_TYPE = 4;
/*     */   
/*     */   public static final int ACTIVE_TYPE = 5;
/*     */   
/*     */   public static final int INACTIVE_TYPE = 6;
/*     */   
/*  46 */   private static HashMap<Integer, AnimationThread> threads = new HashMap<Integer, AnimationThread>();
/*     */   
/*  47 */   private static AnimationThreadFactory instance = new AnimationThreadFactory();
/*     */   
/*     */   public static AnimationThread createThread(int paramInt) {
/*  66 */     if (threads.containsKey(Integer.valueOf(paramInt)))
/*  67 */       return threads.get(Integer.valueOf(paramInt)); 
/*  69 */     return instance.newThread(paramInt);
/*     */   }
/*     */   
/*     */   private AnimationThread newThread(int paramInt) {
/*  78 */     AnimationThread animationThread = new AnimationThread(paramInt);
/*  79 */     threads.put(Integer.valueOf(paramInt), animationThread);
/*  80 */     animationThread.setDaemon(true);
/*  81 */     animationThread.start();
/*  82 */     return animationThread;
/*     */   }
/*     */   
/*     */   static class AnimationThread extends Thread {
/*  92 */     private int delay = 0;
/*     */     
/*  93 */     private HashMap<ComponentKey, ComponentAnimation> componentAnimations = new HashMap<ComponentKey, ComponentAnimation>();
/*     */     
/*  94 */     private ReferenceQueue<JComponent> queue = new ReferenceQueue<JComponent>();
/*     */     
/*     */     public AnimationThread(int param1Int) {
/* 103 */       this.delay = param1Int;
/* 105 */       setPriority(7);
/* 106 */       setName("SyntheticaAnimation " + param1Int);
/*     */     }
/*     */     
/*     */     public void run() {
/* 115 */       while (!isInterrupted()) {
/*     */         try {
/* 119 */           sleep(this.delay);
/* 120 */           HashMap<ComponentKey, ComponentAnimation> hashMap = null;
/* 122 */           synchronized (this.componentAnimations) {
/* 124 */             Reference<? extends JComponent> reference = this.queue.poll();
/* 125 */             while (reference != null) {
/* 127 */               this.componentAnimations.remove(((WeakComponent)reference).key);
/* 128 */               reference = this.queue.poll();
/*     */             } 
/* 130 */             hashMap = new HashMap<ComponentKey, ComponentAnimation>(this.componentAnimations);
/*     */           } 
/* 134 */           for (Map.Entry<ComponentKey, ComponentAnimation> entry : hashMap.entrySet()) {
/* 136 */             JComponent jComponent = ((ComponentKey)entry.getKey()).wc.get();
/* 137 */             if (jComponent == null)
/*     */               continue; 
/* 139 */             ComponentAnimation componentAnimation = (ComponentAnimation)entry.getValue();
/* 140 */             if (jComponent != null && componentAnimation != null) {
/* 143 */               Component component = null;
/* 144 */               if (jComponent instanceof JScrollPane)
/* 145 */                 component = ((JScrollPane)jComponent).getViewport().getView(); 
/* 147 */               boolean bool = false;
/* 148 */               Rectangle rectangle = null;
/* 149 */               synchronized (componentAnimation) {
/* 151 */                 boolean bool1 = ((componentAnimation.state & 0x2) > 0) ? true : false;
/* 152 */                 boolean bool2 = jComponent.hasFocus();
/* 153 */                 rectangle = componentAnimation.repaintRect;
/* 155 */                 switch (componentAnimation.type) {
/*     */                   case 4:
/*     */                   case 5:
/*     */                   case 6:
/* 160 */                     if (componentAnimation.next())
/* 161 */                       bool = true; 
/*     */                     break;
/*     */                   case 1:
/* 166 */                     if (componentAnimation.state != -1 && bool1 && componentAnimation.next()) {
/* 167 */                       bool = true;
/*     */                       break;
/*     */                     } 
/* 168 */                     if (componentAnimation.state != -1 && !bool1)
/* 169 */                       componentAnimation.reset(); 
/*     */                     break;
/*     */                   case 2:
/* 173 */                     if (componentAnimation.state != -1 && !bool1 && componentAnimation.next()) {
/* 174 */                       bool = true;
/*     */                       break;
/*     */                     } 
/* 175 */                     if (componentAnimation.state != -1 && bool1)
/* 176 */                       componentAnimation.reset(); 
/*     */                     break;
/*     */                   case 3:
/* 180 */                     if (jComponent instanceof JComboBox && ((JComboBox)jComponent).isEditable() && ((JComboBox)jComponent).getEditor() != null) {
/* 183 */                       Component component1 = ((JComboBox)jComponent).getEditor().getEditorComponent();
/* 184 */                       if (component1 != null)
/* 185 */                         bool2 = component1.hasFocus(); 
/* 187 */                     } else if (jComponent instanceof javax.swing.JSpinner) {
/* 189 */                       Component component1 = SyntheticaLookAndFeel.findComponent("Spinner.formattedTextField", jComponent);
/* 190 */                       if (component1 != null)
/* 191 */                         bool2 = component1.hasFocus(); 
/* 193 */                     } else if (jComponent instanceof JScrollPane) {
/* 195 */                       JScrollPane jScrollPane = (JScrollPane)jComponent;
/* 196 */                       if (component != null)
/* 197 */                         bool2 = component.hasFocus(); 
/* 198 */                       int i = SyntheticaLookAndFeel.getInt("Synthetica.focus.scrollPane.animation.maxWidth", jScrollPane, 400);
/* 199 */                       int j = SyntheticaLookAndFeel.getInt("Synthetica.focus.scrollPane.animation.maxHeight", jScrollPane, 200);
/* 200 */                       if (jScrollPane.getWidth() > i || jScrollPane.getHeight() > j)
/*     */                         break; 
/*     */                     } 
/* 203 */                     if (componentAnimation.next() && bool2 && isActive(jComponent)) {
/* 204 */                       bool = true;
/*     */                       break;
/*     */                     } 
/* 205 */                     if (!bool2)
/* 206 */                       componentAnimation.reset(); 
/*     */                     break;
/*     */                   default:
/* 210 */                     if (componentAnimation.next() && isActive(jComponent))
/* 211 */                       bool = true; 
/*     */                     break;
/*     */                 } 
/*     */               } 
/* 214 */               if (bool)
/* 215 */                 repaint(jComponent, rectangle); 
/*     */             } 
/*     */           } 
/* 219 */         } catch (InterruptedException interruptedException) {
/* 221 */           interrupt();
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     private void repaint(JComponent param1JComponent, Rectangle param1Rectangle) {
/* 228 */       if (param1Rectangle == null) {
/* 229 */         param1JComponent.repaint();
/*     */       } else {
/* 231 */         param1JComponent.repaint(0L, param1Rectangle.x, param1Rectangle.y, param1Rectangle.width, param1Rectangle.height);
/*     */       } 
/*     */     }
/*     */     
/*     */     private boolean isActive(JComponent param1JComponent) {
/* 243 */       Container container = param1JComponent.getTopLevelAncestor();
/* 244 */       if (container instanceof Window && !"###focusableSwingPopup###".equals(container.getName()))
/* 245 */         return ((Window)container).isActive(); 
/* 246 */       return true;
/*     */     }
/*     */     
/*     */     public void addComponent(JComponent param1JComponent, String param1String, int param1Int1, int param1Int2, String[] param1ArrayOfString, int param1Int3, Rectangle param1Rectangle) {
/* 263 */       boolean bool = ((param1Int1 & 0x2) > 0) ? true : false;
/* 264 */       ComponentKey componentKey = new ComponentKey(param1JComponent, param1String);
/* 266 */       if (this.componentAnimations.containsKey(componentKey)) {
/* 268 */         ComponentAnimation componentAnimation1 = this.componentAnimations.get(componentKey);
/* 269 */         synchronized (componentAnimation1) {
/* 271 */           componentAnimation1.repaintRect = param1Rectangle;
/* 272 */           if (componentAnimation1.type != param1Int2 || !Arrays.toString((Object[])param1ArrayOfString).equals(Arrays.toString((Object[])componentAnimation1.imagePaths))) {
/* 274 */             componentAnimation1.reset();
/* 275 */             componentAnimation1.type = param1Int2;
/* 276 */             componentAnimation1.imagePaths = param1ArrayOfString;
/* 277 */             componentAnimation1.cyles = param1Int3;
/*     */           } 
/* 280 */           if (componentAnimation1.state != -1 || bool)
/* 281 */             componentAnimation1.state = param1Int1; 
/*     */         } 
/*     */         return;
/*     */       } 
/* 286 */       componentKey.setComponent(param1JComponent);
/* 287 */       ComponentAnimation componentAnimation = new ComponentAnimation(null);
/* 288 */       componentAnimation.imagePaths = param1ArrayOfString;
/* 289 */       componentAnimation.cyles = param1Int3;
/* 290 */       componentAnimation.repaintRect = param1Rectangle;
/* 291 */       componentAnimation.type = param1Int2;
/* 293 */       if (bool) {
/* 294 */         componentAnimation.state = param1Int1;
/* 296 */       } else if (param1Int2 == 6) {
/* 297 */         componentAnimation.cylesDone = param1Int3;
/*     */       } 
/* 298 */       synchronized (this.componentAnimations) {
/* 300 */         this.componentAnimations.put(componentKey, componentAnimation);
/*     */       } 
/*     */     }
/*     */     
/*     */     void rotateRepaintRect(JComponent param1JComponent, String param1String) {
/* 314 */       ComponentKey componentKey = new ComponentKey(param1JComponent, param1String);
/* 315 */       ComponentAnimation componentAnimation = this.componentAnimations.get(componentKey);
/* 316 */       if (componentAnimation != null) {
/* 318 */         int i = componentAnimation.repaintRect.height;
/* 319 */         componentAnimation.repaintRect.height = componentAnimation.repaintRect.width;
/* 320 */         componentAnimation.repaintRect.width = i;
/*     */       } 
/*     */     }
/*     */     
/*     */     public String getImagePath(JComponent param1JComponent, String param1String) {
/* 334 */       ComponentAnimation componentAnimation = this.componentAnimations.get(new ComponentKey(param1JComponent, param1String));
/* 335 */       String str = null;
/* 336 */       synchronized (componentAnimation) {
/* 339 */         if (componentAnimation.type == 2 && (componentAnimation.state == -1 || componentAnimation.isComplete())) {
/* 340 */           str = componentAnimation.imagePaths[componentAnimation.imagePaths.length - 1];
/* 342 */         } else if (componentAnimation.type == 6 && componentAnimation.isComplete()) {
/* 343 */           str = componentAnimation.imagePaths[componentAnimation.imagePaths.length - 1];
/*     */         } else {
/* 345 */           str = componentAnimation.imagePaths[componentAnimation.index];
/*     */         } 
/*     */       } 
/* 347 */       return str;
/*     */     }
/*     */     
/*     */     private class ComponentKey {
/*     */       private int hashCode;
/*     */       
/*     */       private AnimationThreadFactory.AnimationThread.WeakComponent wc;
/*     */       
/*     */       ComponentKey(JComponent param2JComponent, String param2String) {
/* 372 */         this.hashCode = param2JComponent.hashCode() * 31 + param2String.hashCode();
/*     */       }
/*     */       
/*     */       void setComponent(JComponent param2JComponent) {
/* 381 */         this.wc = new AnimationThreadFactory.AnimationThread.WeakComponent(param2JComponent, this);
/*     */       }
/*     */       
/*     */       public boolean equals(Object param2Object) {
/* 387 */         ComponentKey componentKey = (ComponentKey)param2Object;
/* 388 */         return (componentKey.hashCode == this.hashCode);
/*     */       }
/*     */       
/*     */       public int hashCode() {
/* 394 */         return this.hashCode;
/*     */       }
/*     */     }
/*     */     
/*     */     private class WeakComponent extends WeakReference<JComponent> {
/*     */       private AnimationThreadFactory.AnimationThread.ComponentKey key;
/*     */       
/*     */       public WeakComponent(JComponent param2JComponent, AnimationThreadFactory.AnimationThread.ComponentKey param2ComponentKey) {
/* 409 */         super(param2JComponent, AnimationThreadFactory.AnimationThread.this.queue);
/* 410 */         this.key = param2ComponentKey;
/*     */       }
/*     */     }
/*     */     
/*     */     private static class ComponentAnimation {
/* 421 */       private int state = -1;
/*     */       
/* 422 */       private int type = 0;
/*     */       
/* 423 */       private int index = 0;
/*     */       
/*     */       private String[] imagePaths;
/*     */       
/*     */       private Rectangle repaintRect;
/*     */       
/* 426 */       private long cyles = 0L;
/*     */       
/* 427 */       private long cylesDone = 0L;
/*     */       
/*     */       boolean next() {
/* 435 */         if (this.cyles == 0L || this.cylesDone == this.cyles || this.imagePaths.length == 1)
/* 436 */           return false; 
/* 437 */         this.index++;
/* 438 */         if (this.index == this.imagePaths.length - 1) {
/* 439 */           this.cylesDone++;
/* 440 */         } else if (this.index == this.imagePaths.length) {
/* 441 */           this.index = 0;
/*     */         } 
/* 442 */         return true;
/*     */       }
/*     */       
/*     */       void reset() {
/* 450 */         this.index = 0;
/* 451 */         this.cylesDone = 0L;
/*     */       }
/*     */       
/*     */       boolean isComplete() {
/* 459 */         return (this.cyles == this.cylesDone);
/*     */       }
/*     */       
/*     */       private ComponentAnimation() {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\AnimationThreadFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */