package de.javasoft.io;

public class FileProperties {
  public String location;
  
  public long files;
  
  public long directories;
  
  public long size;
  
  public long lastModified;
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\io\FileProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */