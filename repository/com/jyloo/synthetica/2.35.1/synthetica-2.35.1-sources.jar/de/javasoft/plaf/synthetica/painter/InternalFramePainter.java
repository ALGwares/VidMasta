/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.java2d.DropShadow;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class InternalFramePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.InternalFramePainter";
/*     */   
/*  54 */   private static WeakHashMap<JComponent, Object> opaqued = new WeakHashMap<JComponent, Object>();
/*     */   
/*     */   public static InternalFramePainter getInstance() {
/*  68 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static InternalFramePainter getInstance(SynthContext paramSynthContext) {
/*  77 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, InternalFramePainter.class, "Synthetica.InternalFramePainter"));
/*  78 */     if (syntheticaComponentPainter == null)
/*  79 */       syntheticaComponentPainter = getInstance(paramSynthContext, InternalFramePainter.class, "Synthetica.InternalFramePainter"); 
/*  80 */     return (InternalFramePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintInternalFrameTitlePaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  88 */     BasicInternalFrameTitlePane basicInternalFrameTitlePane = (BasicInternalFrameTitlePane)paramSynthContext.getComponent();
/*  89 */     boolean bool1 = ((paramSynthContext.getComponentState() & 0x200) > 0) ? true : false;
/*  91 */     setIcons(basicInternalFrameTitlePane, paramSynthContext);
/*  95 */     if (!opaqued.containsKey(basicInternalFrameTitlePane)) {
/*  97 */       opaqued.put(basicInternalFrameTitlePane, null);
/*  98 */       Component[] arrayOfComponent = basicInternalFrameTitlePane.getComponents();
/*  99 */       for (byte b = 0; b < arrayOfComponent.length; b++) {
/* 101 */         Component component = arrayOfComponent[b];
/* 102 */         if (component instanceof JButton) {
/* 104 */           JButton jButton = (JButton)component;
/* 108 */           jButton.setOpaque(false);
/*     */         } 
/*     */       } 
/*     */     } 
/* 113 */     String str = "Synthetica.internalFrameTitlePane.background";
/* 114 */     if (bool1)
/* 115 */       str = String.valueOf(str) + ".selected"; 
/* 116 */     str = SyntheticaLookAndFeel.getString(str, basicInternalFrameTitlePane);
/* 117 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.internalFrameTitlePane.background.insets", basicInternalFrameTitlePane);
/* 118 */     Insets insets2 = insets1;
/* 119 */     boolean bool2 = false;
/* 120 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.background.horizontalTiled", basicInternalFrameTitlePane))
/* 121 */       bool2 = true; 
/* 122 */     boolean bool3 = false;
/* 123 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.background.verticalTiled", basicInternalFrameTitlePane))
/* 124 */       bool3 = true; 
/* 125 */     if (str != null) {
/* 127 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, bool2, bool3);
/* 128 */       imagePainter.draw();
/*     */     } 
/* 131 */     str = "Synthetica.internalFrameTitlePane.background.light";
/* 132 */     if (bool1)
/* 133 */       str = String.valueOf(str) + ".selected"; 
/* 134 */     str = SyntheticaLookAndFeel.getString(str, basicInternalFrameTitlePane);
/* 135 */     if (str != null) {
/* 137 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, bool3);
/* 138 */       imagePainter.draw();
/*     */     } 
/* 141 */     paintTitle(paramSynthContext, paramGraphics, paramInt3);
/*     */   }
/*     */   
/*     */   protected void paintTitle(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt) {
/* 146 */     BasicInternalFrameTitlePane basicInternalFrameTitlePane = (BasicInternalFrameTitlePane)paramSynthContext.getComponent();
/* 147 */     boolean bool = ((paramSynthContext.getComponentState() & 0x200) > 0) ? true : false;
/* 149 */     String str = getTitle(basicInternalFrameTitlePane.getParent());
/* 150 */     FontMetrics fontMetrics = basicInternalFrameTitlePane.getFontMetrics(basicInternalFrameTitlePane.getFont());
/* 151 */     int i = fontMetrics.getHeight();
/* 152 */     int j = fontMetrics.stringWidth(str);
/* 153 */     int k = ((basicInternalFrameTitlePane.getSize()).height - i) / 2;
/* 155 */     byte b = 4;
/* 156 */     boolean bool1 = isRTL(basicInternalFrameTitlePane);
/* 157 */     Rectangle rectangle1 = getMenuButtonBounds(basicInternalFrameTitlePane);
/* 158 */     Rectangle rectangle2 = getControlButtonsBounds(basicInternalFrameTitlePane);
/* 159 */     int m = bool1 ? (rectangle2.x + rectangle2.width + b) : (rectangle1.x + rectangle1.width + b);
/* 160 */     int n = bool1 ? (rectangle1.x - b - j) : (rectangle2.x - b - j);
/* 161 */     n = Math.max(m, n);
/* 163 */     int i1 = bool1 ? n : m;
/* 164 */     i1 = SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.title.center", basicInternalFrameTitlePane) ? (paramInt / 2 - fontMetrics.stringWidth(str) / 2) : i1;
/* 165 */     i1 = bool1 ? Math.min(i1, n) : Math.max(i1, m);
/* 166 */     i1 = bool1 ? Math.max(i1, m) : Math.min(i1, n);
/* 169 */     Rectangle rectangle3 = basicInternalFrameTitlePane.getBounds();
/* 170 */     rectangle3.width -= rectangle1.width + rectangle2.width + b * 4;
/* 171 */     str = paramSynthContext.getStyle().getGraphicsUtils(paramSynthContext).layoutText(paramSynthContext, paramGraphics.getFontMetrics(), str, null, 0, 0, 0, 0, rectangle3, new Rectangle(0, 0), new Rectangle(0, 0), 0);
/* 173 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.dropShadow", basicInternalFrameTitlePane) && bool && j > 0 && i > 0) {
/* 175 */       BufferedImage bufferedImage = new BufferedImage(j, i, 2);
/* 176 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/* 177 */       graphics2D.setFont(paramGraphics.getFont());
/* 178 */       graphics2D.drawString(str, 0, fontMetrics.getAscent());
/* 179 */       graphics2D.dispose();
/* 180 */       DropShadow dropShadow = new DropShadow(bufferedImage);
/* 181 */       dropShadow.setDistance(SyntheticaLookAndFeel.getInt("Synthetica.internalFrame.titlePane.dropShadow.distance", basicInternalFrameTitlePane, -5));
/* 182 */       if (SyntheticaLookAndFeel.getColor("Synthetica.internalFrame.titlePane.dropShadow.color", basicInternalFrameTitlePane) != null)
/* 183 */         dropShadow.setShadowColor(SyntheticaLookAndFeel.getColor("Synthetica.internalFrame.titlePane.dropShadow.color", basicInternalFrameTitlePane)); 
/* 184 */       if (SyntheticaLookAndFeel.get("Synthetica.internalFrame.titlePane.dropShadow.highQuality", basicInternalFrameTitlePane) != null)
/* 185 */         dropShadow.setQuality(SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.dropShadow.highQuality", basicInternalFrameTitlePane)); 
/* 186 */       dropShadow.paintShadow(paramGraphics, i1, k);
/*     */     } 
/* 189 */     Color color1 = basicInternalFrameTitlePane.getForeground();
/* 190 */     Color color2 = (color1 == null || color1 instanceof javax.swing.plaf.ColorUIResource) ? paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.FOREGROUND) : color1;
/* 191 */     SynthStyle synthStyle = paramSynthContext.getStyle();
/* 194 */     if (basicInternalFrameTitlePane.getParent() instanceof JInternalFrame) {
/* 196 */       JInternalFrame jInternalFrame = (JInternalFrame)basicInternalFrameTitlePane.getParent();
/* 197 */       synthStyle = SynthLookAndFeel.getStyle(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE);
/* 198 */       paramSynthContext = new SynthContext(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, synthStyle, paramSynthContext.getComponentState());
/*     */     } 
/* 201 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.title.etchedTop", basicInternalFrameTitlePane)) {
/* 203 */       paramGraphics.setColor(Color.BLACK);
/* 204 */       synthStyle.getGraphicsUtils(paramSynthContext).paintText(paramSynthContext, paramGraphics, str, i1, k - 1, -2);
/*     */     } 
/* 206 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.title.etchedBottom", basicInternalFrameTitlePane)) {
/* 208 */       paramGraphics.setColor(Color.WHITE);
/* 209 */       synthStyle.getGraphicsUtils(paramSynthContext).paintText(paramSynthContext, paramGraphics, str, i1, k + 1, -2);
/*     */     } 
/* 212 */     paramGraphics.setColor(color2);
/* 214 */     synthStyle.getGraphicsUtils(paramSynthContext).paintText(paramSynthContext, paramGraphics, str, i1, k, -2);
/*     */   }
/*     */   
/*     */   private String getTitle(Container paramContainer) {
/* 219 */     String str = null;
/* 220 */     if (paramContainer instanceof JInternalFrame) {
/* 221 */       str = ((JInternalFrame)paramContainer).getTitle();
/* 222 */     } else if (paramContainer instanceof JInternalFrame.JDesktopIcon) {
/* 223 */       str = ((JInternalFrame.JDesktopIcon)paramContainer).getInternalFrame().getTitle();
/*     */     } 
/* 224 */     str = (str == null) ? "" : str;
/* 225 */     return str;
/*     */   }
/*     */   
/*     */   public void paintInternalFrameTitlePaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintInternalFrameBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintInternalFrameBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 245 */     JInternalFrame jInternalFrame = (JInternalFrame)paramSynthContext.getComponent();
/* 246 */     String str = "Synthetica.internalFrame.border";
/* 248 */     if (jInternalFrame.isSelected())
/* 249 */       str = String.valueOf(str) + ".selected"; 
/* 250 */     str = SyntheticaLookAndFeel.getString(str, jInternalFrame);
/* 252 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.internalFrame.border.insets", jInternalFrame);
/* 253 */     Insets insets2 = insets1;
/* 254 */     ImagePainter imagePainter = new ImagePainter(jInternalFrame, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 255 */     imagePainter.drawBorder();
/*     */   }
/*     */   
/*     */   private void setIcons(BasicInternalFrameTitlePane paramBasicInternalFrameTitlePane, SynthContext paramSynthContext) {
/* 267 */     String str1 = (String)paramBasicInternalFrameTitlePane.getClientProperty("Synthetica.MOUSE_OVER");
/* 268 */     boolean bool1 = (str1 != null) ? true : false;
/* 269 */     String str2 = (String)paramBasicInternalFrameTitlePane.getClientProperty("Synthetica.MOUSE_PRESSED");
/* 270 */     boolean bool2 = (str2 != null) ? true : false;
/* 271 */     SynthStyle synthStyle = paramSynthContext.getStyle();
/* 272 */     SynthContext synthContext1 = new SynthContext(paramBasicInternalFrameTitlePane, paramSynthContext.getRegion(), synthStyle, 2);
/* 273 */     SynthContext synthContext2 = new SynthContext(paramBasicInternalFrameTitlePane, paramSynthContext.getRegion(), synthStyle, 4);
/* 274 */     Container container = paramBasicInternalFrameTitlePane.getParent();
/* 276 */     String str3 = "InternalFrameTitlePane.iconifyIcon";
/* 277 */     Icon icon1 = synthStyle.getIcon(paramSynthContext, str3);
/* 278 */     if (bool2 && str2.endsWith("iconifyButton")) {
/* 279 */       icon1 = (synthStyle.getIcon(synthContext2, str3) == icon1) ? synthStyle.getIcon(synthContext1, str3) : synthStyle.getIcon(synthContext2, str3);
/* 280 */     } else if (bool1 && str1.endsWith("iconifyButton")) {
/* 281 */       icon1 = synthStyle.getIcon(synthContext1, str3);
/*     */     } 
/* 283 */     str3 = "InternalFrameTitlePane.maximizeIcon";
/* 284 */     Icon icon2 = synthStyle.getIcon(paramSynthContext, str3);
/* 285 */     if (bool2 && str2.endsWith("maximizeButton")) {
/* 286 */       icon2 = (synthStyle.getIcon(synthContext2, str3) == icon2) ? synthStyle.getIcon(synthContext1, str3) : synthStyle.getIcon(synthContext2, str3);
/* 287 */     } else if (bool1 && str1.endsWith("maximizeButton")) {
/* 288 */       icon2 = synthStyle.getIcon(synthContext1, str3);
/*     */     } 
/* 290 */     str3 = "InternalFrameTitlePane.closeIcon";
/* 291 */     Icon icon3 = synthStyle.getIcon(paramSynthContext, str3);
/* 292 */     if (bool2 && str2.endsWith("closeButton")) {
/* 293 */       icon3 = (synthStyle.getIcon(synthContext2, str3) == icon3) ? synthStyle.getIcon(synthContext1, str3) : synthStyle.getIcon(synthContext2, str3);
/* 294 */     } else if (bool1 && str1.endsWith("closeButton")) {
/* 295 */       icon3 = synthStyle.getIcon(synthContext1, str3);
/*     */     } 
/* 297 */     str3 = "InternalFrameTitlePane.minimizeIcon";
/* 298 */     Icon icon4 = synthStyle.getIcon(paramSynthContext, str3);
/* 299 */     if (bool2 && ((
/* 300 */       str2.endsWith("maximizeButton") && container instanceof JInternalFrame) || (
/* 301 */       str2.endsWith("iconifyButton") && container instanceof JInternalFrame.JDesktopIcon))) {
/* 302 */       icon4 = (synthStyle.getIcon(synthContext2, str3) == icon4) ? synthStyle.getIcon(synthContext1, str3) : synthStyle.getIcon(synthContext2, str3);
/* 303 */     } else if (bool1 && ((
/* 304 */       str1.endsWith("maximizeButton") && container instanceof JInternalFrame) || (
/* 305 */       str1.endsWith("iconifyButton") && container instanceof JInternalFrame.JDesktopIcon))) {
/* 306 */       icon4 = synthStyle.getIcon(synthContext1, str3);
/*     */     } 
/* 308 */     JButton jButton1 = null;
/* 309 */     JButton jButton2 = null;
/* 310 */     JButton jButton3 = null;
/* 311 */     Component[] arrayOfComponent = paramBasicInternalFrameTitlePane.getComponents();
/* 312 */     for (byte b = 0; b < arrayOfComponent.length; b++) {
/* 314 */       Component component = arrayOfComponent[b];
/* 315 */       if (component instanceof JButton) {
/* 317 */         String str = component.getName();
/* 318 */         if (str.endsWith("closeButton"))
/* 319 */           jButton3 = (JButton)component; 
/* 320 */         if (str.endsWith("iconifyButton"))
/* 321 */           jButton1 = (JButton)component; 
/* 322 */         if (str.endsWith("maximizeButton"))
/* 323 */           jButton2 = (JButton)component; 
/*     */       } 
/*     */     } 
/* 327 */     if (container instanceof JInternalFrame) {
/* 329 */       JInternalFrame jInternalFrame = (JInternalFrame)container;
/* 330 */       if (jInternalFrame.isMaximum()) {
/* 332 */         if (jButton1 != null)
/* 333 */           jButton1.setIcon(icon1); 
/* 334 */         if (jButton2 != null)
/* 335 */           jButton2.setIcon(icon4); 
/* 337 */       } else if (jInternalFrame.isIcon()) {
/* 339 */         if (jButton1 != null)
/* 340 */           jButton1.setIcon(icon4); 
/* 341 */         if (jButton2 != null)
/* 342 */           jButton2.setIcon(icon2); 
/*     */       } else {
/* 346 */         if (jButton1 != null)
/* 347 */           jButton1.setIcon(icon1); 
/* 348 */         if (jButton2 != null)
/* 349 */           jButton2.setIcon(icon2); 
/*     */       } 
/* 352 */     } else if (container instanceof JInternalFrame.JDesktopIcon) {
/* 354 */       if (jButton1 != null)
/* 355 */         jButton1.setIcon(icon4); 
/* 356 */       if (jButton2 != null)
/* 357 */         jButton2.setIcon(icon2); 
/*     */     } 
/* 359 */     if (jButton3 != null)
/* 360 */       jButton3.setIcon(icon3); 
/*     */   }
/*     */   
/*     */   protected Rectangle getControlButtonsBounds(BasicInternalFrameTitlePane paramBasicInternalFrameTitlePane) {
/* 367 */     JButton jButton1 = null;
/* 368 */     JButton jButton2 = null;
/* 369 */     JButton jButton3 = null;
/* 370 */     boolean bool = isRTL(paramBasicInternalFrameTitlePane);
/* 372 */     Component[] arrayOfComponent = paramBasicInternalFrameTitlePane.getComponents();
/* 373 */     for (byte b = 0; b < arrayOfComponent.length; b++) {
/* 375 */       Component component = arrayOfComponent[b];
/* 376 */       if (component instanceof JButton) {
/* 378 */         String str = component.getName();
/* 379 */         if (str != null) {
/* 381 */           if (str.endsWith("closeButton"))
/* 382 */             jButton3 = (JButton)component; 
/* 383 */           if (str.endsWith("iconifyButton"))
/* 384 */             jButton1 = (JButton)component; 
/* 385 */           if (str.endsWith("maximizeButton"))
/* 386 */             jButton2 = (JButton)component; 
/*     */         } 
/*     */       } 
/*     */     } 
/* 391 */     JInternalFrame jInternalFrame = null;
/* 392 */     if (paramBasicInternalFrameTitlePane.getParent() instanceof JInternalFrame) {
/* 394 */       jInternalFrame = (JInternalFrame)paramBasicInternalFrameTitlePane.getParent();
/* 395 */       if (!jInternalFrame.isClosable() && !jInternalFrame.isMaximizable() && !jInternalFrame.isIconifiable())
/* 396 */         return new Rectangle(bool ? 0 : ((paramBasicInternalFrameTitlePane.getBounds()).width - 1), 0, 0, 0); 
/*     */     } 
/* 399 */     Rectangle rectangle = new Rectangle(0, 0, 0, 0);
/* 400 */     if (jButton3 != null && !jButton3.getBounds().equals(rectangle)) {
/* 401 */       rectangle = jButton3.getBounds();
/* 402 */     } else if (jButton2 != null && !jButton2.getBounds().equals(rectangle)) {
/* 403 */       rectangle = jButton2.getBounds();
/* 404 */     } else if (jButton1 != null && !jButton1.getBounds().equals(rectangle)) {
/* 405 */       rectangle = jButton1.getBounds();
/*     */     } 
/* 408 */     if ((jInternalFrame != null && jInternalFrame.isIconifiable()) || (
/* 409 */       jInternalFrame == null && jButton1 != null)) {
/* 411 */       Rectangle rectangle1 = jButton1.getBounds();
/* 412 */       if (bool) {
/* 413 */         rectangle.width = rectangle1.x + rectangle1.width - rectangle.x;
/*     */       } else {
/* 416 */         rectangle.width = rectangle.x + rectangle.width - rectangle1.x;
/* 417 */         rectangle.x = rectangle1.x;
/*     */       } 
/* 420 */     } else if ((jInternalFrame != null && jInternalFrame.isMaximizable()) || (
/* 421 */       jInternalFrame == null && jButton2 != null)) {
/* 423 */       Rectangle rectangle1 = jButton2.getBounds();
/* 424 */       if (bool) {
/* 425 */         rectangle.width = rectangle1.x + rectangle1.width - rectangle.x;
/*     */       } else {
/* 428 */         rectangle.width = rectangle.x + rectangle.width - rectangle1.x;
/* 429 */         rectangle.x = rectangle1.x;
/*     */       } 
/*     */     } 
/* 432 */     return rectangle;
/*     */   }
/*     */   
/*     */   protected Rectangle getMenuButtonBounds(BasicInternalFrameTitlePane paramBasicInternalFrameTitlePane) {
/* 437 */     JButton jButton = (JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.menuButton", paramBasicInternalFrameTitlePane);
/* 438 */     Rectangle rectangle = (jButton == null) ? new Rectangle(0, 0, 0, 0) : jButton.getBounds();
/* 439 */     if (jButton == null) {
/* 441 */       rectangle.x = isRTL(paramBasicInternalFrameTitlePane) ? ((paramBasicInternalFrameTitlePane.getBounds()).width - 1) : 0;
/* 442 */       rectangle.y = (paramBasicInternalFrameTitlePane.getBounds()).y;
/*     */     } 
/* 444 */     return rectangle;
/*     */   }
/*     */   
/*     */   protected boolean isRTL(BasicInternalFrameTitlePane paramBasicInternalFrameTitlePane) {
/* 449 */     return !paramBasicInternalFrameTitlePane.getRootPane().getComponentOrientation().isLeftToRight();
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 455 */     if (paramString.equals("paintInternalFrameBorder") || paramString.equals("paintInternalFrameBackground"))
/* 456 */       return Cacheable.ScaleType.NINE_SQUARE; 
/* 457 */     return super.getCacheScaleType(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\InternalFramePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */