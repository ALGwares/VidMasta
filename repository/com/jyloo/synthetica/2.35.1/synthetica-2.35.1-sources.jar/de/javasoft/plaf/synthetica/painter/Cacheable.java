/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ interface Cacheable {
/*    */   int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString);
/*    */   
/*    */   ScaleType getCacheScaleType(String paramString);
/*    */   
/*    */   Insets getCacheScaleInsets(SynthContext paramSynthContext, String paramString);
/*    */   
/*    */   public enum ScaleType {
/* 26 */     NONE, NINE_SQUARE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\Cacheable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */