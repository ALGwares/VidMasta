/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ListStyle extends StyleWrapper {
/* 32 */   private static ListStyle instance = new ListStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 40 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 42 */       instance.setStyle(paramSynthStyle);
/* 43 */       return instance;
/*    */     } 
/* 45 */     ListStyle listStyle = new ListStyle();
/* 46 */     listStyle.setStyle(paramSynthStyle);
/* 47 */     return listStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 53 */     JComponent jComponent = paramSynthContext.getComponent();
/* 55 */     if (paramColorType == ColorType.BACKGROUND && jComponent.getBackground() != null)
/* 56 */       return jComponent.getBackground(); 
/* 57 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */   
/*    */   public Object get(SynthContext paramSynthContext, Object paramObject) {
/* 63 */     if ("Tree.dropLineColor".equals(paramObject))
/* 64 */       return UIManager.get("Tree.dropLineColor"); 
/* 65 */     return this.synthStyle.get(paramSynthContext, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ListStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */