/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ class FocusPainter {
/*     */   static void paintFocus(String paramString, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  44 */     paintFocus(paramString, paramSynthContext, null, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   static void paintFocus(String paramString1, SynthContext paramSynthContext, String paramString2, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  65 */     JComponent jComponent = paramSynthContext.getComponent();
/*  66 */     int i = paramSynthContext.getComponentState();
/*  67 */     paintFocus(paramString1, jComponent, i, paramString2, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   static void paintFocus(String paramString1, JComponent paramJComponent, int paramInt1, String paramString2, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  89 */     paintFocus(paramString1, paramJComponent, paramInt1, paramString2, 0, paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   static void paintFocus(String paramString1, JComponent paramJComponent, int paramInt1, String paramString2, int paramInt2, Graphics paramGraphics, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 112 */     String str1 = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/* 113 */     String str2 = SyntheticaLookAndFeel.getString(paramString1, null, str1, true);
/* 114 */     Insets insets = SyntheticaLookAndFeel.getInsets(paramString1, "insets", str1, true);
/* 119 */     boolean bool = ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.paintFocus", paramJComponent, Boolean.valueOf(true))).booleanValue();
/* 120 */     if (str2 != null && str2.length() > 0 && bool) {
/* 122 */       int i = SyntheticaLookAndFeel.getInt(paramString1, "animation.cycles", str1, true, -1);
/* 123 */       int j = SyntheticaLookAndFeel.getInt(paramString1, "animation.delay", str1, true, 60);
/* 124 */       int k = SyntheticaLookAndFeel.getInt(paramString1, "animation.type", str1, true, 3);
/* 126 */       Insets insets1 = insets;
/* 127 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, paramString2, i, j, k, paramInt1, paramGraphics, paramInt3, paramInt4, paramInt5, paramInt6, str2, insets, insets1, 1, 1);
/* 128 */       imagePainter.setAngle(paramInt2);
/* 129 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\FocusPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */