/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class TreePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.TreePainter";
/*     */   
/*     */   private static boolean cellRendererSelectionBackgroundEnabled;
/*     */   
/*     */   public static TreePainter getInstance() {
/*  46 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static TreePainter getInstance(SynthContext paramSynthContext) {
/*  55 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TreePainter.class, "Synthetica.TreePainter"));
/*  56 */     if (syntheticaComponentPainter == null)
/*  57 */       syntheticaComponentPainter = getInstance(paramSynthContext, TreePainter.class, "Synthetica.TreePainter"); 
/*  58 */     return (TreePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public static void reinitialize() {
/*  65 */     cellRendererSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.selectionBackground.enabled", null, false);
/*     */   }
/*     */   
/*     */   public void paintTreeBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintTreeBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  78 */     JComponent jComponent = paramSynthContext.getComponent();
/*  79 */     Color color = jComponent.getBackground();
/*  80 */     if (color != null && !(color instanceof javax.swing.plaf.ColorUIResource) && jComponent.isOpaque()) {
/*  82 */       paramGraphics.setColor(color);
/*  83 */       paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintTreeCellBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintTreeCellBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  93 */     JComponent jComponent = paramSynthContext.getComponent();
/*  94 */     if (cellRendererSelectionBackgroundEnabled) {
/*  96 */       boolean bool1 = true;
/*  97 */       boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.respectFocus", jComponent, false);
/*  98 */       if (bool2)
/* 101 */         if (jComponent.getParent() instanceof javax.swing.CellRendererPane) {
/* 102 */           bool1 = jComponent.getParent().getParent().hasFocus();
/*     */         } else {
/* 104 */           bool1 = jComponent.hasFocus();
/*     */         }  
/* 106 */       String str = SyntheticaLookAndFeel.getString(bool1 ? "Synthetica.tree.selectionBackground" : "Synthetica.tree.selectionBackground.inactive", jComponent);
/* 107 */       if (str != null) {
/* 109 */         Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.tree.selectionBackground.insets", jComponent, false);
/* 110 */         ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 111 */         imagePainter.draw();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 119 */     return Cacheable.ScaleType.NINE_SQUARE;
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 125 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TreePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */