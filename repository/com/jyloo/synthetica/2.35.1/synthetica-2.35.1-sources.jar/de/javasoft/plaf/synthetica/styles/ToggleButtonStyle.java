/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ToggleButtonStyle extends StyleWrapper {
/* 32 */   private static ToggleButtonStyle instance = new ToggleButtonStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 40 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 42 */       instance.setStyle(paramSynthStyle);
/* 43 */       return instance;
/*    */     } 
/* 45 */     ToggleButtonStyle toggleButtonStyle = new ToggleButtonStyle();
/* 46 */     toggleButtonStyle.setStyle(paramSynthStyle);
/* 47 */     return toggleButtonStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 53 */     JComponent jComponent = paramSynthContext.getComponent();
/* 55 */     if (paramColorType == ColorType.TEXT_FOREGROUND && !(jComponent.getForeground() instanceof javax.swing.plaf.ColorUIResource))
/* 56 */       return jComponent.getForeground(); 
/* 57 */     return super.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ToggleButtonStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */