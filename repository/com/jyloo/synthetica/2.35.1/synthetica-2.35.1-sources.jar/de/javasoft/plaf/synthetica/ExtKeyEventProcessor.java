/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.KeyEventPostProcessor;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.FocusManager;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.MenuElement;
/*     */ import javax.swing.MenuSelectionManager;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.RootPaneUI;
/*     */ 
/*     */ class ExtKeyEventProcessor implements KeyEventPostProcessor {
/*     */   private static boolean altKeyPressed = false;
/*     */   
/*     */   private static boolean menuActivated = false;
/*     */   
/*     */   private static boolean winKeyArmed = false;
/*     */   
/*     */   public boolean postProcessKeyEvent(KeyEvent paramKeyEvent) {
/*  46 */     if (paramKeyEvent.isConsumed())
/*  47 */       return false; 
/*  49 */     winMetaKeySupport(paramKeyEvent);
/*  51 */     if (!activateMenuByAltKey())
/*  52 */       return false; 
/*  54 */     int i = paramKeyEvent.getModifiers();
/*  56 */     if (paramKeyEvent.getKeyCode() == 18)
/*  56 */       if ((((i != 10) ? 1 : 0) & ((i != 32) ? 1 : 0)) != 0) {
/*  58 */         Component component = paramKeyEvent.getComponent();
/*  59 */         Window window = SwingUtilities.getWindowAncestor(component);
/*  60 */         JRootPane jRootPane = SwingUtilities.getRootPane(component);
/*  61 */         JMenuBar jMenuBar = (jRootPane != null) ? jRootPane.getJMenuBar() : null;
/*  63 */         if (jMenuBar == null && window instanceof JFrame)
/*  64 */           jMenuBar = ((JFrame)window).getJMenuBar(); 
/*  66 */         if (paramKeyEvent.getID() == 401) {
/*  68 */           if (!altKeyPressed)
/*  69 */             altPressed(paramKeyEvent, component, jRootPane, jMenuBar); 
/*  70 */           altKeyPressed = true;
/*  71 */           return true;
/*     */         } 
/*  73 */         if (paramKeyEvent.getID() == 402) {
/*  75 */           if (altKeyPressed)
/*  76 */             altReleased(paramKeyEvent, component, jRootPane, jMenuBar); 
/*  77 */           altKeyPressed = false;
/*     */         } 
/*  82 */         return false;
/*     */       }  
/*     */     altKeyPressed = false;
/*  82 */     return false;
/*     */   }
/*     */   
/*     */   static void resetWinMetaKey() {
/*  87 */     winKeyArmed = false;
/*     */   }
/*     */   
/*     */   private void winMetaKeySupport(KeyEvent paramKeyEvent) {
/*  93 */     int i = paramKeyEvent.getKeyCode();
/*  94 */     boolean bool1 = paramKeyEvent.isMetaDown();
/*  95 */     boolean bool2 = paramKeyEvent.isControlDown();
/*  96 */     Window window = FocusManager.getCurrentManager().getActiveWindow();
/*  97 */     JFrame jFrame = (window instanceof JFrame) ? (JFrame)window : null;
/* 100 */     if (i == 70 && bool1 && bool2 && paramKeyEvent.getID() == 401 && 
/* 101 */       jFrame != null && jFrame.isResizable() && SyntheticaTitlePane.isFullScreenOnMacSupported(jFrame)) {
/* 103 */       RootPaneUI rootPaneUI = jFrame.getRootPane().getUI();
/* 104 */       if (rootPaneUI instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)rootPaneUI).getTitlePane() instanceof SyntheticaTitlePane) {
/* 106 */         SyntheticaTitlePane syntheticaTitlePane = (SyntheticaTitlePane)((SyntheticaRootPaneUI)rootPaneUI).getTitlePane();
/* 107 */         if (isMaximized(window)) {
/* 108 */           syntheticaTitlePane.restore();
/*     */         } else {
/* 110 */           syntheticaTitlePane.maximize();
/*     */         } 
/*     */       } 
/*     */     } 
/* 114 */     if (i == 524 && paramKeyEvent.getID() == 401) {
/* 115 */       winKeyArmed = true;
/* 116 */     } else if (!winKeyArmed || i != 38) {
/* 120 */       if (bool1 && i == 38 && !isMaximized(window) && jFrame != null) {
/* 122 */         RootPaneUI rootPaneUI = jFrame.getRootPane().getUI();
/* 123 */         if (rootPaneUI instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)rootPaneUI).isSnapEnabled(window) && ((SyntheticaRootPaneUI)rootPaneUI).getTitlePane() instanceof SyntheticaTitlePane)
/* 124 */           ((SyntheticaTitlePane)((SyntheticaRootPaneUI)rootPaneUI).getTitlePane()).maximize(); 
/* 127 */       } else if ((winKeyArmed || bool1) && i == 40 && isMaximized(window) && jFrame != null) {
/* 129 */         RootPaneUI rootPaneUI = jFrame.getRootPane().getUI();
/* 130 */         if (rootPaneUI instanceof SyntheticaRootPaneUI) {
/* 132 */           SyntheticaRootPaneUI syntheticaRootPaneUI = (SyntheticaRootPaneUI)rootPaneUI;
/* 133 */           if (isMaximized(window) && syntheticaRootPaneUI.getTitlePane() instanceof SyntheticaTitlePane) {
/* 135 */             ((SyntheticaTitlePane)syntheticaRootPaneUI.getTitlePane()).restore();
/* 136 */             syntheticaRootPaneUI.restoreSnappedWindow(window, window.getGraphicsConfiguration(), true);
/*     */           } 
/*     */         } 
/* 140 */       } else if (!winKeyArmed || i != 40) {
/* 144 */         if (bool1 && i == 40 && !isMaximized(window) && jFrame != null) {
/* 146 */           RootPaneUI rootPaneUI = jFrame.getRootPane().getUI();
/* 147 */           if (rootPaneUI instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)rootPaneUI).isSnapEnabled(window) && ((SyntheticaRootPaneUI)rootPaneUI).getTitlePane() instanceof SyntheticaTitlePane)
/* 148 */             ((SyntheticaTitlePane)((SyntheticaRootPaneUI)rootPaneUI).getTitlePane()).iconify(); 
/* 151 */         } else if ((winKeyArmed || bool1) && (i == 37 || i == 39) && !bool2 && jFrame != null) {
/* 153 */           RootPaneUI rootPaneUI = jFrame.getRootPane().getUI();
/* 154 */           if (rootPaneUI instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)rootPaneUI).isSnapEnabled(window))
/* 156 */             if (i == 37) {
/* 157 */               ((SyntheticaRootPaneUI)rootPaneUI).snapPrev(window);
/*     */             } else {
/* 159 */               ((SyntheticaRootPaneUI)rootPaneUI).snapNext(window);
/*     */             }  
/*     */         } else {
/* 163 */           winKeyArmed = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isMaximized(Window paramWindow) {
/* 168 */     return (paramWindow instanceof Frame && (((Frame)paramWindow).getExtendedState() & 0x6) == 6);
/*     */   }
/*     */   
/*     */   private void altPressed(KeyEvent paramKeyEvent, Component paramComponent, JRootPane paramJRootPane, JMenuBar paramJMenuBar) {
/* 175 */     if (UIManager.get("Button.showMnemonics") == null && !(paramComponent instanceof JMenuBar) && paramJRootPane != null)
/* 176 */       paramJRootPane.repaint(); 
/* 177 */     altPressed(paramKeyEvent, paramJMenuBar);
/*     */   }
/*     */   
/*     */   private void altPressed(KeyEvent paramKeyEvent, JMenuBar paramJMenuBar) {
/* 183 */     boolean bool = UIManager.getBoolean("Synthetica.forcedAltKeyEventConsumption");
/* 184 */     MenuSelectionManager menuSelectionManager = MenuSelectionManager.defaultManager();
/* 185 */     MenuElement[] arrayOfMenuElement = menuSelectionManager.getSelectedPath();
/* 187 */     if (arrayOfMenuElement.length > 0) {
/* 190 */       if (!(arrayOfMenuElement[0] instanceof javax.swing.plaf.basic.ComboPopup))
/* 191 */         menuSelectionManager.clearSelectedPath(); 
/* 192 */       menuActivated = false;
/* 193 */       if (!bool)
/* 194 */         paramKeyEvent.consume(); 
/*     */     } else {
/* 198 */       if (paramJMenuBar != null)
/* 199 */         menuActivated = true; 
/* 200 */       if (paramJMenuBar != null && paramJMenuBar.getMenu(0) != null && !bool)
/* 201 */         paramKeyEvent.consume(); 
/*     */     } 
/* 204 */     if (bool)
/* 205 */       paramKeyEvent.consume(); 
/* 207 */     if (paramJMenuBar != null && menuActivated)
/* 208 */       paramJMenuBar.repaint(); 
/*     */   }
/*     */   
/*     */   public static void setMenuActive(boolean paramBoolean) {
/* 213 */     menuActivated = paramBoolean;
/*     */   }
/*     */   
/*     */   public static boolean isMenuActive() {
/* 219 */     return menuActivated;
/*     */   }
/*     */   
/*     */   public static boolean isAltKeyPressed() {
/* 224 */     return altKeyPressed;
/*     */   }
/*     */   
/*     */   public static boolean showMnemonicsOnAltKeyOnly() {
/* 229 */     if (OS.getCurrentOS() == OS.Windows && SyntheticaLookAndFeel.getBoolean("Synthetica.showMnemonicsOnAltKeyOnly", null, true))
/* 230 */       return true; 
/* 231 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.forceShowMnemonicsOnAltKeyOnly", null);
/*     */   }
/*     */   
/*     */   public static boolean activateMenuByAltKey() {
/* 236 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.activateMenuByAltKey", null, true);
/*     */   }
/*     */   
/*     */   private void altReleased(KeyEvent paramKeyEvent, Component paramComponent, JRootPane paramJRootPane, JMenuBar paramJMenuBar) {
/* 242 */     if (UIManager.get("Button.showMnemonics") == null && !(paramComponent instanceof JMenuBar) && paramJRootPane != null)
/* 243 */       paramJRootPane.repaint(); 
/* 244 */     altReleased(paramKeyEvent, paramJMenuBar);
/*     */   }
/*     */   
/*     */   private void altReleased(KeyEvent paramKeyEvent, JMenuBar paramJMenuBar) {
/* 250 */     MenuSelectionManager menuSelectionManager = MenuSelectionManager.defaultManager();
/* 252 */     if ((menuSelectionManager.getSelectedPath()).length == 0 && menuActivated) {
/* 254 */       JMenu jMenu = (paramJMenuBar != null) ? paramJMenuBar.getMenu(0) : null;
/* 255 */       if (jMenu != null) {
/* 257 */         MenuElement[] arrayOfMenuElement = new MenuElement[2];
/* 258 */         arrayOfMenuElement[0] = paramJMenuBar;
/* 259 */         arrayOfMenuElement[1] = jMenu;
/* 260 */         menuSelectionManager.setSelectedPath(arrayOfMenuElement);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\ExtKeyEventProcessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */