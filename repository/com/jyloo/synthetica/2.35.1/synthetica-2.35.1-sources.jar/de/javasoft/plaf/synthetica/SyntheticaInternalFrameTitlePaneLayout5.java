/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*     */ 
/*     */ class SyntheticaInternalFrameTitlePaneLayout5 implements LayoutManager {
/*     */   private JInternalFrame frame;
/*     */   
/*     */   private BasicInternalFrameTitlePane titlePane;
/*     */   
/*     */   private JButton menuButton;
/*     */   
/*     */   private JButton iconButton;
/*     */   
/*     */   private JButton maxButton;
/*     */   
/*     */   private JButton closeButton;
/*     */   
/*  42 */   private int buttonSpacing = 2;
/*     */   
/*  43 */   private int titleSpacing = 2;
/*     */   
/*     */   public SyntheticaInternalFrameTitlePaneLayout5(BasicInternalFrameTitlePane paramBasicInternalFrameTitlePane) {
/*  47 */     this.titlePane = paramBasicInternalFrameTitlePane;
/*  48 */     Container container = paramBasicInternalFrameTitlePane.getParent();
/*  49 */     if (container instanceof JInternalFrame) {
/*  50 */       this.frame = (JInternalFrame)container;
/*     */     } else {
/*  52 */       this.frame = ((JInternalFrame.JDesktopIcon)container).getInternalFrame();
/*     */     } 
/*  53 */     this.menuButton = (JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.menuButton", paramBasicInternalFrameTitlePane);
/*  54 */     this.iconButton = (JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.iconifyButton", paramBasicInternalFrameTitlePane);
/*  55 */     this.maxButton = (JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.maximizeButton", paramBasicInternalFrameTitlePane);
/*  56 */     this.closeButton = (JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.closeButton", paramBasicInternalFrameTitlePane);
/*     */   }
/*     */   
/*     */   public void addLayoutComponent(String paramString, Component paramComponent) {}
/*     */   
/*     */   public void removeLayoutComponent(Component paramComponent) {}
/*     */   
/*     */   public Dimension preferredLayoutSize(Container paramContainer) {
/*  69 */     return minimumLayoutSize(paramContainer);
/*     */   }
/*     */   
/*     */   public Dimension minimumLayoutSize(Container paramContainer) {
/*  74 */     int i = 0;
/*  75 */     int j = 0;
/*  76 */     byte b1 = 0;
/*  78 */     Dimension dimension = this.menuButton.getPreferredSize();
/*  79 */     i += dimension.width;
/*  80 */     j = Math.max(dimension.height, j);
/*  81 */     if (this.frame.isClosable()) {
/*  83 */       b1++;
/*  84 */       dimension = this.closeButton.getPreferredSize();
/*  85 */       i += dimension.width;
/*  86 */       j = Math.max(dimension.height, j);
/*     */     } 
/*  88 */     if (this.frame.isMaximizable()) {
/*  90 */       b1++;
/*  91 */       dimension = this.maxButton.getPreferredSize();
/*  92 */       i += dimension.width;
/*  93 */       j = Math.max(dimension.height, j);
/*     */     } 
/*  95 */     if (this.frame.isIconifiable()) {
/*  97 */       b1++;
/*  98 */       dimension = this.iconButton.getPreferredSize();
/*  99 */       i += dimension.width;
/* 100 */       j = Math.max(dimension.height, j);
/*     */     } 
/* 102 */     i += (b1 > 0) ? ((b1 - 1) * this.buttonSpacing) : 0;
/* 104 */     FontMetrics fontMetrics = this.titlePane.getFontMetrics(this.titlePane.getFont());
/* 105 */     j = Math.max(fontMetrics.getHeight() + 2, j);
/* 107 */     String str = this.frame.getTitle();
/* 108 */     byte b2 = (str != null) ? SwingUtilities.computeStringWidth(fontMetrics, str) : 0;
/* 109 */     byte b3 = (str != null) ? str.length() : 0;
/* 111 */     if (b3 > 3) {
/* 113 */       int k = SwingUtilities.computeStringWidth(fontMetrics, String.valueOf(str.substring(0, 3)) + "...");
/* 114 */       i += (b2 < k) ? b2 : k;
/*     */     } else {
/* 117 */       i += b2;
/*     */     } 
/* 118 */     i += this.titleSpacing * 2;
/* 120 */     Insets insets = this.titlePane.getInsets();
/* 121 */     j += insets.top + insets.bottom;
/* 122 */     i += insets.left + insets.right;
/* 123 */     return new Dimension(i, j);
/*     */   }
/*     */   
/*     */   public void layoutContainer(Container paramContainer) {
/* 128 */     Insets insets = paramContainer.getInsets();
/* 129 */     if (this.frame.getComponentOrientation().isLeftToRight()) {
/* 131 */       setButtonBounds(this.menuButton, insets.left, false);
/* 132 */       int i = this.titlePane.getWidth() - insets.right;
/* 133 */       if (this.frame.isClosable())
/* 134 */         i = setButtonBounds(this.closeButton, i, true); 
/* 135 */       if (this.frame.isMaximizable())
/* 136 */         i = setButtonBounds(this.maxButton, i, true); 
/* 137 */       if (this.frame.isIconifiable())
/* 138 */         i = setButtonBounds(this.iconButton, i, true); 
/*     */     } else {
/* 142 */       setButtonBounds(this.menuButton, this.titlePane.getWidth() - insets.right, true);
/* 143 */       int i = insets.left;
/* 144 */       if (this.frame.isClosable())
/* 145 */         i = setButtonBounds(this.closeButton, i, false); 
/* 146 */       if (this.frame.isMaximizable())
/* 147 */         i = setButtonBounds(this.maxButton, i, false); 
/* 148 */       if (this.frame.isIconifiable())
/* 149 */         i = setButtonBounds(this.iconButton, i, false); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int setButtonBounds(JButton paramJButton, int paramInt, boolean paramBoolean) {
/* 155 */     Insets insets = this.titlePane.getInsets();
/* 156 */     Dimension dimension = paramJButton.getPreferredSize();
/* 157 */     if (paramBoolean)
/* 158 */       paramInt -= dimension.width; 
/* 159 */     paramJButton.setBounds(paramInt, insets.top + (this.titlePane.getHeight() - insets.top - insets.bottom - dimension.height) / 2, dimension.width, dimension.height);
/* 160 */     if (paramBoolean)
/* 161 */       return paramInt - this.buttonSpacing; 
/* 162 */     return paramInt + dimension.width + this.buttonSpacing;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaInternalFrameTitlePaneLayout5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */