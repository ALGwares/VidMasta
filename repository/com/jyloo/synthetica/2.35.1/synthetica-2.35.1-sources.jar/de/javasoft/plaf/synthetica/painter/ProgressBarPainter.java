/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class ProgressBarPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ProgressBarPainter";
/*     */   
/*  48 */   private static HashMap<String, Image> imgCache = new HashMap<String, Image>();
/*     */   
/*     */   public static ProgressBarPainter getInstance() {
/*  62 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ProgressBarPainter getInstance(SynthContext paramSynthContext) {
/*  71 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ProgressBarPainter.class, "Synthetica.ProgressBarPainter"));
/*  72 */     if (syntheticaComponentPainter == null)
/*  73 */       syntheticaComponentPainter = getInstance(paramSynthContext, ProgressBarPainter.class, "Synthetica.ProgressBarPainter"); 
/*  74 */     return (ProgressBarPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintProgressBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintProgressBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  86 */     JProgressBar jProgressBar = (JProgressBar)paramSynthContext.getComponent();
/*  88 */     Insets insets1 = paramSynthContext.getStyle().getInsets(paramSynthContext, null);
/*  90 */     Insets insets2 = jProgressBar.getInsets();
/*  91 */     paramInt3 -= insets2.left + insets2.right - insets1.left - insets1.right;
/*  92 */     paramInt4 -= insets2.top + insets2.bottom - insets1.top - insets1.bottom;
/*  93 */     paramInt1 += insets2.left - insets1.left;
/*  94 */     paramInt2 += insets2.top - insets1.top;
/*  95 */     boolean bool = (jProgressBar.getValue() > 0 || jProgressBar.isIndeterminate()) ? SyntheticaState.State.ACTIVE.toInt() : false;
/*  96 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, bool, false);
/*  98 */     UIKey uIKey = new UIKey("progressBar.x.background", syntheticaPainterState);
/*  99 */     if (jProgressBar.getOrientation() == 1)
/* 100 */       uIKey = new UIKey("progressBar.y.background", syntheticaPainterState); 
/* 102 */     Insets insets3 = (Insets)uIKey.findProperty(paramSynthContext, "insets", true, 2);
/* 103 */     Insets insets4 = insets3;
/* 104 */     String str = (String)uIKey.findProperty(paramSynthContext, null, true, 1);
/* 106 */     uIKey = new UIKey("progressBar.background", syntheticaPainterState);
/* 107 */     if (str != null) {
/* 109 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), jProgressBar, 1);
/* 110 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), jProgressBar, 50);
/* 111 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), jProgressBar, 6);
/* 112 */       if (syntheticaPainterState.isSet(SyntheticaState.State.ACTIVE))
/* 113 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), jProgressBar, 5); 
/* 114 */       ImagePainter imagePainter = new ImagePainter(jProgressBar, i, j, k, syntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets3, insets4, 0, 0);
/* 115 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintProgressBarForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 124 */     Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 125 */     JProgressBar jProgressBar = (JProgressBar)paramSynthContext.getComponent();
/* 126 */     jProgressBar.putClientProperty("Synthetica.progressBar.textFillStart", Integer.valueOf((paramInt5 == 0) ? paramInt1 : paramInt2));
/* 127 */     jProgressBar.putClientProperty("Synthetica.progressBar.textFillAmount", Integer.valueOf((paramInt5 == 0) ? paramInt3 : paramInt4));
/* 129 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/* 130 */     UIKey uIKey = new UIKey(jProgressBar.isIndeterminate() ? "progressBar.x.indeterminate" : "progressBar.x", syntheticaPainterState);
/* 131 */     if (paramInt5 == 1)
/* 132 */       uIKey = new UIKey(jProgressBar.isIndeterminate() ? "progressBar.y.indeterminate" : "progressBar.y", syntheticaPainterState); 
/* 134 */     Insets insets1 = (Insets)uIKey.findProperty(paramSynthContext, "insets", true, 2);
/* 136 */     if (insets1 == null)
/* 136 */       insets1 = new Insets(0, 0, 0, 0); 
/* 137 */     Insets insets2 = insets1;
/* 139 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.progressBar.respectMinimumBarImageSize", jProgressBar, true);
/* 140 */     if (paramInt5 == 0) {
/* 142 */       byte b = bool ? (insets1.left + insets1.right) : 1;
/* 143 */       if (paramInt3 < b)
/*     */         return; 
/*     */     } else {
/* 148 */       byte b = bool ? (insets1.top + insets1.bottom) : 1;
/* 149 */       if (paramInt4 < b)
/*     */         return; 
/*     */     } 
/* 153 */     int i = paramInt3;
/* 154 */     int j = paramInt4;
/* 155 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.progressBar.tiled", jProgressBar) ? true : false;
/* 157 */     String str = (String)uIKey.findProperty(paramSynthContext, null, true, 2);
/* 158 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.progressBar.continuous", jProgressBar)) {
/* 160 */       Image image = imgCache.get(str);
/* 161 */       if (image == null) {
/* 163 */         image = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(str))).getImage();
/* 164 */         imgCache.put(str, image);
/*     */       } 
/* 166 */       int i1 = image.getWidth(null) - insets1.left - insets1.right;
/* 167 */       int i2 = image.getHeight(null) - insets1.top - insets1.bottom;
/* 170 */       i = (paramInt3 - insets1.left - insets1.right) / i1 * i1 + insets1.left + insets1.right;
/* 171 */       j = (paramInt4 - insets1.top - insets1.bottom) / i2 * i2 + insets1.top + insets1.bottom;
/* 172 */       bool1 = true;
/*     */     } 
/* 175 */     int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), jProgressBar, -1);
/* 176 */     int m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), jProgressBar, 70);
/* 177 */     int n = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), jProgressBar, 0);
/* 179 */     RenderingHints renderingHints = graphics2D.getRenderingHints();
/* 181 */     graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 183 */     ImagePainter imagePainter = null;
/* 184 */     if (paramInt5 == 0) {
/* 186 */       imagePainter = new ImagePainter(jProgressBar, k, m, n, syntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2, i, paramInt4, str, insets1, insets2, bool1, 0);
/* 187 */       imagePainter.draw();
/*     */     } else {
/* 191 */       imagePainter = new ImagePainter(jProgressBar, k, m, n, syntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2 - j + paramInt4, paramInt3, j, str, insets1, insets2, 0, bool1);
/* 192 */       imagePainter.draw();
/*     */     } 
/* 195 */     graphics2D.setRenderingHints(renderingHints);
/* 198 */     if (jProgressBar.isStringPainted() && jProgressBar.isIndeterminate() && JAVA5) {
/* 200 */       SynthStyle synthStyle = paramSynthContext.getStyle();
/* 201 */       Font font = synthStyle.getFont(paramSynthContext);
/* 202 */       paramGraphics.setFont(font);
/* 203 */       paramGraphics.setColor(synthStyle.getColor(paramSynthContext, ColorType.TEXT_FOREGROUND));
/* 205 */       FontMetrics fontMetrics = paramGraphics.getFontMetrics();
/* 206 */       Rectangle rectangle = jProgressBar.getBounds();
/* 207 */       int i1 = synthStyle.getGraphicsUtils(paramSynthContext).computeStringWidth(paramSynthContext, font, fontMetrics, jProgressBar.getString());
/* 208 */       Point point = new Point(rectangle.width / 2 - i1 / 2, (rectangle.height - fontMetrics.getAscent() + fontMetrics.getDescent()) / 2);
/* 209 */       synthStyle.getGraphicsUtils(paramSynthContext).paintText(paramSynthContext, paramGraphics, jProgressBar.getString(), point.x, point.y, -1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 216 */     if (paramString.equals("paintProgressBarForeground"))
/* 217 */       return -1; 
/* 219 */     JProgressBar jProgressBar = (JProgressBar)paramSynthContext.getComponent();
/* 220 */     int i = jProgressBar.getOrientation();
/* 222 */     int j = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 223 */     j = 31 * j + i;
/* 224 */     return j;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ProgressBarPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */