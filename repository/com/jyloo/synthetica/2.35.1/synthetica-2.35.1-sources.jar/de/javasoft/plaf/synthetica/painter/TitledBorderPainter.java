/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class TitledBorderPainter extends SyntheticaComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.TitledBorderPainter";
/*    */   
/*    */   public static TitledBorderPainter getInstance() {
/* 45 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(null, TitledBorderPainter.class, "Synthetica.TitledBorderPainter"));
/* 46 */     if (syntheticaComponentPainter == null)
/* 47 */       syntheticaComponentPainter = getInstance(null, TitledBorderPainter.class, "Synthetica.TitledBorderPainter"); 
/* 48 */     return (TitledBorderPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintBorder(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 53 */     String str = "Synthetica.titledBorder";
/* 54 */     str = SyntheticaLookAndFeel.getString(str, paramComponent);
/* 55 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.titledBorder.image.insets", paramComponent);
/* 56 */     if (insets1 == null)
/* 57 */       insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.titledBorder.insets", paramComponent); 
/* 58 */     Insets insets2 = insets1;
/* 59 */     ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 60 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.titledBorder.paintCenter", paramComponent)) {
/* 61 */       imagePainter.draw();
/*    */     } else {
/* 63 */       imagePainter.drawBorder();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TitledBorderPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */