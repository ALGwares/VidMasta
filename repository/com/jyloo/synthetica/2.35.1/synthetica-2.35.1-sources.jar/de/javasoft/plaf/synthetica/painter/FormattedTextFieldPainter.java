/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class FormattedTextFieldPainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.FormattedTextFieldPainter";
/*    */   
/*    */   public static FormattedTextFieldPainter getInstance() {
/* 44 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static FormattedTextFieldPainter getInstance(SynthContext paramSynthContext) {
/* 53 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, FormattedTextFieldPainter.class, "Synthetica.FormattedTextFieldPainter"));
/* 54 */     if (syntheticaComponentPainter == null)
/* 55 */       syntheticaComponentPainter = getInstance(paramSynthContext, FormattedTextFieldPainter.class, "Synthetica.FormattedTextFieldPainter"); 
/* 56 */     return (FormattedTextFieldPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintFormattedTextFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 64 */     if (!paintCheck(paramSynthContext))
/*    */       return; 
/* 66 */     paintBackground("formattedTextField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public void paintFormattedTextFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 74 */     if (!paintCheck(paramSynthContext))
/*    */       return; 
/* 76 */     paintBorder("formattedTextField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   protected boolean paintCheck(SynthContext paramSynthContext) {
/* 81 */     JComponent jComponent = paramSynthContext.getComponent();
/* 82 */     String str = jComponent.getName();
/* 83 */     if (str != null && str.startsWith("Spinner"))
/* 84 */       return false; 
/* 85 */     if (jComponent.getParent() instanceof javax.swing.JComboBox)
/* 86 */       return false; 
/* 87 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\FormattedTextFieldPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */