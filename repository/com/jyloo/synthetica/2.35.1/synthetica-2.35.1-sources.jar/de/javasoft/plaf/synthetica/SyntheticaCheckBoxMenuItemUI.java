/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.painter.MenuPainter;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Point;
/*    */ import java.awt.event.MouseEvent;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.MenuElement;
/*    */ import javax.swing.MenuSelectionManager;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class SyntheticaCheckBoxMenuItemUI extends SyntheticaMenuItemUI {
/*    */   public static ComponentUI createUI(JComponent paramJComponent) {
/* 36 */     return new SyntheticaCheckBoxMenuItemUI();
/*    */   }
/*    */   
/*    */   protected String getPropertyPrefix() {
/* 41 */     return "CheckBoxMenuItem";
/*    */   }
/*    */   
/*    */   public void processMouseEvent(JMenuItem paramJMenuItem, MouseEvent paramMouseEvent, MenuElement[] paramArrayOfMenuElement, MenuSelectionManager paramMenuSelectionManager) {
/* 46 */     Point point = paramMouseEvent.getPoint();
/* 47 */     if (point.x >= 0 && point.x < paramJMenuItem.getWidth() && point.y >= 0 && point.y < paramJMenuItem.getHeight()) {
/* 49 */       if (paramMouseEvent.getID() == 502) {
/* 51 */         paramMenuSelectionManager.clearSelectedPath();
/* 52 */         paramJMenuItem.doClick(0);
/*    */       } else {
/* 55 */         paramMenuSelectionManager.setSelectedPath(paramArrayOfMenuElement);
/*    */       } 
/* 57 */     } else if (paramJMenuItem.getModel().isArmed()) {
/* 59 */       int i = paramArrayOfMenuElement.length - 1;
/* 60 */       MenuElement[] arrayOfMenuElement = new MenuElement[i];
/* 61 */       for (byte b = 0; b < i; b++)
/* 62 */         arrayOfMenuElement[b] = paramArrayOfMenuElement[b]; 
/* 63 */       paramMenuSelectionManager.setSelectedPath(arrayOfMenuElement);
/*    */     } 
/*    */   }
/*    */   
/*    */   void paintBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 70 */     MenuPainter.getInstance(paramSynthContext).paintCheckBoxMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   void paintBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 76 */     MenuPainter.getInstance(paramSynthContext).paintCheckBoxMenuItemBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaCheckBoxMenuItemUI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */