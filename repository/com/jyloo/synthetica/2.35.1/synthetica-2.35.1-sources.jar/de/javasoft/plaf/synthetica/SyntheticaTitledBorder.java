/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.painter.TitledBorderPainter;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.border.Border;
/*    */ 
/*    */ public class SyntheticaTitledBorder implements Border {
/*    */   public void paintBorder(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 32 */     TitledBorderPainter.getInstance().paintBorder(paramComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public Insets getBorderInsets(Component paramComponent) {
/* 37 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.titledBorder.insets", paramComponent);
/* 39 */     return (Insets)insets.clone();
/*    */   }
/*    */   
/*    */   public boolean isBorderOpaque() {
/* 44 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaTitledBorder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */