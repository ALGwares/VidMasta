/*     */ package de.javasoft.plaf.synthetica.filechooser;
/*     */ 
/*     */ import de.javasoft.io.FileOperationEvent;
/*     */ import de.javasoft.io.FileOperationListener;
/*     */ import de.javasoft.io.FileProperties;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.painter.ImagePainter;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.text.MessageFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ public class FilePropertiesDialog extends JDialog implements FileOperationListener, Runnable {
/*     */   private boolean abort;
/*     */   
/*  61 */   private long counter = 0L;
/*     */   
/*     */   private JLabel location;
/*     */   
/*     */   private JLabel files;
/*     */   
/*     */   private JLabel size;
/*     */   
/*     */   private JLabel date;
/*     */   
/*     */   private FileProperties props;
/*     */   
/*     */   private Color brightLabelColor;
/*     */   
/*     */   private Color labelColor;
/*     */   
/*     */   private static final int xGap = 10;
/*     */   
/*     */   private static final int yGap = 10;
/*     */   
/*  73 */   String title = "";
/*     */   
/*  74 */   String imagePath = "";
/*     */   
/*     */   Insets imageInsets;
/*     */   
/*     */   public FilePropertiesDialog(Dialog paramDialog) {
/*  80 */     super(paramDialog);
/*  81 */     init(paramDialog);
/*     */   }
/*     */   
/*     */   public FilePropertiesDialog(Frame paramFrame) {
/*  86 */     super(paramFrame);
/*  87 */     init(paramFrame);
/*     */   }
/*     */   
/*     */   private void init(Window paramWindow) {
/*  92 */     Image image = null;
/*  94 */     this.title = UIManager.getString("FilePropertiesDialog.title");
/*  95 */     this.imagePath = UIManager.getString("Synthetica.filePropertiesDialog.title.background");
/*  96 */     this.imageInsets = SyntheticaLookAndFeel.getInsets("Synthetica.filePropertiesDialog.title.background.insets", null, new Insets(0, 0, 4, 100));
/*  97 */     image = (Image)UIManager.get("Synthetica.filePropertiesDialog.iconImage");
/*  98 */     setTitle(this.title);
/*  99 */     setLayout(new BorderLayout());
/* 100 */     getRootPane().putClientProperty("Synthetica.dialog.iconImage", image);
/* 104 */     JPanel jPanel1 = new JPanel() {
/* 106 */         private Image background = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(FilePropertiesDialog.this.imagePath))).getImage();
/*     */         
/*     */         public void paintComponent(Graphics param1Graphics) {
/* 110 */           ImagePainter imagePainter = new ImagePainter(this.background, param1Graphics, 0, 0, getWidth(), this.background.getHeight(null), FilePropertiesDialog.this.imageInsets, FilePropertiesDialog.this.imageInsets);
/* 111 */           imagePainter.draw();
/* 112 */           Graphics2D graphics2D = (Graphics2D)param1Graphics;
/* 113 */           graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 114 */           int i = UIManager.getInt("Synthetica.filePropertiesDialog.title.xPos");
/* 115 */           int j = UIManager.getInt("Synthetica.filePropertiesDialog.title.yPos");
/* 116 */           graphics2D.drawString(FilePropertiesDialog.this.title, i, j);
/* 117 */           graphics2D.dispose();
/*     */         }
/*     */         
/*     */         public Dimension getPreferredSize() {
/* 121 */           return new Dimension(this.background.getWidth(null), this.background.getHeight(null));
/*     */         }
/*     */       };
/* 124 */     float f = SyntheticaLookAndFeel.scaleFontSize(UIManager.getInt("Synthetica.filePropertiesDialog.title.size"));
/* 125 */     jPanel1.setFont(jPanel1.getFont().deriveFont(1, f));
/* 126 */     jPanel1.setForeground(UIManager.getColor("Synthetica.filePropertiesDialog.title.color"));
/* 128 */     JPanel jPanel2 = new JPanel(new GridBagLayout());
/* 129 */     jPanel2.setBorder(new EmptyBorder(10, 10, 10, 10));
/* 130 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 131 */     gridBagConstraints.anchor = 17;
/* 132 */     gridBagConstraints.weightx = 0.0D;
/* 133 */     gridBagConstraints.weighty = 0.0D;
/* 134 */     gridBagConstraints.gridwidth = 2;
/* 135 */     gridBagConstraints.gridheight = 1;
/* 140 */     gridBagConstraints.gridx = 0;
/* 141 */     gridBagConstraints.gridy = 0;
/* 142 */     JPanel jPanel3 = new JPanel(new BorderLayout());
/* 144 */     jPanel2.add(jPanel3, gridBagConstraints);
/* 146 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 147 */     gridBagConstraints.gridwidth = 2;
/* 148 */     gridBagConstraints.gridx = 0;
/* 149 */     gridBagConstraints.gridy = 1;
/* 150 */     gridBagConstraints.weightx = 1.0D;
/* 151 */     gridBagConstraints.fill = 2;
/* 154 */     this.files = new JLabel("!");
/* 155 */     this.labelColor = this.files.getForeground();
/* 156 */     this.brightLabelColor = new Color(this.labelColor.getRGB() + 6316128);
/* 157 */     this.files.setForeground(this.brightLabelColor);
/* 159 */     jPanel2.add(this.files, gridBagConstraints);
/* 161 */     gridBagConstraints.insets = new Insets(0, 0, 2, 10);
/* 162 */     gridBagConstraints.gridwidth = 1;
/* 163 */     gridBagConstraints.gridx = 0;
/* 164 */     gridBagConstraints.gridy = 2;
/* 165 */     gridBagConstraints.weightx = 0.0D;
/* 166 */     gridBagConstraints.fill = 0;
/* 167 */     JLabel jLabel1 = new JLabel(UIManager.getString("FilePropertiesDialog.location"));
/* 168 */     jPanel2.add(jLabel1, gridBagConstraints);
/* 170 */     gridBagConstraints.insets = new Insets(0, 0, 2, 0);
/* 171 */     gridBagConstraints.gridx = 1;
/* 172 */     gridBagConstraints.weightx = 1.0D;
/* 173 */     gridBagConstraints.fill = 2;
/* 174 */     this.location = new JLabel();
/* 175 */     jPanel2.add(this.location, gridBagConstraints);
/* 177 */     gridBagConstraints.insets = new Insets(0, 0, 2, 10);
/* 178 */     gridBagConstraints.gridwidth = 1;
/* 179 */     gridBagConstraints.gridx = 0;
/* 180 */     gridBagConstraints.gridy = 3;
/* 181 */     gridBagConstraints.weightx = 0.0D;
/* 182 */     gridBagConstraints.fill = 0;
/* 183 */     JLabel jLabel2 = new JLabel(UIManager.getString("FilePropertiesDialog.size"));
/* 184 */     jPanel2.add(jLabel2, gridBagConstraints);
/* 186 */     gridBagConstraints.insets = new Insets(0, 0, 2, 0);
/* 187 */     gridBagConstraints.gridx = 1;
/* 188 */     gridBagConstraints.weightx = 1.0D;
/* 189 */     gridBagConstraints.fill = 2;
/* 190 */     this.size = new JLabel();
/* 191 */     this.size.setForeground(this.brightLabelColor);
/* 192 */     jPanel2.add(this.size, gridBagConstraints);
/* 194 */     gridBagConstraints.insets = new Insets(0, 0, 20, 10);
/* 195 */     gridBagConstraints.gridx = 0;
/* 196 */     gridBagConstraints.gridy = 4;
/* 197 */     gridBagConstraints.weightx = 0.0D;
/* 198 */     gridBagConstraints.fill = 0;
/* 199 */     JLabel jLabel3 = new JLabel(UIManager.getString("FilePropertiesDialog.date"));
/* 200 */     jPanel2.add(jLabel3, gridBagConstraints);
/* 202 */     gridBagConstraints.insets = new Insets(0, 0, 20, 0);
/* 203 */     gridBagConstraints.gridx = 1;
/* 204 */     gridBagConstraints.weightx = 1.0D;
/* 205 */     gridBagConstraints.fill = 2;
/* 206 */     this.date = new JLabel();
/* 207 */     jPanel2.add(this.date, gridBagConstraints);
/* 209 */     gridBagConstraints.anchor = paramWindow.getComponentOrientation().isLeftToRight() ? 13 : 17;
/* 210 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 211 */     gridBagConstraints.gridwidth = 2;
/* 212 */     gridBagConstraints.gridx = 0;
/* 213 */     gridBagConstraints.gridy = 5;
/* 214 */     gridBagConstraints.weightx = 0.0D;
/* 215 */     gridBagConstraints.fill = 0;
/* 216 */     JButton jButton = new JButton(UIManager.getString("FilePropertiesDialog.ok"));
/* 217 */     jButton.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/* 221 */             FilePropertiesDialog.this.abort = true;
/* 222 */             FilePropertiesDialog.this.dispose();
/*     */           }
/*     */         });
/* 225 */     jButton.setMinimumSize(new Dimension((jButton.getPreferredSize()).width * 2, (jButton.getPreferredSize()).height));
/* 226 */     jButton.setPreferredSize(jButton.getMinimumSize());
/* 227 */     jPanel2.add(jButton, gridBagConstraints);
/* 229 */     add(jPanel1, "North");
/* 230 */     add(jPanel2);
/* 231 */     pack();
/* 233 */     int i = (paramWindow.getLocation()).x + (paramWindow.getSize()).width / 2;
/* 234 */     int j = i - (getSize()).width / 2;
/* 235 */     int k = (paramWindow.getLocation()).y + (paramWindow.getSize()).height / 2;
/* 236 */     int m = k - (getSize()).height / 2;
/* 237 */     setLocation(j, m);
/* 239 */     addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent param1WindowEvent) {
/* 243 */             FilePropertiesDialog.this.abort = true;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public boolean processFileOperationEvent(FileOperationEvent paramFileOperationEvent) {
/* 253 */     this.counter++;
/* 254 */     this.props = (FileProperties)paramFileOperationEvent.getSource();
/* 257 */     if (this.counter % 100L == 0L || this.counter < 10L)
/* 258 */       EventQueue.invokeLater(this); 
/* 259 */     return !this.abort;
/*     */   }
/*     */   
/*     */   public void run() {
/* 267 */     NumberFormat numberFormat = NumberFormat.getInstance();
/* 268 */     String str1 = UIManager.getString("FilePropertiesDialog.filesFormat");
/* 269 */     String str2 = numberFormat.format(this.props.directories);
/* 270 */     String str3 = numberFormat.format(this.props.files);
/* 271 */     this.files.setText(MessageFormat.format(str1, new Object[] { str3, str2 }));
/* 273 */     String str4 = UIManager.getString("FilePropertiesDialog.sizeFormat");
/* 274 */     String str5 = numberFormat.format(this.props.size);
/* 275 */     numberFormat = NumberFormat.getInstance();
/* 276 */     numberFormat.setMinimumFractionDigits(2);
/* 277 */     numberFormat.setMaximumFractionDigits(2);
/* 278 */     String str6 = numberFormat.format(this.props.size / 1024.0D / 1024.0D);
/* 279 */     this.size.setText(MessageFormat.format(str4, new Object[] { str5, str6 }));
/* 281 */     this.location.setText(this.props.location);
/* 283 */     if (this.props.directories + this.props.files == 1L) {
/* 285 */       SimpleDateFormat simpleDateFormat = new SimpleDateFormat(UIManager.getString("FilePropertiesDialog.dateFormat"));
/* 286 */       this.date.setText(simpleDateFormat.format(new Date(this.props.lastModified)));
/*     */     } else {
/* 289 */       this.date.setText("---");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void refresh() {
/* 294 */     this.counter = 0L;
/* 295 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 299 */             FilePropertiesDialog.this.files.setForeground(FilePropertiesDialog.this.labelColor);
/* 300 */             FilePropertiesDialog.this.size.setForeground(FilePropertiesDialog.this.labelColor);
/*     */           }
/*     */         });
/* 303 */     EventQueue.invokeLater(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\filechooser\FilePropertiesDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */