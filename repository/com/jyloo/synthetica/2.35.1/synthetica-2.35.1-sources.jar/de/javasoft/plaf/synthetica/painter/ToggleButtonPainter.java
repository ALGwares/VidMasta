/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class ToggleButtonPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ToggleButtonPainter";
/*     */   
/*     */   public static ToggleButtonPainter getInstance() {
/*  53 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ToggleButtonPainter getInstance(SynthContext paramSynthContext) {
/*  62 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ToggleButtonPainter.class, "Synthetica.ToggleButtonPainter"));
/*  63 */     if (syntheticaComponentPainter == null)
/*  64 */       syntheticaComponentPainter = getInstance(paramSynthContext, ToggleButtonPainter.class, "Synthetica.ToggleButtonPainter"); 
/*  65 */     return (ToggleButtonPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintToggleButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintToggleButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  77 */     if (!paintCheck(paramSynthContext))
/*     */       return; 
/*  80 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/*  81 */     int i = paramSynthContext.getComponentState();
/*  83 */     if ((i & 0x4) > 0 && (i & 0x2) > 0)
/*  84 */       i ^= 0x2; 
/*  86 */     String str = (String)SyntheticaLookAndFeel.getClientProperty("JButton.segmentPosition", abstractButton, "");
/*  87 */     if ((abstractButton.isBorderPainted() || abstractButton.getText() == null || abstractButton.getText().length() == 0) && SyntheticaLookAndFeel.isOpaque(abstractButton))
/*  88 */       paintToggleButtonBackground(abstractButton, new SyntheticaState(i), str, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   public void paintToggleButtonBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, String paramString, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 106 */     boolean bool = isToolBarButton(paramJComponent);
/* 107 */     boolean bool1 = (paramString != null && paramString.length() > 0) ? true : false;
/* 108 */     String str1 = createSuffix(paramString);
/* 110 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.toggleButton.border.insets", paramJComponent);
/* 111 */     Insets insets2 = insets1;
/* 112 */     String str2 = (bool && bool1) ? "Synthetica.toolBar.toggleButton" : "Synthetica.toggleButton";
/* 114 */     if (isToolBarButtonBarButton(paramJComponent)) {
/* 116 */       String str = "Synthetica.toolBar.buttonBar.toggleButton.border" + str1;
/* 117 */       if (paramSyntheticaState.isSet(SyntheticaState.State.PRESSED)) {
/* 118 */         str = String.valueOf(str) + ".pressed";
/*     */       } else {
/* 121 */         if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED))
/* 122 */           str = String.valueOf(str) + ".selected"; 
/* 123 */         if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER))
/* 124 */           str = String.valueOf(str) + ".hover"; 
/*     */       } 
/* 126 */       if (SyntheticaLookAndFeel.get(str, paramJComponent) != null)
/* 127 */         str2 = "Synthetica.toolBar.buttonBar.toggleButton"; 
/*     */     } 
/* 130 */     str2 = String.valueOf(str2) + ".border";
/* 131 */     str2 = String.valueOf(str2) + str1;
/* 133 */     if (paramSyntheticaState.isSet(SyntheticaState.State.PRESSED) && SyntheticaLookAndFeel.get(String.valueOf(str2) + ".pressed", paramJComponent) != null) {
/* 134 */       str2 = String.valueOf(str2) + ".pressed";
/* 135 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED)) {
/* 136 */       str2 = String.valueOf(str2) + ".selected";
/*     */     } 
/* 137 */     if (!paramJComponent.isEnabled())
/* 138 */       str2 = String.valueOf(str2) + ".disabled"; 
/* 140 */     if (bool1) {
/* 142 */       if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER))
/* 143 */         str2 = String.valueOf(str2) + ".hover"; 
/* 147 */     } else if (bool && paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && !paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && !SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.buttons.paintBorder", paramJComponent)) {
/* 148 */       str2 = "Synthetica.toolBar.button.border.hover";
/* 149 */     } else if (bool && paramSyntheticaState.isSet(SyntheticaState.State.PRESSED)) {
/* 150 */       str2 = "Synthetica.toolBar.button.border.pressed";
/* 151 */     } else if (bool && !paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && !SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.buttons.paintBorder", paramJComponent)) {
/* 152 */       str2 = "Synthetica.toolBar.button.border";
/* 153 */     } else if (bool && paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && !paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && 
/* 154 */       SyntheticaLookAndFeel.getString("Synthetica.toolBar.toggleButton.border.selected", paramJComponent) != null) {
/* 155 */       str2 = "Synthetica.toolBar.toggleButton.border.selected";
/* 156 */     } else if (bool && paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && 
/* 157 */       SyntheticaLookAndFeel.getString("Synthetica.toolBar.toggleButton.border.selectedAndHover", paramJComponent) != null) {
/* 158 */       str2 = "Synthetica.toolBar.toggleButton.border.selectedAndHover";
/* 159 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER)) {
/* 160 */       str2 = String.valueOf(str2) + ".hover";
/*     */     } 
/* 164 */     if (paramJComponent.hasFocus() && SyntheticaLookAndFeel.get(String.valueOf(str2) + ".focused", paramJComponent) != null)
/* 165 */       str2 = String.valueOf(str2) + ".focused"; 
/* 167 */     str2 = SyntheticaLookAndFeel.getString(str2, paramJComponent);
/* 168 */     if (str2 != null) {
/* 171 */       int i = 0;
/* 172 */       int j = 0;
/* 173 */       int k = 0;
/* 174 */       if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER)) {
/* 176 */         i = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.hover.animation.cycles", paramJComponent, 1);
/* 177 */         j = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.hover.animation.delay", paramJComponent, 50);
/* 178 */         k = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.hover.animation.type", paramJComponent, 1);
/*     */       } else {
/* 182 */         i = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.animation.cycles", paramJComponent, 1);
/* 183 */         j = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.animation.delay", paramJComponent, 50);
/* 184 */         k = SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.animation.type", paramJComponent, 2);
/*     */       } 
/* 186 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, i, j, k, paramSyntheticaState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, 
/* 187 */           0, 0);
/* 189 */       imagePainter.draw();
/*     */     } 
/* 193 */     if (paramJComponent.hasFocus() && ((AbstractButton)paramJComponent).isFocusPainted())
/* 194 */       paintFocus(paramJComponent, paramSyntheticaState, paramString, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   protected void paintFocus(JComponent paramJComponent, SyntheticaState paramSyntheticaState, String paramString, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 212 */     String str1 = createSuffix(paramString);
/* 213 */     String str2 = "focus.toggleButton" + str1;
/* 214 */     if (isToolBarButton(paramJComponent)) {
/* 215 */       str2 = String.valueOf(str2) + ".toolBar";
/* 216 */     } else if (isToolBarButtonBarButton(paramJComponent)) {
/* 217 */       str2 = String.valueOf(str2) + ".buttonBar.toolBar";
/*     */     } 
/* 219 */     FocusPainter.paintFocus(str2, paramJComponent, paramSyntheticaState.getState(), null, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   private String createSuffix(String paramString) {
/* 224 */     return (paramString == null || paramString.length() == 0) ? "" : (paramString.startsWith(".") ? paramString : ("." + paramString));
/*     */   }
/*     */   
/*     */   protected boolean paintCheck(SynthContext paramSynthContext) {
/* 235 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/* 236 */     int i = paramSynthContext.getComponentState();
/* 238 */     boolean bool1 = ((i & 0x2) > 0) ? true : false;
/* 239 */     boolean bool2 = ((i & 0x200) > 0) ? true : false;
/* 240 */     boolean bool3 = ((i & 0x4) > 0) ? true : false;
/* 241 */     boolean bool = isToolBarButton(abstractButton);
/* 243 */     if (bool)
/* 245 */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.buttons.paintBorder", abstractButton) && 
/* 246 */         SyntheticaLookAndFeel.get("Synthetica.toolBar.toggleButton.border", abstractButton) == null && 
/* 247 */         !bool1 && !bool2 && (!bool3 || !SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.button.pressed.paintBorder", abstractButton)))
/* 248 */         return false;  
/* 251 */     if (abstractButton.isBorderPainted() || abstractButton.getText() == null || abstractButton.getText().length() == 0) {
/* 253 */       if (!abstractButton.isBorderPainted() && !bool1 && !bool2)
/* 254 */         return false; 
/* 255 */       if (!abstractButton.isContentAreaFilled())
/* 256 */         return false; 
/* 258 */     } else if (!abstractButton.isBorderPainted()) {
/* 259 */       return false;
/*     */     } 
/* 261 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isToolBarButton(JComponent paramJComponent) {
/* 266 */     Boolean bool = (Boolean)paramJComponent.getClientProperty("Synthetica.useToolBarStyle");
/* 267 */     return (bool == null || bool.booleanValue()) ? (paramJComponent.getParent() instanceof javax.swing.JToolBar) : false;
/*     */   }
/*     */   
/*     */   private boolean isToolBarButtonBarButton(JComponent paramJComponent) {
/* 272 */     Container container = paramJComponent.getParent();
/* 273 */     return (container != null && container.getParent() instanceof javax.swing.JToolBar && "ButtonBar".equals(SyntheticaLookAndFeel.getStyleName(container)));
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 279 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/* 280 */     String str = (String)abstractButton.getClientProperty("JButton.segmentPosition");
/* 281 */     Border border = abstractButton.getBorder();
/* 283 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 284 */     i = (str == null) ? i : (31 * i + str.hashCode());
/* 285 */     i = (border == null) ? i : (31 * i + (abstractButton.isBorderPainted() ? 0 : 1));
/* 286 */     i = 31 * i + (abstractButton.isContentAreaFilled() ? 0 : 1);
/* 287 */     i = 31 * i + ((abstractButton.getParent() instanceof javax.swing.JToolBar) ? 0 : 1);
/* 289 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ToggleButtonPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */