/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.GraphicsUtils;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.java2d.Synthetica2DUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class RadioButtonStyle extends StyleWrapper {
/*  38 */   private static RadioButtonStyle instance = new RadioButtonStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  46 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  48 */       instance.setStyle(paramSynthStyle);
/*  49 */       return instance;
/*     */     } 
/*  51 */     RadioButtonStyle radioButtonStyle = new RadioButtonStyle();
/*  52 */     radioButtonStyle.setStyle(paramSynthStyle);
/*  53 */     return radioButtonStyle;
/*     */   }
/*     */   
/*     */   public Icon getIcon(SynthContext paramSynthContext, Object paramObject) {
/*  72 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/*  73 */     if (abstractButton.getIcon() != null)
/*  74 */       return null; 
/*  78 */     int i = paramSynthContext.getComponentState();
/*  79 */     Boolean bool = (Boolean)abstractButton.getClientProperty("Synthetica.MOUSE_OVER");
/*  80 */     boolean bool1 = (bool == null) ? false : bool.booleanValue();
/*  86 */     Icon icon = null;
/*  87 */     if ((i & 0x4) > 0) {
/*  90 */       boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.radioButton.emulatedPressedState.enabled", abstractButton);
/*  91 */       boolean bool3 = abstractButton.isSelected();
/*  93 */       if (bool2)
/*  94 */         icon = SyntheticaLookAndFeel.loadIcon(bool3 ? "Synthetica.radioButton.selected.image" : "Synthetica.radioButton.image"); 
/*  95 */       if (icon == null)
/*  96 */         icon = this.synthStyle.getIcon(new SynthContext(abstractButton, paramSynthContext.getRegion(), paramSynthContext.getStyle(), bool3 ? 516 : 4), paramObject); 
/*  97 */       if (bool2) {
/*  99 */         BufferedImage bufferedImage1 = (BufferedImage)GraphicsUtils.iconToImage(paramSynthContext, icon);
/* 100 */         Color color = SyntheticaLookAndFeel.getColor("Synthetica.radioButton.emulatedPressedState.color", abstractButton, UIManager.getColor("Panel.background").darker());
/* 101 */         float f = SyntheticaLookAndFeel.getInt("Synthetica.radioButton.emulatedPressedState.alpha", abstractButton, 25) / 100.0F;
/* 102 */         BufferedImage bufferedImage2 = Synthetica2DUtils.createColorizedImage(bufferedImage1, color, f);
/* 103 */         icon = new ImageIcon(bufferedImage2);
/*     */       } 
/* 106 */     } else if ((i & 0x200) > 0 && bool1) {
/* 107 */       icon = this.synthStyle.getIcon(new SynthContext(abstractButton, paramSynthContext.getRegion(), paramSynthContext.getStyle(), i | 0x2), paramObject);
/*     */     } else {
/* 109 */       icon = this.synthStyle.getIcon(paramSynthContext, paramObject);
/*     */     } 
/* 111 */     if (abstractButton.getClientProperty("Synthetica.background") != null) {
/* 113 */       float f = (abstractButton.getClientProperty("Synthetica.background.alpha") == null) ? 0.1F : ((Float)abstractButton.getClientProperty("Synthetica.background.alpha")).floatValue();
/* 114 */       BufferedImage bufferedImage1 = (BufferedImage)GraphicsUtils.iconToImage(paramSynthContext, icon);
/* 115 */       BufferedImage bufferedImage2 = Synthetica2DUtils.createColorizedImage(bufferedImage1, (Color)abstractButton.getClientProperty("Synthetica.background"), f);
/* 116 */       icon = new ImageIcon(bufferedImage2);
/*     */     } 
/* 118 */     return icon;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\RadioButtonStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */