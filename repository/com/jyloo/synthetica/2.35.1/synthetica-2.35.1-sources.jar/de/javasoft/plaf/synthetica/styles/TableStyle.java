/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import java.awt.FontMetrics;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class TableStyle extends StyleWrapper {
/* 36 */   private static TableStyle instance = new TableStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 44 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 46 */       instance.setStyle(paramSynthStyle);
/* 47 */       return instance;
/*    */     } 
/* 49 */     TableStyle tableStyle = new TableStyle();
/* 50 */     tableStyle.setStyle(paramSynthStyle);
/* 51 */     return tableStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 57 */     if (paramColorType == ColorType.BACKGROUND) {
/* 60 */       Color color = paramSynthContext.getComponent().getBackground();
/* 61 */       if (color != null && !(color instanceof javax.swing.plaf.UIResource))
/* 62 */         return color; 
/*    */     } 
/* 64 */     return super.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */   
/*    */   public Object get(SynthContext paramSynthContext, Object paramObject) {
/* 70 */     if ("Table.rowHeight".equals(paramObject)) {
/* 72 */       JComponent jComponent = paramSynthContext.getComponent();
/* 73 */       FontMetrics fontMetrics = jComponent.getFontMetrics(jComponent.getFont());
/* 74 */       int i = fontMetrics.getHeight();
/* 75 */       Integer integer = (Integer)this.synthStyle.get(paramSynthContext, paramObject);
/* 76 */       if (integer == null)
/* 77 */         return new Integer(i + 2); 
/* 79 */       return new Integer((int)SyntheticaLookAndFeel.scaleFontSize(integer.intValue()));
/*    */     } 
/* 81 */     if ("Table.dropLineColor".equals(paramObject))
/* 82 */       return UIManager.get("Table.dropLineColor"); 
/* 83 */     if ("Table.dropLineShortColor".equals(paramObject))
/* 84 */       return UIManager.get("Table.dropLineShortColor"); 
/* 85 */     return this.synthStyle.get(paramSynthContext, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\TableStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */