package de.javasoft.util;

public interface IVersion {
  int getMajor();
  
  int getMinor();
  
  int getRevision();
  
  int getBuild();
  
  String toString();
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasof\\util\IVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */