/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaIcon;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.plaf.UIResource;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ abstract class SyntheticaIconPainter extends SyntheticaIcon implements UIResource {
/*    */   public abstract int getIconHeight();
/*    */   
/*    */   public abstract int getIconWidth();
/*    */   
/*    */   public abstract void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2);
/*    */   
/*    */   public int getIconWidth(SynthContext paramSynthContext) {
/* 35 */     return getIconWidth();
/*    */   }
/*    */   
/*    */   public int getIconHeight(SynthContext paramSynthContext) {
/* 40 */     return getIconHeight();
/*    */   }
/*    */   
/*    */   public void paintIcon(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 45 */     paintIcon(paramSynthContext.getComponent(), paramGraphics, paramInt1, paramInt2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaIconPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */