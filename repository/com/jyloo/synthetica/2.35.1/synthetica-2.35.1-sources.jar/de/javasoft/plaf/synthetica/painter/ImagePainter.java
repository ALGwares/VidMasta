/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.java2d.Synthetica2DUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.RGBImageFilter;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public class ImagePainter {
/*  58 */   public static final Logger logger = Logger.getLogger(ImagePainter.class.getName());
/*     */   
/*     */   public static final int STRETCHED = 0;
/*     */   
/*     */   public static final int TILED = 1;
/*     */   
/*     */   private Graphics g;
/*     */   
/*     */   private int x;
/*     */   
/*     */   private int y;
/*     */   
/*     */   private int w;
/*     */   
/*     */   private int h;
/*     */   
/*     */   private int iw;
/*     */   
/*     */   private int ih;
/*     */   
/*     */   private Image image;
/*     */   
/*     */   private Insets sInsets;
/*     */   
/*     */   private Insets dInsets;
/*     */   
/*     */   private int xPolicy;
/*     */   
/*     */   private int yPolicy;
/*     */   
/*     */   private WeakReference<JComponent> weakComponent;
/*     */   
/*     */   private AnimationThreadFactory.AnimationThread animationThread;
/*     */   
/*     */   private String id;
/*     */   
/*  72 */   private int angle = 0;
/*     */   
/*     */   private boolean flipHorizontal;
/*     */   
/*     */   private boolean flipVertical;
/*     */   
/*     */   private boolean animationEnabled;
/*     */   
/*  77 */   private static long initDuration = -1L;
/*     */   
/*  78 */   private static int initOperations = 0;
/*     */   
/*  79 */   private static long paintDuration = 0L;
/*     */   
/*  80 */   private static int paintOperations = 0;
/*     */   
/*  81 */   private static HashMap<String, Image> imageCache = new HashMap<String, Image>();
/*     */   
/*  82 */   private static boolean debug = SyntheticaLookAndFeel.isSystemPropertySet("synthetica.debug");
/*     */   
/*     */   private static final String SYNTHETICA_BACKGROUND = "Synthetica.background";
/*     */   
/*     */   private static final String SYNTHETICA_BACKGROUND_ALPHA = "Synthetica.background.alpha";
/*     */   
/*  86 */   private static final boolean RESPECT_PARENT_BACKGROUND = SyntheticaLookAndFeel.getBoolean("Synthetica.background.respectParent", null, false);
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Graphics paramGraphics, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String paramString, Insets paramInsets1, Insets paramInsets2, int paramInt9, int paramInt10) {
/* 110 */     this(paramJComponent, null, paramInt1, paramInt2, paramInt3, paramInt4, paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8, paramString, paramInsets1, paramInsets2, paramInt9, paramInt10);
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, String paramString1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Graphics paramGraphics, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String paramString2, Insets paramInsets1, Insets paramInsets2, int paramInt9, int paramInt10) {
/* 138 */     this(paramJComponent, paramString1, paramInt1, paramInt2, paramInt3, paramInt4, paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8, paramString2, paramInsets1, paramInsets2, paramInt9, paramInt10, false, false);
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, String paramString1, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Graphics paramGraphics, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String paramString2, Insets paramInsets1, Insets paramInsets2, int paramInt9, int paramInt10, boolean paramBoolean1, boolean paramBoolean2) {
/* 168 */     if (logger.isLoggable(Level.FINE))
/* 169 */       logger.log(Level.FINE, "Image Path: " + paramString2); 
/* 170 */     if (!debug && paramString2 == null)
/*     */       return; 
/* 172 */     if (debug && initDuration == -1L) {
/* 177 */       Frame[] arrayOfFrame = Frame.getFrames();
/* 178 */       for (byte b1 = 0; b1 < arrayOfFrame.length; b1++) {
/* 180 */         if (arrayOfFrame[b1] instanceof JFrame)
/* 182 */           ((JFrame)arrayOfFrame[b1]).getRootPane().registerKeyboardAction(
/* 183 */               new ActionListener() {
/*     */                 public void actionPerformed(ActionEvent param1ActionEvent) {
/* 187 */                   System.out.println("inits: " + ImagePainter.initOperations + " in " + ImagePainter
/* 188 */                       .initDuration + " ms");
/* 189 */                   System.out.println("paint: " + ImagePainter.paintOperations + " in " + ImagePainter
/* 190 */                       .paintDuration + " ms");
/* 191 */                   ImagePainter.initDuration = 0L;
/* 192 */                   ImagePainter.initOperations = 0;
/* 193 */                   ImagePainter.paintDuration = 0L;
/* 194 */                   ImagePainter.paintOperations = 0;
/* 196 */                   Frame[] arrayOfFrame = Frame.getFrames();
/* 197 */                   for (byte b = 0; b < arrayOfFrame.length; b++) {
/* 199 */                     Frame frame = arrayOfFrame[b];
/* 200 */                     if (frame instanceof JFrame && (
/* 201 */                       (JFrame)frame).getRootPane() != null) {
/* 203 */                       frame.setSize(640, 550);
/* 204 */                       frame.validate();
/* 205 */                       ((JFrame)frame).getRootPane().repaint();
/*     */                     } 
/*     */                   } 
/*     */                 }
/* 209 */               }"durationAction", 
/* 210 */               KeyStroke.getKeyStroke(123, 10), 
/* 211 */               1); 
/*     */       } 
/*     */     } 
/* 215 */     long l = System.currentTimeMillis();
/* 217 */     if (paramString1 == null)
/* 217 */       paramString1 = "null"; 
/* 218 */     this.id = paramString1;
/* 219 */     this.flipHorizontal = paramBoolean1;
/* 220 */     this.flipVertical = paramBoolean2;
/* 221 */     if (paramJComponent != null) {
/* 223 */       this.weakComponent = new WeakReference<JComponent>(paramJComponent);
/* 224 */       if (paramJComponent.getClientProperty("Synthetica.flipHorizontal") != null && ((Boolean)paramJComponent.getClientProperty("Synthetica.flipHorizontal")).booleanValue())
/* 225 */         this.flipHorizontal = true; 
/* 226 */       if (paramJComponent.getClientProperty("Synthetica.flipVertical") != null && ((Boolean)paramJComponent.getClientProperty("Synthetica.flipVertical")).booleanValue())
/* 227 */         this.flipVertical = true; 
/*     */     } 
/* 229 */     if (this.flipHorizontal) {
/* 231 */       paramInsets1 = flipLeftRight(paramInsets1);
/* 232 */       paramInsets2 = flipLeftRight(paramInsets2);
/*     */     } 
/* 234 */     if (this.flipVertical) {
/* 236 */       paramInsets1 = flipTopBottom(paramInsets1);
/* 237 */       paramInsets2 = flipTopBottom(paramInsets2);
/*     */     } 
/* 240 */     String[] arrayOfString1 = paramString2.split(",");
/* 241 */     this.animationEnabled = isAnimationEnabled(paramJComponent);
/* 242 */     if (this.animationEnabled && paramJComponent != null && paramInt2 > 0) {
/* 244 */       AnimationThreadFactory.AnimationThread animationThread = AnimationThreadFactory.createThread(paramInt2);
/* 245 */       Rectangle rectangle = new Rectangle(paramInt5, paramInt6, paramInt7, paramInt8);
/* 247 */       if (paramJComponent instanceof JTabbedPane && !paramString1.equals("null"))
/* 248 */         rectangle = ((JTabbedPane)paramJComponent).getBoundsAt(Integer.parseInt(paramString1.split("/")[1])); 
/* 249 */       animationThread.addComponent(paramJComponent, this.id, paramInt4, paramInt3, arrayOfString1, paramInt1, rectangle);
/* 250 */       this.animationThread = animationThread;
/*     */     } 
/* 253 */     this.g = paramGraphics;
/* 254 */     this.x = paramInt5;
/* 255 */     this.y = paramInt6;
/* 256 */     this.w = paramInt7;
/* 257 */     this.h = paramInt8;
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString2;
/* 259 */     for (i = (arrayOfString2 = arrayOfString1).length, b = 0; b < i; ) {
/* 259 */       String str = arrayOfString2[b];
/* 261 */       this.image = imageCache.get(str);
/* 262 */       if (this.image == null) {
/* 264 */         URL uRL = SyntheticaLookAndFeel.class.getResource(str);
/* 265 */         if (uRL == null)
/* 266 */           throw new RuntimeException("File not found: " + str); 
/*     */         try {
/* 271 */           this.image = toCompatibleImage(ImageIO.read(uRL));
/* 273 */         } catch (IOException iOException) {
/* 275 */           throw new RuntimeException(iOException);
/*     */         } 
/* 277 */         imageCache.put(str, this.image);
/*     */       } 
/*     */       b++;
/*     */     } 
/* 285 */     this.iw = this.image.getWidth(null);
/* 286 */     this.ih = this.image.getHeight(null);
/* 287 */     this.sInsets = paramInsets1;
/* 288 */     this.dInsets = paramInsets2;
/* 289 */     this.xPolicy = paramInt9;
/* 290 */     this.yPolicy = paramInt10;
/* 292 */     if (debug) {
/* 294 */       long l1 = System.currentTimeMillis();
/* 295 */       long l2 = l1 - l;
/* 296 */       initDuration += l2;
/* 297 */       initOperations++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Insets flipLeftRight(Insets paramInsets) {
/* 303 */     if (paramInsets == null)
/* 304 */       return null; 
/* 305 */     return new Insets(paramInsets.top, paramInsets.right, paramInsets.bottom, paramInsets.left);
/*     */   }
/*     */   
/*     */   private Insets flipTopBottom(Insets paramInsets) {
/* 310 */     if (paramInsets == null)
/* 311 */       return null; 
/* 312 */     return new Insets(paramInsets.bottom, paramInsets.left, paramInsets.top, paramInsets.right);
/*     */   }
/*     */   
/*     */   private boolean isAnimationEnabled(JComponent paramJComponent) {
/* 317 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.animation.enabled", paramJComponent, true);
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, Insets paramInsets1, Insets paramInsets2, int paramInt5, int paramInt6) {
/* 338 */     this(paramJComponent, -1, -1, -1, -1, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramString, paramInsets1, paramInsets2, paramInt5, paramInt6);
/*     */   }
/*     */   
/*     */   public ImagePainter(Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, Insets paramInsets1, Insets paramInsets2, int paramInt5, int paramInt6) {
/* 358 */     this(null, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramString, paramInsets1, paramInsets2, paramInt5, paramInt6);
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, int paramInt1, int paramInt2, int paramInt3, Insets paramInsets1, Graphics paramGraphics, int paramInt4, int paramInt5, int paramInt6, int paramInt7, String paramString, Insets paramInsets2, Insets paramInsets3, int paramInt8, int paramInt9) {
/* 386 */     this(paramJComponent, paramInt1, paramInt2, paramInt3, paramInsets1, paramGraphics, paramInt4, paramInt5, paramInt6, paramInt7, paramString, paramInsets2, paramInsets3, paramInt8, paramInt9, false, false);
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, int paramInt1, int paramInt2, int paramInt3, Insets paramInsets1, Graphics paramGraphics, int paramInt4, int paramInt5, int paramInt6, int paramInt7, String paramString, Insets paramInsets2, Insets paramInsets3, int paramInt8, int paramInt9, boolean paramBoolean1, boolean paramBoolean2) {
/* 416 */     this(paramJComponent, null, -1, -1, -1, -1, paramGraphics, paramInt4, paramInt5, paramInt6, paramInt7, paramString, paramInsets2, paramInsets3, paramInt8, paramInt9, paramBoolean1, paramBoolean2);
/* 417 */     if (!debug && paramString == null)
/*     */       return; 
/* 420 */     Image image = imageCache.get(paramString);
/* 421 */     if (image == null || !(image instanceof BufferedImage))
/*     */       try {
/* 426 */         image = toCompatibleImage(ImageIO.read(SyntheticaLookAndFeel.class.getResource(paramString)));
/* 427 */         imageCache.put(paramString, image);
/* 429 */       } catch (Exception exception) {
/* 431 */         exception.printStackTrace();
/*     */       }  
/* 434 */     this.image = paramJComponent.createImage(new FilteredImageSource(image.getSource(), new Colorizer(0, paramInt1, paramInt2, paramInt3, image.getWidth(null), image.getHeight(null), paramInsets1)));
/*     */   }
/*     */   
/*     */   public ImagePainter(JComponent paramJComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, Insets paramInsets1, Insets paramInsets2, Insets paramInsets3, Insets paramInsets4, int paramInt5, int paramInt6) {
/* 441 */     this(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramString, paramInsets1, paramInsets2, paramInt5, paramInt6);
/* 442 */     String str = String.valueOf(paramString) + "_EXCLUDED_OUTER_INSETS";
/* 443 */     Image image = imageCache.get(str);
/* 444 */     if (image == null) {
/* 446 */       int i = this.iw - paramInsets1.left - paramInsets1.right;
/* 447 */       int j = this.ih - paramInsets1.top - paramInsets1.bottom;
/* 448 */       BufferedImage bufferedImage = new BufferedImage(i, j, 2);
/* 449 */       Graphics2D graphics2D = bufferedImage.createGraphics();
/* 450 */       this.g = graphics2D;
/* 451 */       this.x = 0;
/* 452 */       this.y = 0;
/* 453 */       this.w = i;
/* 454 */       this.h = j;
/* 455 */       draw();
/* 456 */       graphics2D.dispose();
/* 457 */       imageCache.put(str, bufferedImage);
/* 458 */       image = bufferedImage;
/* 459 */       this.g = paramGraphics;
/* 460 */       this.x = paramInt1;
/* 461 */       this.y = paramInt2;
/* 462 */       this.w = paramInt3;
/* 463 */       this.h = paramInt4;
/*     */     } 
/* 465 */     this.image = image;
/* 466 */     this.iw = image.getWidth(null);
/* 467 */     this.ih = image.getHeight(null);
/* 468 */     this.sInsets = paramInsets3;
/* 469 */     this.dInsets = paramInsets4;
/*     */   }
/*     */   
/*     */   public ImagePainter(Image paramImage, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Insets paramInsets1, Insets paramInsets2) {
/* 475 */     this.image = paramImage;
/* 476 */     this.iw = paramImage.getWidth(null);
/* 477 */     this.ih = paramImage.getHeight(null);
/* 479 */     this.g = paramGraphics;
/* 480 */     this.x = paramInt1;
/* 481 */     this.y = paramInt2;
/* 482 */     this.w = paramInt3;
/* 483 */     this.h = paramInt4;
/* 484 */     this.sInsets = paramInsets1;
/* 485 */     this.dInsets = paramInsets2;
/*     */   }
/*     */   
/*     */   public static void clearImageCache() {
/* 493 */     imageCache.clear();
/*     */   }
/*     */   
/*     */   public void setAngle(int paramInt) {
/* 501 */     this.angle = paramInt;
/* 502 */     if (this.animationThread != null && this.weakComponent != null && !(this.weakComponent.get() instanceof JTabbedPane) && paramInt != 0)
/* 503 */       this.animationThread.rotateRepaintRect(this.weakComponent.get(), this.id); 
/*     */   }
/*     */   
/*     */   public void draw() {
/* 514 */     drawBorder();
/* 516 */     drawCenter();
/*     */   }
/*     */   
/*     */   public void drawBorder() {
/* 524 */     drawTopLeft();
/* 525 */     drawTopCenter();
/* 526 */     drawTopRight();
/* 527 */     drawLeft();
/* 528 */     drawRight();
/* 529 */     drawBottomLeft();
/* 530 */     drawBottomCenter();
/* 531 */     drawBottomRight();
/*     */   }
/*     */   
/*     */   public void drawCenter() {
/* 544 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 545 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 547 */     if (this.dInsets == null || this.sInsets == null)
/*     */       return; 
/* 548 */     drawImage(this.image, this.g, 
/* 549 */         this.x + this.dInsets.left, this.y + this.dInsets.top, this.x + this.w - this.dInsets.right, this.y + this.h - this.dInsets.bottom, 
/* 550 */         this.sInsets.left, this.sInsets.top, this.iw - this.sInsets.right, this.ih - this.sInsets.bottom, 
/* 551 */         this.xPolicy, this.yPolicy);
/*     */   }
/*     */   
/*     */   public void drawTopLeft() {
/* 560 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 561 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 566 */     drawImage(this.image, this.g, 
/* 567 */         this.x, this.y, this.x + this.dInsets.left, Math.min(this.y + this.h - this.dInsets.bottom, this.y + this.dInsets.top), 
/* 568 */         0, 0, this.sInsets.left, Math.min(this.h - this.sInsets.bottom, this.sInsets.top), 
/* 569 */         0, 0);
/*     */   }
/*     */   
/*     */   public void drawTopRight() {
/* 583 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 584 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 589 */     drawImage(this.image, this.g, 
/* 590 */         this.x + this.w - this.dInsets.right, this.y, this.x + this.w, Math.min(this.y + this.h - this.dInsets.bottom, this.y + this.dInsets.top), 
/* 591 */         this.iw - this.sInsets.right, 0, this.iw, Math.min(this.h - this.sInsets.bottom, this.sInsets.top), 
/* 592 */         0, 0);
/*     */   }
/*     */   
/*     */   public void drawBottomLeft() {
/* 606 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 607 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 612 */     drawImage(this.image, this.g, 
/* 613 */         this.x, this.y + this.h - this.dInsets.bottom, this.x + this.dInsets.left, this.y + this.h, 
/* 614 */         0, this.ih - this.sInsets.bottom, this.sInsets.left, this.ih, 
/* 615 */         0, 0);
/*     */   }
/*     */   
/*     */   public void drawBottomRight() {
/* 625 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 626 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 631 */     drawImage(this.image, this.g, 
/* 632 */         this.x + this.w - this.dInsets.right, this.y + this.h - this.dInsets.bottom, this.x + this.w, this.y + this.h, 
/* 633 */         this.iw - this.sInsets.right, this.ih - this.sInsets.bottom, this.iw, this.ih, 
/* 634 */         0, 0);
/*     */   }
/*     */   
/*     */   public void drawTopCenter() {
/* 644 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 645 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 650 */     drawImage(this.image, this.g, 
/* 651 */         this.x + this.dInsets.left, this.y, this.x + this.w - this.dInsets.right, Math.min(this.y + this.h - this.dInsets.bottom, this.y + this.dInsets.top), 
/* 652 */         this.sInsets.left, 0, this.iw - this.sInsets.right, Math.min(this.h - this.sInsets.bottom, this.sInsets.top), 
/* 653 */         this.xPolicy, this.yPolicy);
/*     */   }
/*     */   
/*     */   public void drawLeft() {
/* 667 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 668 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 673 */     drawImage(this.image, this.g, 
/* 674 */         this.x, this.y + this.dInsets.top, this.x + this.dInsets.left, this.y + this.h - this.dInsets.bottom, 
/* 675 */         0, this.sInsets.top, this.sInsets.left, this.ih - this.sInsets.bottom, 
/* 676 */         this.xPolicy, this.yPolicy);
/*     */   }
/*     */   
/*     */   public void drawRight() {
/* 686 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 687 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 692 */     drawImage(this.image, this.g, 
/* 693 */         this.x + this.w - this.dInsets.right, this.y + this.dInsets.top, this.x + this.w, this.y + this.h - this.dInsets.bottom, 
/* 694 */         this.iw - this.sInsets.right, this.sInsets.top, this.iw, this.ih - this.sInsets.bottom, 
/* 695 */         this.xPolicy, this.yPolicy);
/*     */   }
/*     */   
/*     */   public void drawBottomCenter() {
/* 705 */     if (this.animationEnabled && this.weakComponent != null && this.animationThread != null)
/* 706 */       this.image = imageCache.get(this.animationThread.getImagePath(this.weakComponent.get(), this.id)); 
/* 711 */     drawImage(this.image, this.g, 
/* 712 */         this.x + this.dInsets.left, this.y + this.h - this.dInsets.bottom, this.x + this.w - this.dInsets.right, this.y + this.h, 
/* 713 */         this.sInsets.left, this.ih - this.sInsets.bottom, this.iw - this.sInsets.right, this.ih, 
/* 714 */         this.xPolicy, this.yPolicy);
/*     */   }
/*     */   
/*     */   private void drawImage(Image paramImage, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10) {
/* 726 */     if (paramImage == null)
/*     */       return; 
/* 729 */     if (this.angle != 0)
/* 730 */       rotateGraphics(paramGraphics, true); 
/* 732 */     if (this.flipHorizontal)
/* 733 */       paramImage = Synthetica2DUtils.flipHorizontal(paramImage); 
/* 734 */     if (this.flipVertical)
/* 735 */       paramImage = Synthetica2DUtils.flipVertical(paramImage); 
/* 738 */     if (this.weakComponent != null) {
/* 740 */       JComponent jComponent = this.weakComponent.get();
/* 741 */       Color color = RESPECT_PARENT_BACKGROUND ? jComponent.getBackground() : (jComponent.isBackgroundSet() ? jComponent.getBackground() : null);
/* 742 */       float f = SyntheticaLookAndFeel.getInt("Synthetica.background.alpha", jComponent, 10) / 100.0F;
/* 744 */       if (jComponent.getClientProperty("Synthetica.background") != null || (
/* 745 */         color != null && !(color instanceof javax.swing.plaf.ColorUIResource) && !(color instanceof java.awt.SystemColor))) {
/* 747 */         if (!(paramImage instanceof BufferedImage)) {
/* 749 */           BufferedImage bufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
/* 750 */           bufferedImage.getGraphics().drawImage(paramImage, 0, 0, null);
/* 751 */           paramImage = bufferedImage;
/*     */         } 
/* 753 */         if (jComponent.getClientProperty("Synthetica.background") != null)
/* 754 */           color = (Color)jComponent.getClientProperty("Synthetica.background"); 
/* 755 */         if (jComponent.getClientProperty("Synthetica.background.alpha") != null)
/* 756 */           f = ((Float)jComponent.getClientProperty("Synthetica.background.alpha")).floatValue(); 
/* 757 */         byte b = (color == null) ? 255 : color.getAlpha();
/* 758 */         if (b < 'ÿ')
/* 759 */           f = 0.99999F; 
/* 760 */         paramImage = Synthetica2DUtils.createColorizedImage((BufferedImage)paramImage, color, f);
/*     */       } 
/*     */     } 
/* 764 */     long l1 = System.currentTimeMillis();
/* 765 */     if (paramInt9 == 0 && paramInt10 == 0) {
/* 767 */       paramGraphics.drawImage(paramImage, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramInt7, paramInt8, null);
/*     */     } else {
/* 772 */       int i = paramInt1;
/* 773 */       int j = paramInt7 - paramInt5;
/* 774 */       int k = paramInt8 - paramInt6;
/* 776 */       for (; paramInt2 < paramInt4; paramInt2 += k) {
/* 778 */         for (; paramInt1 < paramInt3; paramInt1 += j) {
/* 780 */           int m = paramInt3;
/* 781 */           if (paramInt9 == 1)
/* 782 */             m = Math.min(paramInt3, paramInt1 + j); 
/* 784 */           int n = paramInt4;
/* 785 */           if (paramInt10 == 1)
/* 786 */             n = Math.min(paramInt4, paramInt2 + k); 
/* 789 */           int i1 = (paramInt9 == 1) ? Math.min(paramInt7, paramInt5 + m - paramInt1) : paramInt7;
/* 790 */           int i2 = (paramInt10 == 1) ? Math.min(paramInt8, paramInt6 + n - paramInt2) : paramInt8;
/* 792 */           paramGraphics.drawImage(paramImage, paramInt1, paramInt2, m, n, paramInt5, paramInt6, i1, i2, null);
/* 794 */           if (paramInt9 == 0)
/*     */             break; 
/*     */         } 
/* 796 */         if (paramInt10 == 0)
/*     */           break; 
/* 797 */         paramInt1 = i;
/*     */       } 
/*     */     } 
/* 800 */     if (this.angle != 0)
/* 801 */       rotateGraphics(paramGraphics, false); 
/* 803 */     long l2 = System.currentTimeMillis();
/* 804 */     long l3 = l2 - l1;
/* 805 */     if (debug && l3 > 100L)
/* 807 */       System.out.println("Paint performance lack: " + l3 + " ms " + findImage(paramImage)); 
/* 812 */     paintDuration += l3;
/* 813 */     paintOperations++;
/*     */   }
/*     */   
/*     */   private void rotateGraphics(Graphics paramGraphics, boolean paramBoolean) {
/* 819 */     Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 820 */     if (paramBoolean) {
/* 822 */       graphics2D.translate((this.angle > 0) ? this.h : 0, (this.angle > 0) ? 0 : this.w);
/* 823 */       graphics2D.rotate(Math.toRadians(this.angle), this.x, this.y);
/*     */     } else {
/* 827 */       graphics2D.rotate(Math.toRadians(-this.angle), this.x, this.y);
/* 828 */       graphics2D.translate((this.angle > 0) ? -this.h : 0, (this.angle > 0) ? 0 : -this.w);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String findImage(Image paramImage) {
/* 837 */     String str = null;
/* 838 */     Set<Map.Entry<String, Image>> set = imageCache.entrySet();
/* 839 */     for (Map.Entry<String, Image> entry : set) {
/* 842 */       if (entry.getValue() == paramImage) {
/* 844 */         str = (String)entry.getKey();
/*     */         break;
/*     */       } 
/*     */     } 
/* 848 */     return str;
/*     */   }
/*     */   
/*     */   private BufferedImage toCompatibleImage(Image paramImage) {
/* 853 */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 854 */     GraphicsDevice graphicsDevice = graphicsEnvironment.getDefaultScreenDevice();
/* 855 */     GraphicsConfiguration graphicsConfiguration = graphicsDevice.getDefaultConfiguration();
/* 856 */     BufferedImage bufferedImage = graphicsConfiguration.createCompatibleImage(paramImage.getWidth(null), paramImage.getHeight(null), 3);
/* 857 */     Graphics graphics = bufferedImage.getGraphics();
/* 858 */     graphics.drawImage(paramImage, 0, 0, null);
/* 859 */     graphics.dispose();
/* 860 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   private static class Colorizer extends RGBImageFilter {
/*     */     private int a;
/*     */     
/*     */     private int r;
/*     */     
/*     */     private int g;
/*     */     
/*     */     private int b;
/*     */     
/*     */     private int w;
/*     */     
/*     */     private int h;
/*     */     
/*     */     private Insets insets;
/*     */     
/*     */     public Colorizer(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, Insets param1Insets) {
/* 874 */       this.canFilterIndexColorModel = true;
/* 875 */       this.a = param1Int1;
/* 876 */       this.r = param1Int2;
/* 877 */       this.g = param1Int3;
/* 878 */       this.b = param1Int4;
/* 879 */       this.w = param1Int5;
/* 880 */       this.h = param1Int6;
/* 881 */       this.insets = param1Insets;
/*     */     }
/*     */     
/*     */     public int filterRGB(int param1Int1, int param1Int2, int param1Int3) {
/* 886 */       if (param1Int1 < this.insets.left || param1Int1 > this.w - this.insets.right - 1 || 
/* 887 */         param1Int2 < this.insets.top || param1Int2 > this.h - this.insets.bottom - 1)
/* 888 */         return param1Int3; 
/* 889 */       Color color = new Color(param1Int3, true);
/* 890 */       int i = Math.min(Math.max(color.getRed() + color.getRed() * this.r / 100, 0), 255);
/* 891 */       int j = Math.min(Math.max(color.getGreen() + color.getGreen() * this.g / 100, 0), 255);
/* 892 */       int k = Math.min(Math.max(color.getBlue() + color.getBlue() * this.b / 100, 0), 255);
/* 893 */       int m = Math.min(Math.max(color.getAlpha() + color.getAlpha() * this.a / 100, 0), 255);
/* 894 */       return (new Color(i, j, k, m)).getRGB();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ImagePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */