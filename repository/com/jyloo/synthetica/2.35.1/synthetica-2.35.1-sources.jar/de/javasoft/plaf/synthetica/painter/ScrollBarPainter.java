/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class ScrollBarPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ScrollBarPainter";
/*     */   
/*  52 */   private static HashMap<String, Image> imgCache = new HashMap<String, Image>();
/*     */   
/*     */   public static ScrollBarPainter getInstance() {
/*  66 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ScrollBarPainter getInstance(SynthContext paramSynthContext) {
/*  75 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ScrollBarPainter.class, "Synthetica.ScrollBarPainter"));
/*  76 */     if (syntheticaComponentPainter == null)
/*  77 */       syntheticaComponentPainter = getInstance(paramSynthContext, ScrollBarPainter.class, "Synthetica.ScrollBarPainter"); 
/*  78 */     return (ScrollBarPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintScrollBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintScrollBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintScrollBarThumbBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*     */   
/*     */   public void paintScrollBarTrackBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintScrollBarThumbBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 102 */     if (paramInt3 < 4 || paramInt4 < 4)
/*     */       return; 
/* 104 */     JScrollBar jScrollBar = (JScrollBar)paramSynthContext.getComponent();
/* 105 */     int i = paramSynthContext.getComponentState();
/* 106 */     boolean bool = ((i & 0x2) > 0);
/* 107 */     boolean bool1 = (jScrollBar.getClientProperty("Synthetica.MOUSE_PRESSED") == null) ? false : (((Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_PRESSED")).booleanValue() & bool);
/* 108 */     boolean bool2 = (jScrollBar.getOrientation() == 1 && !jScrollBar.getComponentOrientation().isLeftToRight()) ? true : false;
/* 111 */     Rectangle rectangle = (Rectangle)jScrollBar.getClientProperty("Synthetica.scrollBarTrack.bounds");
/* 112 */     if (rectangle == null)
/* 113 */       rectangle = new Rectangle(); 
/* 114 */     SynthStyle synthStyle = SynthLookAndFeel.getStyle(jScrollBar, Region.SCROLL_BAR);
/* 115 */     SynthContext synthContext = new SynthContext(jScrollBar, Region.SCROLL_BAR, synthStyle, 0);
/* 116 */     Dimension dimension = (Dimension)synthStyle.get(synthContext, "ScrollBar.minimumThumbSize");
/* 117 */     if ((paramInt5 == 1 && rectangle.height < dimension.height) || (
/* 118 */       paramInt5 == 0 && rectangle.width < dimension.width))
/*     */       return; 
/* 121 */     UIKey uIKey = new UIKey("scrollBarThumb." + ((paramInt5 == 0) ? "x" : "y"), new SyntheticaState(i));
/* 122 */     Insets insets1 = (Insets)uIKey.findProperty(paramSynthContext, "background.insets", true, 2);
/* 123 */     Insets insets2 = insets1;
/* 125 */     String str1 = null;
/* 126 */     String str2 = "Synthetica.scrollBarThumb";
/* 127 */     if (paramInt5 == 0) {
/* 129 */       str1 = String.valueOf(str2) + ".x.grip";
/* 130 */       str2 = String.valueOf(str2) + ".x.background";
/* 131 */       if (JAVA5 && paramInt3 < insets1.left + insets1.right) {
/* 133 */         insets1 = new Insets(4, 4, 4, 4);
/* 134 */         insets2 = insets1;
/*     */       } 
/*     */     } else {
/* 139 */       str1 = String.valueOf(str2) + ".y.grip";
/* 140 */       str2 = String.valueOf(str2) + ".y.background";
/* 141 */       if (JAVA5 && paramInt4 < insets1.top + insets1.bottom) {
/* 143 */         insets1 = new Insets(4, 4, 4, 4);
/* 144 */         insets2 = insets1;
/*     */       } 
/*     */     } 
/* 148 */     if (bool1 && SyntheticaLookAndFeel.get(String.valueOf(str2) + ".pressed", jScrollBar) != null) {
/* 150 */       str2 = String.valueOf(str2) + ".pressed";
/* 151 */       if (SyntheticaLookAndFeel.get(String.valueOf(str1) + ".pressed", jScrollBar) != null)
/* 152 */         str1 = String.valueOf(str1) + ".pressed"; 
/* 154 */     } else if (bool) {
/* 156 */       str2 = String.valueOf(str2) + ".hover";
/* 158 */       if (SyntheticaLookAndFeel.get(String.valueOf(str1) + ".hover", jScrollBar) != null)
/* 159 */         str1 = String.valueOf(str1) + ".hover"; 
/*     */     } 
/* 162 */     str2 = SyntheticaLookAndFeel.getString(str2, jScrollBar);
/* 163 */     int j = 0;
/* 164 */     int k = 0;
/* 165 */     int m = 0;
/* 166 */     if (bool) {
/* 168 */       j = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.hover.animation.cycles", jScrollBar, 1);
/* 169 */       k = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.hover.animation.delay", jScrollBar, 50);
/* 170 */       m = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.hover.animation.type", jScrollBar, 1);
/*     */     } else {
/* 174 */       j = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.animation.cycles", jScrollBar, 1);
/* 175 */       k = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.animation.delay", jScrollBar, 50);
/* 176 */       m = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarThumb.animation.type", jScrollBar, 2);
/*     */     } 
/* 178 */     ImagePainter imagePainter = new ImagePainter(jScrollBar, "thumb", j, k, m, i, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, 0, 0, bool2, false);
/* 180 */     imagePainter.draw();
/* 183 */     str1 = SyntheticaLookAndFeel.getString(str1, jScrollBar);
/* 185 */     if (str1 == null)
/*     */       return; 
/* 186 */     Image image = imgCache.get(str1);
/* 187 */     if (image == null) {
/* 189 */       image = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(str1))).getImage();
/* 190 */       imgCache.put(str1, image);
/*     */     } 
/* 192 */     int n = image.getWidth(null);
/* 193 */     int i1 = image.getHeight(null);
/* 194 */     int i2 = paramInt1 + (paramInt3 - n) / 2;
/* 195 */     int i3 = paramInt2 + (paramInt4 - i1) / 2;
/* 196 */     if (paramInt5 == 0 && paramInt3 - 4 <= n)
/*     */       return; 
/* 198 */     if (paramInt5 == 1 && paramInt4 - 4 <= i1)
/*     */       return; 
/* 200 */     paramGraphics.drawImage(image, i2, i3, null);
/*     */   }
/*     */   
/*     */   public void paintScrollBarTrackBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 208 */     JScrollBar jScrollBar = (JScrollBar)paramSynthContext.getComponent();
/* 209 */     UIKey uIKey = new UIKey("scrollBarTrack." + ((jScrollBar.getOrientation() == 0) ? "x" : "y"), new SyntheticaState(paramSynthContext.getComponentState()));
/* 210 */     Insets insets1 = (Insets)uIKey.findProperty(paramSynthContext, "background.insets", true, 2);
/* 211 */     Insets insets2 = (Insets)insets1.clone();
/* 212 */     boolean bool = (jScrollBar.getOrientation() == 1 && !jScrollBar.getComponentOrientation().isLeftToRight()) ? true : false;
/* 214 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.clipEdgesOnShowingBoth", jScrollBar);
/* 215 */     if (bool1 && isHorizontalAndVerticalScrollBarVisible(jScrollBar))
/* 217 */       if (jScrollBar.getOrientation() == 0) {
/* 218 */         insets2.right = 0;
/*     */       } else {
/* 220 */         insets2.bottom = 0;
/*     */       }  
/* 224 */     Container container = jScrollBar.getParent();
/* 225 */     if (container instanceof JScrollPane && ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.scrollPane.clipScrollBarEdges", (JComponent)container, Boolean.valueOf(false))).booleanValue())
/* 227 */       if (jScrollBar.getOrientation() == 0) {
/* 229 */         insets2.left = 0;
/* 230 */         insets2.right = 0;
/*     */       } else {
/* 234 */         insets2.top = 0;
/* 235 */         insets2.bottom = 0;
/*     */       }  
/* 240 */     jScrollBar.putClientProperty("Synthetica.scrollBarTrack.bounds", new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4));
/* 242 */     String str = "Synthetica.scrollBarTrack";
/* 243 */     if (jScrollBar.getOrientation() == 0) {
/* 244 */       str = String.valueOf(str) + ".x.background";
/*     */     } else {
/* 246 */       str = String.valueOf(str) + ".y.background";
/*     */     } 
/* 248 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.hoverAndPressed.enabled", jScrollBar)) {
/* 250 */       str = SyntheticaLookAndFeel.getString(str, jScrollBar);
/* 251 */       ImagePainter imagePainter1 = new ImagePainter(jScrollBar, null, -1, -1, -1, -1, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0, bool, false);
/* 252 */       imagePainter1.draw();
/*     */       return;
/*     */     } 
/* 256 */     boolean bool2 = (jScrollBar.getClientProperty("Synthetica.MOUSE_OVER") == null) ? false : ((Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_OVER")).booleanValue();
/* 257 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.hoverOnButtons.enabled", jScrollBar)) {
/* 259 */       paramInt1 = 0;
/* 260 */       paramInt2 = 0;
/* 261 */       paramInt3 = jScrollBar.getWidth();
/* 262 */       paramInt4 = jScrollBar.getHeight();
/* 263 */       ArrayList arrayList = new ArrayList();
/* 264 */       SyntheticaLookAndFeel.findComponents("ScrollBar.button", jScrollBar, arrayList);
/* 265 */       for (Component component : arrayList)
/* 266 */         bool2 |= ((JButton)component).getModel().isRollover(); 
/*     */     } 
/* 269 */     int i = bool2 & ((jScrollBar.getModel().getMaximum() > jScrollBar.getModel().getExtent()) ? 1 : 0);
/* 271 */     if (i != 0)
/* 272 */       str = String.valueOf(str) + ".hover"; 
/* 274 */     if (jScrollBar.getParent() instanceof JScrollPane && SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.focusState.enabled", jScrollBar)) {
/* 276 */       Component component = ((JScrollPane)jScrollBar.getParent()).getViewport().getView();
/* 277 */       boolean bool3 = (component != null && component.hasFocus()) ? true : false;
/* 278 */       if (bool3 && SyntheticaLookAndFeel.get(String.valueOf(str) + ".focused", jScrollBar) != null)
/* 279 */         str = String.valueOf(str) + ".focused"; 
/*     */     } 
/* 282 */     str = SyntheticaLookAndFeel.getString(str, jScrollBar);
/* 283 */     int j = 0;
/* 284 */     int k = 0;
/* 285 */     int m = 0;
/* 286 */     if (i != 0) {
/* 288 */       j = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.hover.animation.cycles", jScrollBar, 1);
/* 289 */       k = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.hover.animation.delay", jScrollBar, 50);
/* 290 */       m = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.hover.animation.type", jScrollBar, 1);
/*     */     } else {
/* 294 */       j = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.animation.cycles", jScrollBar, 1);
/* 295 */       k = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.animation.delay", jScrollBar, 50);
/* 296 */       m = SyntheticaLookAndFeel.getInt("Synthetica.scrollBarTrack.animation.type", jScrollBar, 2);
/*     */     } 
/* 298 */     int n = paramSynthContext.getComponentState();
/* 299 */     if (i != 0)
/* 300 */       n |= 0x2; 
/* 302 */     ImagePainter imagePainter = new ImagePainter(jScrollBar, "track", j, k, m, n, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0, bool, false);
/* 304 */     imagePainter.draw();
/*     */   }
/*     */   
/*     */   private boolean isHorizontalAndVerticalScrollBarVisible(JScrollBar paramJScrollBar) {
/* 309 */     JScrollPane jScrollPane = (JScrollPane)paramJScrollBar.getParent();
/* 310 */     JScrollBar jScrollBar1 = jScrollPane.getHorizontalScrollBar();
/* 311 */     JScrollBar jScrollBar2 = jScrollPane.getVerticalScrollBar();
/* 312 */     return (jScrollBar1 != null && jScrollBar2 != null && jScrollBar1.isVisible() && jScrollBar2.isVisible());
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 318 */     JScrollBar jScrollBar = (JScrollBar)paramSynthContext.getComponent();
/* 319 */     int i = jScrollBar.getOrientation();
/* 321 */     int j = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 322 */     j = 31 * j + i;
/* 323 */     return j;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ScrollBarPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */