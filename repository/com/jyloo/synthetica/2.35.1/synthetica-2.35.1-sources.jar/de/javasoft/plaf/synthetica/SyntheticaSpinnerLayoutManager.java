/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JFormattedTextField;
/*     */ import javax.swing.plaf.UIResource;
/*     */ 
/*     */ public class SyntheticaSpinnerLayoutManager implements LayoutManager, UIResource {
/*  32 */   private static Insets editorInsets = (new JFormattedTextField(Integer.valueOf(0))).getInsets();
/*     */   
/*  33 */   private JComponent nextButton = null;
/*     */   
/*  34 */   private JComponent previousButton = null;
/*     */   
/*  35 */   private JComponent editor = null;
/*     */   
/*     */   public void addLayoutComponent(String paramString, Component paramComponent) {
/*  40 */     if ("Next".equals(paramString)) {
/*  41 */       this.nextButton = (JComponent)paramComponent;
/*  42 */     } else if ("Previous".equals(paramString)) {
/*  43 */       this.previousButton = (JComponent)paramComponent;
/*  44 */     } else if ("Editor".equals(paramString)) {
/*  45 */       this.editor = (JComponent)paramComponent;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeLayoutComponent(Component paramComponent) {
/*  51 */     if (paramComponent == this.nextButton) {
/*  52 */       this.nextButton = null;
/*  53 */     } else if (paramComponent == this.previousButton) {
/*  54 */       this.previousButton = null;
/*  55 */     } else if (paramComponent == this.editor) {
/*  56 */       this.editor = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension preferredLayoutSize(Container paramContainer) {
/*  62 */     Dimension dimension1 = getPrefSize(this.nextButton);
/*  63 */     Dimension dimension2 = getPrefSize(this.previousButton);
/*  64 */     Dimension dimension3 = getPrefSize(this.editor);
/*  65 */     dimension3.height = (dimension3.height + 1) / 2 * 2 + editorInsets.top + editorInsets.bottom;
/*  66 */     Dimension dimension4 = new Dimension(dimension3.width, dimension3.height);
/*  67 */     dimension4.width += Math.max(dimension1.width, dimension2.width);
/*  68 */     Insets insets = paramContainer.getInsets();
/*  69 */     dimension4.width += insets.left + insets.right;
/*  70 */     return dimension4;
/*     */   }
/*     */   
/*     */   private Dimension getPrefSize(Component paramComponent) {
/*  75 */     return (paramComponent == null) ? new Dimension(0, 0) : paramComponent.getPreferredSize();
/*     */   }
/*     */   
/*     */   public Dimension minimumLayoutSize(Container paramContainer) {
/*  81 */     return preferredLayoutSize(paramContainer);
/*     */   }
/*     */   
/*     */   public void layoutContainer(Container paramContainer) {
/*     */     int n, i1;
/*  87 */     Insets insets = paramContainer.getInsets();
/*  88 */     int i = paramContainer.getWidth() - insets.left - insets.right;
/*  89 */     int j = paramContainer.getHeight() - insets.top - insets.bottom;
/*  90 */     int k = Math.max((getPrefSize(this.nextButton)).width, (getPrefSize(this.previousButton)).width);
/*  91 */     int m = i - k;
/*  94 */     if (paramContainer.getComponentOrientation().isLeftToRight()) {
/*  96 */       n = insets.left;
/*  97 */       i1 = n + m;
/*     */     } else {
/* 101 */       i1 = insets.left;
/* 102 */       n = i1 + k;
/*     */     } 
/* 104 */     setChildBounds(this.editor, n, insets.top, m, j);
/* 105 */     int i2 = j / 2;
/* 106 */     int i3 = j - i2;
/* 107 */     setChildBounds(this.nextButton, i1, insets.top, k, i2);
/* 108 */     setChildBounds(this.previousButton, i1, insets.top + i2, k, i3);
/*     */   }
/*     */   
/*     */   private void setChildBounds(Component paramComponent, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 113 */     if (paramComponent != null)
/* 114 */       paramComponent.setBounds(paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaSpinnerLayoutManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */