/*     */ package de.javasoft.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class FileUtils {
/*     */   public static boolean delete(File paramFile, boolean paramBoolean, FileOperationListener paramFileOperationListener) {
/*  41 */     boolean bool = false;
/*     */     File[] arrayOfFile;
/*  42 */     if (paramFile.isDirectory() && (arrayOfFile = paramFile.listFiles()) != null)
/*  44 */       for (byte b = 0; b < arrayOfFile.length; b++) {
/*  46 */         if (arrayOfFile[b].isDirectory() && paramBoolean) {
/*  48 */           bool = delete(arrayOfFile[b], paramBoolean, paramFileOperationListener) ? false : true;
/*  49 */           if (bool)
/*  49 */             return !bool; 
/*     */         } else {
/*  53 */           if (paramFileOperationListener != null)
/*  54 */             bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(FileUtils.class, arrayOfFile[b], 3)) ? false : true; 
/*  55 */           if (bool)
/*  55 */             return !bool; 
/*  56 */           arrayOfFile[b].delete();
/*     */         } 
/*     */       }  
/*  60 */     if (paramFileOperationListener != null)
/*  61 */       bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(FileUtils.class, paramFile, 3)) ? false : true; 
/*  62 */     if (bool)
/*  62 */       return !bool; 
/*  63 */     paramFile.delete();
/*  64 */     return !bool;
/*     */   }
/*     */   
/*     */   public static boolean copy(File paramFile1, File paramFile2, boolean paramBoolean1, boolean paramBoolean2, FileOperationListener paramFileOperationListener) throws FileNotFoundException, IOException {
/*  85 */     boolean bool = false;
/*  86 */     if (paramFileOperationListener != null)
/*  87 */       bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(FileUtils.class, paramFile1, 2)) ? false : true; 
/*  88 */     if (bool)
/*  88 */       return !bool; 
/*  90 */     FileInputStream fileInputStream = new FileInputStream(paramFile1);
/*  91 */     FileOutputStream fileOutputStream = new FileOutputStream(paramFile2);
/*  92 */     byte[] arrayOfByte = new byte[65536];
/*  93 */     int i = 0;
/*  94 */     while ((i = fileInputStream.read(arrayOfByte)) != -1)
/*  95 */       fileOutputStream.write(arrayOfByte, 0, i); 
/*  96 */     fileOutputStream.close();
/*  97 */     fileInputStream.close();
/*  99 */     if (paramBoolean1)
/* 100 */       paramFile2.setLastModified(paramFile1.lastModified()); 
/* 102 */     if (paramBoolean2) {
/* 104 */       bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(FileUtils.class, paramFile1, 3)) ? false : true;
/* 105 */       if (bool)
/* 105 */         return !bool; 
/* 106 */       paramFile1.delete();
/*     */     } 
/* 108 */     return !bool;
/*     */   }
/*     */   
/*     */   public static boolean copy(File paramFile1, File paramFile2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, FileOperationListener paramFileOperationListener) throws IOException {
/* 128 */     boolean bool = false;
/* 130 */     if (!paramFile1.exists())
/* 131 */       throw new IOException("Source directory not found: " + paramFile1.getAbsolutePath()); 
/*     */     File[] arrayOfFile;
/* 137 */     if (paramFile1.isDirectory() && (arrayOfFile = paramFile1.listFiles()) != null) {
/* 140 */       if (!paramFile2.exists()) {
/* 142 */         if (paramFileOperationListener != null)
/* 143 */           bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(FileUtils.class, paramFile2, 1)) ? false : true; 
/* 144 */         if (bool)
/* 144 */           return !bool; 
/* 145 */         paramFile2.mkdir();
/*     */       } 
/* 148 */       for (byte b = 0; b < arrayOfFile.length; b++) {
/* 150 */         if (arrayOfFile[b].isDirectory() && paramBoolean1) {
/* 152 */           File file = new File(paramFile2, arrayOfFile[b].getName());
/* 154 */           bool = copy(arrayOfFile[b], file, paramBoolean1, paramBoolean2, paramBoolean3, paramFileOperationListener) ? false : true;
/* 155 */           if (bool)
/* 155 */             return !bool; 
/* 157 */         } else if (arrayOfFile[b].isFile()) {
/* 159 */           File file = new File(paramFile2, arrayOfFile[b].getName());
/* 161 */           if (paramBoolean2 || !file.exists() || file.lastModified() < paramFile1.lastModified()) {
/* 163 */             bool = copy(arrayOfFile[b], file, true, paramBoolean3, paramFileOperationListener) ? false : true;
/* 164 */             if (bool)
/* 164 */               return !bool; 
/*     */           } 
/*     */         } 
/*     */       } 
/* 172 */     } else if (paramBoolean2 || !paramFile2.exists() || paramFile2.lastModified() < paramFile1.lastModified()) {
/* 174 */       bool = copy(paramFile1, paramFile2, true, paramBoolean3, paramFileOperationListener) ? false : true;
/* 175 */       if (bool)
/* 175 */         return !bool; 
/*     */     } 
/* 180 */     if (paramFile1.isDirectory() && paramBoolean1 && paramBoolean3)
/* 181 */       bool = delete(paramFile1, false, paramFileOperationListener) ? false : true; 
/* 183 */     return !bool;
/*     */   }
/*     */   
/*     */   public static boolean determineProperties(FileProperties paramFileProperties, File paramFile, boolean paramBoolean, FileOperationListener paramFileOperationListener) throws IOException {
/* 200 */     boolean bool = false;
/* 201 */     if (!paramFile.exists())
/* 202 */       throw new IOException("File not found: " + paramFile.getAbsolutePath()); 
/* 204 */     if (paramFileProperties.location == null)
/* 205 */       paramFileProperties.location = paramFile.getParent(); 
/*     */     File[] arrayOfFile;
/* 208 */     if (paramFile.isDirectory() && paramBoolean && (
/* 209 */       arrayOfFile = paramFile.listFiles()) != null && arrayOfFile.length > 0) {
/* 211 */       paramFileProperties.directories++;
/* 212 */       for (byte b = 0; b < arrayOfFile.length; b++) {
/* 214 */         if (arrayOfFile[b].isDirectory() && paramBoolean) {
/* 216 */           bool = determineProperties(paramFileProperties, arrayOfFile[b], paramBoolean, paramFileOperationListener) ? false : true;
/* 217 */           if (bool)
/* 217 */             return !bool; 
/* 219 */         } else if (arrayOfFile[b].isFile()) {
/* 221 */           paramFileProperties.files++;
/* 222 */           paramFileProperties.size += arrayOfFile[b].length();
/* 223 */           if (paramFileOperationListener != null)
/* 224 */             bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(paramFileProperties, paramFile, 4)) ? false : true; 
/* 225 */           if (bool)
/* 225 */             return !bool; 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 232 */       if (paramFile.isDirectory()) {
/* 233 */         paramFileProperties.directories++;
/*     */       } else {
/* 236 */         paramFileProperties.files++;
/* 237 */         paramFileProperties.size += paramFile.length();
/*     */       } 
/* 239 */       paramFileProperties.lastModified = paramFile.lastModified();
/* 240 */       if (paramFileOperationListener != null)
/* 241 */         bool = paramFileOperationListener.processFileOperationEvent(new FileOperationEvent(paramFileProperties, paramFile, 4)) ? false : true; 
/*     */     } 
/* 244 */     return !bool;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\io\FileUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */