/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class PasswordFieldPainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.PasswordFieldPainter";
/*    */   
/*    */   public static PasswordFieldPainter getInstance() {
/* 42 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static PasswordFieldPainter getInstance(SynthContext paramSynthContext) {
/* 51 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, PasswordFieldPainter.class, "Synthetica.PasswordFieldPainter"));
/* 52 */     if (syntheticaComponentPainter == null)
/* 53 */       syntheticaComponentPainter = getInstance(paramSynthContext, PasswordFieldPainter.class, "Synthetica.PasswordFieldPainter"); 
/* 54 */     return (PasswordFieldPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintPasswordFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 62 */     paintBackground("passwordField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public void paintPasswordFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 70 */     paintBorder("passwordField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\PasswordFieldPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */