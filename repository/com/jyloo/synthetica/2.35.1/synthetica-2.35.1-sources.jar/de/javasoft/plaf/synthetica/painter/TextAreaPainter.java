/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class TextAreaPainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.TextAreaPainter";
/*    */   
/*    */   public static TextAreaPainter getInstance() {
/* 42 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static TextAreaPainter getInstance(SynthContext paramSynthContext) {
/* 51 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TextAreaPainter.class, "Synthetica.TextAreaPainter"));
/* 52 */     if (syntheticaComponentPainter == null)
/* 53 */       syntheticaComponentPainter = getInstance(paramSynthContext, TextAreaPainter.class, "Synthetica.TextAreaPainter"); 
/* 54 */     return (TextAreaPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintTextAreaBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTextAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 66 */     paintBackground("textArea", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 72 */     return Cacheable.ScaleType.NINE_SQUARE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TextAreaPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */