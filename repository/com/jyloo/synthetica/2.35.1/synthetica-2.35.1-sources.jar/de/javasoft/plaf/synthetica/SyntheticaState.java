/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class SyntheticaState {
/*     */   public enum State {
/*  35 */     UNDEFINED("UNDEFINED", 0),
/*  36 */     ENABLED("ENABLED", 1),
/*  37 */     HOVER("HOVER", 2),
/*  38 */     PRESSED("PRESSED", 4),
/*  39 */     DISABLED("DISABLED", 8),
/*  41 */     FOCUSED("FOCUSED", 256),
/*  42 */     SELECTED("SELECTED", 512),
/*  43 */     DEFAULT("DEFAULT", 1024),
/*  44 */     LOCKED("LOCKED", 2048),
/*  45 */     ACTIVE("ACTIVE", 4096);
/*     */     
/*     */     private int state;
/*     */     
/*     */     private String name;
/*     */     
/*  52 */     private static Map<String, State> states = new HashMap<String, State>();
/*     */     
/*     */     static {
/*     */       byte b;
/*     */       int i;
/*     */       State[] arrayOfState;
/*  53 */       for (i = (arrayOfState = values()).length, b = 0; b < i; ) {
/*  53 */         State state = arrayOfState[b];
/*  54 */         states.put(state.name, state);
/*     */         b++;
/*     */       } 
/*     */     }
/*     */     
/*     */     State(String param1String1, int param1Int1) {
/*  59 */       this.name = param1String1;
/*  60 */       this.state = param1Int1;
/*     */     }
/*     */     
/*     */     public static State parse(String param1String) throws ParseException {
/*  65 */       State state = states.get(param1String.toUpperCase());
/*  66 */       if (state == null)
/*  67 */         throw new ParseException("Unsupported state: " + param1String, -1); 
/*  68 */       return state;
/*     */     }
/*     */     
/*     */     public int toInt() {
/*  73 */       return this.state;
/*     */     }
/*     */     
/*     */     public String toString() {
/*  79 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*  84 */   private int cState = 0;
/*     */   
/*     */   public SyntheticaState() {}
/*     */   
/*     */   public SyntheticaState(int paramInt) {
/* 100 */     this();
/* 101 */     this.cState = paramInt;
/*     */   }
/*     */   
/*     */   public SyntheticaState(State paramState) {
/* 111 */     setState(paramState);
/*     */   }
/*     */   
/*     */   public int getState() {
/* 121 */     return this.cState;
/*     */   }
/*     */   
/*     */   public void setState(int paramInt) {
/* 131 */     this.cState = paramInt;
/*     */   }
/*     */   
/*     */   public void setState(State paramState) {
/* 141 */     this.cState |= paramState.toInt();
/*     */   }
/*     */   
/*     */   public void resetState(State paramState) {
/* 151 */     if (isSet(paramState))
/* 152 */       this.cState ^= paramState.toInt(); 
/*     */   }
/*     */   
/*     */   public boolean isSet(State paramState) {
/* 163 */     return ((getState() & paramState.toInt()) > 0);
/*     */   }
/*     */   
/*     */   public boolean isSet(int paramInt) {
/* 174 */     return ((getState() & paramInt) != 0);
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 183 */     if (paramObject instanceof SyntheticaState)
/* 184 */       return (((SyntheticaState)paramObject).getState() == getState()); 
/* 185 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 196 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     byte b;
/*     */     int i;
/*     */     State[] arrayOfState;
/* 197 */     for (i = (arrayOfState = State.values()).length, b = 0; b < i; ) {
/* 197 */       State state = arrayOfState[b];
/* 199 */       if ((getState() & state.toInt()) != 0) {
/* 201 */         stringBuilder.append(':');
/* 202 */         stringBuilder.append(state);
/*     */       } 
/*     */       b++;
/*     */     } 
/* 205 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */