/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class UIKey {
/*     */   private StringBuilder sb;
/*     */   
/*     */   public UIKey(String paramString, SyntheticaState paramSyntheticaState) {
/*  45 */     this(paramString, paramSyntheticaState, -1, -1, -1);
/*     */   }
/*     */   
/*     */   public UIKey(String paramString1, SyntheticaState paramSyntheticaState, String paramString2) {
/*  57 */     this(paramString1, paramSyntheticaState, -1, -1, -1, paramString2);
/*     */   }
/*     */   
/*     */   UIKey(String paramString, SyntheticaState paramSyntheticaState, int paramInt1, int paramInt2, int paramInt3) {
/*  62 */     this(paramString, paramSyntheticaState, paramInt1, paramInt2, paramInt3, "Synthetica.");
/*     */   }
/*     */   
/*     */   UIKey(String paramString1, SyntheticaState paramSyntheticaState, int paramInt1, int paramInt2, int paramInt3, String paramString2) {
/*  67 */     this.sb = new StringBuilder(paramString2);
/*  68 */     this.sb.append(paramString1);
/*  70 */     if (paramInt1 >= 0) {
/*  72 */       if (paramInt1 == 1) {
/*  73 */         this.sb.append(".up");
/*  74 */       } else if (paramInt1 == 5) {
/*  75 */         this.sb.append(".down");
/*  76 */       } else if (paramInt1 == 7) {
/*  77 */         this.sb.append(".left");
/*  78 */       } else if (paramInt1 == 3) {
/*  79 */         this.sb.append(".right");
/*     */       } 
/*  81 */     } else if (paramInt2 >= 0) {
/*  83 */       if (paramInt2 == 1) {
/*  84 */         this.sb.append(".top");
/*  85 */       } else if (paramInt2 == 2) {
/*  86 */         this.sb.append(".left");
/*  87 */       } else if (paramInt2 == 3) {
/*  88 */         this.sb.append(".bottom");
/*  89 */       } else if (paramInt2 == 4) {
/*  90 */         this.sb.append(".right");
/*     */       } 
/*  92 */     } else if (paramInt3 >= 0) {
/*  94 */       if (paramInt3 == 0) {
/*  95 */         this.sb.append(".x");
/*  96 */       } else if (paramInt3 == 1) {
/*  97 */         this.sb.append(".y");
/*     */       } 
/*     */     } 
/* 100 */     if (paramSyntheticaState.isSet(SyntheticaState.State.DEFAULT))
/* 101 */       this.sb.append(".default"); 
/* 103 */     if (paramSyntheticaState.isSet(SyntheticaState.State.DISABLED)) {
/* 104 */       this.sb.append(".disabled");
/* 105 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.PRESSED)) {
/* 106 */       this.sb.append(".pressed");
/* 107 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER)) {
/* 108 */       this.sb.append(".hover");
/*     */     } 
/* 110 */     if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED))
/* 111 */       this.sb.append(".selected"); 
/* 113 */     if (paramSyntheticaState.isSet(SyntheticaState.State.LOCKED))
/* 114 */       this.sb.append(".locked"); 
/* 116 */     if (paramSyntheticaState.isSet(SyntheticaState.State.ACTIVE))
/* 117 */       this.sb.append(".active"); 
/*     */   }
/*     */   
/*     */   public String get() {
/* 127 */     return this.sb.toString();
/*     */   }
/*     */   
/*     */   String get(String paramString) {
/* 138 */     StringBuilder stringBuilder = new StringBuilder(this.sb.toString());
/* 139 */     stringBuilder.append(".");
/* 140 */     stringBuilder.append(paramString);
/* 141 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   static Object findProperty(JComponent paramJComponent, String paramString1, String paramString2, boolean paramBoolean, int paramInt) {
/* 162 */     byte b = 46;
/* 163 */     int i = paramString1.length();
/* 164 */     while (i > -1) {
/* 166 */       paramString1 = paramString1.substring(0, i);
/* 167 */       StringBuilder stringBuilder = new StringBuilder(paramString1);
/* 168 */       if (paramString2 != null) {
/* 170 */         stringBuilder.append(b);
/* 171 */         stringBuilder.append(paramString2);
/*     */       } 
/* 174 */       Object object = SyntheticaLookAndFeel.get(stringBuilder.toString(), paramJComponent);
/* 175 */       if (object != null || !paramBoolean || paramInt == 0)
/* 176 */         return object; 
/* 177 */       i = paramString1.lastIndexOf(b);
/* 178 */       paramInt--;
/*     */     } 
/* 180 */     return null;
/*     */   }
/*     */   
/*     */   static Object findProperty(SynthContext paramSynthContext, String paramString1, String paramString2, boolean paramBoolean, int paramInt) {
/* 185 */     return findProperty(paramSynthContext.getComponent(), paramString1, paramString2, paramBoolean, paramInt);
/*     */   }
/*     */   
/*     */   Object findProperty(SynthContext paramSynthContext, String paramString, boolean paramBoolean, int paramInt) {
/* 190 */     return findProperty(paramSynthContext, get(), paramString, paramBoolean, paramInt);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\UIKey.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */