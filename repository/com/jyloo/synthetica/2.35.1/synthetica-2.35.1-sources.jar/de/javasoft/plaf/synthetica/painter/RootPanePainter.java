/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLogoRenderer;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaRootPaneUI;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaTitlePane;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class RootPanePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.RootPanePainter";
/*     */   
/*     */   public static RootPanePainter getInstance() {
/*  88 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static RootPanePainter getInstance(SynthContext paramSynthContext) {
/*  97 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, RootPanePainter.class, "Synthetica.RootPanePainter"));
/*  98 */     if (syntheticaComponentPainter == null)
/*  99 */       syntheticaComponentPainter = getInstance(paramSynthContext, RootPanePainter.class, "Synthetica.RootPanePainter"); 
/* 100 */     return (RootPanePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintRootPaneBorder(JRootPane paramJRootPane, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 118 */     Window window = getWindow(paramJRootPane);
/* 120 */     boolean bool1 = isMaximized(window);
/* 121 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.opaque", window, true);
/* 122 */     if (bool1 && bool2)
/*     */       return; 
/* 125 */     boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.border.respectFill", window);
/* 126 */     String str1 = "Synthetica.rootPane.border";
/* 127 */     if (window.isActive())
/* 128 */       str1 = String.valueOf(str1) + ".selected"; 
/* 129 */     str1 = SyntheticaLookAndFeel.getString(str1, window);
/* 130 */     Insets insets1 = (Insets)SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.insets", window, false).clone();
/* 131 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.respectHeaderHeight", window)) {
/* 133 */       int k = ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane().getHeight();
/* 134 */       k += (paramJRootPane.getJMenuBar() == null) ? 0 : paramJRootPane.getJMenuBar().getHeight();
/* 135 */       k += (SyntheticaLookAndFeel.get("Synthetica.rootPane.border.size", window) == null) ? 4 : (SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window)).top;
/* 136 */       insets1.top = k;
/*     */     } 
/* 138 */     Insets insets2 = insets1;
/* 139 */     int i = paramInt4;
/* 140 */     if (bool1) {
/* 143 */       if (!bool3)
/* 144 */         i = insets1.top; 
/* 145 */       insets1 = (Insets)SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window, false).clone();
/* 147 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.insets", window, false);
/* 148 */       insets1.left = (insets1.left < insets.left) ? insets.left : insets1.left;
/* 149 */       insets1.right = (insets1.right < insets.right) ? insets.right : insets1.right;
/* 150 */       insets2 = new Insets(0, 0, 0, 0);
/*     */     } 
/* 153 */     boolean bool4 = false;
/* 154 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.horizontalTiled", window))
/* 155 */       bool4 = true; 
/* 156 */     boolean bool5 = false;
/* 157 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.verticalTiled", window))
/* 158 */       bool5 = true; 
/* 160 */     boolean bool6 = SyntheticaRootPaneUI.isEvalCopy();
/* 161 */     String str2 = ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getRootPaneBorderText();
/* 162 */     int j = 0;
/* 163 */     if ((bool6 || str2 != null) && !bool1) {
/* 165 */       i -= 16;
/* 166 */       j = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.margin.left", window, 0);
/* 167 */       paramInt1 += j;
/* 168 */       paramInt3 -= j;
/*     */     } 
/* 172 */     if (OS.getCurrentOS() == OS.Mac && (JAVA5 || JAVA6) && (!SyntheticaLookAndFeel.isWindowOpacityEnabled(window) || SyntheticaLookAndFeel.isWindowShapeEnabled(window)))
/* 173 */       paramGraphics.clearRect(paramInt1, paramInt2, paramInt3, i); 
/* 175 */     paintBorder(paramJRootPane, paramGraphics, paramInt1, paramInt2, paramInt3, i, str1, insets1, insets2, bool4, bool5, window, bool1, bool3);
/* 176 */     str1 = "Synthetica.rootPane.border.light";
/* 177 */     if (window.isActive())
/* 178 */       str1 = String.valueOf(str1) + ".selected"; 
/* 179 */     str1 = SyntheticaLookAndFeel.getString(str1, window);
/* 180 */     if (str1 != null)
/* 181 */       paintBorder(paramJRootPane, paramGraphics, paramInt1, paramInt2, paramInt3, i, str1, insets1, insets2, 0, 1, window, bool1, bool3); 
/* 183 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.paintStatusBar", window) && paramJRootPane.getClientProperty("Synthetica.statusBar") != null) {
/* 185 */       i = paramInt4;
/* 186 */       if ((bool6 || str2 != null) && !bool1)
/* 187 */         i -= 16; 
/* 188 */       int k = ((JComponent)paramJRootPane.getClientProperty("Synthetica.statusBar")).getHeight();
/* 189 */       k += (SyntheticaLookAndFeel.get("Synthetica.rootPane.border.size", window) == null) ? 4 : (SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window)).top;
/* 190 */       SyntheticaAddonsPainter.getInstance("Synthetica.StatusBarPainter").paintStatusBarBackground(paramJRootPane, new SyntheticaState(), paramGraphics, 0, i - k, paramInt3, k);
/*     */     } 
/* 193 */     if (!bool1 && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.paintTitlePaneInBorder", window, false)) {
/* 195 */       int k = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePaneInBorder.leftOffset", window, 0);
/* 196 */       int m = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePaneInBorder.rightOffset", window, 0);
/* 197 */       int n = ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane().getHeight();
/* 198 */       n += (SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window)).top;
/* 199 */       if (window.isActive())
/* 200 */         paramSyntheticaState.setState(SyntheticaState.State.SELECTED); 
/* 201 */       paintTitlePaneBackground(paramJRootPane, paramSyntheticaState, paramGraphics, k, insets1.top, paramInt3 - k - m, n - insets1.top);
/*     */     } 
/* 205 */     str1 = "Synthetica.rootPane.titlePane.background";
/* 206 */     str1 = SyntheticaLookAndFeel.getString(str1, window);
/* 207 */     boolean bool7 = (str1 != null && bool2) ? true : false;
/* 208 */     if (!bool7 && paramJRootPane.getClientProperty("Synthetica.logoRenderer") != null)
/* 209 */       renderLogo(paramJRootPane, window.isActive(), bool1, true, paramGraphics, paramInt3, paramInt4); 
/* 211 */     if ((bool6 || str2 != null) && !bool1) {
/* 213 */       paramGraphics.setColor(bool6 ? UIManager.getColor("Panel.background") : SyntheticaLookAndFeel.getColor("Synthetica.rootPane.borderText.background", window, UIManager.getColor("Panel.background")));
/* 214 */       paramGraphics.fillRect(paramInt1, paramInt4 - 16, paramInt3, 16);
/* 215 */       if (j > 0)
/* 216 */         paramGraphics.fillRect(paramInt1 - j, paramInt2, j, paramInt4); 
/* 217 */       paramGraphics.setColor(bool6 ? new Color(13369344) : SyntheticaLookAndFeel.getColor("Synthetica.rootPane.borderText.foreground", window, UIManager.getColor("Label.foreground")));
/* 218 */       paramGraphics.setFont(paramGraphics.getFont().deriveFont(10.0F));
/* 219 */       String str = bool6 ? "Synthetica - Unregistered Evaluation Copy!" : str2;
/* 220 */       paramGraphics.drawString(str, 4, paramInt4 - 16 + paramGraphics.getFontMetrics().getAscent());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintBorder(JRootPane paramJRootPane, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString, Insets paramInsets1, Insets paramInsets2, int paramInt5, int paramInt6, Window paramWindow, boolean paramBoolean1, boolean paramBoolean2) {
/* 227 */     if (paramBoolean1 && paramBoolean2) {
/* 229 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.insets", paramWindow, false);
/* 230 */       insets = new Insets(insets.top - paramInsets1.top, insets.left - paramInsets1.left, insets.bottom - paramInsets1.bottom, insets.right - paramInsets1.right);
/* 232 */       ImagePainter imagePainter = new ImagePainter(paramJRootPane, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramString, paramInsets1, paramInsets2, insets, insets, paramInt5, paramInt6);
/* 233 */       imagePainter.draw();
/*     */     } else {
/* 237 */       SyntheticaState syntheticaState = new SyntheticaState(paramWindow.isActive() ? SyntheticaState.State.ACTIVE.toInt() : 0);
/* 238 */       UIKey uIKey = new UIKey("rootPane.border", syntheticaState);
/* 239 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJRootPane, 1);
/* 240 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJRootPane, 50);
/* 241 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJRootPane, paramWindow.isActive() ? 0 : 6);
/* 243 */       ImagePainter imagePainter = new ImagePainter(paramJRootPane, i, j, k, syntheticaState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramString, paramInsets1, paramInsets2, paramInt5, paramInt6);
/* 244 */       if (paramBoolean1) {
/* 245 */         imagePainter.drawCenter();
/* 246 */       } else if (paramBoolean2) {
/* 247 */         imagePainter.draw();
/*     */       } else {
/* 249 */         imagePainter.drawBorder();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintRootPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 258 */     JComponent jComponent = paramSynthContext.getComponent();
/* 259 */     if (jComponent instanceof JRootPane)
/* 260 */       paintRootPaneBorder((JRootPane)jComponent, new SyntheticaState(paramSynthContext.getComponentState()), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   public void paintContentBackground(JRootPane paramJRootPane, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 280 */     Window window = SwingUtilities.getWindowAncestor(paramJRootPane);
/* 281 */     String str = "Synthetica.rootPane.border";
/* 282 */     if (window.isActive())
/* 283 */       str = String.valueOf(str) + ".selected"; 
/* 284 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 285 */     Insets insets1 = (SyntheticaLookAndFeel.get("Synthetica.rootPane.border.size", window) == null) ? new Insets(4, 4, 4, 4) : SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window);
/* 286 */     Insets insets2 = (Insets)insets1.clone();
/* 287 */     insets2.top += ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane().getHeight();
/* 288 */     Insets insets3 = new Insets(0, 0, 0, 0);
/* 290 */     boolean bool1 = false;
/* 291 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.horizontalTiled", window))
/* 292 */       bool1 = true; 
/* 293 */     boolean bool2 = false;
/* 294 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.verticalTiled", window))
/* 295 */       bool2 = true; 
/* 297 */     ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets2, insets3, bool1, bool2);
/* 298 */     imagePainter.drawCenter();
/* 300 */     str = "Synthetica.rootPane.border.light";
/* 301 */     if (window.isActive())
/* 302 */       str = String.valueOf(str) + ".selected"; 
/* 303 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 304 */     if (str != null) {
/* 306 */       imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets2, insets3, 0, 1);
/* 307 */       imagePainter.drawCenter();
/*     */     } 
/* 310 */     MenuPainter.getInstance().paintMenuBarBackground(paramJRootPane, new SyntheticaState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   protected void renderLogo(JRootPane paramJRootPane, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 330 */     SyntheticaLogoRenderer syntheticaLogoRenderer = (SyntheticaLogoRenderer)paramJRootPane.getClientProperty("Synthetica.logoRenderer");
/* 331 */     JComponent jComponent = syntheticaLogoRenderer.getRendererComponent(paramJRootPane, paramBoolean1);
/* 332 */     Window window = getWindow(paramJRootPane);
/* 334 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", window);
/* 335 */     if (insets == null)
/* 336 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.insets", window); 
/* 337 */     int i = insets.top;
/* 338 */     i = (paramBoolean2 || !paramBoolean3) ? 0 : i;
/* 339 */     i += ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane().getHeight();
/* 340 */     JMenuBar jMenuBar = (JMenuBar)SyntheticaLookAndFeel.findComponent(JMenuBar.class, paramJRootPane);
/* 341 */     boolean bool1 = (paramJRootPane.getClientProperty("Synthetica.logoRenderer.titlePaneOnly") == null) ? false : ((Boolean)paramJRootPane.getClientProperty("Synthetica.logoRenderer.titlePaneOnly")).booleanValue();
/* 342 */     if (jMenuBar != null && !jMenuBar.isOpaque() && SyntheticaLookAndFeel.get("Synthetica.menuBar.background.active", jMenuBar) == null && !bool1)
/* 343 */       i += jMenuBar.getHeight(); 
/* 345 */     boolean bool2 = (paramJRootPane.getClientProperty("Synthetica.logoRenderer.respectButtons") == null) ? false : ((Boolean)paramJRootPane.getClientProperty("Synthetica.logoRenderer.respectButtons")).booleanValue();
/* 346 */     if (bool2) {
/* 348 */       Rectangle rectangle1 = ((SyntheticaTitlePane)((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane()).getMenuButtonBounds();
/* 349 */       Rectangle rectangle2 = ((SyntheticaTitlePane)((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane()).getControlButtonsBounds();
/* 351 */       int j = Math.min(rectangle1.x + rectangle1.width, rectangle2.x + rectangle2.width);
/* 352 */       int k = Math.max(rectangle1.x, rectangle2.x) - j;
/* 353 */       j += (paramBoolean2 || !paramBoolean3) ? 0 : insets.left;
/* 354 */       jComponent.setSize(new Dimension(k, i));
/* 355 */       paramGraphics.translate(j, 0);
/* 356 */       jComponent.paint(paramGraphics);
/* 357 */       paramGraphics.translate(-j, 0);
/*     */     } else {
/* 361 */       jComponent.setSize(new Dimension(paramInt1, i));
/* 362 */       jComponent.paint(paramGraphics);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintTitlePaneBackground(JRootPane paramJRootPane, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 381 */     Window window = getWindow(paramJRootPane);
/* 382 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.opaque", window, true);
/* 384 */     String str = "Synthetica.rootPane.titlePane.background";
/* 385 */     if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED))
/* 386 */       str = String.valueOf(str) + ".selected"; 
/* 387 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 388 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.background.insets", window);
/* 389 */     boolean bool1 = false;
/* 390 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.horizontalTiled", window))
/* 391 */       bool1 = true; 
/* 392 */     boolean bool2 = false;
/* 393 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.background.verticalTiled", window))
/* 394 */       bool2 = true; 
/* 396 */     ImagePainter imagePainter = null;
/* 397 */     boolean bool3 = (str != null && bool) ? true : false;
/* 398 */     if (bool3) {
/* 400 */       imagePainter = new ImagePainter(paramJRootPane, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, bool1, bool2);
/* 401 */       imagePainter.draw();
/*     */     } 
/* 404 */     str = "Synthetica.rootPane.titlePane.background.light";
/* 405 */     if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED))
/* 406 */       str = String.valueOf(str) + ".selected"; 
/* 407 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 408 */     if (str != null && bool) {
/* 410 */       imagePainter = new ImagePainter(paramJRootPane, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, bool2);
/* 411 */       imagePainter.draw();
/*     */     } 
/* 414 */     if (bool3 && paramJRootPane.getClientProperty("Synthetica.logoRenderer") != null)
/* 415 */       renderLogo(paramJRootPane, window.isActive(), isMaximized(window), false, paramGraphics, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   public void paintTitlePaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 423 */     JRootPane jRootPane = (JRootPane)paramSynthContext.getComponent();
/* 424 */     paintTitlePaneBackground(jRootPane, new SyntheticaState(paramSynthContext.getComponentState()), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   protected boolean isMaximized(Window paramWindow) {
/* 429 */     return (paramWindow instanceof Frame && (((Frame)paramWindow).getExtendedState() & 0x6) == 6);
/*     */   }
/*     */   
/*     */   public void paintButtonAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 437 */     JRootPane jRootPane = (JRootPane)paramSynthContext.getComponent();
/* 438 */     Window window = getWindow(jRootPane);
/* 439 */     boolean bool = ((paramSynthContext.getComponentState() & 0x200) > 0) ? true : false;
/* 441 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.buttonArea.insets", window);
/* 442 */     if (insets != null) {
/* 444 */       paramInt1 -= insets.left;
/* 445 */       paramInt2 -= insets.top;
/* 446 */       paramInt3 += insets.left + insets.right;
/* 447 */       paramInt4 += insets.top + insets.bottom;
/* 448 */       String str = "Synthetica.rootPane.titlePane.buttonArea.background";
/* 449 */       if (bool && SyntheticaLookAndFeel.getString("Synthetica.rootPane.titlePane.buttonArea.background.selected", window) != null)
/* 450 */         str = String.valueOf(str) + ".selected"; 
/* 451 */       str = SyntheticaLookAndFeel.getString(str, window);
/* 452 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.buttonArea.background.insets", window);
/* 453 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets1, 0, 0);
/* 454 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintResizeBackground(JRootPane paramJRootPane, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 473 */     Window window = getWindow(paramJRootPane);
/* 474 */     paramGraphics.setColor(SyntheticaLookAndFeel.getColor("Synthetica.rootPane.resizeFillColor", window, new Color(1073741824, true)));
/* 475 */     paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 476 */     paramGraphics.setColor(SyntheticaLookAndFeel.getColor("Synthetica.rootPane.resizeBorderColor", window, new Color(-2139062144, true)));
/* 477 */     paramGraphics.drawRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1);
/*     */   }
/*     */   
/*     */   public void paintSnapBackground(JRootPane paramJRootPane, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 495 */     Window window = getWindow(paramJRootPane);
/* 496 */     String str = "Synthetica.rootPane.snap.background.image";
/* 497 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 498 */     if (str != null) {
/* 500 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.snap.background.image.insets", window, false);
/* 501 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 502 */       imagePainter.draw();
/*     */     } else {
/* 506 */       paramGraphics.setColor(SyntheticaLookAndFeel.getColor("Synthetica.rootPane.snap.background", window, new Color(1610612736, true)));
/* 507 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.snap.rectSize", window, 16);
/* 508 */       if (i > 0) {
/* 510 */         for (byte b = 0; b < i; b++)
/* 511 */           paramGraphics.drawRect(paramInt1 + b, paramInt2 + b, paramInt3 - b * 2 - 1, paramInt4 - b * 2 - 1); 
/* 513 */       } else if (i < 0) {
/* 514 */         paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       } 
/* 515 */       paramGraphics.setColor(SyntheticaLookAndFeel.getColor("Synthetica.rootPane.snap.borderColor", window, new Color(-2139062144, true)));
/* 516 */       paramGraphics.drawRect(paramInt1, paramInt2, paramInt3 - 1, paramInt4 - 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintHeaderShadowBackground(JRootPane paramJRootPane, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 535 */     Window window = getWindow(paramJRootPane);
/* 536 */     String str = "Synthetica.rootPane.headerShadow.background.image";
/* 537 */     str = SyntheticaLookAndFeel.getString(str, window);
/* 538 */     if (str != null) {
/* 540 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.headerShadow.background.image.insets", window, false);
/* 541 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 542 */       imagePainter.draw();
/*     */     } else {
/* 547 */       paramGraphics.setColor(new Color(1610612736, true));
/* 548 */       paramGraphics.drawLine(paramInt1, paramInt2, paramInt1 + paramInt3 - 1, paramInt2);
/* 549 */       paramGraphics.setColor(new Color(637534208, true));
/* 550 */       paramGraphics.drawLine(paramInt1, paramInt2 + 1, paramInt1 + paramInt3 - 1, paramInt2 + 1);
/* 551 */       paramGraphics.setColor(new Color(301989888, true));
/* 552 */       paramGraphics.drawLine(paramInt1, paramInt2 + 2, paramInt1 + paramInt3 - 1, paramInt2 + 2);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected Window getWindow(JRootPane paramJRootPane) {
/* 559 */     Container container = paramJRootPane.getParent();
/* 560 */     return (container instanceof Window) ? (Window)container : SwingUtilities.getWindowAncestor(container);
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 566 */     if (paramString.equals("paintRootPaneBorder") || paramString.equals("paintRootPaneBackground"))
/* 567 */       return Cacheable.ScaleType.NINE_SQUARE; 
/* 568 */     return super.getCacheScaleType(paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\RootPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */