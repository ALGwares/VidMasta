/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class SliderPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.SliderPainter";
/*     */   
/*     */   public static SliderPainter getInstance() {
/*  54 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static SliderPainter getInstance(SynthContext paramSynthContext) {
/*  63 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, SliderPainter.class, "Synthetica.SliderPainter"));
/*  64 */     if (syntheticaComponentPainter == null)
/*  65 */       syntheticaComponentPainter = getInstance(paramSynthContext, SliderPainter.class, "Synthetica.SliderPainter"); 
/*  66 */     return (SliderPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintSliderBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  74 */     JComponent jComponent = paramSynthContext.getComponent();
/*  75 */     if (jComponent.hasFocus())
/*  76 */       FocusPainter.paintFocus("focus.slider", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   public void paintSliderBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSliderTrackBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSliderTrackBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  95 */     JSlider jSlider = (JSlider)paramSynthContext.getComponent();
/*  96 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/*  97 */     paintSliderTrack(jSlider, syntheticaPainterState, jSlider.getOrientation(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*  99 */     syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, 0, true);
/* 100 */     paintSliderTrack(jSlider, syntheticaPainterState, jSlider.getOrientation(), jSlider.getValue(), jSlider.getMinimum(), jSlider.getMaximum(), jSlider.getInverted(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintSliderTrack(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 117 */     UIKey uIKey = new UIKey("slider.track", paramSyntheticaState, -1, -1, paramInt1);
/* 118 */     Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "image.insets", true, 1);
/* 119 */     Insets insets2 = insets1;
/* 120 */     String str = SyntheticaLookAndFeel.getString(uIKey.get("image"), paramJComponent);
/* 121 */     ImagePainter imagePainter = new ImagePainter(paramJComponent, paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5, str, insets1, insets2, 0, 0);
/* 122 */     imagePainter.draw();
/*     */   }
/*     */   
/*     */   public void paintSliderTrack(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, Graphics paramGraphics, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/* 144 */     String str1 = "slider.trackMark";
/* 145 */     UIKey uIKey = new UIKey(str1, paramSyntheticaState, -1, -1, paramInt1);
/* 146 */     String str2 = SyntheticaLookAndFeel.getString(uIKey.get("image"), paramJComponent);
/* 147 */     if (str2 == null) {
/* 149 */       str1 = "slider.track";
/* 150 */       uIKey = new UIKey(str1, paramSyntheticaState, -1, -1, paramInt1);
/* 151 */       str2 = SyntheticaLookAndFeel.getString(uIKey.get("image"), paramJComponent);
/*     */     } 
/* 153 */     if (str2 != null) {
/* 155 */       Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "image.insets", true, 1);
/* 156 */       Insets insets2 = (Insets)insets1.clone();
/* 158 */       uIKey = new UIKey(str1, paramSyntheticaState);
/* 159 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, 1);
/* 160 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 50);
/* 161 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 2);
/* 162 */       if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER) || paramSyntheticaState.isSet(SyntheticaState.State.PRESSED))
/* 163 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 1); 
/* 165 */       int m = paramInt2 - paramInt3;
/* 166 */       int n = (paramInt4 == paramInt3) ? m : (paramInt4 - paramInt3);
/* 167 */       boolean bool = (paramJComponent.isEnabled() && isSliderTrackMarkEnabled(paramJComponent)) ? true : false;
/* 169 */       if (n == 0)
/* 170 */         n = 1; 
/* 171 */       if (paramInt1 == 0) {
/* 173 */         int i1 = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbWidth", paramJComponent, Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.slider.thumb.width", paramJComponent, 10)))).intValue();
/* 174 */         int i2 = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbX", paramJComponent, Integer.valueOf(paramInt7))).intValue();
/* 175 */         paramInt7 -= i1;
/* 176 */         if (((paramBoolean ? 0 : 1) ^ (paramJComponent.getComponentOrientation().isLeftToRight() ? 0 : 1)) != 0) {
/* 178 */           paramInt7 = bool ? (i2 - paramInt5 + i1 / 2) : (paramInt7 * m / n + i1 / 2);
/* 179 */           insets2.right = 0;
/*     */         } else {
/* 183 */           int i3 = bool ? (paramInt7 + paramInt5 - i2 + i1 / 2) : (paramInt7 * m / n + i1 / 2);
/* 184 */           paramInt5 += paramInt7 - i3 + i1;
/* 185 */           paramInt7 = i3;
/* 186 */           insets2.left = 0;
/*     */         } 
/*     */       } else {
/* 191 */         int i1 = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbHeight", paramJComponent, Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.slider.thumb.height", paramJComponent, 10)))).intValue();
/* 192 */         int i2 = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbY", paramJComponent, Integer.valueOf(paramInt8))).intValue();
/* 193 */         paramInt8 -= i1;
/* 194 */         if (!paramBoolean) {
/* 196 */           int i3 = bool ? (paramInt8 + paramInt6 - i2 + i1 / 2) : (paramInt8 * m / n + i1 / 2);
/* 197 */           paramInt6 += paramInt8 - i3 + i1;
/* 198 */           paramInt8 = i3;
/* 199 */           insets2.top = 0;
/*     */         } else {
/* 203 */           paramInt8 = bool ? (i2 - paramInt6 + i1 / 2) : (paramInt8 * m / n + i1 / 2);
/* 204 */           insets2.bottom = 0;
/*     */         } 
/*     */       } 
/* 207 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, "track", i, j, k, paramSyntheticaState.getState(), paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8, str2, insets1, insets2, 0, 0);
/* 208 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintSliderThumbBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*     */   
/*     */   public void paintSliderThumbBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 221 */     JSlider jSlider = (JSlider)paramSynthContext.getComponent();
/* 222 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/* 223 */     paintSliderThumb(jSlider, syntheticaPainterState, paramInt5, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintSliderThumb(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 240 */     if (isSliderTrackMarkEnabled(paramJComponent)) {
/* 242 */       int i = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbX", paramJComponent, Integer.valueOf(-1))).intValue();
/* 243 */       int j = ((Integer)SyntheticaLookAndFeel.getClientProperty("Synthetica.thumbY", paramJComponent, Integer.valueOf(-1))).intValue();
/* 244 */       if (i != paramInt2 || j != paramInt3) {
/* 246 */         paramJComponent.putClientProperty("Synthetica.thumbX", Integer.valueOf(paramInt2));
/* 247 */         paramJComponent.putClientProperty("Synthetica.thumbY", Integer.valueOf(paramInt3));
/* 248 */         paramJComponent.putClientProperty("Synthetica.thumbWidth", Integer.valueOf(paramInt4));
/* 249 */         paramJComponent.putClientProperty("Synthetica.thumbHeight", Integer.valueOf(paramInt5));
/* 250 */         paramJComponent.repaint();
/*     */       } 
/*     */     } 
/* 254 */     UIKey uIKey = new UIKey("slider.thumb", paramSyntheticaState, -1, -1, paramInt1);
/* 255 */     Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "image.insets", true, 1);
/* 256 */     Insets insets2 = insets1;
/* 257 */     String str = SyntheticaLookAndFeel.getString(uIKey.get("image"), paramJComponent);
/* 260 */     if (paramSyntheticaState.isSet(SyntheticaState.State.PRESSED) && str == null) {
/* 262 */       paramSyntheticaState.setState(SyntheticaState.State.HOVER.toInt());
/* 263 */       uIKey = new UIKey("slider.thumb", paramSyntheticaState, -1, -1, paramInt1);
/* 264 */       str = SyntheticaLookAndFeel.getString(uIKey.get("image"), paramJComponent);
/*     */     } 
/* 267 */     if (str != null) {
/* 269 */       uIKey = new UIKey("slider.thumb", paramSyntheticaState);
/* 270 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, 1);
/* 271 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 50);
/* 272 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 2);
/* 273 */       if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER) || paramSyntheticaState.isSet(SyntheticaState.State.PRESSED))
/* 274 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 1); 
/* 276 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, "thumb", i, j, k, paramSyntheticaState.getState(), paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5, str, insets1, insets2, 0, 0);
/* 277 */       imagePainter.draw();
/*     */     } 
/* 280 */     if (paramJComponent.hasFocus() || paramSyntheticaState.isSet(SyntheticaState.State.FOCUSED)) {
/* 282 */       String str1 = null;
/* 283 */       if (SyntheticaLookAndFeel.get("Synthetica.focus.slider.thumb.x", paramJComponent) != null && ((JSlider)paramJComponent).getOrientation() == 0) {
/* 284 */         str1 = "focus.slider.thumb.x";
/* 285 */       } else if (SyntheticaLookAndFeel.get("Synthetica.focus.slider.thumb.y", paramJComponent) != null && ((JSlider)paramJComponent).getOrientation() == 1) {
/* 286 */         str1 = "focus.slider.thumb.y";
/* 287 */       } else if (SyntheticaLookAndFeel.get("Synthetica.focus.slider.thumb", paramJComponent) != null) {
/* 288 */         str1 = "focus.slider.thumb";
/*     */       } 
/* 290 */       if (str1 != null)
/* 291 */         FocusPainter.paintFocus(str1, paramJComponent, paramSyntheticaState.getState(), "", paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isSliderTrackMarkEnabled(JComponent paramJComponent) {
/* 297 */     return !(!SyntheticaLookAndFeel.getBoolean("Synthetica.slider.hoverAndPressed.enabled", paramJComponent, false) && 
/* 298 */       !SyntheticaLookAndFeel.getBoolean("Synthetica.slider.trackMark.enabled", paramJComponent, false));
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 304 */     if (paramString.equals("paintSliderBackground"))
/* 305 */       return -1; 
/* 307 */     JSlider jSlider = (JSlider)paramSynthContext.getComponent();
/* 308 */     int i = jSlider.getOrientation();
/* 310 */     int j = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 311 */     j = 31 * j + i;
/* 312 */     return j;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SliderPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */