/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class TextPanePainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.TextPanePainter";
/*    */   
/*    */   public static TextPanePainter getInstance() {
/* 42 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static TextPanePainter getInstance(SynthContext paramSynthContext) {
/* 51 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TextPanePainter.class, "Synthetica.TextPanePainter"));
/* 52 */     if (syntheticaComponentPainter == null)
/* 53 */       syntheticaComponentPainter = getInstance(paramSynthContext, TextPanePainter.class, "Synthetica.TextPanePainter"); 
/* 54 */     return (TextPanePainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintTextPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTextPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 66 */     paintBackground("textPane", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 72 */     return Cacheable.ScaleType.NINE_SQUARE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TextPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */