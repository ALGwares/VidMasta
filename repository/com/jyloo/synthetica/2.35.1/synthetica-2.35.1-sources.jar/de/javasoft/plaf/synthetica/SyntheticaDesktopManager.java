/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import java.lang.reflect.Field;
/*    */ import javax.swing.DefaultDesktopManager;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JInternalFrame;
/*    */ 
/*    */ public class SyntheticaDesktopManager extends DefaultDesktopManager {
/*    */   private static final long serialVersionUID = -4402279640030928428L;
/*    */   
/*    */   public void beginDraggingFrame(JComponent paramJComponent) {
/* 35 */     boolean bool = paramJComponent.isOpaque();
/* 37 */     if (!bool)
/* 38 */       paramJComponent.setOpaque(true); 
/* 39 */     super.beginDraggingFrame(paramJComponent);
/* 41 */     paramJComponent.setOpaque(bool);
/*    */   }
/*    */   
/*    */   public void dragFrame(JComponent paramJComponent, int paramInt1, int paramInt2) {
/* 47 */     super.dragFrame(paramJComponent, paramInt1, paramInt2);
/* 48 */     if (paramJComponent instanceof JInternalFrame) {
/* 50 */       setDragging(paramJComponent, false);
/* 51 */       repaintBorder(paramJComponent);
/* 52 */       setDragging(paramJComponent, true);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void repaintBorder(JComponent paramJComponent) {
/* 58 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.internalFrame.border.insets", paramJComponent);
/* 59 */     int i = paramJComponent.getWidth();
/* 60 */     int j = paramJComponent.getHeight();
/* 62 */     paramJComponent.paintImmediately(0, 0, i, insets.top);
/* 64 */     paramJComponent.paintImmediately(0, insets.top, insets.left, j - insets.top - insets.bottom);
/* 66 */     paramJComponent.paintImmediately(0, j - insets.bottom, i, insets.bottom);
/* 68 */     paramJComponent.paintImmediately(i - insets.right, insets.top, insets.right, j - insets.top - insets.bottom);
/*    */   }
/*    */   
/*    */   private void setDragging(JComponent paramJComponent, boolean paramBoolean) {
/* 73 */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*    */       try {
/* 77 */         Class<JInternalFrame> clazz = JInternalFrame.class;
/* 78 */         Field field = clazz.getDeclaredField("isDragging");
/* 79 */         field.setAccessible(true);
/* 80 */         field.set(paramJComponent, Boolean.valueOf(paramBoolean));
/* 82 */       } catch (Exception exception) {
/* 84 */         throw new RuntimeException(exception);
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDesktopManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */