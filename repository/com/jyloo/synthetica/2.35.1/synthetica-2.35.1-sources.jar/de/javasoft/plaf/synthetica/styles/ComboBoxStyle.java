/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ComboBoxStyle extends StyleWrapper {
/* 29 */   private static ComboBoxStyle instance = new ComboBoxStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 37 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 39 */       instance.setStyle(paramSynthStyle);
/* 40 */       return instance;
/*    */     } 
/* 42 */     ComboBoxStyle comboBoxStyle = new ComboBoxStyle();
/* 43 */     comboBoxStyle.setStyle(paramSynthStyle);
/* 44 */     return comboBoxStyle;
/*    */   }
/*    */   
/*    */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/* 50 */     Insets insets = super.getInsets(paramSynthContext, paramInsets);
/* 51 */     if (!paramSynthContext.getComponent().getComponentOrientation().isLeftToRight())
/* 52 */       insets = new Insets(insets.top, insets.right, insets.bottom, insets.left); 
/* 53 */     return insets;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ComboBoxStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */