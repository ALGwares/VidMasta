/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class ArrowButtonPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ArrowButtonPainter";
/*     */   
/*     */   public static ArrowButtonPainter getInstance() {
/*  53 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ArrowButtonPainter getInstance(SynthContext paramSynthContext) {
/*  62 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ArrowButtonPainter.class, "Synthetica.ArrowButtonPainter"));
/*  63 */     if (syntheticaComponentPainter == null)
/*  64 */       syntheticaComponentPainter = getInstance(paramSynthContext, ArrowButtonPainter.class, "Synthetica.ArrowButtonPainter"); 
/*  65 */     return (ArrowButtonPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintArrowButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintArrowButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  78 */     JButton jButton = (JButton)paramSynthContext.getComponent();
/*  79 */     Container container = jButton.getParent();
/*  80 */     String str1 = jButton.getName();
/*  81 */     boolean bool1 = false;
/*  82 */     if (container instanceof JComboBox)
/*  83 */       bool1 = ((JComboBox)container).isEditable() ? false : SyntheticaState.State.LOCKED.toInt(); 
/*  84 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, bool1, false);
/*  87 */     if (str1 != null && str1.startsWith("SplitPaneDivider."))
/*     */       return; 
/*  90 */     int i = ((Integer)jButton.getClientProperty("__arrow_direction__")).intValue();
/*  91 */     boolean bool2 = true;
/*  92 */     boolean bool3 = ((i == 5 || i == 1) && !jButton.getComponentOrientation().isLeftToRight()) ? true : false;
/*  94 */     if (container instanceof JComboBox || (str1 != null && str1.startsWith("ComboBox.arrowButton"))) {
/*  96 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", container))
/*  97 */         syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, bool1, false, true); 
/*  98 */       i = 7;
/* 100 */     } else if (container instanceof javax.swing.JSpinner || "Spinner.nextButton".equals(str1) || "Spinner.previousButton".equals(str1)) {
/* 102 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.hoverAndPressed.enabled", container))
/* 103 */         syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, bool1, false, false); 
/* 104 */       i = 7;
/*     */     } 
/* 148 */     Insets insets1 = null;
/* 149 */     UIKey uIKey = new UIKey("arrowButton.y.background", syntheticaPainterState);
/* 150 */     if (bool2) {
/* 153 */       if (paramInt3 <= 12 || paramInt4 <= 12) {
/* 154 */         uIKey = new UIKey("arrowButton.8x8.background", syntheticaPainterState);
/* 156 */       } else if (i == 3 || i == 7) {
/* 157 */         uIKey = new UIKey("arrowButton.x.background", syntheticaPainterState);
/*     */       } 
/* 158 */       insets1 = (Insets)uIKey.findProperty(paramSynthContext, "insets", true, 3);
/*     */     } 
/* 161 */     String str2 = (String)uIKey.findProperty(paramSynthContext, null, true, 2);
/* 162 */     Insets insets2 = insets1;
/* 164 */     int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), jButton, 1);
/* 165 */     int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), jButton, 50);
/* 166 */     int m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), jButton, 2);
/* 167 */     if (syntheticaPainterState.isSet(SyntheticaState.State.HOVER))
/* 168 */       m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), jButton, 1); 
/* 169 */     ImagePainter imagePainter = new ImagePainter(jButton, null, j, k, m, syntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, 0, 0, bool3, false);
/* 171 */     imagePainter.draw();
/*     */   }
/*     */   
/*     */   public void paintArrowButtonForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 179 */     JComponent jComponent = paramSynthContext.getComponent();
/* 180 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/* 181 */     UIKey uIKey = new UIKey("arrow", syntheticaPainterState, paramInt5, -1, -1);
/* 182 */     boolean bool = ((paramInt5 == 5 || paramInt5 == 1) && !jComponent.getComponentOrientation().isLeftToRight()) ? true : false;
/* 184 */     if (paramInt3 < 16 || paramInt4 < 16) {
/* 186 */       uIKey = new UIKey("arrow.8x8", syntheticaPainterState, paramInt5, -1, -1);
/* 187 */       paramInt1 += (paramInt3 - 8 + 1) / 2;
/* 188 */       paramInt2 += (paramInt4 - 8 + 1) / 2;
/* 189 */       paramInt3 = 8;
/* 190 */       paramInt4 = 8;
/* 192 */     } else if (paramInt3 != 16 || paramInt4 != 16) {
/* 194 */       paramInt1 += bool ? ((paramInt3 - 16) / 2) : ((paramInt3 - 16 + 1) / 2);
/* 195 */       paramInt2 += (paramInt4 - 16 + 1) / 2;
/* 196 */       paramInt3 = 16;
/* 197 */       paramInt4 = 16;
/*     */     } 
/* 200 */     paramInt1 += (jComponent.getClientProperty("Synthetica.arrow.xOffset") == null) ? 0 : ((Integer)jComponent.getClientProperty("Synthetica.arrow.xOffset")).intValue();
/* 201 */     paramInt2 += (jComponent.getClientProperty("Synthetica.arrow.yOffset") == null) ? 0 : ((Integer)jComponent.getClientProperty("Synthetica.arrow.yOffset")).intValue();
/* 203 */     Insets insets1 = new Insets(0, 0, 0, 0);
/* 204 */     Insets insets2 = new Insets(0, 0, 0, 0);
/* 206 */     String str = SyntheticaLookAndFeel.getString(uIKey.get(), jComponent);
/* 207 */     if (str != null) {
/* 209 */       ImagePainter imagePainter = new ImagePainter(jComponent, null, -1, -1, -1, -1, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0, bool, false);
/* 210 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ArrowButtonPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */