/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ScrollPaneLayout;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ public class SyntheticaScrollPaneLayoutManager extends ScrollPaneLayout.UIResource {
/*     */   public void layoutContainer(Container paramContainer) {
/*  40 */     super.layoutContainer(paramContainer);
/*  41 */     Border border = (paramContainer instanceof JComponent) ? ((JComponent)paramContainer).getBorder() : null;
/*  42 */     boolean bool = border instanceof javax.swing.border.TitledBorder;
/*  43 */     boolean bool1 = (SyntheticaLookAndFeel.findDefaultBorder(border) != null) ? true : false;
/*  44 */     if (bool || bool1) {
/*  46 */       JScrollPane jScrollPane = (JScrollPane)paramContainer;
/*  47 */       Component component = jScrollPane.getViewport().getView();
/*  48 */       Insets insets = jScrollPane.getBorder().getBorderInsets(jScrollPane);
/*  49 */       Rectangle rectangle1 = this.viewport.getBounds();
/*  50 */       boolean bool2 = jScrollPane.getComponentOrientation().isLeftToRight();
/*  51 */       int i = 0;
/*  52 */       int j = 0;
/*  53 */       boolean bool3 = component instanceof javax.swing.text.JTextComponent;
/*  54 */       boolean bool4 = component instanceof JTable;
/*  56 */       Rectangle rectangle2 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.vertical.relativeBounds", jScrollPane);
/*  57 */       if (rectangle2 != null) {
/*  59 */         Rectangle rectangle3 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.vertical.relativeBounds", jScrollPane);
/*  60 */         Rectangle rectangle4 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.vertical.relativeBounds", jScrollPane);
/*  61 */         i = (bool3 && rectangle3 != null) ? rectangle3.x : ((bool4 && rectangle4 != null) ? rectangle4.x : rectangle2.x);
/*  62 */         rectangle2 = (Rectangle)rectangle2.clone();
/*     */       } 
/*  64 */       if (bool && SyntheticaLookAndFeel.get("Synthetica.scrollBar.titledBorder.vertical.relativeBounds", jScrollPane) != null) {
/*  65 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.titledBorder.vertical.relativeBounds", jScrollPane)).clone();
/*  66 */       } else if (bool3 && SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.vertical.relativeBounds", jScrollPane) != null) {
/*  67 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.vertical.relativeBounds", jScrollPane)).clone();
/*  68 */       } else if (bool4 && SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.vertical.relativeBounds", jScrollPane) != null) {
/*  69 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.vertical.relativeBounds", jScrollPane)).clone();
/*     */       } 
/*  71 */       boolean bool5 = (component instanceof JTable) ? ((((JTable)component).getTableHeader() != null) ? true : false) : false;
/*  72 */       if (bool5 && rectangle2 != null) {
/*  74 */         rectangle2.y = 0;
/*  75 */         rectangle2.height /= 2;
/*     */       } 
/*  84 */       if (this.vsb != null && this.vsb.isVisible() && rectangle2 != null && insets.right >= rectangle2.x)
/*  86 */         applyScrollBarBounds(this.vsb, rectangle2, bool2); 
/*  91 */       rectangle2 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.horizontal.relativeBounds", jScrollPane);
/*  92 */       if (rectangle2 != null) {
/*  94 */         Rectangle rectangle3 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.horizontal.relativeBounds", jScrollPane);
/*  95 */         Rectangle rectangle4 = (Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.horizontal.relativeBounds", jScrollPane);
/*  96 */         j = (bool3 && rectangle3 != null) ? rectangle3.y : ((bool4 && rectangle4 != null) ? rectangle4.y : rectangle2.y);
/*  97 */         rectangle2 = (Rectangle)rectangle2.clone();
/*     */       } 
/*  99 */       if (bool && SyntheticaLookAndFeel.get("Synthetica.scrollBar.titledBorder.horizontal.relativeBounds", jScrollPane) != null) {
/* 100 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.titledBorder.horizontal.relativeBounds", jScrollPane)).clone();
/* 101 */       } else if (bool3 && SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.horizontal.relativeBounds", jScrollPane) != null) {
/* 102 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.textComponent.horizontal.relativeBounds", jScrollPane)).clone();
/* 103 */       } else if (bool4 && SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.horizontal.relativeBounds", jScrollPane) != null) {
/* 104 */         rectangle2 = (Rectangle)((Rectangle)SyntheticaLookAndFeel.get("Synthetica.scrollBar.table.horizontal.relativeBounds", jScrollPane)).clone();
/*     */       } 
/* 106 */       if (this.hsb != null && this.hsb.isVisible() && rectangle2 != null && insets.bottom >= rectangle2.y) {
/* 108 */         applyScrollBarBounds(this.hsb, rectangle2, true);
/* 109 */         rectangle1.height += rectangle2.y;
/*     */       } 
/* 112 */       if (!rectangle1.equals(this.viewport.getBounds()))
/* 113 */         this.viewport.setBounds(rectangle1); 
/* 115 */       if (this.lowerLeft != null)
/* 116 */         this.lowerLeft.setLocation(this.lowerLeft.getX() - i, this.lowerLeft.getY() + j); 
/* 118 */       if (this.lowerRight != null)
/* 119 */         this.lowerRight.setLocation(this.lowerRight.getX() + i, this.lowerRight.getY() + j); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void applyScrollBarBounds(JScrollBar paramJScrollBar, Rectangle paramRectangle, boolean paramBoolean) {
/* 132 */     Rectangle rectangle = paramJScrollBar.getBounds();
/* 133 */     rectangle.x += paramBoolean ? paramRectangle.x : -paramRectangle.x;
/* 134 */     rectangle.y += paramRectangle.y;
/* 135 */     rectangle.width += paramRectangle.width;
/* 136 */     rectangle.height += paramRectangle.height;
/* 137 */     paramJScrollBar.setBounds(rectangle);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaScrollPaneLayoutManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */