/*    */ package de.javasoft.util;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import java.text.ParseException;
/*    */ 
/*    */ public class JavaVersion {
/* 21 */   private static final int VERSION = getVersion();
/*    */   
/* 23 */   public static final boolean JAVA5 = (VERSION == 5);
/*    */   
/* 24 */   public static final boolean JAVA6 = (VERSION == 6);
/*    */   
/* 25 */   public static final boolean JAVA6U10_OR_ABOVE = isJava6uNOrAbove(10);
/*    */   
/* 26 */   public static final boolean JAVA7 = (VERSION == 7);
/*    */   
/* 27 */   public static final boolean JAVA7_OR_ABOVE = (VERSION >= 7);
/*    */   
/* 28 */   public static final boolean JAVA7U8_OR_ABOVE = isJava7uNOrAbove(8);
/*    */   
/* 29 */   public static final boolean JAVA8 = (VERSION == 8);
/*    */   
/* 30 */   public static final boolean JAVA8_OR_ABOVE = (VERSION >= 8);
/*    */   
/* 31 */   public static final boolean JAVA9 = (VERSION == 9);
/*    */   
/* 32 */   public static final boolean JAVA9_OR_ABOVE = (VERSION >= 9);
/*    */   
/* 33 */   public static final boolean JAVA11 = (VERSION == 11);
/*    */   
/* 34 */   public static final boolean JAVA11_OR_ABOVE = (VERSION >= 11);
/*    */   
/* 35 */   public static final boolean JAVA15 = (VERSION == 15);
/*    */   
/* 36 */   public static final boolean JAVA15_OR_ABOVE = (VERSION >= 15);
/*    */   
/*    */   public static int getVersion() {
/* 46 */     String str = System.getProperty("java.version");
/* 47 */     boolean bool = str.startsWith("1.");
/* 48 */     if (bool)
/* 49 */       str = str.substring(2); 
/* 50 */     int i = str.indexOf('.');
/* 51 */     int j = str.indexOf('-');
/* 52 */     return Integer.parseInt(str.substring(0, (i > -1) ? i : ((j > -1) ? j : (bool ? 1 : str.length()))));
/*    */   }
/*    */   
/*    */   public static boolean isJava6uNOrAbove(int paramInt) {
/* 57 */     String str = System.getProperty("java.version");
/* 58 */     if (JAVA5)
/* 59 */       return false; 
/* 60 */     if (str.equals("1.6.0"))
/* 61 */       return false; 
/* 62 */     if (str.startsWith("1.6.0_"))
/*    */       try {
/* 67 */         int i = ((Long)NumberFormat.getIntegerInstance().parse(str.substring(6))).intValue();
/* 68 */         return (i >= paramInt);
/* 70 */       } catch (ParseException parseException) {
/* 72 */         return false;
/*    */       }  
/* 75 */     return true;
/*    */   }
/*    */   
/*    */   public static boolean isJava7uNOrAbove(int paramInt) {
/* 80 */     String str = System.getProperty("java.version");
/* 81 */     if (JAVA5 || JAVA6)
/* 82 */       return false; 
/* 83 */     if (str.equals("1.7.0"))
/* 84 */       return false; 
/* 85 */     if (str.startsWith("1.7.0_"))
/*    */       try {
/* 90 */         int i = ((Long)NumberFormat.getIntegerInstance().parse(str.substring(6))).intValue();
/* 91 */         return (i >= paramInt);
/* 93 */       } catch (ParseException parseException) {
/* 95 */         return false;
/*    */       }  
/* 98 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasof\\util\JavaVersion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */