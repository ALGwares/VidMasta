/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import java.awt.Container;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class LabelStyle extends StyleWrapper {
/* 36 */   private static LabelStyle instance = new LabelStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 44 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 46 */       instance.setStyle(paramSynthStyle);
/* 47 */       return instance;
/*    */     } 
/* 49 */     LabelStyle labelStyle = new LabelStyle();
/* 50 */     labelStyle.setStyle(paramSynthStyle);
/* 51 */     return labelStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 57 */     JComponent jComponent = paramSynthContext.getComponent();
/* 58 */     Container container = jComponent.getParent();
/* 59 */     if (container != null && container instanceof JComponent) {
/* 61 */       Color color = null;
/* 62 */       if (((JComponent)container).getUIClassID().equals("StatusBarUI")) {
/* 63 */         color = SyntheticaLookAndFeel.getColor("Synthetica.statusBar.label.foreground", jComponent);
/* 64 */       } else if (container instanceof javax.swing.JToolBar) {
/* 65 */         color = SyntheticaLookAndFeel.getColor("Synthetica.toolBar.label.foreground", jComponent);
/*    */       } 
/* 67 */       if (color != null)
/* 68 */         return color; 
/* 70 */     } else if (paramColorType == ColorType.TEXT_FOREGROUND && container instanceof javax.swing.CellRendererPane && container.getParent() instanceof JComboBox) {
/* 72 */       JComboBox jComboBox = (JComboBox)container.getParent();
/* 73 */       Color color = null;
/* 74 */       if (!jComboBox.isEnabled()) {
/* 75 */         color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.disabled.textColor", jComboBox);
/* 77 */       } else if (jComboBox.getForeground() != null && !(jComboBox.getForeground() instanceof javax.swing.plaf.ColorUIResource)) {
/* 78 */         color = jComboBox.getForeground();
/* 79 */       } else if (jComboBox.hasFocus()) {
/* 80 */         color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.focused.textColor", jComboBox);
/* 81 */       } else if (!jComboBox.isEditable()) {
/* 82 */         color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.locked.textColor", jComboBox);
/*    */       } 
/* 83 */       return color;
/*    */     } 
/* 86 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\LabelStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */