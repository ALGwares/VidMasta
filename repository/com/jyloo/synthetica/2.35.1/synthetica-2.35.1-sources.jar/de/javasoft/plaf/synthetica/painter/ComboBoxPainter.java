/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.accessibility.Accessible;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.ComboBoxUI;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class ComboBoxPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ComboBoxPainter";
/*     */   
/*     */   public static ComboBoxPainter getInstance() {
/*  67 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ComboBoxPainter getInstance(SynthContext paramSynthContext) {
/*  76 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ComboBoxPainter.class, "Synthetica.ComboBoxPainter"));
/*  77 */     if (syntheticaComponentPainter == null)
/*  78 */       syntheticaComponentPainter = getInstance(paramSynthContext, ComboBoxPainter.class, "Synthetica.ComboBoxPainter"); 
/*  79 */     return (ComboBoxPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintComboBoxBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  88 */     if (paramSynthContext.getComponent() instanceof JComboBox) {
/*  90 */       JComboBox jComboBox = (JComboBox)paramSynthContext.getComponent();
/*  91 */       if (hasFocus(jComboBox))
/*  92 */         FocusPainter.paintFocus(jComboBox.isEditable() ? "focus.comboBox" : "focus.comboBox.locked", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean hasFocus(JComboBox paramJComboBox) {
/*  98 */     Component component = null;
/*  99 */     if (paramJComboBox.isEditable())
/* 100 */       component = paramJComboBox.getEditor().getEditorComponent(); 
/* 102 */     if (paramJComboBox.hasFocus() || (component != null && component.hasFocus()))
/* 103 */       return true; 
/* 104 */     return false;
/*     */   }
/*     */   
/*     */   public void paintComboBoxBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 113 */     JComboBox jComboBox = (JComboBox)paramSynthContext.getComponent();
/* 114 */     jComboBox.putClientProperty("Synthetica.flipHorizontal", Boolean.valueOf(!jComboBox.getComponentOrientation().isLeftToRight()));
/* 115 */     SyntheticaLookAndFeel.setChildrenOpaque(jComboBox, false);
/* 117 */     Color color = jComboBox.getBackground();
/* 118 */     boolean bool1 = (color != null && !(color instanceof javax.swing.plaf.ColorUIResource)) ? false : true;
/* 119 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.keepLockedBorderIfColored", jComboBox);
/* 120 */     boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.noBorderIfColored", jComboBox);
/* 121 */     boolean bool4 = SyntheticaLookAndFeel.isOpaque(jComboBox);
/* 122 */     boolean bool5 = jComboBox.isEnabled();
/* 123 */     boolean bool6 = jComboBox.isEditable() ? false : true;
/* 125 */     if (!bool4)
/*     */       return; 
/* 127 */     if (bool1) {
/* 130 */       if (hasFocus(jComboBox))
/* 131 */         paramSynthContext = new SynthContext(jComboBox, Region.COMBO_BOX, paramSynthContext.getStyle(), paramSynthContext.getComponentState() | 0x100); 
/* 133 */       if (!bool5) {
/* 134 */         color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.disabled.backgroundColor", jComboBox);
/* 135 */       } else if (bool6) {
/* 137 */         color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.locked.backgroundColor", jComboBox);
/* 138 */         if (color == null)
/* 139 */           color = paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND); 
/*     */       } else {
/* 142 */         color = paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND);
/*     */       } 
/*     */     } 
/* 145 */     SyntheticaPainterState syntheticaPainterState = createState(paramSynthContext, jComboBox);
/* 146 */     UIKey uIKey = getUIKey(jComboBox, "comboBox", syntheticaPainterState);
/* 147 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get(uIKey.get("fillBackground"), jComboBox);
/* 148 */     Border border1 = jComboBox.getBorder();
/* 149 */     Border border2 = SyntheticaLookAndFeel.findDefaultBorder(border1);
/* 150 */     boolean bool7 = (border2 == null) ? false : border2.getClass().getName().equals("javax.swing.plaf.synth.SynthBorder");
/* 151 */     boolean bool8 = (border1 instanceof CompoundBorder && ((CompoundBorder)border1).getInsideBorder() == border2) ? true : false;
/* 153 */     if (bool8) {
/* 155 */       Insets insets3 = border1.getBorderInsets(jComboBox);
/* 156 */       Insets insets4 = border2.getBorderInsets(jComboBox);
/* 157 */       paramInt1 += insets3.left - insets4.left;
/* 158 */       paramInt2 += insets3.top - insets4.top;
/* 159 */       paramInt3 -= insets3.left - insets4.left + insets3.right - insets4.right;
/* 160 */       paramInt4 -= insets3.top - insets4.top + insets3.bottom - insets4.bottom;
/*     */     } 
/* 163 */     if (bool == null || bool.booleanValue())
/* 164 */       fillBackground(jComboBox, border1, border2, bool7, paramGraphics, color, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 166 */     if (!bool1 && bool3)
/*     */       return; 
/* 170 */     SyntheticaState syntheticaState = new SyntheticaState(syntheticaPainterState.getState());
/* 171 */     syntheticaState.resetState(SyntheticaState.State.HOVER);
/* 172 */     syntheticaState.resetState(SyntheticaState.State.PRESSED);
/* 175 */     if (!bool1 && !bool2)
/* 176 */       syntheticaState.resetState(SyntheticaState.State.LOCKED); 
/* 178 */     uIKey = getUIKey(jComboBox, "comboBox.border", syntheticaState);
/* 181 */     String str1 = uIKey.get();
/* 182 */     boolean bool9 = (SyntheticaLookAndFeel.get(str1, jComboBox) != null) ? true : false;
/* 183 */     if ((str1.equals("Synthetica.comboBox.border.disabled") && !bool9) || (
/* 184 */       str1.equals("Synthetica.comboBox.border.locked") && !bool9) || (
/* 185 */       str1.equals("Synthetica.comboBox.border.disabled.locked") && !bool9))
/* 187 */       uIKey = getUIKey(jComboBox, "textField.border", syntheticaState); 
/* 190 */     String str2 = (String)uIKey.findProperty(paramSynthContext, null, true, 1);
/* 191 */     if (syntheticaPainterState.isSet(SyntheticaState.State.FOCUSED) && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused", jComboBox) != null)
/* 192 */       str2 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused", jComboBox); 
/* 193 */     if (jComboBox.isPopupVisible() && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".opened", jComboBox) != null) {
/* 195 */       str2 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".opened", jComboBox);
/* 196 */       BasicComboPopup basicComboPopup = null;
/*     */       try {
/* 200 */         ComboBoxUI comboBoxUI = jComboBox.getUI();
/* 201 */         Method method = comboBoxUI.getClass().getDeclaredMethod("getPopup", null);
/* 202 */         basicComboPopup = (BasicComboPopup)method.invoke(comboBoxUI, null);
/* 204 */       } catch (Exception exception) {
/* 206 */         Accessible accessible = jComboBox.getUI().getAccessibleChild(jComboBox, 0);
/* 207 */         if (accessible instanceof BasicComboPopup)
/* 208 */           basicComboPopup = (BasicComboPopup)accessible; 
/*     */       } 
/* 210 */       Boolean bool10 = Boolean.valueOf((basicComboPopup == null) ? true : MenuPainter.popupIsBelowInvoker(jComboBox, basicComboPopup).booleanValue());
/* 211 */       if ((bool10 == null || !bool10.booleanValue()) && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".openedAndPopupNotBelow", jComboBox) != null)
/* 212 */         str2 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".openedAndPopupNotBelow", jComboBox); 
/*     */     } 
/* 215 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.comboBox.border.insets", jComboBox);
/* 216 */     Insets insets2 = (SyntheticaLookAndFeel.get("Synthetica.comboBox.border.dInsets", jComboBox) == null) ? insets1 : SyntheticaLookAndFeel.getInsets("Synthetica.comboBox.border.dInsets", jComboBox);
/* 218 */     if (!bool7) {
/* 220 */       Insets insets = jComboBox.getInsets();
/* 221 */       paramInt1 += insets.left;
/* 222 */       paramInt2 += insets.top;
/* 223 */       paramInt3 += -insets.left - insets.right;
/* 224 */       paramInt4 += -insets.top - insets.bottom;
/* 225 */       insets2 = new Insets(0, 0, 0, 0);
/*     */     } 
/* 228 */     ImagePainter imagePainter = new ImagePainter(jComboBox, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, 0, 0);
/* 229 */     if (!bool1 && !bool2) {
/* 230 */       imagePainter.drawBorder();
/* 231 */     } else if (!bool7) {
/* 232 */       imagePainter.drawCenter();
/*     */     } else {
/* 234 */       imagePainter.draw();
/*     */     } 
/* 236 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", jComboBox))
/* 237 */       paintHoverPressed(jComboBox, syntheticaPainterState, border1, border2, bool8, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, insets1, insets2); 
/*     */   }
/*     */   
/*     */   private void fillBackground(JComponent paramJComponent, Border paramBorder1, Border paramBorder2, boolean paramBoolean, Graphics paramGraphics, Color paramColor, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 242 */     Color color = paramGraphics.getColor();
/* 243 */     paramGraphics.setColor(paramColor);
/* 244 */     Insets insets = paramJComponent.getInsets();
/* 246 */     if (paramBorder1 == null || insets.equals(new Insets(0, 0, 0, 0))) {
/* 247 */       paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 248 */     } else if (!paramBoolean) {
/* 249 */       paramGraphics.fillRect(paramInt1 + insets.left, paramInt2 + insets.top, paramInt3 - insets.left - insets.right, paramInt4 - insets.top - insets.bottom);
/*     */     } else {
/* 252 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.comboBox.border.fillInsets", paramJComponent, false);
/* 253 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.comboBox.border.arcWidth", paramJComponent, 8);
/* 254 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.comboBox.border.arcHeight", paramJComponent, 8);
/* 255 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 256 */       RenderingHints renderingHints = graphics2D.getRenderingHints();
/* 257 */       graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 258 */       graphics2D.fillRoundRect(paramInt1 + insets1.left, paramInt2 + insets1.top, paramInt3 - insets1.left - insets1.right, paramInt4 - insets1.top - insets1.bottom, i, j);
/* 259 */       graphics2D.setRenderingHints(renderingHints);
/*     */     } 
/* 262 */     paramGraphics.setColor(color);
/*     */   }
/*     */   
/*     */   private SyntheticaPainterState createState(SynthContext paramSynthContext, JComboBox paramJComboBox) {
/* 267 */     byte b = 0;
/* 268 */     JButton jButton = (JButton)SyntheticaLookAndFeel.findComponent(JButton.class, paramJComboBox);
/* 269 */     if (jButton != null && jButton.getModel().isPressed())
/* 270 */       b = 4; 
/* 271 */     return new SyntheticaPainterState(paramSynthContext, b, true);
/*     */   }
/*     */   
/*     */   private void paintHoverPressed(JComboBox paramJComboBox, SyntheticaPainterState paramSyntheticaPainterState, Border paramBorder1, Border paramBorder2, boolean paramBoolean, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Insets paramInsets1, Insets paramInsets2) {
/* 278 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.stateChange4ButtonOnly", paramJComboBox)) {
/* 280 */       boolean bool = paramJComboBox.getComponentOrientation().isLeftToRight();
/* 281 */       if (paramInsets1.equals(paramInsets2))
/* 282 */         paramInsets2 = new Insets(paramInsets1.top, 0, paramInsets1.bottom, paramInsets1.right); 
/* 283 */       int m = SyntheticaLookAndFeel.findComponent(JButton.class, paramJComboBox).getWidth();
/* 284 */       Insets insets = paramBoolean ? paramBorder2.getBorderInsets(paramJComboBox) : paramJComboBox.getInsets();
/* 285 */       int n = SyntheticaLookAndFeel.getInt("Synthetica.comboBox.button.relativeX", paramJComboBox, 0);
/* 286 */       if (paramBorder2 != null) {
/* 288 */         paramInt1 += bool ? (paramInt3 - insets.right - m + n) : 0;
/* 289 */         paramInt3 = m + (bool ? insets.right : insets.left) - n;
/*     */       } else {
/* 298 */         paramInt1 += bool ? (paramInt3 - m + n) : 0;
/* 299 */         paramInt3 = m - n;
/*     */       } 
/*     */     } 
/* 303 */     UIKey uIKey1 = getUIKey(paramJComboBox, "comboBox", paramSyntheticaPainterState);
/* 304 */     UIKey uIKey2 = getUIKey(paramJComboBox, "comboBox.border", paramSyntheticaPainterState);
/* 305 */     String str = (String)UIKey.findProperty(paramJComboBox, uIKey2.get(), (String)null, true, 2);
/* 307 */     int i = SyntheticaLookAndFeel.getInt(uIKey1.get("animation.cycles"), paramJComboBox, 1);
/* 308 */     int j = SyntheticaLookAndFeel.getInt(uIKey1.get("animation.delay"), paramJComboBox, 50);
/* 309 */     int k = SyntheticaLookAndFeel.getInt(uIKey1.get("animation.type"), paramJComboBox, 2);
/* 310 */     if (paramSyntheticaPainterState.isSet(SyntheticaState.State.HOVER) || paramSyntheticaPainterState.isSet(SyntheticaState.State.PRESSED)) {
/* 311 */       k = SyntheticaLookAndFeel.getInt(uIKey1.get("animation.type"), paramJComboBox, 1);
/* 312 */     } else if (!SyntheticaLookAndFeel.getBoolean("Synthetica.animation.enabled", paramJComboBox, false)) {
/*     */       return;
/*     */     } 
/* 314 */     ImagePainter imagePainter = new ImagePainter(paramJComboBox, i, j, k, paramSyntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, paramInsets1, paramInsets2, 0, 0);
/* 315 */     if (paramBorder2 == null) {
/* 316 */       imagePainter.drawCenter();
/*     */     } else {
/* 318 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected UIKey getUIKey(JComponent paramJComponent, String paramString, SyntheticaState paramSyntheticaState) {
/* 323 */     return new UIKey(paramString, paramSyntheticaState);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 329 */     JComponent jComponent = paramSynthContext.getComponent();
/* 330 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 332 */     if (jComponent instanceof JComboBox) {
/* 334 */       JComboBox jComboBox = (JComboBox)paramSynthContext.getComponent();
/* 335 */       boolean bool1 = jComboBox.isEditable() ? false : true;
/* 336 */       boolean bool2 = (jComboBox.getClientProperty("Synthetica.MOUSE_OVER") == null) ? false : ((Boolean)jComboBox.getClientProperty("Synthetica.MOUSE_OVER")).booleanValue();
/* 337 */       i = 31 * i + (bool1 ? 0 : 1);
/* 338 */       i = 31 * i + (bool2 ? 0 : 1);
/* 339 */       i = 31 * i + (hasFocus(jComboBox) ? 0 : 1);
/*     */     } 
/* 341 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ComboBoxPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */