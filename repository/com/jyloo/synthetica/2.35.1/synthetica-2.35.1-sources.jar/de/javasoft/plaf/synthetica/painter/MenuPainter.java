/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import de.javasoft.util.java2d.Synthetica2DUtils;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.lang.reflect.Field;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class MenuPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.MenuPainter";
/*     */   
/*     */   private static Icon topMarkerIcon;
/*     */   
/*     */   private static Icon bottomMarkerIcon;
/*     */   
/*     */   public static MenuPainter getInstance() {
/*  62 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static MenuPainter getInstance(SynthContext paramSynthContext) {
/*  71 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, MenuPainter.class, "Synthetica.MenuPainter"));
/*  72 */     if (syntheticaComponentPainter == null)
/*  73 */       syntheticaComponentPainter = getInstance(paramSynthContext, MenuPainter.class, "Synthetica.MenuPainter"); 
/*  74 */     return (MenuPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public static void reinitialize() {
/*  81 */     topMarkerIcon = null;
/*  82 */     bottomMarkerIcon = null;
/*     */   }
/*     */   
/*     */   public void paintMenuBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintPopupMenuBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintMenuBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintPopupMenuBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 106 */     JPopupMenu jPopupMenu = (JPopupMenu)paramSynthContext.getComponent();
/* 108 */     boolean bool = SyntheticaLookAndFeel.isToplevelPopupMenu(jPopupMenu);
/* 109 */     paintPopupMenuBackground(jPopupMenu, bool, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/* 111 */     if (bool) {
/* 113 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.insets", jPopupMenu, false);
/* 115 */       paintToplevelPopupMenuMarker(jPopupMenu, insets, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       byte b;
/*     */       int i;
/*     */       Component[] arrayOfComponent;
/* 118 */       for (i = (arrayOfComponent = jPopupMenu.getComponents()).length, b = 0; b < i; ) {
/* 118 */         Component component = arrayOfComponent[b];
/* 120 */         if (component instanceof JComponent && ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.popupMenu.title", (JComponent)component, Boolean.valueOf(false))).booleanValue()) {
/* 122 */           Rectangle rectangle = component.getBounds();
/* 123 */           paintToplevelPopupMenuTitleBackground(jPopupMenu, paramGraphics, insets.left, rectangle.y, paramInt3 - insets.left - insets.right, rectangle.height);
/*     */         } 
/*     */         b++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintPopupMenuBackground(JPopupMenu paramJPopupMenu, boolean paramBoolean, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 134 */     Component component = paramJPopupMenu.getInvoker();
/* 136 */     boolean bool = (SyntheticaLookAndFeel.get("Synthetica.comboPopup.insets", paramJPopupMenu) != null) ? true : false;
/* 137 */     if (!bool && paramJPopupMenu.getName() != null && paramJPopupMenu.getName().startsWith("ComboPopup")) {
/* 139 */       if (!SyntheticaLookAndFeel.isWindowOpacityEnabled(null)) {
/* 141 */         Component component1 = SyntheticaLookAndFeel.findComponent(JList.class, paramJPopupMenu);
/* 142 */         if (component1 != null) {
/* 143 */           paramGraphics.setColor(component1.getBackground());
/*     */         } else {
/* 145 */           paramGraphics.setColor(paramJPopupMenu.getBackground());
/*     */         } 
/* 146 */         paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       } 
/*     */       return;
/*     */     } 
/* 152 */     JComponent jComponent = (JComponent)paramJPopupMenu.getParent();
/* 157 */     String str = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.background", paramJPopupMenu);
/* 158 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.background.insets", paramJPopupMenu);
/* 159 */     Insets insets2 = insets1;
/* 161 */     if (paramBoolean) {
/* 163 */       insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.background.insets", paramJPopupMenu, false);
/* 164 */       insets2 = insets1;
/* 165 */       Boolean bool1 = popupIsBelowInvoker(component, paramJPopupMenu);
/* 167 */       if (bool1 == null)
/* 168 */         bool1 = Boolean.valueOf(false); 
/* 169 */       str = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.toplevel" + (bool1.booleanValue() ? ".belowInvoker.background" : ".aboveInvoker.background"), paramJPopupMenu);
/* 170 */       if (str == null)
/* 171 */         str = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.toplevel.background", paramJPopupMenu); 
/*     */     } 
/* 174 */     BufferedImage bufferedImage = (jComponent == null) ? null : (BufferedImage)jComponent.getClientProperty("POPUP_BACKGROUND");
/* 177 */     if (bufferedImage != null)
/* 179 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.blur.enabled", paramJPopupMenu)) {
/* 182 */         if (!((Boolean)jComponent.getClientProperty("POPUP_LIGHTWEIGHT")).booleanValue()) {
/* 184 */           ImagePainter imagePainter2 = new ImagePainter(bufferedImage, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, insets1, insets2);
/* 185 */           imagePainter2.drawBorder();
/*     */         } 
/* 188 */         Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.blur.insets", paramJPopupMenu);
/* 189 */         int i = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.blur.size", paramJPopupMenu, 5);
/* 190 */         BufferedImage bufferedImage1 = Synthetica2DUtils.createBlurredImage(bufferedImage, i);
/* 191 */         ImagePainter imagePainter1 = new ImagePainter(bufferedImage1, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, insets, insets);
/* 192 */         imagePainter1.drawCenter();
/* 194 */         String str1 = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.blur.background", paramJPopupMenu);
/* 195 */         if (str1 != null && !paramBoolean)
/* 196 */           str = str1; 
/*     */       } else {
/* 199 */         paramGraphics.drawImage(bufferedImage, paramInt1, paramInt2, null);
/*     */       }  
/* 203 */     ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 204 */     imagePainter.draw();
/* 207 */     str = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.iconSeparator", paramJPopupMenu);
/* 208 */     if (str != null)
/* 210 */       if ((SyntheticaLookAndFeel.preservePopupIconSpace(paramJPopupMenu) || SyntheticaLookAndFeel.popupHasCheckRadio(paramJPopupMenu)) && 
/* 211 */         !SyntheticaLookAndFeel.popupHasCheckRadioWithIcon(paramJPopupMenu)) {
/* 213 */         boolean bool1 = paramJPopupMenu.getComponentOrientation().isLeftToRight();
/* 214 */         Insets insets = paramJPopupMenu.getInsets();
/* 215 */         int i = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparator.gap", paramJPopupMenu, 24);
/* 216 */         Integer integer = (Integer)paramJPopupMenu.getClientProperty("Synthetica.menuItem.maxIconWidth");
/* 217 */         int j = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparator.width", paramJPopupMenu, 1);
/* 219 */         if (integer != null && integer.intValue() > 0)
/* 220 */           j += integer.intValue() - 16; 
/* 221 */         paramJPopupMenu.putClientProperty("Synthetica.flipHorizontal", Boolean.valueOf(!bool1));
/* 222 */         int k = paramInt1 + (bool1 ? i : (paramInt3 - insets.right - i - j + insets.left));
/* 223 */         int m = paramInt2 + insets.top;
/* 224 */         int n = paramInt4 - insets.top - insets.bottom;
/* 225 */         insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.iconSeparator.insets", paramJPopupMenu, new Insets(0, 0, 0, 2));
/* 226 */         insets2 = insets1;
/* 227 */         imagePainter = new ImagePainter(paramJPopupMenu, paramGraphics, k, m, j, n, str, insets1, insets2, 0, 0);
/* 228 */         imagePainter.draw();
/* 229 */         paramJPopupMenu.putClientProperty("Synthetica.flipHorizontal", Boolean.valueOf(false));
/*     */       }  
/*     */   }
/*     */   
/*     */   protected void paintToplevelPopupMenuMarker(JPopupMenu paramJPopupMenu, Insets paramInsets, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 236 */     if (topMarkerIcon == null)
/* 237 */       topMarkerIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.popupMenu.toplevel.topMarker.image"); 
/* 238 */     if (bottomMarkerIcon == null)
/* 239 */       bottomMarkerIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.popupMenu.toplevel.bottomMarker.image"); 
/* 241 */     Component component = paramJPopupMenu.getInvoker();
/* 242 */     Boolean bool = popupIsBelowInvoker(component, paramJPopupMenu);
/* 243 */     Icon icon = (bool == null) ? null : (bool.booleanValue() ? topMarkerIcon : bottomMarkerIcon);
/* 244 */     if (icon != null) {
/* 246 */       Point point = SwingUtilities.convertPoint(component, component.getWidth() / 2, paramInt2, paramJPopupMenu);
/* 247 */       int i = bool.booleanValue() ? paramInt2 : (paramInt2 + paramInt4 - icon.getIconHeight());
/* 248 */       icon.paintIcon(paramJPopupMenu, paramGraphics, point.x - icon.getIconWidth() / 2, i);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void paintToplevelPopupMenuTitleBackground(JComponent paramJComponent, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 254 */     String str = SyntheticaLookAndFeel.getString("Synthetica.popupMenu.toplevel.title.background", paramJComponent);
/* 255 */     if (str != null) {
/* 257 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.title.background.insets", paramJComponent, false);
/* 258 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 259 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   static Boolean popupIsBelowInvoker(Component paramComponent, JPopupMenu paramJPopupMenu) {
/* 266 */     Point point1 = paramComponent.getLocation();
/* 267 */     SwingUtilities.convertPointToScreen(point1, paramComponent.getParent());
/* 268 */     Point point2 = new Point(0, (paramJPopupMenu.getLocation()).y);
/* 269 */     SwingUtilities.convertPointToScreen(point2, paramJPopupMenu.getParent());
/* 270 */     if (point2.y >= point1.y + paramComponent.getHeight() / 2)
/* 271 */       return Boolean.TRUE; 
/* 272 */     if (point2.y + paramJPopupMenu.getHeight() <= point1.y + paramComponent.getHeight() / 2)
/* 273 */       return Boolean.FALSE; 
/* 274 */     return null;
/*     */   }
/*     */   
/*     */   public void paintMenuBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 282 */     String str = null;
/* 283 */     JMenu jMenu = (JMenu)paramSynthContext.getComponent();
/* 284 */     int i = paramSynthContext.getComponentState();
/* 285 */     boolean bool1 = ((i & 0x8) > 0) ? true : false;
/* 286 */     boolean bool2 = ((i & 0x200) > 0) ? true : false;
/* 289 */     Boolean bool = (Boolean)jMenu.getClientProperty("Synthetica.MOUSE_OVER");
/* 290 */     boolean bool3 = (bool == null) ? false : bool.booleanValue();
/* 291 */     if (bool3)
/* 292 */       i |= 0x2; 
/* 293 */     boolean bool4 = ((i & 0x2) > 0) ? true : false;
/* 296 */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*     */       try {
/* 300 */         Icon icon = paramSynthContext.getStyle().getIcon(paramSynthContext, "Menu.arrowIcon");
/* 301 */         BasicMenuUI basicMenuUI = (BasicMenuUI)((JMenu)paramSynthContext.getComponent()).getUI();
/* 303 */         Class<?> clazz = Class.forName("javax.swing.plaf.basic.BasicMenuItemUI");
/* 304 */         Field field = clazz.getDeclaredField("arrowIcon");
/* 305 */         field.setAccessible(true);
/* 306 */         field.set(basicMenuUI, icon);
/* 308 */       } catch (Exception exception) {
/* 310 */         throw new RuntimeException(exception);
/*     */       }  
/* 315 */     str = "Synthetica.menu";
/* 316 */     Insets insets = null;
/* 317 */     if (jMenu.isTopLevelMenu()) {
/* 320 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.menu.toplevel.paintMenuBarBackground", jMenu.getParent())) {
/* 322 */         str = String.valueOf(str) + ".toplevel.menuBarBackground";
/* 323 */         Container container = jMenu.getParent();
/* 324 */         if (isSingleTopLevelMenu(jMenu, container)) {
/* 325 */           str = String.valueOf(str) + ".single";
/* 326 */         } else if (isFirstTopLevelMenu(jMenu, container)) {
/* 327 */           str = String.valueOf(str) + ".first";
/* 328 */         } else if (isLastTopLevelMenu(jMenu, container)) {
/* 329 */           str = String.valueOf(str) + ".last";
/*     */         } else {
/* 331 */           str = String.valueOf(str) + ".middle";
/*     */         } 
/* 332 */         str = SyntheticaLookAndFeel.getString(str, jMenu);
/* 333 */         insets = SyntheticaLookAndFeel.getInsets("Synthetica.menu.toplevel.menuBarBackground.insets", jMenu, false);
/* 334 */         ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 335 */         imagePainter.draw();
/* 336 */         str = "Synthetica.menu";
/*     */       } 
/* 339 */       str = String.valueOf(str) + ".toplevel.background";
/* 340 */       if (bool1) {
/* 341 */         str = String.valueOf(str) + ".disabled";
/* 342 */       } else if (bool2) {
/* 343 */         str = String.valueOf(str) + ".selected";
/* 344 */       } else if (bool4) {
/* 345 */         str = String.valueOf(str) + ((SyntheticaLookAndFeel.getString(String.valueOf(str) + ".hover", jMenu) != null) ? ".hover" : ".selected");
/*     */       } 
/* 346 */       str = SyntheticaLookAndFeel.getString(str, jMenu);
/* 347 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.menu.toplevel.background.insets", jMenu);
/*     */     } else {
/* 351 */       if (bool1) {
/* 352 */         str = String.valueOf(str) + ".disabled";
/* 353 */       } else if (bool4) {
/* 354 */         str = String.valueOf(str) + ".hover";
/* 355 */       } else if (bool2) {
/* 357 */         if (SyntheticaLookAndFeel.getString(String.valueOf(str) + ".selected", jMenu) == null) {
/* 358 */           str = String.valueOf(str) + ".hover";
/*     */         } else {
/* 360 */           str = String.valueOf(str) + ".selected";
/*     */         } 
/*     */       } 
/* 363 */       str = SyntheticaLookAndFeel.getString(str, jMenu);
/* 364 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.menu.insets", jMenu);
/*     */     } 
/* 366 */     if (str != null) {
/* 368 */       Insets insets1 = insets;
/* 370 */       int j = 0;
/* 371 */       int k = 0;
/* 372 */       int m = 0;
/* 373 */       if (bool4 || bool2) {
/* 375 */         i |= 0x2;
/* 376 */         j = SyntheticaLookAndFeel.getInt("Synthetica.menu.hover.animation.cycles", jMenu, 1);
/* 377 */         k = SyntheticaLookAndFeel.getInt("Synthetica.menu.hover.animation.delay", jMenu, 50);
/* 378 */         m = SyntheticaLookAndFeel.getInt("Synthetica.menu.hover.animation.type", jMenu, 1);
/*     */       } else {
/* 382 */         j = SyntheticaLookAndFeel.getInt("Synthetica.menu.animation.cycles", jMenu, 1);
/* 383 */         k = SyntheticaLookAndFeel.getInt("Synthetica.menu.animation.delay", jMenu, 50);
/* 384 */         m = SyntheticaLookAndFeel.getInt("Synthetica.menu.animation.type", jMenu, 2);
/*     */       } 
/* 386 */       ImagePainter imagePainter = new ImagePainter(jMenu, j, k, m, i, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets1, 0, 0);
/* 387 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean isSingleTopLevelMenu(JMenu paramJMenu, Container paramContainer) {
/* 393 */     return (isFirstTopLevelMenu(paramJMenu, paramContainer) && isLastTopLevelMenu(paramJMenu, paramContainer));
/*     */   }
/*     */   
/*     */   protected boolean isFirstTopLevelMenu(JMenu paramJMenu, Container paramContainer) {
/* 398 */     JMenu jMenu = null;
/*     */     byte b;
/*     */     int i;
/*     */     Component[] arrayOfComponent;
/* 399 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 399 */       Component component = arrayOfComponent[b];
/* 401 */       if (jMenu == null && component == paramJMenu)
/* 402 */         return true; 
/* 403 */       if (jMenu != null)
/* 404 */         return false; 
/* 405 */       if (component instanceof JMenu)
/* 406 */         jMenu = (JMenu)component; 
/*     */       b++;
/*     */     } 
/* 408 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isLastTopLevelMenu(JMenu paramJMenu, Container paramContainer) {
/* 413 */     JMenu jMenu = null;
/*     */     byte b;
/*     */     int i;
/*     */     Component[] arrayOfComponent;
/* 414 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 414 */       Component component = arrayOfComponent[b];
/* 416 */       if (component instanceof JMenu)
/* 417 */         jMenu = (JMenu)component; 
/*     */       b++;
/*     */     } 
/* 419 */     return (jMenu == paramJMenu);
/*     */   }
/*     */   
/*     */   public void paintMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 427 */     JComponent jComponent = paramSynthContext.getComponent();
/* 428 */     String str = "Synthetica.menuItem";
/* 429 */     int i = paramSynthContext.getComponentState();
/* 430 */     boolean bool1 = ((i & 0x8) > 0) ? true : false;
/* 431 */     boolean bool2 = ((i & 0x2) > 0) ? true : false;
/* 433 */     if (bool1) {
/* 434 */       str = String.valueOf(str) + ".disabled";
/* 435 */     } else if (bool2) {
/* 436 */       str = String.valueOf(str) + ".hover";
/*     */     } 
/* 437 */     str = SyntheticaLookAndFeel.getString(str, jComponent);
/* 438 */     if (str != null) {
/* 440 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.menuItem.insets", jComponent);
/* 441 */       Insets insets2 = insets1;
/* 443 */       int j = 0;
/* 444 */       int k = 0;
/* 445 */       int m = 0;
/* 446 */       if (bool2) {
/* 448 */         j = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.hover.animation.cycles", jComponent, 1);
/* 449 */         k = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.hover.animation.delay", jComponent, 50);
/* 450 */         m = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.hover.animation.type", jComponent, 1);
/*     */       } else {
/* 454 */         j = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.animation.cycles", jComponent, 1);
/* 455 */         k = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.animation.delay", jComponent, 50);
/* 456 */         m = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.animation.type", jComponent, 2);
/*     */       } 
/* 458 */       ImagePainter imagePainter = new ImagePainter(jComponent, j, k, m, i, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 460 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintRadioButtonMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 468 */     paintMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintRadioButtonMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintCheckBoxMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 479 */     paintMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintCheckBoxMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintMenuBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 490 */     paintMenuBarBackground(paramSynthContext.getComponent(), new SyntheticaState(paramSynthContext.getComponentState()), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintMenuBarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 507 */     Container container = paramJComponent.getRootPane().getParent();
/* 508 */     boolean bool = true;
/* 509 */     if (container instanceof Window) {
/* 510 */       bool = ((Window)container).isActive();
/* 511 */     } else if (container instanceof JInternalFrame) {
/* 512 */       bool = ((JInternalFrame)container).isSelected();
/*     */     } 
/* 514 */     String str = "Synthetica.menuBar.background";
/* 515 */     if (bool) {
/* 516 */       str = String.valueOf(str) + ".active";
/*     */     } else {
/* 518 */       str = String.valueOf(str) + ".inactive";
/*     */     } 
/* 519 */     str = SyntheticaLookAndFeel.getString(str, paramJComponent);
/* 520 */     if (str != null) {
/* 522 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.menuBar.background.insets", paramJComponent);
/* 523 */       if (insets1 == null)
/* 524 */         insets1 = new Insets(0, 0, 0, 0); 
/* 525 */       Insets insets2 = insets1;
/* 526 */       Insets insets3 = insets2;
/* 527 */       boolean bool1 = false;
/* 528 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.menuBar.background.horizontalTiled", paramJComponent))
/* 529 */         bool1 = true; 
/* 530 */       boolean bool2 = false;
/* 531 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.menuBar.background.verticalTiled", paramJComponent))
/* 532 */         bool2 = true; 
/* 534 */       UIKey uIKey = new UIKey("menuBar.background", paramSyntheticaState);
/* 535 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, 1);
/* 536 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 50);
/* 537 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, bool ? 0 : 6);
/* 538 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, i, j, k, paramSyntheticaState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets2, insets3, bool1, bool2);
/* 539 */       imagePainter.draw();
/* 541 */       str = "Synthetica.menuBar.background.light";
/* 542 */       if (bool) {
/* 543 */         str = String.valueOf(str) + ".active";
/*     */       } else {
/* 545 */         str = String.valueOf(str) + ".inactive";
/*     */       } 
/* 546 */       str = SyntheticaLookAndFeel.getString(str, paramJComponent);
/* 547 */       if (str != null) {
/* 549 */         imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets2, insets3, 0, bool2);
/* 550 */         imagePainter.draw();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\MenuPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */