/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class ToolBarHandlePainter extends SyntheticaComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.ToolBarHandlePainter";
/*    */   
/*    */   public static ToolBarHandlePainter getInstance() {
/* 49 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static ToolBarHandlePainter getInstance(SynthContext paramSynthContext) {
/* 58 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ToolBarHandlePainter.class, "Synthetica.ToolBarHandlePainter"));
/* 59 */     if (syntheticaComponentPainter == null)
/* 60 */       syntheticaComponentPainter = getInstance(paramSynthContext, ToolBarHandlePainter.class, "Synthetica.ToolBarHandlePainter"); 
/* 61 */     return (ToolBarHandlePainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintHandle(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 78 */     UIKey uIKey = null;
/* 79 */     if (paramInt1 == 0) {
/* 80 */       uIKey = new UIKey("toolBar.handle.image.y", paramSyntheticaState);
/*    */     } else {
/* 82 */       uIKey = new UIKey("toolBar.handle.image.x", paramSyntheticaState);
/*    */     } 
/* 84 */     Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "insets", true, 2);
/* 85 */     Insets insets2 = insets1;
/* 87 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.handle.image.x.tiled", paramJComponent) ? true : false;
/* 88 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.handle.image.y.tiled", paramJComponent) ? true : false;
/* 89 */     String str = SyntheticaLookAndFeel.getString(uIKey.get(), paramJComponent);
/* 90 */     if (str != null) {
/* 92 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5, str, insets1, insets2, bool1, bool2);
/* 93 */       imagePainter.draw();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ToolBarHandlePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */