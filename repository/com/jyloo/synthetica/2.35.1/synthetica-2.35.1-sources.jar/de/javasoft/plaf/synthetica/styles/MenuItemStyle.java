/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicHTML;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ public class MenuItemStyle extends StyleWrapper {
/*  40 */   private static MenuItemStyle instance = new MenuItemStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  49 */     paramJComponent.setOpaque(false);
/*  51 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  53 */       instance.setStyle(paramSynthStyle);
/*  54 */       return instance;
/*     */     } 
/*  56 */     MenuItemStyle menuItemStyle = new MenuItemStyle();
/*  57 */     menuItemStyle.setStyle(paramSynthStyle);
/*  58 */     return menuItemStyle;
/*     */   }
/*     */   
/*     */   public Font getFont(SynthContext paramSynthContext) {
/*  64 */     menuItemHtmlColorCorrection(paramSynthContext);
/*  65 */     return this.synthStyle.getFont(paramSynthContext);
/*     */   }
/*     */   
/*     */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/*  71 */     JMenuItem jMenuItem = (JMenuItem)paramSynthContext.getComponent();
/*  72 */     if (paramColorType.equals(ColorType.TEXT_FOREGROUND)) {
/*  74 */       Color color = jMenuItem.getForeground();
/*  75 */       if (!(color instanceof javax.swing.plaf.UIResource))
/*  76 */         return color; 
/*     */     } 
/*  78 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*     */   }
/*     */   
/*     */   public Icon getIcon(SynthContext paramSynthContext, Object paramObject) {
/*  84 */     JMenuItem jMenuItem = (JMenuItem)paramSynthContext.getComponent();
/*  86 */     if ((jMenuItem instanceof javax.swing.JRadioButtonMenuItem || jMenuItem instanceof javax.swing.JCheckBoxMenuItem) && 
/*  87 */       jMenuItem.isSelected() && !jMenuItem.isEnabled()) {
/*  89 */       SynthContext synthContext = new SynthContext(jMenuItem, paramSynthContext.getRegion(), paramSynthContext.getStyle(), 520);
/*  90 */       return this.synthStyle.getIcon(synthContext, paramObject);
/*     */     } 
/*  93 */     return this.synthStyle.getIcon(paramSynthContext, paramObject);
/*     */   }
/*     */   
/*     */   public String getString(SynthContext paramSynthContext, Object paramObject, String paramString) {
/*  99 */     if ("MenuItem.acceleratorDelimiter".equals(paramObject)) {
/* 102 */       String str = UIManager.getString("MenuItem.acceleratorDelimiter");
/* 103 */       if (str != null)
/* 104 */         return str; 
/*     */     } 
/* 106 */     return super.getString(paramSynthContext, paramObject, paramString);
/*     */   }
/*     */   
/*     */   static void menuItemHtmlColorCorrection(SynthContext paramSynthContext) {
/* 114 */     JMenuItem jMenuItem = (JMenuItem)paramSynthContext.getComponent();
/* 115 */     String str1 = jMenuItem.getText();
/* 116 */     if (str1 == null || jMenuItem.getClientProperty("html") == null)
/*     */       return; 
/* 118 */     SynthStyle synthStyle = paramSynthContext.getStyle();
/* 119 */     int i = paramSynthContext.getComponentState();
/* 120 */     boolean bool1 = (jMenuItem instanceof javax.swing.JMenu) ? (((i & 0x200) > 0) ? true : false) : (((i & 0x2) > 0) ? true : false);
/* 121 */     boolean bool2 = ((i & 0x8) > 0) ? true : false;
/* 124 */     boolean bool3 = ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.MOUSE_OVER", jMenuItem, Boolean.FALSE)).booleanValue();
/* 125 */     boolean bool4 = ((i & 0x200) > 0) ? true : false;
/* 127 */     if (bool1 || bool2) {
/* 129 */       int j = str1.toLowerCase().indexOf("<html>");
/* 132 */       if (jMenuItem instanceof javax.swing.JMenu && paramSynthContext.getRegion() != Region.MENU)
/* 133 */         synthStyle = SynthLookAndFeel.getStyle(jMenuItem, Region.MENU); 
/* 134 */       String str3 = Integer.toHexString(synthStyle.getColor(paramSynthContext, ColorType.TEXT_FOREGROUND).getRGB());
/* 135 */       String str4 = "color=#" + str3.substring(2);
/* 136 */       String str5 = str1.substring(j, j + 6);
/* 137 */       str1 = str1.replaceFirst(str5, "<html><font " + str4 + ">");
/*     */     } 
/* 141 */     if (jMenuItem.getParent() != null && !jMenuItem.getParent().isVisible()) {
/* 143 */       jMenuItem.putClientProperty("Synthetica.oldText", "");
/* 144 */       if (jMenuItem instanceof javax.swing.JMenu)
/* 145 */         jMenuItem.putClientProperty("Synthetica.oldHover", Boolean.FALSE); 
/*     */     } 
/* 148 */     String str2 = (String)jMenuItem.getClientProperty("Synthetica.oldText");
/* 149 */     jMenuItem.putClientProperty("Synthetica.oldText", str1);
/* 150 */     boolean bool5 = false;
/* 151 */     if (jMenuItem instanceof javax.swing.JMenu) {
/* 153 */       bool5 = ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.oldHover", jMenuItem, Boolean.FALSE)).booleanValue();
/* 154 */       jMenuItem.putClientProperty("Synthetica.oldHover", Boolean.valueOf(bool3));
/*     */     } 
/* 157 */     View view = (View)jMenuItem.getClientProperty("html");
/* 158 */     if ((!str1.equals(str2) && view != jMenuItem.getClientProperty("Synthetica.oldView")) || (
/* 159 */       jMenuItem instanceof javax.swing.JMenu && bool4 && !bool3 && bool5 != bool3)) {
/* 162 */       jMenuItem.putClientProperty("Synthetica.oldView", view);
/* 163 */       updateHTMLRenderer(jMenuItem);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void updateHTMLRenderer(JMenuItem paramJMenuItem) {
/* 169 */     BasicHTML.updateRenderer(paramJMenuItem, (String)paramJMenuItem.getClientProperty("Synthetica.oldText"));
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\MenuItemStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */