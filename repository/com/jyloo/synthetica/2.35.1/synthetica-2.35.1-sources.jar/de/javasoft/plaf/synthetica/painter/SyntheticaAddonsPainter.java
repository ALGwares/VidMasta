/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class SyntheticaAddonsPainter extends SyntheticaComponentPainter {
/*    */   public static final String DOCKING_PAINTER = "Synthetica.DockingPainter";
/*    */   
/*    */   public static final String FLEXDOCK_PAINTER = "Synthetica.FlexdockPainter";
/*    */   
/*    */   public static final String HYPERLINK_PAINTER = "Synthetica.HyperlinkPainter";
/*    */   
/*    */   public static final String MONTH_VIEW_PAINTER = "Synthetica.MonthViewPainter";
/*    */   
/*    */   public static final String MULTI_LEVEL_BAR_PAINTER = "Synthetica.MultiLevelBarPainter";
/*    */   
/*    */   public static final String STATUS_BAR_PAINTER = "Synthetica.StatusBarPainter";
/*    */   
/*    */   public static final String SYSTEM_MONITOR_PAINTER = "Synthetica.SystemMonitorPainter";
/*    */   
/*    */   public static final String TASK_PANE_PAINTER = "Synthetica.TaskPanePainter";
/*    */   
/*    */   public static final String TITLED_PANEL_PAINTER = "Synthetica.TitledPanelPainter";
/*    */   
/*    */   public static SyntheticaAddonsPainter getInstance(String paramString) {
/* 40 */     return (SyntheticaAddonsPainter)getInstance(null, null, paramString);
/*    */   }
/*    */   
/*    */   public void paintDockingTitleBarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintDockingContentPaneBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintDockingDockbarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*    */   
/*    */   public void paintDockingSlidePanelBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*    */   
/*    */   public void paintDockingDockbarLabelBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*    */   
/*    */   public void paintFlexdockTitleBarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintHyperlinkFocus(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintMonthViewMonthBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintMultiLevelBar(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintStatusBarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintSystemMonitorBorder(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintSystemMonitorBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintSystemMonitorForeground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintSystemMonitorSpotlight(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTaskPaneContainerBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTaskPaneTitleBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, boolean paramBoolean1, boolean paramBoolean2, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTaskPaneExpandedControl(JComponent paramJComponent, SyntheticaState paramSyntheticaState, boolean paramBoolean1, boolean paramBoolean2, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTaskPaneFocus(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTitledPanelBorder(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTitledPanelBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTitledPanelTitleBorder(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintTitledPanelTitleBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaAddonsPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */