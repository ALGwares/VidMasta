/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Window;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolTip;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class ToolTipPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ToolTipPainter";
/*     */   
/*  39 */   private static WeakHashMap<JToolTip, Object> opaqued = new WeakHashMap<JToolTip, Object>();
/*     */   
/*     */   public static ToolTipPainter getInstance() {
/*  53 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ToolTipPainter getInstance(SynthContext paramSynthContext) {
/*  62 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ToolTipPainter.class, "Synthetica.ToolTipPainter"));
/*  63 */     if (syntheticaComponentPainter == null)
/*  64 */       syntheticaComponentPainter = getInstance(paramSynthContext, ToolTipPainter.class, "Synthetica.ToolTipPainter"); 
/*  65 */     return (ToolTipPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintToolTipBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintToolTipBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  77 */     prepareBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*  79 */     JToolTip jToolTip = (JToolTip)paramSynthContext.getComponent();
/*  80 */     int i = paramSynthContext.getComponentState();
/*  82 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.toolTip.background.insets", jToolTip);
/*  83 */     Insets insets2 = insets1;
/*  85 */     String str = SyntheticaLookAndFeel.getString("Synthetica.toolTip.background", jToolTip);
/*  86 */     int j = SyntheticaLookAndFeel.getInt("Synthetica.toolTip.animation.cycles", jToolTip, 1);
/*  87 */     int k = SyntheticaLookAndFeel.getInt("Synthetica.toolTip.animation.delay", jToolTip, 50);
/*  88 */     int m = SyntheticaLookAndFeel.getInt("Synthetica.toolTip.animation.type", jToolTip, 4);
/*  89 */     ImagePainter imagePainter = new ImagePainter(jToolTip, j, k, m, i, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/*  90 */     imagePainter.draw();
/*     */   }
/*     */   
/*     */   protected void prepareBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  96 */     JToolTip jToolTip = (JToolTip)paramSynthContext.getComponent();
/*  97 */     JComponent jComponent = (JComponent)jToolTip.getParent();
/*  98 */     if (jComponent == null)
/*     */       return; 
/* 103 */     Window window = SwingUtilities.getWindowAncestor(jToolTip);
/* 104 */     if (!JAVA7U8_OR_ABOVE && OS.getCurrentOS() == OS.Mac && window.getClass().getName().contains("$HeavyWeightWindow"))
/* 105 */       paramGraphics.clearRect(paramInt1, paramInt2, paramInt3, paramInt4); 
/* 108 */     if (JAVA5 && !opaqued.containsKey(jToolTip)) {
/* 110 */       opaqued.put(jToolTip, null);
/* 111 */       jToolTip.setOpaque(false);
/* 112 */       jComponent.setOpaque(false);
/* 113 */       jComponent.repaint();
/*     */     } 
/* 116 */     BufferedImage bufferedImage = (BufferedImage)jComponent.getClientProperty("POPUP_BACKGROUND");
/* 117 */     if (bufferedImage != null)
/* 118 */       paramGraphics.drawImage(bufferedImage, paramInt1, paramInt2, null); 
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 125 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ToolTipPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */