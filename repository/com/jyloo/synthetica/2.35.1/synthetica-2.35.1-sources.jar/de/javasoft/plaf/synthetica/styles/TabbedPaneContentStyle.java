/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JTabbedPane;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class TabbedPaneContentStyle extends StyleWrapper {
/* 30 */   private static TabbedPaneContentStyle instance = new TabbedPaneContentStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 38 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 40 */       instance.setStyle(paramSynthStyle);
/* 41 */       return instance;
/*    */     } 
/* 43 */     TabbedPaneContentStyle tabbedPaneContentStyle = new TabbedPaneContentStyle();
/* 44 */     tabbedPaneContentStyle.setStyle(paramSynthStyle);
/* 45 */     return tabbedPaneContentStyle;
/*    */   }
/*    */   
/*    */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/* 51 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/* 52 */     int i = jTabbedPane.getTabPlacement();
/* 53 */     Insets insets = super.getInsets(paramSynthContext, paramInsets);
/* 54 */     if (i == 2)
/* 55 */       return SyntheticaLookAndFeel.getInsets("Synthetica.tabbedPane.insets.left", jTabbedPane, insets); 
/* 56 */     if (i == 4)
/* 57 */       return SyntheticaLookAndFeel.getInsets("Synthetica.tabbedPane.insets.right", jTabbedPane, insets); 
/* 58 */     if (i == 3)
/* 59 */       return SyntheticaLookAndFeel.getInsets("Synthetica.tabbedPane.insets.bottom", jTabbedPane, insets); 
/* 60 */     return insets;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\TabbedPaneContentStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */