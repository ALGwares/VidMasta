/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class SpinnerPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.SpinnerPainter";
/*     */   
/*     */   public static SpinnerPainter getInstance() {
/*  61 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static SpinnerPainter getInstance(SynthContext paramSynthContext) {
/*  70 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, SpinnerPainter.class, "Synthetica.SpinnerPainter"));
/*  71 */     if (syntheticaComponentPainter == null)
/*  72 */       syntheticaComponentPainter = getInstance(paramSynthContext, SpinnerPainter.class, "Synthetica.SpinnerPainter"); 
/*  73 */     return (SpinnerPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintSpinnerBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  82 */     JSpinner jSpinner = (JSpinner)paramSynthContext.getComponent();
/*  83 */     if (hasFocus(jSpinner))
/*  84 */       FocusPainter.paintFocus("focus.spinner", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   public void paintSpinnerBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  92 */     JSpinner jSpinner = (JSpinner)paramSynthContext.getComponent();
/*  93 */     jSpinner.putClientProperty("Synthetica.flipHorizontal", Boolean.valueOf(!jSpinner.getComponentOrientation().isLeftToRight()));
/*  95 */     Color color = jSpinner.getBackground();
/*  96 */     boolean bool1 = (color != null && !(color instanceof javax.swing.plaf.ColorUIResource)) ? false : true;
/*  97 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.noBorderIfColored", jSpinner);
/*  98 */     boolean bool3 = SyntheticaLookAndFeel.isOpaque(jSpinner);
/* 100 */     if (!bool3)
/*     */       return; 
/* 102 */     if (bool1)
/* 103 */       color = paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND); 
/* 105 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, 0, true);
/* 106 */     UIKey uIKey = new UIKey("spinner", syntheticaPainterState);
/* 107 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get(uIKey.get("fillBackground"), jSpinner);
/* 108 */     Border border1 = jSpinner.getBorder();
/* 109 */     Border border2 = SyntheticaLookAndFeel.findDefaultBorder(border1);
/* 110 */     boolean bool4 = (border1 instanceof CompoundBorder && ((CompoundBorder)border1).getInsideBorder() == border2) ? true : false;
/* 112 */     if (bool4) {
/* 114 */       Insets insets3 = border1.getBorderInsets(jSpinner);
/* 115 */       Insets insets4 = border2.getBorderInsets(jSpinner);
/* 116 */       paramInt1 += insets3.left - insets4.left;
/* 117 */       paramInt2 += insets3.top - insets4.top;
/* 118 */       paramInt3 -= insets3.left - insets4.left + insets3.right - insets4.right;
/* 119 */       paramInt4 -= insets3.top - insets4.top + insets3.bottom - insets4.bottom;
/*     */     } 
/* 122 */     if (bool == null || bool.booleanValue())
/* 123 */       fillBackground(jSpinner, border1, border2, paramGraphics, color, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 125 */     if (!bool1 && bool2)
/*     */       return; 
/* 129 */     SyntheticaState syntheticaState = new SyntheticaState(syntheticaPainterState.getState());
/* 130 */     syntheticaState.resetState(SyntheticaState.State.HOVER);
/* 131 */     syntheticaState.resetState(SyntheticaState.State.PRESSED);
/* 133 */     uIKey = new UIKey("spinner.border", syntheticaState);
/* 136 */     String str1 = uIKey.get();
/* 137 */     boolean bool5 = (SyntheticaLookAndFeel.get(str1, jSpinner) != null) ? true : false;
/* 138 */     if (str1.equals("Synthetica.spinner.border.disabled") && !bool5)
/* 140 */       uIKey = new UIKey("textField.border", syntheticaState); 
/* 143 */     String str2 = (String)uIKey.findProperty(paramSynthContext, null, true, 1);
/* 145 */     if (hasFocus(jSpinner) && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused", jSpinner) != null)
/* 146 */       str2 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused", jSpinner); 
/* 147 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.spinner.border.insets", jSpinner);
/* 148 */     Insets insets2 = (SyntheticaLookAndFeel.get("Synthetica.spinner.border.dInsets", jSpinner) == null) ? insets1 : SyntheticaLookAndFeel.getInsets("Synthetica.spinner.border.dInsets", jSpinner);
/* 150 */     if (border2 == null) {
/* 152 */       Insets insets = jSpinner.getInsets();
/* 153 */       paramInt1 += insets.left;
/* 154 */       paramInt2 += insets.top;
/* 155 */       paramInt3 += -insets.left - insets.right;
/* 156 */       paramInt4 += -insets.top - insets.bottom;
/* 157 */       insets2 = new Insets(0, 0, 0, 0);
/*     */     } 
/* 160 */     ImagePainter imagePainter = new ImagePainter(jSpinner, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, 0, 0);
/* 161 */     if (!bool1) {
/* 162 */       imagePainter.drawBorder();
/* 163 */     } else if (border2 == null) {
/* 164 */       imagePainter.drawCenter();
/*     */     } else {
/* 166 */       imagePainter.draw();
/*     */     } 
/* 168 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.hoverAndPressed.enabled", jSpinner))
/* 169 */       paintHoverPressed(jSpinner, syntheticaPainterState, border1, border2, bool4, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, insets1, insets2); 
/*     */   }
/*     */   
/*     */   private void paintHoverPressed(JSpinner paramJSpinner, SyntheticaPainterState paramSyntheticaPainterState, Border paramBorder1, Border paramBorder2, boolean paramBoolean, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Insets paramInsets1, Insets paramInsets2) {
/* 176 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.stateChange4ButtonOnly", paramJSpinner)) {
/* 178 */       boolean bool = paramJSpinner.getComponentOrientation().isLeftToRight();
/* 179 */       if (paramInsets1.equals(paramInsets2))
/* 180 */         paramInsets2 = new Insets(paramInsets1.top, 0, paramInsets1.bottom, paramInsets1.right); 
/* 181 */       int m = SyntheticaLookAndFeel.findComponent("Spinner.nextButton", paramJSpinner).getWidth();
/* 182 */       Insets insets = paramBoolean ? paramBorder2.getBorderInsets(paramJSpinner) : paramJSpinner.getInsets();
/* 183 */       int n = SyntheticaLookAndFeel.getInt("Synthetica.spinner.buttons.relativeX", paramJSpinner, 0);
/* 184 */       if (paramBorder2 != null) {
/* 186 */         paramInt1 += bool ? (paramInt3 - insets.right - m + n) : 0;
/* 187 */         paramInt3 = m + (bool ? insets.right : insets.left) - n;
/*     */       } else {
/* 191 */         paramInt1 += bool ? (paramInt3 - m + n) : 0;
/* 192 */         paramInt3 = m - n;
/*     */       } 
/*     */     } 
/* 196 */     String str1 = "spinner.border";
/* 197 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.stateChange4SingleButton", paramJSpinner)) {
/* 199 */       JButton jButton = (JButton)SyntheticaLookAndFeel.findComponent("Spinner.nextButton", paramJSpinner);
/* 200 */       if (jButton.getModel().isPressed() || jButton.getModel().isRollover()) {
/* 202 */         str1 = String.valueOf(str1) + ".nextButton";
/* 203 */         if (jButton.getModel().isPressed())
/* 204 */           paramSyntheticaPainterState.setState(SyntheticaState.State.PRESSED); 
/*     */       } 
/* 207 */       jButton = (JButton)SyntheticaLookAndFeel.findComponent("Spinner.previousButton", paramJSpinner);
/* 208 */       if (jButton.getModel().isPressed() || jButton.getModel().isRollover()) {
/* 210 */         str1 = String.valueOf(str1) + ".previousButton";
/* 211 */         if (jButton.getModel().isPressed())
/* 212 */           paramSyntheticaPainterState.setState(SyntheticaState.State.PRESSED); 
/*     */       } 
/*     */     } 
/* 216 */     UIKey uIKey1 = new UIKey(str1, paramSyntheticaPainterState);
/* 218 */     String str2 = (String)UIKey.findProperty(paramJSpinner, uIKey1.get(), (String)null, true, 1);
/* 219 */     UIKey uIKey2 = new UIKey("spinner", paramSyntheticaPainterState);
/* 220 */     int i = SyntheticaLookAndFeel.getInt(uIKey2.get("animation.cycles"), paramJSpinner, 1);
/* 221 */     int j = SyntheticaLookAndFeel.getInt(uIKey2.get("animation.delay"), paramJSpinner, 50);
/* 222 */     int k = SyntheticaLookAndFeel.getInt(uIKey2.get("animation.type"), paramJSpinner, 2);
/* 223 */     if (paramSyntheticaPainterState.isSet(SyntheticaState.State.HOVER) || paramSyntheticaPainterState.isSet(SyntheticaState.State.PRESSED))
/* 224 */       k = SyntheticaLookAndFeel.getInt(uIKey2.get("animation.type"), paramJSpinner, 1); 
/* 225 */     ImagePainter imagePainter = new ImagePainter(paramJSpinner, i, j, k, paramSyntheticaPainterState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, paramInsets1, paramInsets2, 0, 0);
/* 226 */     if (paramBorder2 == null) {
/* 227 */       imagePainter.drawCenter();
/*     */     } else {
/* 229 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean hasFocus(JComponent paramJComponent) {
/* 234 */     if (paramJComponent.isEnabled() && paramJComponent.isFocusable()) {
/* 236 */       Component component = SyntheticaLookAndFeel.findComponent("Spinner.formattedTextField", paramJComponent);
/* 237 */       if (paramJComponent.hasFocus() || (component != null && component.hasFocus()))
/* 238 */         return true; 
/*     */     } 
/* 240 */     return false;
/*     */   }
/*     */   
/*     */   private void fillBackground(JSpinner paramJSpinner, Border paramBorder1, Border paramBorder2, Graphics paramGraphics, Color paramColor, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 245 */     Color color = paramGraphics.getColor();
/* 246 */     paramGraphics.setColor(paramColor);
/* 247 */     Insets insets = paramJSpinner.getInsets();
/* 249 */     if (paramBorder1 == null || insets.equals(new Insets(0, 0, 0, 0))) {
/* 250 */       paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 251 */     } else if (paramBorder2 == null) {
/* 252 */       paramGraphics.fillRect(paramInt1 + insets.left, paramInt2 + insets.top, paramInt3 - insets.left - insets.right, paramInt4 - insets.top - insets.bottom);
/*     */     } else {
/* 255 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.spinner.border.fillInsets", paramJSpinner, false);
/* 256 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.spinner.border.arcWidth", paramJSpinner, 8);
/* 257 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.spinner.border.arcHeight", paramJSpinner, 8);
/* 258 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 259 */       RenderingHints renderingHints = graphics2D.getRenderingHints();
/* 260 */       graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 261 */       graphics2D.fillRoundRect(paramInt1 + insets1.left, paramInt2 + insets1.top, paramInt3 - insets1.left - insets1.right, paramInt4 - insets1.top - insets1.bottom, i, j);
/* 262 */       graphics2D.setRenderingHints(renderingHints);
/*     */     } 
/* 265 */     paramGraphics.setColor(color);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 271 */     JComponent jComponent = paramSynthContext.getComponent();
/* 272 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 273 */     i = i * 31 + (hasFocus(jComponent) ? 0 : 1);
/* 274 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SpinnerPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */