/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.MenuPainter;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.basic.BasicMenuItemUI;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthConstants;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ public class SyntheticaMenuItemUI extends BasicMenuItemUI implements PropertyChangeListener, SynthConstants {
/*  76 */   private static boolean paintDebugRects = UIManager.getBoolean("Synthetica.menuItem.paintDebugRectangles");
/*     */   
/*  77 */   private static WeakHashMap<JPopupMenu, MaxWidth> maxWidths = new WeakHashMap<JPopupMenu, MaxWidth>();
/*     */   
/*     */   private String acceleratorDelimiter;
/*     */   
/*  81 */   private static Rectangle iconRect = new Rectangle();
/*     */   
/*  82 */   private static Rectangle textRect = new Rectangle();
/*     */   
/*  83 */   private static Rectangle acceleratorRect = new Rectangle();
/*     */   
/*  84 */   private static Rectangle checkIconRect = new Rectangle();
/*     */   
/*  85 */   private static Rectangle arrowIconRect = new Rectangle();
/*     */   
/*  86 */   private static Rectangle viewRect = new Rectangle(32767, 32767);
/*     */   
/*  87 */   private static Rectangle r = new Rectangle();
/*     */   
/*     */   public static ComponentUI createUI(JComponent paramJComponent) {
/*  91 */     return new SyntheticaMenuItemUI();
/*     */   }
/*     */   
/*     */   protected void installDefaults() {
/*  97 */     updateStyle(this.menuItem);
/*     */   }
/*     */   
/*     */   protected void installListeners() {
/* 103 */     super.installListeners();
/* 104 */     this.menuItem.addPropertyChangeListener(this);
/*     */   }
/*     */   
/*     */   private void updateStyle(JMenuItem paramJMenuItem) {
/* 109 */     String str = getPropertyPrefix();
/* 110 */     SynthContext synthContext = getContext(paramJMenuItem, 1);
/* 111 */     SynthStyle synthStyle = getStyle(paramJMenuItem);
/* 113 */     synthStyle.installDefaults(synthContext);
/* 115 */     Object object = synthStyle.get(synthContext, "MenuItem.textIconGap");
/* 116 */     if (object != null)
/* 117 */       LookAndFeel.installProperty(paramJMenuItem, "iconTextGap", object); 
/* 118 */     this.defaultTextIconGap = paramJMenuItem.getIconTextGap();
/* 120 */     if (this.menuItem.getMargin() == null || this.menuItem.getMargin() instanceof javax.swing.plaf.UIResource) {
/* 122 */       Insets insets = (Insets)synthStyle.get(synthContext, String.valueOf(str) + ".margin");
/* 123 */       if (insets == null)
/* 124 */         insets = new InsetsUIResource(0, 0, 0, 0); 
/* 125 */       this.menuItem.setMargin(insets);
/*     */     } 
/* 128 */     this.acceleratorDelimiter = synthStyle.getString(synthContext, String.valueOf(str) + ".acceleratorDelimiter", getAcceleratorDelimiter());
/* 129 */     this.arrowIcon = synthStyle.getIcon(synthContext, String.valueOf(str) + ".arrowIcon");
/* 130 */     this.arrowIcon = SyntheticaLookAndFeel.<Icon>getClientProperty("Synthetica.menuItem.arrowIcon", this.menuItem, this.arrowIcon);
/* 131 */     this.checkIcon = synthStyle.getIcon(synthContext, String.valueOf(str) + ".checkIcon");
/*     */   }
/*     */   
/*     */   protected void uninstallDefaults() {
/* 137 */     super.uninstallDefaults();
/*     */   }
/*     */   
/*     */   protected void uninstallListeners() {
/* 143 */     super.uninstallListeners();
/* 144 */     this.menuItem.removePropertyChangeListener(this);
/*     */   }
/*     */   
/*     */   protected Dimension getPreferredMenuItemSize(JComponent paramJComponent, Icon paramIcon1, Icon paramIcon2, int paramInt) {
/* 150 */     SynthContext synthContext1 = getMenuItemContext(paramJComponent);
/* 151 */     SynthContext synthContext2 = getContext(paramJComponent, Region.MENU_ITEM_ACCELERATOR);
/* 152 */     return getPreferredMenuItemSize(synthContext1, synthContext2, false, paramJComponent, paramIcon1, paramIcon2, paramInt, this.acceleratorDelimiter);
/*     */   }
/*     */   
/*     */   static Dimension getPreferredMenuItemSize(SynthContext paramSynthContext1, SynthContext paramSynthContext2, boolean paramBoolean, JComponent paramJComponent, Icon paramIcon1, Icon paramIcon2, int paramInt, String paramString) {
/* 158 */     JMenuItem jMenuItem = (JMenuItem)paramJComponent;
/* 159 */     Icon icon = jMenuItem.getIcon();
/* 160 */     String str1 = jMenuItem.getText();
/* 161 */     KeyStroke keyStroke = jMenuItem.getAccelerator();
/* 162 */     String str2 = "";
/* 164 */     JPopupMenu jPopupMenu = findPopup(jMenuItem);
/* 165 */     int i = paramSynthContext1.getStyle().getInt(paramSynthContext1, "MenuItem.textIconGap", paramInt);
/* 166 */     int j = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.textIconGap", jPopupMenu, i);
/* 167 */     int k = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.acceleratorGap", jPopupMenu, i * 4);
/* 168 */     int m = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparatorGap", jPopupMenu, 0);
/* 170 */     if (keyStroke != null) {
/* 172 */       int i1 = keyStroke.getModifiers();
/* 173 */       if (i1 > 0) {
/* 175 */         str2 = modifiersAsText(i1);
/* 176 */         str2 = String.valueOf(str2) + paramString;
/*     */       } 
/* 178 */       int i2 = keyStroke.getKeyCode();
/* 179 */       if (i2 != 0) {
/* 180 */         str2 = String.valueOf(str2) + KeyEvent.getKeyText(i2);
/*     */       } else {
/* 182 */         str2 = String.valueOf(str2) + keyStroke.getKeyChar();
/*     */       } 
/*     */     } 
/* 185 */     Font font = paramSynthContext1.getStyle().getFont(paramSynthContext1);
/* 186 */     FontMetrics fontMetrics1 = jMenuItem.getFontMetrics(font);
/* 187 */     FontMetrics fontMetrics2 = jMenuItem.getFontMetrics(paramSynthContext2.getStyle().getFont(paramSynthContext2));
/* 189 */     resetRects();
/* 191 */     layoutMenuItem(paramSynthContext1, fontMetrics1, paramSynthContext2, str1, fontMetrics2, str2, icon, paramIcon1, paramIcon2, jMenuItem.getVerticalAlignment(), jMenuItem.getHorizontalAlignment(), 
/* 192 */         jMenuItem.getVerticalTextPosition(), jMenuItem.getHorizontalTextPosition(), viewRect, iconRect, textRect, acceleratorRect, checkIconRect, arrowIconRect, 
/* 193 */         (str1 == null) ? 0 : paramInt, paramInt, paramBoolean);
/* 196 */     r.setBounds(textRect);
/* 197 */     r = SwingUtilities.computeUnion(paramBoolean ? iconRect.x : textRect.x, iconRect.y, paramBoolean ? iconRect.width : 0, iconRect.height, r);
/* 199 */     if (jPopupMenu != null) {
/* 201 */       MaxWidth maxWidth = maxWidths.get(jPopupMenu);
/* 202 */       if (maxWidth == null) {
/* 204 */         maxWidths.put(jPopupMenu, new MaxWidth(null));
/* 205 */         maxWidth = maxWidths.get(jPopupMenu);
/* 207 */       } else if (isHorizontalLayout(jPopupMenu)) {
/* 208 */         maxWidth.clear();
/*     */       } 
/* 210 */       maxWidth.maxTextWidth = Math.max(maxWidth.maxTextWidth, r.width);
/* 211 */       r.width = maxWidth.maxTextWidth;
/* 213 */       maxWidth.maxAcceleratorWidth = Math.max(maxWidth.maxAcceleratorWidth, acceleratorRect.width);
/* 214 */       r.width += maxWidth.maxAcceleratorWidth;
/* 215 */       if (maxWidth.maxAcceleratorWidth > 0)
/* 216 */         r.width += k; 
/* 218 */       r.width += maxWidth.maxIconWidth;
/* 219 */       if (maxWidth.maxIconWidth > 0)
/* 220 */         r.width += j; 
/* 222 */       if (!paramBoolean) {
/* 224 */         if (SyntheticaLookAndFeel.popupHasCheckRadioWithIcon(jPopupMenu)) {
/* 227 */           r.width += maxWidth.maxCheckIconWidth;
/* 228 */           if (maxWidth.maxCheckIconWidth > 0)
/* 229 */             r.width += i; 
/* 231 */         } else if (SyntheticaLookAndFeel.popupHasCheckRadio(jPopupMenu)) {
/* 234 */           r.width -= maxWidth.maxIconWidth;
/* 235 */           r.width += Math.max(maxWidth.maxIconWidth, maxWidth.maxCheckIconWidth);
/* 237 */           if (maxWidth.maxIconWidth > 0)
/* 238 */             r.width -= j; 
/* 239 */           r.width += i;
/*     */         } 
/* 243 */         if (maxWidth.maxAcceleratorWidth == 0) {
/* 245 */           r.width += maxWidth.maxArrowIconWidth;
/* 246 */           if (maxWidth.maxArrowIconWidth > 0)
/* 247 */             r.width += i; 
/*     */         } 
/*     */       } 
/* 252 */     } else if (!paramBoolean) {
/* 254 */       r.width += acceleratorRect.width;
/* 255 */       if (acceleratorRect.width > 0)
/* 256 */         r.width += k; 
/* 258 */       r.width += iconRect.width;
/* 259 */       if (iconRect.width > 0)
/* 260 */         r.width += j; 
/* 262 */       r.width += checkIconRect.width;
/* 263 */       if (checkIconRect.width > 0)
/* 264 */         r.width += i; 
/* 266 */       byte b = (paramIcon2 == null) ? 0 : SyntheticaLookAndFeel.getInt("Synthetica.menuItem.arrowIconGap", paramJComponent, i);
/* 267 */       r.width += arrowIconRect.width + b;
/*     */     } 
/* 270 */     r.width += paramBoolean ? i : (i * 2);
/* 271 */     if (!paramBoolean && jPopupMenu != null && (SyntheticaLookAndFeel.preservePopupIconSpace(jPopupMenu) || SyntheticaLookAndFeel.popupHasCheckRadio(jPopupMenu)))
/* 272 */       r.width += m; 
/* 274 */     Insets insets1 = paramSynthContext1.getStyle().getInsets(paramSynthContext1, null);
/* 275 */     Insets insets2 = jMenuItem.getMargin();
/* 276 */     if (insets2 != null)
/* 277 */       insets1 = new Insets(insets1.top + insets2.top, insets1.left + insets2.left, insets1.bottom + insets2.bottom, insets1.right + insets2.right); 
/* 278 */     r.width += (paramBoolean ? 0 : insets1.left) + insets1.right;
/* 280 */     r.width += (paramBoolean && icon != null) ? (insets1.left + j) : 0;
/* 281 */     r.height += insets1.top + insets1.bottom;
/* 284 */     int n = SyntheticaLookAndFeel.getInt("Menu.menuPopupOffsetX", null, 0);
/* 285 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.respectTopLevelMenuWidth", jPopupMenu, true);
/* 286 */     if (bool && jPopupMenu != null && SyntheticaLookAndFeel.isToplevelPopupMenu(jPopupMenu) && r.width + n < jPopupMenu.getInvoker().getWidth())
/* 287 */       r.width = jPopupMenu.getInvoker().getWidth() - n; 
/* 290 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.menuItem.justifySize", jPopupMenu, true)) {
/* 292 */       if (r.width % 2 == 0)
/* 293 */         r.width++; 
/* 294 */       if (r.height % 2 == 0)
/* 295 */         r.height++; 
/*     */     } 
/* 298 */     return r.getSize();
/*     */   }
/*     */   
/*     */   private static boolean isHorizontalLayout(JPopupMenu paramJPopupMenu) {
/* 303 */     if (JavaVersion.JAVA5 || !(paramJPopupMenu.getLayout() instanceof BoxLayout))
/* 304 */       return false; 
/* 306 */     int i = ((BoxLayout)paramJPopupMenu.getLayout()).getAxis();
/* 307 */     return !(i != 0 && i != 2);
/*     */   }
/*     */   
/*     */   private static String layoutMenuItem(SynthContext paramSynthContext1, FontMetrics paramFontMetrics1, SynthContext paramSynthContext2, String paramString1, FontMetrics paramFontMetrics2, String paramString2, Icon paramIcon1, Icon paramIcon2, Icon paramIcon3, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Rectangle paramRectangle1, Rectangle paramRectangle2, Rectangle paramRectangle3, Rectangle paramRectangle4, Rectangle paramRectangle5, Rectangle paramRectangle6, int paramInt5, int paramInt6, boolean paramBoolean) {
/* 320 */     JComponent jComponent = paramSynthContext1.getComponent();
/* 321 */     JPopupMenu jPopupMenu = findPopup(jComponent);
/* 322 */     boolean bool1 = jComponent.getComponentOrientation().isLeftToRight();
/* 323 */     int i = paramSynthContext1.getStyle().getInt(paramSynthContext1, "MenuItem.textIconGap", paramInt6);
/* 324 */     int j = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.textIconGap", jPopupMenu, i);
/* 325 */     int k = SyntheticaLookAndFeel.getInt("Synthetica.menuItem.acceleratorGap", jPopupMenu, i * 4);
/* 326 */     int m = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparatorGap", jPopupMenu, 0);
/* 327 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.centerText", jPopupMenu, false);
/* 328 */     boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.forceIconSpace", jPopupMenu, false);
/* 330 */     int n = (paramIcon1 == null) ? (bool3 ? SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.defaultIconWidth", jPopupMenu, 16) : 0) : paramIcon1.getIconWidth();
/* 331 */     int i1 = (paramIcon2 == null) ? 0 : paramIcon2.getIconWidth();
/* 332 */     int i2 = (paramIcon3 == null) ? 0 : paramIcon3.getIconWidth();
/* 333 */     if (jPopupMenu != null) {
/* 335 */       MaxWidth maxWidth = maxWidths.get(jPopupMenu);
/* 336 */       if (maxWidth == null) {
/* 338 */         maxWidths.put(jPopupMenu, new MaxWidth(null));
/* 339 */         maxWidth = maxWidths.get(jPopupMenu);
/*     */       } 
/* 341 */       maxWidth.maxIconWidth = Math.max(maxWidth.maxIconWidth, n);
/* 342 */       n = maxWidth.maxIconWidth;
/* 343 */       maxWidth.maxCheckIconWidth = Math.max(maxWidth.maxCheckIconWidth, i1);
/* 344 */       i1 = maxWidth.maxCheckIconWidth;
/* 345 */       maxWidth.maxArrowIconWidth = Math.max(maxWidth.maxArrowIconWidth, i2);
/* 346 */       i2 = maxWidth.maxArrowIconWidth;
/* 348 */       jPopupMenu.putClientProperty("Synthetica.menuItem.maxIconWidth", Integer.valueOf(n));
/*     */     } 
/* 351 */     boolean bool4 = (jPopupMenu == null) ? ((paramIcon1 != null) ? true : false) : SyntheticaLookAndFeel.preservePopupIconSpace(jPopupMenu);
/* 352 */     boolean bool5 = (jPopupMenu == null) ? ((paramIcon2 != null) ? true : false) : SyntheticaLookAndFeel.popupHasCheckRadio(jPopupMenu);
/* 353 */     boolean bool6 = (jPopupMenu == null) ? ((bool5 && bool4) ? true : false) : SyntheticaLookAndFeel.popupHasCheckRadioWithIcon(jPopupMenu);
/* 355 */     paramSynthContext1.getStyle().getGraphicsUtils(paramSynthContext1).layoutText(paramSynthContext1, paramFontMetrics1, paramString1, paramIcon1, paramInt2, paramInt1, paramInt4, paramInt3, paramRectangle1, paramRectangle2, paramRectangle3, j);
/* 358 */     if (!paramBoolean) {
/* 360 */       if (paramIcon2 != null) {
/* 362 */         paramRectangle5.width = SyntheticaIcon.getIconWidth(paramIcon2, paramSynthContext1);
/* 363 */         paramRectangle5.height = SyntheticaIcon.getIconHeight(paramIcon2, paramSynthContext1);
/*     */       } else {
/* 366 */         paramRectangle5.width = paramRectangle5.height = 0;
/*     */       } 
/* 368 */       if (paramIcon3 != null) {
/* 370 */         paramRectangle6.width = SyntheticaIcon.getIconWidth(paramIcon3, paramSynthContext1);
/* 371 */         paramRectangle6.height = SyntheticaIcon.getIconHeight(paramIcon3, paramSynthContext1);
/*     */       } else {
/* 374 */         paramRectangle6.width = paramRectangle6.height = 0;
/*     */       } 
/*     */     } 
/* 377 */     if (paramBoolean) {
/* 379 */       Insets insets = paramSynthContext1.getStyle().getInsets(paramSynthContext1, null);
/* 380 */       if (bool1) {
/* 381 */         paramRectangle3.x += i + insets.left;
/*     */       } else {
/* 383 */         paramRectangle3.x -= i + insets.left;
/*     */       } 
/* 386 */       if (paramRectangle2.width > 0)
/* 387 */         paramRectangle2.x += (insets.left + j) * (bool1 ? 1 : -1); 
/* 389 */     } else if (bool6) {
/* 391 */       if (bool1) {
/* 393 */         paramRectangle1.x += i;
/* 394 */         paramRectangle2.x = paramRectangle1.x + i + i1 + i;
/* 395 */         paramRectangle3.x = paramRectangle1.x + i + i1 + i + n + j + m;
/*     */       } else {
/* 399 */         paramRectangle5.x = paramRectangle1.x + paramRectangle1.width - i - i1;
/* 400 */         paramRectangle2.x = paramRectangle5.x - i - n;
/* 401 */         paramRectangle3.x = paramRectangle2.x - j - m - paramRectangle3.width;
/*     */       } 
/* 404 */     } else if (bool4 && bool5) {
/* 407 */       int i4 = Math.max(i1, n);
/* 408 */       if (bool1) {
/* 410 */         paramRectangle5.x = paramRectangle1.x + i + (i4 - paramRectangle5.width) / 2;
/* 411 */         paramRectangle2.x = paramRectangle1.x + i + (i4 - paramRectangle2.width) / 2;
/* 412 */         paramRectangle3.x = paramRectangle1.x + i + i4 + i + m;
/*     */       } else {
/* 416 */         paramRectangle5.x = paramRectangle1.x + paramRectangle1.width - i - i1 - (i4 - paramRectangle5.width) / 2;
/* 417 */         paramRectangle2.x = paramRectangle1.x + paramRectangle1.width - i - n - (i4 - paramRectangle2.width) / 2;
/* 418 */         paramRectangle3.x = paramRectangle1.x + paramRectangle1.width - i - i4 - i - m - paramRectangle3.width;
/*     */       } 
/* 421 */     } else if (bool4 && !bool5) {
/* 424 */       if (bool1) {
/* 426 */         paramRectangle1.x += i;
/* 427 */         paramRectangle3.x = paramRectangle1.x + i + n + j + ((jPopupMenu == null) ? 0 : m);
/*     */       } else {
/* 431 */         paramRectangle2.x = paramRectangle1.x + paramRectangle1.width - i - n;
/* 432 */         paramRectangle3.x = paramRectangle2.x - j - ((jPopupMenu == null) ? 0 : m) - paramRectangle3.width;
/*     */       } 
/* 435 */     } else if (!bool4 && bool5) {
/* 437 */       if (bool1) {
/* 439 */         paramRectangle1.x += i;
/* 440 */         paramRectangle3.x = paramRectangle1.x + i + i1 + i + m;
/*     */       } else {
/* 444 */         paramRectangle5.x = paramRectangle1.x + paramRectangle1.width - i - i1;
/* 445 */         paramRectangle3.x = paramRectangle5.x - i - m - paramRectangle3.width;
/*     */       } 
/* 450 */     } else if (bool1) {
/* 451 */       paramRectangle1.x += i;
/* 454 */     } else if (paramRectangle1.width < 32767) {
/* 456 */       paramRectangle3.x = paramRectangle1.x + paramRectangle1.width - paramRectangle3.width - i;
/* 457 */       paramRectangle2.x = 0;
/*     */     } 
/* 462 */     if (!paramBoolean)
/* 464 */       if (bool1) {
/* 465 */         paramRectangle6.x = paramRectangle1.x + paramRectangle1.width - i - paramRectangle6.width;
/*     */       } else {
/* 467 */         paramRectangle1.x += i;
/*     */       }  
/* 471 */     if (paramString2 == null || paramString2.equals("")) {
/* 473 */       paramRectangle4.width = paramRectangle4.height = 0;
/* 474 */       paramString2 = "";
/*     */     } else {
/* 478 */       SynthStyle synthStyle = paramSynthContext2.getStyle();
/* 479 */       paramRectangle4.width = synthStyle.getGraphicsUtils(paramSynthContext2).computeStringWidth(paramSynthContext2, paramFontMetrics2.getFont(), paramFontMetrics2, paramString2);
/* 480 */       paramRectangle4.height = paramFontMetrics2.getHeight();
/*     */     } 
/* 483 */     Rectangle rectangle = paramRectangle2.union(paramRectangle3);
/* 484 */     int i3 = (maxWidths.get(jPopupMenu) == null) ? paramRectangle4.width : ((MaxWidth)maxWidths.get(jPopupMenu)).maxAcceleratorWidth;
/* 486 */     if (bool1) {
/* 487 */       paramRectangle4.x = paramRectangle1.x + paramRectangle1.width - paramRectangle6.width - i - i3;
/*     */     } else {
/* 489 */       paramRectangle4.x = paramRectangle1.x + paramRectangle6.width + i + i3 - paramRectangle4.width;
/*     */     } 
/* 490 */     rectangle.y += rectangle.height / 2 - paramRectangle4.height / 2;
/* 492 */     if (!paramBoolean) {
/* 494 */       rectangle.y += rectangle.height / 2 - paramRectangle6.height / 2;
/* 495 */       rectangle.y += rectangle.height / 2 - paramRectangle5.height / 2;
/*     */     } 
/* 498 */     if (!paramBoolean && bool2) {
/* 500 */       int i4 = paramRectangle1.width - Math.max(i3, i2) - i * 2;
/* 502 */       if (bool6) {
/* 503 */         i4 -= n + i + i1 + j + m;
/* 504 */       } else if (bool4 && bool5) {
/* 505 */         i4 -= Math.max(n, i1) + i + m;
/* 506 */       } else if (bool4 && !bool5) {
/* 507 */         i4 -= n + j + m;
/* 508 */       } else if (!bool4 && bool5) {
/* 509 */         i4 -= i1 + i + m;
/*     */       } 
/* 511 */       if (i3 > 0) {
/* 512 */         i4 -= k;
/* 513 */       } else if (i2 > 0) {
/* 514 */         i4 -= i;
/*     */       } 
/* 516 */       paramRectangle3.x += bool1 ? ((i4 - paramRectangle3.width) / 2) : (-(i4 - paramRectangle3.width) / 2);
/*     */     } 
/* 519 */     return paramString1;
/*     */   }
/*     */   
/*     */   public void update(Graphics paramGraphics, JComponent paramJComponent) {
/* 525 */     SynthContext synthContext = getContext(paramJComponent);
/* 526 */     paintBackground(synthContext, paramGraphics, 0, 0, paramJComponent.getWidth(), paramJComponent.getHeight());
/* 527 */     paint(synthContext, paramGraphics);
/* 528 */     paintBorder(synthContext, paramGraphics, 0, 0, paramJComponent.getWidth(), paramJComponent.getHeight());
/*     */   }
/*     */   
/*     */   void paintBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 533 */     MenuPainter.getInstance(paramSynthContext).paintMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   void paintBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 538 */     MenuPainter.getInstance(paramSynthContext).paintMenuItemBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics, JComponent paramJComponent) {
/* 544 */     paint(getMenuItemContext(paramJComponent), paramGraphics);
/*     */   }
/*     */   
/*     */   private void paint(SynthContext paramSynthContext, Graphics paramGraphics) {
/* 549 */     JComponent jComponent = paramSynthContext.getComponent();
/* 550 */     SynthStyle synthStyle = getStyle(jComponent);
/* 551 */     SynthContext synthContext = getContext(this.menuItem, Region.MENU_ITEM_ACCELERATOR);
/* 552 */     String str = getPropertyPrefix();
/* 553 */     Icon icon = synthStyle.getIcon(paramSynthContext, String.valueOf(str) + ".arrowIcon");
/* 554 */     icon = SyntheticaLookAndFeel.<Icon>getClientProperty("Synthetica.menuItem.arrowIcon", jComponent, icon);
/* 555 */     if ((paramSynthContext.getComponentState() & 0x2) > 0)
/* 556 */       icon = SyntheticaLookAndFeel.<Icon>getClientProperty("Synthetica.menuItem.hover.arrowIcon", jComponent, icon); 
/* 557 */     paint(paramSynthContext, synthContext, paramGraphics, synthStyle.getIcon(paramSynthContext, String.valueOf(str) + ".checkIcon"), icon, false, this.acceleratorDelimiter, this.defaultTextIconGap);
/*     */   }
/*     */   
/*     */   static void paint(SynthContext paramSynthContext1, SynthContext paramSynthContext2, Graphics paramGraphics, Icon paramIcon1, Icon paramIcon2, boolean paramBoolean, String paramString, int paramInt) {
/* 562 */     JComponent jComponent = paramSynthContext1.getComponent();
/* 563 */     JMenuItem jMenuItem = (JMenuItem)jComponent;
/* 564 */     SynthStyle synthStyle = paramSynthContext1.getStyle();
/* 565 */     ButtonModel buttonModel = jMenuItem.getModel();
/* 566 */     Insets insets1 = synthStyle.getInsets(paramSynthContext1, null);
/* 567 */     Insets insets2 = jMenuItem.getMargin();
/* 568 */     if (insets2 != null)
/* 569 */       insets1 = new Insets(insets1.top + insets2.top, insets1.left + insets2.left, insets1.bottom + insets2.bottom, insets1.right + insets2.right); 
/* 570 */     boolean bool = jComponent.getComponentOrientation().isLeftToRight();
/* 572 */     resetRects();
/* 574 */     viewRect.setBounds(0, 0, jMenuItem.getWidth(), jMenuItem.getHeight());
/* 575 */     viewRect.y += insets1.top;
/* 576 */     viewRect.height += -insets1.bottom - insets1.top;
/* 577 */     if (!paramBoolean) {
/* 579 */       viewRect.x += bool ? insets1.left : insets1.right;
/* 580 */       viewRect.width += -insets1.right - insets1.left;
/*     */     } 
/* 583 */     Font font = synthStyle.getFont(paramSynthContext1);
/* 584 */     paramGraphics.setFont(font);
/* 585 */     FontMetrics fontMetrics1 = paramGraphics.getFontMetrics();
/* 586 */     FontMetrics fontMetrics2 = fontMetrics1;
/* 589 */     KeyStroke keyStroke = jMenuItem.getAccelerator();
/* 590 */     String str1 = "";
/* 591 */     if (keyStroke != null) {
/* 593 */       int i = keyStroke.getModifiers();
/* 594 */       if (i > 0) {
/* 596 */         str1 = modifiersAsText(i);
/* 597 */         str1 = String.valueOf(str1) + paramString;
/*     */       } 
/* 600 */       int j = keyStroke.getKeyCode();
/* 601 */       if (j != 0) {
/* 602 */         str1 = String.valueOf(str1) + KeyEvent.getKeyText(j);
/*     */       } else {
/* 604 */         str1 = String.valueOf(str1) + keyStroke.getKeyChar();
/*     */       } 
/*     */     } 
/* 607 */     String str2 = layoutMenuItem(paramSynthContext1, fontMetrics1, paramSynthContext2, jMenuItem.getText(), fontMetrics2, str1, jMenuItem.getIcon(), paramIcon1, paramIcon2, jMenuItem.getVerticalAlignment(), 
/* 608 */         jMenuItem.getHorizontalAlignment(), jMenuItem.getVerticalTextPosition(), jMenuItem.getHorizontalTextPosition(), viewRect, iconRect, textRect, acceleratorRect, checkIconRect, 
/* 609 */         arrowIconRect, (jMenuItem.getText() == null) ? 0 : paramInt, paramInt, paramBoolean);
/* 611 */     if (paramIcon1 != null && !paramBoolean)
/* 612 */       SyntheticaIcon.paintIcon(paramIcon1, paramSynthContext1, paramGraphics, checkIconRect.x, checkIconRect.y, checkIconRect.width, checkIconRect.height); 
/* 615 */     if (jComponent instanceof JMenu && paramSynthContext1.getRegion() != Region.MENU) {
/* 617 */       paramSynthContext1 = getContext(jComponent, Region.MENU);
/* 618 */       synthStyle = paramSynthContext1.getStyle();
/*     */     } 
/* 622 */     if (jMenuItem.getIcon() != null) {
/* 624 */       Icon icon = null;
/* 625 */       if (!buttonModel.isEnabled()) {
/* 626 */         icon = jMenuItem.getDisabledIcon();
/* 627 */       } else if (buttonModel.isPressed() && buttonModel.isArmed()) {
/* 628 */         icon = jMenuItem.getPressedIcon();
/* 629 */       } else if (buttonModel.isRollover() && buttonModel.isSelected()) {
/* 630 */         icon = jMenuItem.getRolloverSelectedIcon();
/* 631 */       } else if (buttonModel.isRollover()) {
/* 632 */         icon = jMenuItem.getRolloverIcon();
/* 633 */       } else if (buttonModel.isSelected()) {
/* 634 */         icon = jMenuItem.getSelectedIcon();
/*     */       } 
/* 637 */       if (icon == null)
/* 638 */         icon = jMenuItem.getIcon(); 
/* 640 */       if (icon != null)
/* 641 */         SyntheticaIcon.paintIcon(icon, paramSynthContext1, paramGraphics, iconRect.x, iconRect.y, iconRect.width, iconRect.height); 
/*     */     } 
/* 645 */     if (str2 != null) {
/* 647 */       View view = (View)jComponent.getClientProperty("html");
/* 648 */       if (view != null) {
/* 649 */         view.paint(paramGraphics, textRect);
/*     */       } else {
/* 652 */         paramGraphics.setColor(synthStyle.getColor(paramSynthContext1, ColorType.TEXT_FOREGROUND));
/* 653 */         paramGraphics.setFont(synthStyle.getFont(paramSynthContext1));
/* 654 */         synthStyle.getGraphicsUtils(paramSynthContext1).paintText(paramSynthContext1, paramGraphics, str2, textRect.x, textRect.y, jMenuItem.getDisplayedMnemonicIndex());
/*     */       } 
/*     */     } 
/* 659 */     if (str1 != null && !str1.equals("")) {
/* 661 */       byte b = 0;
/* 662 */       SynthStyle synthStyle1 = paramSynthContext2.getStyle();
/* 663 */       paramGraphics.setColor(synthStyle1.getColor(paramSynthContext2, ColorType.TEXT_FOREGROUND));
/* 664 */       paramGraphics.setFont(synthStyle1.getFont(paramSynthContext2));
/* 665 */       synthStyle1.getGraphicsUtils(paramSynthContext2).paintText(paramSynthContext2, paramGraphics, str1, acceleratorRect.x - b, acceleratorRect.y, -1);
/*     */     } 
/* 669 */     if (paramIcon2 != null && !paramBoolean)
/* 670 */       SyntheticaIcon.paintIcon(paramIcon2, paramSynthContext1, paramGraphics, arrowIconRect.x, arrowIconRect.y, arrowIconRect.width, arrowIconRect.height); 
/* 672 */     if (paintDebugRects) {
/* 674 */       paramGraphics.setColor(Color.ORANGE);
/* 675 */       paramGraphics.drawRect(viewRect.x, viewRect.y, viewRect.width - 1, viewRect.height - 1);
/* 677 */       paramGraphics.setColor(Color.RED);
/* 678 */       paramGraphics.drawRect(checkIconRect.x, checkIconRect.y, checkIconRect.width - 1, checkIconRect.height - 1);
/* 680 */       paramGraphics.setColor(Color.YELLOW);
/* 681 */       paramGraphics.drawRect(iconRect.x, iconRect.y, iconRect.width - 1, iconRect.height - 1);
/* 683 */       paramGraphics.setColor(Color.GREEN);
/* 684 */       paramGraphics.drawRect(textRect.x, textRect.y, textRect.width - 1, textRect.height - 1);
/* 686 */       paramGraphics.setColor(Color.CYAN);
/* 687 */       paramGraphics.drawRect(acceleratorRect.x, acceleratorRect.y, acceleratorRect.width - 1, acceleratorRect.height - 1);
/* 689 */       paramGraphics.setColor(Color.BLUE);
/* 690 */       paramGraphics.drawRect(arrowIconRect.x, arrowIconRect.y, arrowIconRect.width - 1, arrowIconRect.height - 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String modifiersAsText(int paramInt) {
/* 696 */     if (OS.getCurrentOS() == OS.Mac && SyntheticaLookAndFeel.getBoolean("Synthetica.menuItem.useMacAcceleratorChars", null, false))
/* 697 */       return getMacKeyModifiersText(paramInt); 
/* 698 */     return getKeyModifiersText(paramInt);
/*     */   }
/*     */   
/*     */   private static String getAcceleratorDelimiter() {
/* 707 */     String str = UIManager.getString("MenuItem.acceleratorDelimiter");
/* 708 */     return (str == null) ? "+" : str;
/*     */   }
/*     */   
/*     */   private static String getKeyModifiersText(int paramInt) {
/* 713 */     String str = getAcceleratorDelimiter();
/* 714 */     StringBuffer stringBuffer = new StringBuffer();
/* 715 */     if ((paramInt & 0x4) != 0)
/* 716 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.meta", "Meta")) + str); 
/* 717 */     if ((paramInt & 0x2) != 0)
/* 718 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.control", "Ctrl")) + str); 
/* 719 */     if ((paramInt & 0x8) != 0)
/* 720 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.alt", "Alt")) + str); 
/* 721 */     if ((paramInt & 0x1) != 0)
/* 722 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.shift", "Shift")) + str); 
/* 723 */     if ((paramInt & 0x20) != 0)
/* 724 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.altGraph", "Alt Graph")) + str); 
/* 725 */     if ((paramInt & 0x10) != 0)
/* 726 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.button1", "Button1")) + str); 
/* 728 */     if (stringBuffer.length() > 0)
/* 729 */       stringBuffer.setLength(stringBuffer.length() - str.length()); 
/* 730 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   private static String getMacKeyModifiersText(int paramInt) {
/* 735 */     String str = getAcceleratorDelimiter();
/* 736 */     StringBuffer stringBuffer = new StringBuffer();
/* 738 */     if ((paramInt & 0x2) != 0)
/* 739 */       stringBuffer.append("⌃" + str); 
/* 741 */     if ((paramInt & 0x1) != 0)
/* 742 */       stringBuffer.append("⇧" + str); 
/* 744 */     if ((paramInt & 0x8) != 0)
/* 745 */       stringBuffer.append("⌥" + str); 
/* 746 */     if ((paramInt & 0x20) != 0)
/* 747 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.altGraph", "Alt Graph")) + str); 
/* 749 */     if ((paramInt & 0x4) != 0)
/* 750 */       stringBuffer.append("⌘" + str); 
/* 751 */     if ((paramInt & 0x10) != 0)
/* 752 */       stringBuffer.append(String.valueOf(Toolkit.getProperty("AWT.button1", "Button1")) + str); 
/* 754 */     if (stringBuffer.length() > 0)
/* 755 */       stringBuffer.setLength(stringBuffer.length() - str.length()); 
/* 756 */     return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public static void resetPopupMenu(JPopupMenu paramJPopupMenu) {
/* 764 */     maxWidths.remove(paramJPopupMenu);
/*     */   }
/*     */   
/*     */   static SynthContext getMenuItemContext(JComponent paramJComponent) {
/* 769 */     boolean bool = (paramJComponent instanceof JMenu && ((JMenu)paramJComponent).isTopLevelMenu()) ? true : false;
/* 770 */     Region region = bool ? Region.MENU : Region.MENU_ITEM;
/* 771 */     return getContext(paramJComponent, region);
/*     */   }
/*     */   
/*     */   static SynthStyle getStyle(JComponent paramJComponent) {
/* 776 */     return SynthLookAndFeel.getStyle(paramJComponent, getRegion(paramJComponent));
/*     */   }
/*     */   
/*     */   static SynthContext getContext(JComponent paramJComponent) {
/* 781 */     return getContext(paramJComponent, getComponentState(paramJComponent));
/*     */   }
/*     */   
/*     */   static SynthContext getContext(JComponent paramJComponent, int paramInt) {
/* 786 */     return getContext(paramJComponent, getRegion(paramJComponent), paramInt);
/*     */   }
/*     */   
/*     */   static SynthContext getContext(JComponent paramJComponent, Region paramRegion) {
/* 791 */     return getContext(paramJComponent, paramRegion, getComponentState(paramJComponent));
/*     */   }
/*     */   
/*     */   private static SynthContext getContext(JComponent paramJComponent, Region paramRegion, int paramInt) {
/* 796 */     SynthStyle synthStyle = SynthLookAndFeel.getStyle(paramJComponent, paramRegion);
/* 797 */     return new SynthContext(paramJComponent, paramRegion, synthStyle, paramInt);
/*     */   }
/*     */   
/*     */   private static Region getRegion(JComponent paramJComponent) {
/* 803 */     return SynthLookAndFeel.getRegion(paramJComponent);
/*     */   }
/*     */   
/*     */   private static int getComponentState(JComponent paramJComponent) {
/* 808 */     int i = 0;
/* 810 */     if (!paramJComponent.isEnabled()) {
/* 811 */       i = 8;
/* 812 */     } else if (((JMenuItem)paramJComponent).isArmed()) {
/* 813 */       i = 2;
/* 816 */     } else if (paramJComponent.isEnabled()) {
/* 818 */       if (paramJComponent.isFocusOwner()) {
/* 819 */         i = 257;
/*     */       } else {
/* 821 */         i = 1;
/*     */       } 
/*     */     } else {
/* 824 */       i = 8;
/*     */     } 
/* 826 */     if (((JMenuItem)paramJComponent).isSelected())
/* 827 */       i |= 0x200; 
/* 828 */     return i;
/*     */   }
/*     */   
/*     */   private static JPopupMenu findPopup(Container paramContainer) {
/* 833 */     return (JPopupMenu)SwingUtilities.getAncestorOfClass(JPopupMenu.class, paramContainer);
/*     */   }
/*     */   
/*     */   private static void resetRects() {
/* 843 */     iconRect.setBounds(0, 0, 0, 0);
/* 844 */     textRect.setBounds(0, 0, 0, 0);
/* 845 */     acceleratorRect.setBounds(0, 0, 0, 0);
/* 846 */     checkIconRect.setBounds(0, 0, 0, 0);
/* 847 */     arrowIconRect.setBounds(0, 0, 0, 0);
/* 848 */     viewRect.setBounds(0, 0, 32767, 32767);
/* 849 */     r.setBounds(0, 0, 0, 0);
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent) {
/* 857 */     String str = paramPropertyChangeEvent.getPropertyName();
/* 858 */     if (SyntheticaLookAndFeel.shouldUpdateStyle(paramPropertyChangeEvent)) {
/* 859 */       updateStyle((JMenuItem)paramPropertyChangeEvent.getSource());
/* 860 */     } else if ("Synthetica.menuItem.arrowIcon".equals(str)) {
/* 861 */       this.menuItem.updateUI();
/* 863 */     } else if (("text".equals(str) || "icon".equals(str)) && SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.dynamicItemSupport", null)) {
/* 864 */       resetPopupMenu(findPopup((JMenuItem)paramPropertyChangeEvent.getSource()));
/*     */     } 
/*     */   }
/*     */   
/*     */   private static class MaxWidth {
/*     */     int maxTextWidth;
/*     */     
/*     */     int maxAcceleratorWidth;
/*     */     
/*     */     int maxIconWidth;
/*     */     
/*     */     int maxCheckIconWidth;
/*     */     
/*     */     int maxArrowIconWidth;
/*     */     
/*     */     private MaxWidth() {}
/*     */     
/*     */     public void clear() {
/* 880 */       this.maxTextWidth = 0;
/* 881 */       this.maxAcceleratorWidth = 0;
/* 882 */       this.maxIconWidth = 0;
/* 883 */       this.maxCheckIconWidth = 0;
/* 884 */       this.maxArrowIconWidth = 0;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaMenuItemUI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */