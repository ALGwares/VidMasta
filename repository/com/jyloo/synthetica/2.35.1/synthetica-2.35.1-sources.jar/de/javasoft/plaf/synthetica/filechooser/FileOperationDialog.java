/*     */ package de.javasoft.plaf.synthetica.filechooser;
/*     */ 
/*     */ import de.javasoft.io.FileOperationEvent;
/*     */ import de.javasoft.io.FileOperationListener;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.painter.ImagePainter;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ public class FileOperationDialog extends JDialog implements FileOperationListener, Runnable {
/*     */   public static final int COPY_OPERATION = 1;
/*     */   
/*     */   public static final int MOVE_OPERATION = 2;
/*     */   
/*     */   public static final int DELETE_OPERATION = 3;
/*     */   
/*     */   private boolean abort;
/*     */   
/*     */   private JLabel folderName;
/*     */   
/*     */   private JLabel fileName;
/*     */   
/*     */   private String currentFolderName;
/*     */   
/*     */   private String currentFileName;
/*     */   
/*     */   private JProgressBar progressBar;
/*     */   
/*     */   private static final int xGap = 10;
/*     */   
/*     */   private static final int yGap = 10;
/*     */   
/*  71 */   String title = "";
/*     */   
/*  72 */   String imagePath = "";
/*     */   
/*     */   Insets imageInsets;
/*     */   
/*     */   public FileOperationDialog(Dialog paramDialog, int paramInt) {
/*  78 */     super(paramDialog);
/*  79 */     init(paramDialog, paramInt);
/*     */   }
/*     */   
/*     */   public FileOperationDialog(Frame paramFrame, int paramInt) {
/*  84 */     super(paramFrame);
/*  85 */     init(paramFrame, paramInt);
/*     */   }
/*     */   
/*     */   private void init(Window paramWindow, int paramInt) {
/*  90 */     Image image = null;
/*  92 */     switch (paramInt) {
/*     */       case 1:
/*  95 */         this.title = UIManager.getString("FileOperationDialog.copy.title");
/*  96 */         this.imagePath = UIManager.getString("Synthetica.fileOperationDialog.title.copyBackground");
/*  97 */         this.imageInsets = SyntheticaLookAndFeel.getInsets("Synthetica.fileOperationDialog.title.copyBackground.insets", null, new Insets(0, 0, 4, 100));
/*  98 */         image = (Image)UIManager.get("Synthetica.fileOperationDialog.copy.iconImage");
/*     */         break;
/*     */       case 2:
/* 101 */         this.title = UIManager.getString("FileOperationDialog.move.title");
/* 102 */         this.imagePath = UIManager.getString("Synthetica.fileOperationDialog.title.moveBackground");
/* 103 */         this.imageInsets = SyntheticaLookAndFeel.getInsets("Synthetica.fileOperationDialog.title.moveBackground.insets", null, new Insets(0, 0, 4, 100));
/* 104 */         image = (Image)UIManager.get("Synthetica.fileOperationDialog.move.iconImage");
/*     */         break;
/*     */       case 3:
/* 107 */         this.title = UIManager.getString("FileOperationDialog.delete.title");
/* 108 */         this.imagePath = UIManager.getString("Synthetica.fileOperationDialog.title.deleteBackground");
/* 109 */         this.imageInsets = SyntheticaLookAndFeel.getInsets("Synthetica.fileOperationDialog.title.deleteBackground.insets", null, new Insets(0, 0, 4, 100));
/* 110 */         image = (Image)UIManager.get("Synthetica.fileOperationDialog.delete.iconImage");
/*     */         break;
/*     */     } 
/* 113 */     setTitle(this.title);
/* 114 */     setLayout(new BorderLayout());
/* 115 */     getRootPane().putClientProperty("Synthetica.dialog.iconImage", image);
/* 119 */     JPanel jPanel1 = new JPanel() {
/* 121 */         private Image background = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(FileOperationDialog.this.imagePath))).getImage();
/*     */         
/*     */         public void paintComponent(Graphics param1Graphics) {
/* 125 */           ImagePainter imagePainter = new ImagePainter(this.background, param1Graphics, 0, 0, getWidth(), this.background.getHeight(null), FileOperationDialog.this.imageInsets, FileOperationDialog.this.imageInsets);
/* 126 */           imagePainter.draw();
/* 127 */           Graphics2D graphics2D = (Graphics2D)param1Graphics;
/* 128 */           graphics2D.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/* 129 */           int i = UIManager.getInt("Synthetica.fileOperationDialog.title.xPos");
/* 130 */           int j = UIManager.getInt("Synthetica.fileOperationDialog.title.yPos");
/* 131 */           graphics2D.drawString(FileOperationDialog.this.title, i, j);
/* 132 */           graphics2D.dispose();
/*     */         }
/*     */         
/*     */         public Dimension getPreferredSize() {
/* 136 */           return new Dimension(this.background.getWidth(null), this.background.getHeight(null));
/*     */         }
/*     */       };
/* 139 */     float f = SyntheticaLookAndFeel.scaleFontSize(UIManager.getInt("Synthetica.fileOperationDialog.title.size"));
/* 140 */     jPanel1.setFont(jPanel1.getFont().deriveFont(1, f));
/* 141 */     jPanel1.setForeground(UIManager.getColor("Synthetica.fileOperationDialog.title.color"));
/* 143 */     JPanel jPanel2 = new JPanel(new GridBagLayout());
/* 144 */     jPanel2.setBorder(new EmptyBorder(10, 10, 10, 10));
/* 145 */     GridBagConstraints gridBagConstraints = new GridBagConstraints();
/* 146 */     gridBagConstraints.anchor = 17;
/* 147 */     gridBagConstraints.weightx = 0.0D;
/* 148 */     gridBagConstraints.weighty = 0.0D;
/* 149 */     gridBagConstraints.gridwidth = 2;
/* 150 */     gridBagConstraints.gridheight = 1;
/* 155 */     gridBagConstraints.gridx = 0;
/* 156 */     gridBagConstraints.gridy = 0;
/* 157 */     JPanel jPanel3 = new JPanel(new BorderLayout());
/* 159 */     jPanel2.add(jPanel3, gridBagConstraints);
/* 161 */     gridBagConstraints.insets = new Insets(0, 0, 2, 10);
/* 162 */     gridBagConstraints.gridwidth = 1;
/* 163 */     gridBagConstraints.gridx = 0;
/* 164 */     gridBagConstraints.gridy = 1;
/* 165 */     gridBagConstraints.weightx = 0.0D;
/* 166 */     gridBagConstraints.fill = 0;
/* 167 */     JLabel jLabel1 = new JLabel(UIManager.getString("FileOperationDialog.folder"));
/* 169 */     jPanel2.add(jLabel1, gridBagConstraints);
/* 171 */     gridBagConstraints.insets = new Insets(0, 0, 2, 0);
/* 172 */     gridBagConstraints.gridx = 1;
/* 173 */     gridBagConstraints.weightx = 1.0D;
/* 174 */     gridBagConstraints.fill = 2;
/* 175 */     this.folderName = new JLabel();
/* 177 */     jPanel2.add(this.folderName, gridBagConstraints);
/* 179 */     gridBagConstraints.insets = new Insets(0, 0, 10, 10);
/* 180 */     gridBagConstraints.gridx = 0;
/* 181 */     gridBagConstraints.gridy = 2;
/* 182 */     gridBagConstraints.weightx = 0.0D;
/* 183 */     gridBagConstraints.fill = 0;
/* 184 */     JLabel jLabel2 = new JLabel(UIManager.getString("FileOperationDialog.file"));
/* 186 */     jPanel2.add(jLabel2, gridBagConstraints);
/* 188 */     gridBagConstraints.insets = new Insets(0, 0, 10, 0);
/* 189 */     gridBagConstraints.gridx = 1;
/* 190 */     gridBagConstraints.weightx = 1.0D;
/* 191 */     gridBagConstraints.fill = 2;
/* 192 */     this.fileName = new JLabel();
/* 194 */     jPanel2.add(this.fileName, gridBagConstraints);
/* 196 */     gridBagConstraints.insets = new Insets(0, 0, 20, 0);
/* 197 */     gridBagConstraints.gridwidth = 2;
/* 198 */     gridBagConstraints.gridx = 0;
/* 199 */     gridBagConstraints.gridy = 3;
/* 200 */     this.progressBar = new JProgressBar(0, 50);
/* 201 */     jPanel2.add(this.progressBar, gridBagConstraints);
/* 203 */     gridBagConstraints.anchor = paramWindow.getComponentOrientation().isLeftToRight() ? 13 : 17;
/* 204 */     gridBagConstraints.insets = new Insets(0, 0, 0, 0);
/* 205 */     gridBagConstraints.gridx = 0;
/* 206 */     gridBagConstraints.gridy = 4;
/* 207 */     gridBagConstraints.weightx = 0.0D;
/* 208 */     gridBagConstraints.fill = 0;
/* 209 */     JButton jButton = new JButton(UIManager.getString("FileOperationDialog.cancel"));
/* 210 */     jButton.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/* 214 */             FileOperationDialog.this.abort = true;
/* 215 */             FileOperationDialog.this.dispose();
/*     */           }
/*     */         });
/* 218 */     jPanel2.add(jButton, gridBagConstraints);
/* 220 */     add(jPanel1, "North");
/* 221 */     add(jPanel2);
/* 222 */     pack();
/* 224 */     int i = (paramWindow.getLocation()).x + (paramWindow.getSize()).width / 2;
/* 225 */     int j = i - (getSize()).width / 2;
/* 226 */     int k = (paramWindow.getLocation()).y + (paramWindow.getSize()).height / 2;
/* 227 */     int m = k - (getSize()).height / 2;
/* 228 */     setLocation(j, m);
/* 230 */     addWindowListener(new WindowAdapter() {
/*     */           public void windowClosing(WindowEvent param1WindowEvent) {
/* 234 */             FileOperationDialog.this.abort = true;
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public boolean processFileOperationEvent(FileOperationEvent paramFileOperationEvent) {
/* 245 */     this.currentFolderName = paramFileOperationEvent.getFile().getParentFile().getName();
/* 246 */     this.currentFileName = paramFileOperationEvent.getFile().getName();
/* 247 */     EventQueue.invokeLater(this);
/* 249 */     return !this.abort;
/*     */   }
/*     */   
/*     */   public void run() {
/* 257 */     this.folderName.setText(this.currentFolderName);
/* 258 */     this.fileName.setText(this.currentFileName);
/* 259 */     this.progressBar.setValue((this.progressBar.getValue() + 1) % 50);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\filechooser\FileOperationDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */