/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class TextFieldPainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.TextFieldPainter";
/*    */   
/*    */   public static TextFieldPainter getInstance() {
/* 43 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static TextFieldPainter getInstance(SynthContext paramSynthContext) {
/* 52 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TextFieldPainter.class, "Synthetica.TextFieldPainter"));
/* 53 */     if (syntheticaComponentPainter == null)
/* 54 */       syntheticaComponentPainter = getInstance(paramSynthContext, TextFieldPainter.class, "Synthetica.TextFieldPainter"); 
/* 55 */     return (TextFieldPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintTextFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 65 */     paintBackground("textField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public void paintTextFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 73 */     if (!paintCheck(paramSynthContext))
/*    */       return; 
/* 75 */     paintBorder("textField", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   protected boolean paintCheck(SynthContext paramSynthContext) {
/* 80 */     if (paramSynthContext.getComponent().getParent() instanceof javax.swing.JComboBox)
/* 81 */       return false; 
/* 82 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TextFieldPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */