/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.GraphicsUtils;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.java2d.Synthetica2DUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class CheckBoxStyle extends StyleWrapper {
/*  38 */   private static CheckBoxStyle instance = new CheckBoxStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  46 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  48 */       instance.setStyle(paramSynthStyle);
/*  49 */       return instance;
/*     */     } 
/*  51 */     CheckBoxStyle checkBoxStyle = new CheckBoxStyle();
/*  52 */     checkBoxStyle.setStyle(paramSynthStyle);
/*  53 */     return checkBoxStyle;
/*     */   }
/*     */   
/*     */   public Icon getIcon(SynthContext paramSynthContext, Object paramObject) {
/*  71 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/*  72 */     if (abstractButton.getIcon() != null)
/*  73 */       return null; 
/*  77 */     int i = paramSynthContext.getComponentState();
/*  78 */     Boolean bool = (Boolean)abstractButton.getClientProperty("Synthetica.MOUSE_OVER");
/*  79 */     boolean bool1 = (bool == null) ? false : bool.booleanValue();
/*  85 */     Icon icon = null;
/*  86 */     if ((i & 0x4) > 0) {
/*  89 */       boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.checkBox.emulatedPressedState.enabled", abstractButton);
/*  90 */       boolean bool3 = abstractButton.isSelected();
/*  92 */       if (bool2)
/*  93 */         icon = SyntheticaLookAndFeel.loadIcon(bool3 ? "Synthetica.checkBox.selected.image" : "Synthetica.checkBox.image"); 
/*  94 */       if (icon == null)
/*  95 */         icon = this.synthStyle.getIcon(new SynthContext(abstractButton, paramSynthContext.getRegion(), paramSynthContext.getStyle(), bool3 ? 516 : 4), paramObject); 
/*  96 */       if (bool2) {
/*  98 */         BufferedImage bufferedImage1 = (BufferedImage)GraphicsUtils.iconToImage(paramSynthContext, icon);
/*  99 */         Color color = SyntheticaLookAndFeel.getColor("Synthetica.checkBox.emulatedPressedState.color", abstractButton, UIManager.getColor("Panel.background").darker());
/* 100 */         float f = SyntheticaLookAndFeel.getInt("Synthetica.checkBox.emulatedPressedState.alpha", abstractButton, 25) / 100.0F;
/* 101 */         BufferedImage bufferedImage2 = Synthetica2DUtils.createColorizedImage(bufferedImage1, color, f);
/* 102 */         icon = new ImageIcon(bufferedImage2);
/*     */       } 
/* 105 */     } else if ((i & 0x200) > 0 && bool1) {
/* 106 */       icon = this.synthStyle.getIcon(new SynthContext(abstractButton, paramSynthContext.getRegion(), paramSynthContext.getStyle(), i | 0x2), paramObject);
/*     */     } else {
/* 108 */       icon = this.synthStyle.getIcon(paramSynthContext, paramObject);
/*     */     } 
/* 110 */     if (abstractButton.getClientProperty("Synthetica.background") != null) {
/* 112 */       float f = (abstractButton.getClientProperty("Synthetica.background.alpha") == null) ? 0.1F : ((Float)abstractButton.getClientProperty("Synthetica.background.alpha")).floatValue();
/* 113 */       BufferedImage bufferedImage1 = (BufferedImage)GraphicsUtils.iconToImage(paramSynthContext, icon);
/* 114 */       BufferedImage bufferedImage2 = Synthetica2DUtils.createColorizedImage(bufferedImage1, (Color)abstractButton.getClientProperty("Synthetica.background"), f);
/* 115 */       icon = new ImageIcon(bufferedImage2);
/*     */     } 
/* 117 */     return icon;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\CheckBoxStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */