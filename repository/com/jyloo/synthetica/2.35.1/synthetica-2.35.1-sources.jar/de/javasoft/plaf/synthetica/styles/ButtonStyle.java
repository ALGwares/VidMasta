/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import java.awt.Font;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.FontUIResource;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ButtonStyle extends StyleWrapper {
/* 33 */   private static ButtonStyle instance = new ButtonStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 41 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 43 */       instance.setStyle(paramSynthStyle);
/* 44 */       return instance;
/*    */     } 
/* 46 */     ButtonStyle buttonStyle = new ButtonStyle();
/* 47 */     buttonStyle.setStyle(paramSynthStyle);
/* 48 */     return buttonStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 54 */     JComponent jComponent = paramSynthContext.getComponent();
/* 56 */     if (paramColorType == ColorType.TEXT_FOREGROUND && !(jComponent.getForeground() instanceof javax.swing.plaf.ColorUIResource))
/* 57 */       return jComponent.getForeground(); 
/* 58 */     return super.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */   
/*    */   public Font getFont(SynthContext paramSynthContext) {
/* 64 */     Font font = this.synthStyle.getFont(paramSynthContext);
/* 65 */     JComponent jComponent = paramSynthContext.getComponent();
/* 66 */     String str = "Synthetica.button.font";
/* 67 */     if (jComponent instanceof JButton && ((JButton)jComponent).isDefaultButton())
/* 68 */       str = "Synthetica.button.default.font"; 
/* 69 */     if (SyntheticaLookAndFeel.get(String.valueOf(str) + ".style", jComponent) != null) {
/* 71 */       int i = 0;
/* 72 */       String str1 = SyntheticaLookAndFeel.getString(String.valueOf(str) + ".style", jComponent);
/* 73 */       if (str1.contains("BOLD"))
/* 74 */         i |= 0x1; 
/* 75 */       if (str1.contains("ITALIC"))
/* 76 */         i |= 0x2; 
/* 77 */       float f = SyntheticaLookAndFeel.scaleFontSize(SyntheticaLookAndFeel.getInt(String.valueOf(str) + ".size", jComponent, 0));
/* 78 */       if (f == 0.0F)
/* 79 */         f = font.getSize2D(); 
/* 80 */       font = new FontUIResource(font.deriveFont(i, f));
/*    */     } 
/* 82 */     return font;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ButtonStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */