/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class DesktopPanePainter extends SyntheticaComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.DesktopPanePainter";
/*    */   
/*    */   public static DesktopPanePainter getInstance() {
/* 48 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static DesktopPanePainter getInstance(SynthContext paramSynthContext) {
/* 57 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, DesktopPanePainter.class, "Synthetica.DesktopPanePainter"));
/* 58 */     if (syntheticaComponentPainter == null)
/* 59 */       syntheticaComponentPainter = getInstance(paramSynthContext, DesktopPanePainter.class, "Synthetica.DesktopPanePainter"); 
/* 60 */     return (DesktopPanePainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintDesktopPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintDesktopPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 72 */     JComponent jComponent = paramSynthContext.getComponent();
/* 73 */     String str = SyntheticaLookAndFeel.getString("Synthetica.desktopPane.background", jComponent);
/* 74 */     if (str != null && SyntheticaLookAndFeel.isOpaque(jComponent)) {
/* 76 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.desktopPane.background.insets", jComponent);
/* 77 */       Insets insets2 = insets1;
/* 78 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 79 */       imagePainter.draw();
/*    */     } 
/* 82 */     str = SyntheticaLookAndFeel.getString("Synthetica.desktopPane.patternBackground", jComponent);
/* 83 */     if (str != null && SyntheticaLookAndFeel.isOpaque(jComponent)) {
/* 85 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.desktopPane.patternBackground.insets", jComponent);
/* 86 */       Insets insets2 = insets1;
/* 87 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 1, 1);
/* 88 */       imagePainter.draw();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\DesktopPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */