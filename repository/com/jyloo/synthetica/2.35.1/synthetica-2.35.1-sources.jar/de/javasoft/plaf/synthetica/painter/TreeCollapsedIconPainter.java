/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class TreeCollapsedIconPainter extends SyntheticaBasicIconPainter {
/*    */   private Icon regularIcon;
/*    */   
/*    */   private Icon selectedIcon;
/*    */   
/*    */   public TreeCollapsedIconPainter() {
/* 35 */     super(null, SyntheticaLookAndFeel.getInt("Synthetica.tree.collapsedIcon.size", null, 12), SyntheticaLookAndFeel.getInt("Synthetica.tree.collapsedIcon.size", null, 12));
/*    */   }
/*    */   
/*    */   public void paintIcon(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 41 */     JComponent jComponent = (paramSynthContext == null) ? null : paramSynthContext.getComponent();
/* 42 */     boolean bool = (jComponent instanceof JTree && ((JTree)jComponent).getSelectionModel().isRowSelected(((JTree)jComponent).getClosestRowForLocation(paramInt1, paramInt2))) ? true : false;
/* 43 */     if (this.regularIcon == null && !bool) {
/* 44 */       this.regularIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.collapsedIcon");
/* 45 */     } else if (this.selectedIcon == null && bool) {
/* 46 */       this.selectedIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.selected.collapsedIcon");
/*    */     } 
/* 47 */     Icon icon = bool ? this.selectedIcon : this.regularIcon;
/* 48 */     icon.paintIcon(jComponent, paramGraphics, paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 55 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TreeCollapsedIconPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */