/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Window;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class ToolBarPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ToolBarPainter";
/*     */   
/*     */   public static ToolBarPainter getInstance() {
/*  52 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ToolBarPainter getInstance(SynthContext paramSynthContext) {
/*  61 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ToolBarPainter.class, "Synthetica.ToolBarPainter"));
/*  62 */     if (syntheticaComponentPainter == null)
/*  63 */       syntheticaComponentPainter = getInstance(paramSynthContext, ToolBarPainter.class, "Synthetica.ToolBarPainter"); 
/*  64 */     return (ToolBarPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintToolBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintToolBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  75 */     paintToolBarBackground(paramSynthContext.getComponent(), new SyntheticaState(paramSynthContext.getComponentState()), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintToolBarBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  91 */     Container container = paramJComponent.getRootPane().getParent();
/*  92 */     boolean bool = true;
/*  93 */     if (container instanceof Window) {
/*  94 */       bool = ((Window)container).isActive();
/*  95 */     } else if (container instanceof JInternalFrame) {
/*  96 */       bool = ((JInternalFrame)container).isSelected();
/*     */     } 
/*  98 */     String str = "Synthetica.toolBar.background";
/*  99 */     if (!bool && SyntheticaLookAndFeel.get(String.valueOf(str) + ".inactive", paramJComponent) != null)
/* 100 */       str = String.valueOf(str) + ".inactive"; 
/* 101 */     str = SyntheticaLookAndFeel.getString(str, paramJComponent);
/* 102 */     if (str != null && SyntheticaLookAndFeel.isOpaque(paramJComponent)) {
/* 104 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.toolBar.background.insets", paramJComponent);
/* 105 */       Insets insets2 = insets1;
/* 107 */       boolean bool1 = false;
/* 108 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.background.horizontalTiled", paramJComponent))
/* 109 */         bool1 = true; 
/* 110 */       boolean bool2 = false;
/* 111 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.background.verticalTiled", paramJComponent))
/* 112 */         bool2 = true; 
/* 114 */       UIKey uIKey = new UIKey("toolBar.background", paramSyntheticaState);
/* 115 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, 1);
/* 116 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 50);
/* 117 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, bool ? 0 : 6);
/* 118 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, i, j, k, paramSyntheticaState.getState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, bool1, bool2);
/* 119 */       imagePainter.draw();
/* 121 */       str = "Synthetica.toolBar.background.light";
/* 122 */       str = SyntheticaLookAndFeel.getString(str, paramJComponent);
/* 123 */       if (str != null) {
/* 125 */         imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 126 */         imagePainter.draw();
/*     */       } 
/* 128 */       str = "Synthetica.toolBar.background.light2";
/* 129 */       str = SyntheticaLookAndFeel.getString(str, paramJComponent);
/* 130 */       if (str != null) {
/* 132 */         imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 133 */         imagePainter.draw();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintToolBarContentBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintToolBarContentBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ToolBarPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */