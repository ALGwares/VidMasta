/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*    */ import java.awt.Container;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ class SyntheticaPainterState extends SyntheticaState {
/*    */   public SyntheticaPainterState(SynthContext paramSynthContext) {
/* 33 */     this(paramSynthContext, 0, false);
/*    */   }
/*    */   
/*    */   public SyntheticaPainterState(SynthContext paramSynthContext, int paramInt, boolean paramBoolean) {
/* 38 */     this(paramSynthContext, paramInt, paramBoolean, false);
/*    */   }
/*    */   
/*    */   public SyntheticaPainterState(SynthContext paramSynthContext, int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
/* 45 */     super(paramSynthContext.getComponentState() | paramInt);
/* 47 */     JComponent jComponent = paramSynthContext.getComponent();
/* 48 */     if (jComponent instanceof JTextComponent && !((JTextComponent)jComponent).isEditable()) {
/* 49 */       setState(SyntheticaState.State.LOCKED);
/* 50 */     } else if (jComponent instanceof JComboBox && !((JComboBox)jComponent).isEditable()) {
/* 51 */       setState(SyntheticaState.State.LOCKED);
/*    */     } 
/* 54 */     if (paramBoolean1) {
/* 56 */       boolean bool1 = (jComponent.getClientProperty("Synthetica.MOUSE_OVER") == null) ? false : ((Boolean)jComponent.getClientProperty("Synthetica.MOUSE_OVER")).booleanValue();
/* 57 */       if (bool1)
/* 57 */         setState(SyntheticaState.State.HOVER); 
/* 59 */       boolean bool2 = (jComponent.getClientProperty("Synthetica.MOUSE_PRESSED") == null) ? false : ((Boolean)jComponent.getClientProperty("Synthetica.MOUSE_PRESSED")).booleanValue();
/* 60 */       if (bool2)
/* 60 */         setState(SyntheticaState.State.PRESSED); 
/*    */     } 
/* 63 */     if (paramBoolean2) {
/* 65 */       Container container = jComponent.getParent();
/* 66 */       if (container instanceof JComponent) {
/* 68 */         boolean bool1 = (((JComponent)container).getClientProperty("Synthetica.MOUSE_OVER") == null) ? false : ((Boolean)((JComponent)container).getClientProperty("Synthetica.MOUSE_OVER")).booleanValue();
/* 69 */         if (bool1)
/* 69 */           setState(SyntheticaState.State.HOVER); 
/* 71 */         boolean bool2 = (((JComponent)container).getClientProperty("Synthetica.MOUSE_PRESSED") == null) ? false : ((Boolean)((JComponent)container).getClientProperty("Synthetica.MOUSE_PRESSED")).booleanValue();
/* 72 */         if (bool2)
/* 72 */           setState(SyntheticaState.State.PRESSED); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaPainterState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */