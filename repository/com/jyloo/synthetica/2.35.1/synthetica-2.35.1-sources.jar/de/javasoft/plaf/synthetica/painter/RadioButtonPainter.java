/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ public class RadioButtonPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.RadioButtonPainter";
/*     */   
/*     */   public static RadioButtonPainter getInstance() {
/*  57 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static RadioButtonPainter getInstance(SynthContext paramSynthContext) {
/*  66 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, RadioButtonPainter.class, "Synthetica.RadioButtonPainter"));
/*  67 */     if (syntheticaComponentPainter == null)
/*  68 */       syntheticaComponentPainter = getInstance(paramSynthContext, RadioButtonPainter.class, "Synthetica.RadioButtonPainter"); 
/*  69 */     return (RadioButtonPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintRadioButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  77 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/*  78 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/*  79 */     if (SyntheticaLookAndFeel.get("Synthetica.radioButton.image", abstractButton) != null && 
/*  80 */       abstractButton.getIcon() == null) {
/*  82 */       UIKey uIKey = new UIKey("radioButton", syntheticaPainterState);
/*  83 */       Insets insets1 = new Insets(0, 0, 0, 0);
/*  84 */       Insets insets2 = insets1;
/*  85 */       Insets insets3 = abstractButton.getInsets();
/*  87 */       String str = SyntheticaLookAndFeel.getString(uIKey.get("image"), abstractButton);
/*  89 */       if (abstractButton.hasFocus() && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused.image", abstractButton) != null)
/*  90 */         str = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused.image", abstractButton); 
/*  92 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), abstractButton, 1);
/*  93 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), abstractButton, 50);
/*  94 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), abstractButton, 2);
/*  95 */       if (syntheticaPainterState.isSet(SyntheticaState.State.HOVER) || syntheticaPainterState.isSet(SyntheticaState.State.PRESSED))
/*  96 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), abstractButton, 1); 
/*  98 */       Rectangle rectangle1 = new Rectangle(paramInt1 + insets3.left, paramInt2 + insets3.top, paramInt3 - insets3.left - insets3.right, paramInt4 - insets3.top - insets3.bottom);
/*  99 */       Rectangle rectangle2 = new Rectangle();
/* 100 */       Rectangle rectangle3 = new Rectangle();
/* 102 */       Icon icon = paramSynthContext.getStyle().getIcon(paramSynthContext, "RadioButton.icon");
/* 103 */       paramSynthContext.getStyle().getGraphicsUtils(paramSynthContext).layoutText(paramSynthContext, paramGraphics.getFontMetrics(), abstractButton.getText(), icon, abstractButton.getHorizontalAlignment(), abstractButton.getVerticalAlignment(), abstractButton.getHorizontalTextPosition(), abstractButton.getVerticalTextPosition(), 
/* 104 */           rectangle1, rectangle3, rectangle2, abstractButton.getIconTextGap());
/* 105 */       ImagePainter imagePainter = new ImagePainter(abstractButton, i, j, k, syntheticaPainterState.getState(), paramGraphics, rectangle3.x, rectangle3.y, rectangle3.width, rectangle3.height, str, insets1, insets2, 0, 0);
/* 106 */       if (!syntheticaPainterState.isSet(SyntheticaState.State.PRESSED) || abstractButton.getPressedIcon() == null)
/* 109 */         imagePainter.drawCenter(); 
/* 112 */       if (syntheticaPainterState.isSet(SyntheticaState.State.FOCUSED) && abstractButton.isFocusPainted() && SyntheticaLookAndFeel.get("Synthetica.radioButton.focus", abstractButton) != null) {
/* 114 */         String str1 = "focus.radioButton";
/* 115 */         String str2 = SyntheticaLookAndFeel.getStyleName(abstractButton);
/* 116 */         i = SyntheticaLookAndFeel.getInt(str1, "animation.cycles", str2, true, -1);
/* 117 */         j = SyntheticaLookAndFeel.getInt(str1, "animation.delay", str2, true, 60);
/* 118 */         k = SyntheticaLookAndFeel.getInt(str1, "animation.type", str2, true, 3);
/* 119 */         str = SyntheticaLookAndFeel.getString("Synthetica.radioButton.focus", abstractButton);
/* 120 */         imagePainter = new ImagePainter(abstractButton, "", i, j, k, syntheticaPainterState.getState(), paramGraphics, rectangle3.x, rectangle3.y, rectangle3.width, rectangle3.height, str, insets1, insets2, 0, 0);
/* 121 */         imagePainter.drawCenter();
/*     */       } 
/*     */     } 
/* 125 */     if (syntheticaPainterState.isSet(SyntheticaState.State.FOCUSED) && abstractButton.isFocusPainted()) {
/* 128 */       Icon icon = (abstractButton.getIcon() == null) ? paramSynthContext.getStyle().getIcon(paramSynthContext, "RadioButton.icon") : abstractButton.getIcon();
/* 129 */       String str = abstractButton.getText();
/* 130 */       byte b = (str == null || str.length() == 0) ? 0 : abstractButton.getIconTextGap();
/* 131 */       int i = (abstractButton.getInsets()).left + (abstractButton.getInsets()).right + b + ((icon == null) ? 0 : icon.getIconWidth());
/* 132 */       boolean bool = (abstractButton.getClientProperty("html") != null) ? true : false;
/* 133 */       if (!bool) {
/* 135 */         FontMetrics fontMetrics = abstractButton.getFontMetrics(abstractButton.getFont());
/* 136 */         if (str != null)
/* 137 */           i += fontMetrics.stringWidth(str); 
/*     */       } else {
/* 140 */         i = (int)(i + ((View)abstractButton.getClientProperty("html")).getPreferredSpan(0));
/*     */       } 
/* 141 */       FocusPainter.paintFocus("focus.radioButton", paramSynthContext, paramGraphics, paramInt1, paramInt2, i, paramInt4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintRadioButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 150 */     JRadioButton jRadioButton = (JRadioButton)paramSynthContext.getComponent();
/* 151 */     if (jRadioButton.isBorderPainted()) {
/* 153 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.radioButton.border.insets", jRadioButton);
/* 154 */       Insets insets2 = insets1;
/* 155 */       String str = SyntheticaLookAndFeel.getString("Synthetica.radioButton.border", jRadioButton);
/* 156 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 157 */       imagePainter.drawBorder();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\RadioButtonPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */