/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ public class TextAreaStyle extends StyleWrapper {
/* 33 */   private static TextAreaStyle instance = new TextAreaStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 42 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null && ((JTextComponent)paramJComponent).isEditable()) {
/* 44 */       instance.setStyle(paramSynthStyle);
/* 45 */       return instance;
/*    */     } 
/* 47 */     TextAreaStyle textAreaStyle = new TextAreaStyle();
/* 48 */     textAreaStyle.setStyle(paramSynthStyle);
/* 49 */     return textAreaStyle;
/*    */   }
/*    */   
/*    */   public Color getColorForState(SynthContext paramSynthContext, ColorType paramColorType) {
/* 55 */     JComponent jComponent = paramSynthContext.getComponent();
/* 56 */     if (paramColorType == ColorType.TEXT_FOREGROUND && jComponent.getForeground() instanceof javax.swing.plaf.ColorUIResource && !((JTextComponent)jComponent).isEditable()) {
/* 58 */       Color color = SyntheticaLookAndFeel.getColor("Synthetica.textArea.locked.textColor", jComponent);
/* 59 */       return (color == null) ? super.getColorForState(paramSynthContext, paramColorType) : color;
/*    */     } 
/* 61 */     return super.getColorForState(paramSynthContext, paramColorType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\TextAreaStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */