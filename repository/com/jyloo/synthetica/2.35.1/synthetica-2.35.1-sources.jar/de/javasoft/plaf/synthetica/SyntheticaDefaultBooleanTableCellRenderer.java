/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ public class SyntheticaDefaultBooleanTableCellRenderer extends JCheckBox implements TableCellRenderer, UIResource {
/*     */   private static final long serialVersionUID = 2605436985980373338L;
/*     */   
/*     */   private boolean isRowSelected;
/*     */   
/*     */   private Border noFocusBorder;
/*     */   
/*     */   private Border focusBorder;
/*     */   
/*     */   private Color alternateColor;
/*     */   
/*     */   public SyntheticaDefaultBooleanTableCellRenderer(TableCellRenderer paramTableCellRenderer) {
/*  45 */     setName("Table.cellRenderer");
/*  46 */     setHorizontalAlignment(0);
/*  48 */     Border border1 = (paramTableCellRenderer == null) ? new EmptyBorder(0, 0, 0, 0) : ((JComponent)paramTableCellRenderer).getBorder();
/*  49 */     Insets insets1 = (border1 == null) ? new Insets(0, 0, 0, 0) : border1.getBorderInsets(null);
/*  51 */     Border border2 = UIManager.getBorder("Table.focusCellHighlightBorder");
/*  52 */     Border border3 = (border2 == null) ? new EmptyBorder(0, 0, 0, 0) : border2;
/*  53 */     Insets insets2 = border3.getBorderInsets(null);
/*  55 */     Insets insets3 = new Insets(insets1.top - insets2.top, insets1.left - insets2.left, insets1.bottom - insets2.bottom, insets1.right - insets2.right);
/*  56 */     this.focusBorder = new CompoundBorder(border3, new EmptyBorder(insets3));
/*  57 */     this.noFocusBorder = new CompoundBorder(new EmptyBorder(insets2), new EmptyBorder(insets3));
/*  58 */     this.alternateColor = SyntheticaLookAndFeel.getColor("Table.alternateRowColor", null);
/*     */   }
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2) {
/*  63 */     this.isRowSelected = paramBoolean1;
/*  64 */     if (paramBoolean1) {
/*  66 */       setForeground(unwrap(paramJTable.getSelectionForeground()));
/*  67 */       setBackground(unwrap(paramJTable.getSelectionBackground()));
/*     */     } else {
/*  71 */       setForeground(unwrap(paramJTable.getForeground()));
/*  72 */       Color color = paramJTable.getBackground();
/*  73 */       if ((color == null || color instanceof UIResource) && this.alternateColor != null && paramInt1 % 2 == (JavaVersion.JAVA7_OR_ABOVE ? 1 : 0)) {
/*  74 */         setBackground(this.alternateColor);
/*     */       } else {
/*  76 */         setBackground(unwrap(color));
/*     */       } 
/*     */     } 
/*  78 */     setSelected((paramObject != null && ((Boolean)paramObject).booleanValue()));
/*  80 */     if (paramBoolean2) {
/*  81 */       setBorder(this.focusBorder);
/*     */     } else {
/*  83 */       setBorder(this.noFocusBorder);
/*     */     } 
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   private Color unwrap(Color paramColor) {
/*  89 */     if (paramColor instanceof UIResource)
/*  90 */       return new Color(paramColor.getRGB()); 
/*  91 */     return paramColor;
/*     */   }
/*     */   
/*     */   public boolean isOpaque() {
/*  97 */     return this.isRowSelected ? true : super.isOpaque();
/*     */   }
/*     */   
/*     */   public boolean isBorderPainted() {
/* 103 */     return true;
/*     */   }
/*     */   
/*     */   public void invalidate() {}
/*     */   
/*     */   public void validate() {}
/*     */   
/*     */   public void revalidate() {}
/*     */   
/*     */   public void repaint(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void repaint(Rectangle paramRectangle) {}
/*     */   
/*     */   public void repaint() {}
/*     */   
/*     */   public void firePropertyChange(String paramString, boolean paramBoolean1, boolean paramBoolean2) {}
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDefaultBooleanTableCellRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */