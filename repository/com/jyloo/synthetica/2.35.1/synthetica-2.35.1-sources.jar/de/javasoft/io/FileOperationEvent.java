/*    */ package de.javasoft.io;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public class FileOperationEvent extends EventObject {
/*    */   private static final long serialVersionUID = -7123971027594023024L;
/*    */   
/*    */   public static final int CREATE = 1;
/*    */   
/*    */   public static final int COPY = 2;
/*    */   
/*    */   public static final int DELETE = 3;
/*    */   
/*    */   public static final int PROPERTIES = 4;
/*    */   
/*    */   private File file;
/*    */   
/*    */   private int fileOperation;
/*    */   
/*    */   public FileOperationEvent(Object paramObject, File paramFile, int paramInt) {
/* 41 */     super(paramObject);
/* 42 */     this.file = paramFile;
/* 43 */     this.fileOperation = paramInt;
/*    */   }
/*    */   
/*    */   public File getFile() {
/* 53 */     return this.file;
/*    */   }
/*    */   
/*    */   public int getOperation() {
/* 63 */     return this.fileOperation;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\io\FileOperationEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */