/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Container;
/*    */ import java.awt.Insets;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JPopupMenu;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class PopupMenuStyle extends StyleWrapper {
/* 34 */   private static PopupMenuStyle instance = new PopupMenuStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 42 */     JPopupMenu jPopupMenu = (JPopupMenu)paramJComponent;
/* 44 */     jPopupMenu.setOpaque(false);
/* 45 */     if (!SyntheticaLookAndFeel.isWindowOpacityEnabled(null))
/* 46 */       jPopupMenu.setDoubleBuffered(false); 
/* 53 */     jPopupMenu.addPropertyChangeListener(new PropertyChangeListener() {
/*    */           public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 57 */             String str = param1PropertyChangeEvent.getPropertyName();
/* 58 */             if ("visible".equals(str)) {
/* 60 */               JPopupMenu jPopupMenu = (JPopupMenu)param1PropertyChangeEvent.getSource();
/* 61 */               Container container = jPopupMenu.getParent();
/* 62 */               if (container instanceof JComponent) {
/* 64 */                 JComponent jComponent = (JComponent)container;
/* 66 */                 if (jComponent.isOpaque()) {
/* 68 */                   jComponent.setOpaque(false);
/* 69 */                   if (!SyntheticaLookAndFeel.isWindowOpacityEnabled(null))
/* 70 */                     jComponent.setDoubleBuffered(false); 
/*    */                 } 
/*    */               } 
/*    */             } 
/*    */           }
/*    */         });
/* 77 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 79 */       instance.setStyle(paramSynthStyle);
/* 80 */       return instance;
/*    */     } 
/* 82 */     PopupMenuStyle popupMenuStyle = new PopupMenuStyle();
/* 83 */     popupMenuStyle.setStyle(paramSynthStyle);
/* 84 */     return popupMenuStyle;
/*    */   }
/*    */   
/*    */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/* 90 */     JPopupMenu jPopupMenu = (JPopupMenu)paramSynthContext.getComponent();
/* 91 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.insets", jPopupMenu, false);
/* 92 */     return SyntheticaLookAndFeel.isToplevelPopupMenu(jPopupMenu) ? insets : super.getInsets(paramSynthContext, paramInsets);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\PopupMenuStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */