/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import com.sun.awt.AWTUtilities;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.AWTException;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GraphicsDevice;
/*     */ import java.awt.GraphicsEnvironment;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Robot;
/*     */ import java.awt.Window;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JWindow;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ 
/*     */ public class Popup extends Popup {
/*     */   public static final String POPUP_BACKGROUND = "POPUP_BACKGROUND";
/*     */   
/*     */   public static final String POPUP_LIGHTWEIGHT = "POPUP_LIGHTWEIGHT";
/*     */   
/*     */   private Component owner;
/*     */   
/*     */   private Component contents;
/*     */   
/*     */   private int x;
/*     */   
/*     */   private int y;
/*     */   
/*     */   private Popup popup;
/*     */   
/*     */   private Container heavyWeightContainer;
/*     */   
/*     */   private boolean lightWeight;
/*     */   
/*     */   public Popup(Component paramComponent1, Component paramComponent2, int paramInt1, int paramInt2, Popup paramPopup) {
/*  73 */     this.owner = paramComponent1;
/*  74 */     this.contents = paramComponent2;
/*  75 */     this.popup = paramPopup;
/*  76 */     this.x = paramInt1;
/*  77 */     this.y = paramInt2;
/*  82 */     Container container = paramComponent2.getParent();
/*  83 */     ((JComponent)container).putClientProperty("POPUP_BACKGROUND", null);
/*  84 */     ((JComponent)container).putClientProperty("POPUP_LIGHTWEIGHT", null);
/*  85 */     if (!isWindowOpacityEnabled(null))
/*  86 */       ((JComponent)container).setDoubleBuffered(false); 
/*  88 */     this.lightWeight = true;
/*  89 */     while (container != null) {
/*  95 */       if (container instanceof JWindow || container instanceof java.awt.Panel || container instanceof Window) {
/*  97 */         this.heavyWeightContainer = container;
/*  98 */         this.lightWeight = false;
/*     */         break;
/*     */       } 
/* 101 */       container = container.getParent();
/*     */     } 
/* 103 */     internalFrameCursorBugfix(paramComponent1);
/* 107 */     if (this.heavyWeightContainer != null && OS.getCurrentOS() == OS.Mac && !UIManager.getBoolean("Synthetica.popup.osShadow.enabled")) {
/* 110 */       this.heavyWeightContainer.setBackground(new Color(16777216, true));
/* 111 */       this.heavyWeightContainer.setBackground(new Color(0, true));
/* 112 */       if (this.heavyWeightContainer instanceof JWindow) {
/* 114 */         ((JWindow)this.heavyWeightContainer).getRootPane().putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/* 116 */         ((JWindow)this.heavyWeightContainer).getRootPane().putClientProperty("Window.shadow", Boolean.FALSE);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void internalFrameCursorBugfix(Component paramComponent) {
/* 127 */     if (paramComponent != null && paramComponent instanceof JInternalFrame) {
/* 129 */       Container container = ((JInternalFrame)paramComponent).getTopLevelAncestor();
/* 130 */       Cursor cursor = Cursor.getPredefinedCursor(0);
/* 131 */       if (container instanceof JFrame) {
/* 133 */         ((JFrame)container).getGlassPane().setCursor(cursor);
/* 134 */         ((JFrame)container).getGlassPane().setVisible(false);
/* 136 */       } else if (container instanceof JWindow) {
/* 138 */         ((JWindow)container).getGlassPane().setCursor(cursor);
/* 139 */         ((JWindow)container).getGlassPane().setVisible(false);
/* 141 */       } else if (container instanceof JDialog) {
/* 143 */         ((JDialog)container).getGlassPane().setCursor(cursor);
/* 144 */         ((JDialog)container).getGlassPane().setVisible(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void hide() {
/* 163 */     if (this.contents instanceof BasicComboPopup && SyntheticaLookAndFeel.getBoolean("Synthetica.workaround.8173744.enabled", null, false))
/*     */       try {
/* 167 */         Field field = BasicComboPopup.class.getDeclaredField("comboBox");
/* 168 */         field.setAccessible(true);
/* 169 */         final JComboBox combo = (JComboBox)field.get(this.contents);
/* 170 */         String str = "Synthetica.comboBox.popupWorkaround";
/* 171 */         if (isBugPosition(jComboBox)) {
/* 173 */           long l1 = System.currentTimeMillis();
/* 174 */           long l2 = l1 - ((Long)SyntheticaLookAndFeel.<Long>getClientProperty("Synthetica.comboBox.popupWorkaround", jComboBox, Long.valueOf(l1))).longValue();
/* 175 */           if (l2 < 100L) {
/* 177 */             if (this.heavyWeightContainer instanceof Window)
/* 178 */               this.popup.hide(); 
/* 196 */             SwingUtilities.invokeLater(new Runnable() {
/*     */                   public void run() {
/* 202 */                     combo.setPopupVisible(true);
/* 203 */                     combo.putClientProperty("Synthetica.comboBox.popupWorkaround", Long.valueOf(System.currentTimeMillis()));
/*     */                   }
/*     */                 });
/*     */             return;
/*     */           } 
/*     */         } 
/* 209 */         jComboBox.putClientProperty("Synthetica.comboBox.popupWorkaround", null);
/* 211 */       } catch (Exception exception) {
/* 213 */         exception.printStackTrace();
/*     */       }  
/* 217 */     if (this.heavyWeightContainer instanceof Window && SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.fade-out.enabled", this.contents)) {
/* 219 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.fade-out.delay", this.contents, 25);
/* 220 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.fade-out.duration", this.contents, 150);
/* 221 */       WindowFader windowFader = new WindowFader((Window)this.heavyWeightContainer, this.popup, i, j, false, true);
/* 222 */       windowFader.start();
/* 224 */     } else if (this.popup != null) {
/* 225 */       this.popup.hide();
/*     */     } 
/* 227 */     Container container = (this.contents == null) ? null : this.contents.getParent();
/* 228 */     if (container instanceof JComponent)
/* 229 */       ((JComponent)container).putClientProperty("POPUP_BACKGROUND", null); 
/* 231 */     if (this.heavyWeightContainer != null) {
/* 233 */       this.heavyWeightContainer = null;
/* 235 */       if (JavaVersion.JAVA5)
/* 237 */         while (container != null) {
/* 239 */           if (container instanceof JFrame)
/* 240 */             ((JFrame)container).update(container.getGraphics()); 
/* 241 */           container = container.getParent();
/*     */         }  
/*     */     } 
/* 245 */     this.contents = null;
/* 246 */     this.popup = null;
/*     */   }
/*     */   
/*     */   private boolean isBugPosition(JComponent paramJComponent) {
/* 251 */     PointerInfo pointerInfo = MouseInfo.getPointerInfo();
/* 252 */     Point point = (Point)pointerInfo.getLocation().clone();
/* 253 */     SwingUtilities.convertPointFromScreen(point, paramJComponent);
/* 254 */     if (point.x == paramJComponent.getWidth() - 1 || point.y == paramJComponent.getHeight() - 1)
/* 255 */       return true; 
/* 256 */     paramJComponent = (JComponent)SyntheticaLookAndFeel.findComponent("ComboBox.arrowButton", paramJComponent);
/* 257 */     if (paramJComponent == null)
/* 258 */       return false; 
/* 259 */     point = pointerInfo.getLocation();
/* 260 */     SwingUtilities.convertPointFromScreen(point, paramJComponent);
/* 261 */     Rectangle rectangle = new Rectangle(0, 0, paramJComponent.getWidth(), paramJComponent.getHeight());
/* 262 */     if (rectangle.contains(point) && (point.x == rectangle.width - 1 || point.y == rectangle.height - 1))
/* 263 */       return true; 
/* 264 */     return false;
/*     */   }
/*     */   
/*     */   public Popup getDelegate() {
/* 273 */     return this.popup;
/*     */   }
/*     */   
/*     */   public Component getContents() {
/* 278 */     return this.contents;
/*     */   }
/*     */   
/*     */   public void show() {
/* 291 */     final boolean blurEnabled = (this.contents instanceof javax.swing.JPopupMenu && SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.blur.enabled", this.contents)) ? true : false;
/* 292 */     if (bool && this.heavyWeightContainer == null)
/* 293 */       this.heavyWeightContainer = this.contents.getParent(); 
/* 295 */     if (this.heavyWeightContainer == null) {
/* 297 */       showPopup(this.popup);
/*     */       return;
/*     */     } 
/* 301 */     if (showPopupMenuLater()) {
/* 303 */       SwingUtilities.invokeLater(new Runnable() {
/*     */             public void run() {
/* 307 */               Popup.this.showPopup(blurEnabled);
/*     */             }
/*     */           });
/*     */     } else {
/* 312 */       showPopup(bool);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void showPopup(boolean paramBoolean) {
/* 318 */     if (this.heavyWeightContainer == null)
/*     */       return; 
/* 322 */     if (JavaVersion.JAVA7U8_OR_ABOVE && OS.getCurrentOS() == OS.Mac && this.contents instanceof javax.swing.JToolTip)
/* 323 */       SyntheticaLookAndFeel.setChildrenOpaque(this.heavyWeightContainer, false); 
/* 326 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.popupRobot.enabled", this.contents.getParent(), true);
/* 327 */     if (bool && isSnapshotRequired((this.heavyWeightContainer instanceof Window) ? (Window)this.heavyWeightContainer : null, paramBoolean))
/* 329 */       if (showPopupLater(this.heavyWeightContainer, paramBoolean)) {
/* 331 */         SwingUtilities.invokeLater(new Runnable() {
/*     */               public void run() {
/* 336 */                 if (Popup.this.contents != null) {
/* 338 */                   Container container = Popup.this.contents.getParent();
/* 339 */                   if (container instanceof JComponent) {
/* 341 */                     ((JComponent)container).putClientProperty("POPUP_BACKGROUND", Popup.this.snapshot());
/* 342 */                     ((JComponent)container).putClientProperty("POPUP_LIGHTWEIGHT", Boolean.valueOf(Popup.this.lightWeight));
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } else {
/* 350 */         ((JComponent)this.contents.getParent()).putClientProperty("POPUP_BACKGROUND", snapshot());
/* 351 */         ((JComponent)this.contents.getParent()).putClientProperty("POPUP_LIGHTWEIGHT", Boolean.valueOf(this.lightWeight));
/*     */       }  
/* 355 */     if (this.heavyWeightContainer instanceof Window && SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.fade-in.enabled", this.contents)) {
/* 357 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.fade-in.delay", this.contents, 25);
/* 358 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.fade-in.duration", this.contents, 200);
/* 359 */       WindowFader windowFader = new WindowFader((Window)this.heavyWeightContainer, null, i, j, true, false);
/* 360 */       windowFader.start();
/*     */     } 
/* 363 */     if (showPopupLater(this.heavyWeightContainer, paramBoolean)) {
/* 365 */       SwingUtilities.invokeLater(new Runnable() {
/*     */             public void run() {
/* 370 */               Popup.this.showPopup(Popup.this.popup);
/*     */             }
/*     */           });
/*     */     } else {
/* 375 */       showPopup(this.popup);
/*     */     } 
/* 377 */     if (this.heavyWeightContainer instanceof Window && !isWindowOpacityEnabled((Window)this.heavyWeightContainer) && !paramBoolean)
/* 380 */       if (OS.getCurrentOS() == OS.Windows && JavaVersion.JAVA7_OR_ABOVE && !showPopupMenuLater()) {
/* 382 */         SwingUtilities.invokeLater(new Runnable() {
/*     */               public void run() {
/* 387 */                 SyntheticaLookAndFeel.setWindowOpaque((Window)Popup.this.heavyWeightContainer, false);
/*     */               }
/*     */             });
/*     */       } else {
/* 392 */         SyntheticaLookAndFeel.setWindowOpaque((Window)this.heavyWeightContainer, false);
/*     */       }  
/*     */   }
/*     */   
/*     */   private void showPopup(Popup paramPopup) {
/* 398 */     if (paramPopup == null)
/*     */       return; 
/* 401 */     Container container1 = null;
/* 402 */     if (this.owner != null)
/* 403 */       container1 = (this.owner instanceof Container) ? (Container)this.owner : this.owner.getParent(); 
/* 405 */     for (Container container2 = container1; container2 != null; container2 = container2.getParent()) {
/* 407 */       if (container2 instanceof JRootPane) {
/* 409 */         if (!(container2.getParent() instanceof JInternalFrame))
/* 411 */           container1 = ((JRootPane)container2).getLayeredPane(); 
/* 413 */       } else if (container2 instanceof Window) {
/* 415 */         if (container1 == null)
/* 416 */           container1 = container2; 
/*     */         break;
/*     */       } 
/*     */     } 
/* 420 */     if (container1 != null && SwingUtilities.getWindowAncestor(container1) != null)
/* 421 */       paramPopup.show(); 
/*     */   }
/*     */   
/*     */   private boolean showPopupLater(Container paramContainer, boolean paramBoolean) {
/* 426 */     return (paramContainer instanceof Window && isSnapshotRequired((Window)this.heavyWeightContainer, paramBoolean) && showPopupMenuLater());
/*     */   }
/*     */   
/*     */   private boolean isSnapshotRequired(Window paramWindow, boolean paramBoolean) {
/* 431 */     return !((OS.getCurrentOS() == OS.Mac || (!isWindowOpacityEnabled(paramWindow) && !paramBoolean)) && (
/* 432 */       OS.getCurrentOS() != OS.Mac || !paramBoolean));
/*     */   }
/*     */   
/*     */   private boolean isWindowOpacityEnabled(Window paramWindow) {
/* 437 */     boolean bool = SyntheticaLookAndFeel.isWindowOpacityEnabled(paramWindow);
/* 438 */     if (!bool)
/* 439 */       return false; 
/* 440 */     return isPopupMenuWindowOpaque();
/*     */   }
/*     */   
/*     */   private boolean isPopupMenuWindowOpaque() {
/* 445 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.window.opaque", this.contents, true);
/*     */   }
/*     */   
/*     */   private boolean showPopupMenuLater() {
/* 450 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.showLater", this.contents, true);
/*     */   }
/*     */   
/*     */   private BufferedImage snapshot() {
/* 458 */     BufferedImage bufferedImage = null;
/*     */     try {
/* 461 */       Dimension dimension = this.heavyWeightContainer.getPreferredSize();
/* 462 */       if (dimension.width > 0 && dimension.height > 0) {
/* 464 */         Rectangle rectangle = new Rectangle(this.x, this.y, dimension.width, dimension.height);
/* 465 */         bufferedImage = createScreenCapture(rectangle);
/*     */       } 
/* 468 */     } catch (Exception exception) {
/* 470 */       exception.printStackTrace();
/*     */     } 
/* 472 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   private BufferedImage createScreenCapture(Rectangle paramRectangle) throws AWTException {
/* 477 */     return (new Robot()).createScreenCapture(paramRectangle);
/*     */   }
/*     */   
/*     */   private static class WindowFader extends Timer {
/* 504 */     private static ActionListener listener = new ActionListener() {
/*     */         public void actionPerformed(ActionEvent param2ActionEvent) {
/* 508 */           Popup.WindowFader windowFader = (Popup.WindowFader)param2ActionEvent.getSource();
/* 509 */           float f = windowFader.counter / windowFader.repeats;
/* 510 */           Popup.WindowFader.setWindowOpacity(windowFader.window, windowFader.fadein ? f : (1.0F - f));
/* 511 */           if (windowFader.counter == windowFader.repeats) {
/* 513 */             windowFader.counter = 0;
/* 514 */             windowFader.stop();
/* 515 */             if (windowFader.hidePopup) {
/* 517 */               if (windowFader.popup != null)
/* 518 */                 windowFader.popup.hide(); 
/* 520 */               Popup.WindowFader.setWindowOpacity(windowFader.window, 1.0F);
/*     */             } 
/* 522 */             windowFader.popup = null;
/* 523 */             windowFader.window = null;
/*     */           } else {
/* 526 */             windowFader.counter = windowFader.counter + 1;
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/*     */     private Window window;
/*     */     
/*     */     private Popup popup;
/*     */     
/*     */     private boolean fadein;
/*     */     
/*     */     private boolean hidePopup;
/*     */     
/*     */     private float repeats;
/*     */     
/*     */     private int counter;
/*     */     
/*     */     public WindowFader(Window param1Window, Popup param1Popup, int param1Int1, int param1Int2, boolean param1Boolean1, boolean param1Boolean2) {
/* 539 */       super(0, listener);
/* 540 */       this.window = param1Window;
/* 541 */       this.popup = param1Popup;
/* 542 */       setDelay(param1Int1);
/* 543 */       this.repeats = (param1Int2 / param1Int1);
/* 544 */       this.fadein = param1Boolean1;
/* 545 */       this.hidePopup = param1Boolean2;
/* 546 */       setWindowOpacity(param1Window, param1Boolean1 ? 0.01F : 1.0F);
/*     */     }
/*     */     
/*     */     private static void setWindowOpacity(Window param1Window, float param1Float) {
/* 552 */       if (JavaVersion.JAVA6U10_OR_ABOVE && isTranslucencySupported())
/* 555 */         if (JavaVersion.JAVA6U10_OR_ABOVE && !JavaVersion.JAVA7_OR_ABOVE) {
/*     */           try {
/* 559 */             Class<?> clazz = Class.forName("com.sun.awt.AWTUtilities");
/* 560 */             Method method = clazz.getMethod("setWindowOpacity", new Class[] { Window.class, float.class });
/* 561 */             method.invoke(null, new Object[] { param1Window, Float.valueOf(param1Float) });
/* 563 */           } catch (Exception exception) {
/* 565 */             exception.printStackTrace();
/*     */           } 
/*     */         } else {
/*     */           try {
/* 572 */             Class<?> clazz = Class.forName("java.awt.Window");
/* 573 */             Method method = clazz.getMethod("setOpacity", new Class[] { float.class });
/* 574 */             method.invoke(param1Window, new Object[] { Float.valueOf(param1Float) });
/* 576 */           } catch (Exception exception) {
/* 578 */             exception.printStackTrace();
/*     */           } 
/*     */         }  
/*     */     }
/*     */     
/*     */     private static boolean isTranslucencySupported() {
/* 586 */       boolean bool = false;
/* 587 */       if (JavaVersion.JAVA7_OR_ABOVE) {
/*     */         try {
/* 591 */           Class<?> clazz1 = Class.forName("java.awt.GraphicsDevice");
/* 592 */           Class<?> clazz2 = Class.forName("java.awt.GraphicsDevice$WindowTranslucency");
/* 593 */           Method method = clazz1.getMethod("isWindowTranslucencySupported", new Class[] { clazz2 });
/* 594 */           GraphicsDevice graphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
/* 595 */           bool = ((Boolean)method.invoke(graphicsDevice, new Object[] { Enum.valueOf(clazz2, "TRANSLUCENT") })).booleanValue();
/* 597 */         } catch (Exception exception) {
/* 599 */           exception.printStackTrace();
/*     */         } 
/*     */       } else {
/* 603 */         AWTUtilities.isTranslucencySupported(AWTUtilities.Translucency.TRANSLUCENT);
/*     */       } 
/* 604 */       return bool;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\Popup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */