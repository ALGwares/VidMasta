/*    */ package de.javasoft.plaf.synthetica.filechooser;
/*    */ 
/*    */ import java.text.Collator;
/*    */ import java.text.ParseException;
/*    */ import java.text.RuleBasedCollator;
/*    */ import java.util.Locale;
/*    */ 
/*    */ class GermanCollator extends RuleBasedCollator {
/*    */   private static RuleBasedCollator instance;
/*    */   
/*    */   private static final String rulesDIN5007_2 = "& ae , ä & AE , Ä& oe , ö & OE , Ö& ue , ü & UE , ü";
/*    */   
/*    */   private GermanCollator() throws ParseException {
/* 30 */     super(String.valueOf(((RuleBasedCollator)Collator.getInstance(Locale.GERMAN)).getRules()) + "& ae , ä & AE , Ä& oe , ö & OE , Ö& ue , ü & UE , ü");
/*    */   }
/*    */   
/*    */   public static RuleBasedCollator getInstance() {
/* 35 */     if (instance == null)
/*    */       try {
/* 39 */         instance = new GermanCollator();
/* 41 */       } catch (ParseException parseException) {
/* 43 */         throw new RuntimeException(parseException);
/*    */       }  
/* 46 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\filechooser\GermanCollator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */