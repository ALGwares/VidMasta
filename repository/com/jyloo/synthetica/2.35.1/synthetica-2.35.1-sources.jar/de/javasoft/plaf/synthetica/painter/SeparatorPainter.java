/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Window;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.DimensionUIResource;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class SeparatorPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.SeparatorPainter";
/*     */   
/*  49 */   private static HashMap<String, Image> imgCache = new HashMap<String, Image>();
/*     */   
/*     */   public static SeparatorPainter getInstance() {
/*  63 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static SeparatorPainter getInstance(SynthContext paramSynthContext) {
/*  72 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, SeparatorPainter.class, "Synthetica.SeparatorPainter"));
/*  73 */     if (syntheticaComponentPainter == null)
/*  74 */       syntheticaComponentPainter = getInstance(paramSynthContext, SeparatorPainter.class, "Synthetica.SeparatorPainter"); 
/*  75 */     return (SeparatorPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintSeparatorBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSeparatorBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  86 */     JComponent jComponent = paramSynthContext.getComponent();
/*  87 */     if (jComponent.getParent() instanceof JPopupMenu || jComponent instanceof JPopupMenu.Separator) {
/*  89 */       JPopupMenu jPopupMenu = (JPopupMenu)SwingUtilities.getAncestorOfClass(JPopupMenu.class, jComponent);
/*  90 */       String str = "Synthetica.popupMenuSeparator";
/*  91 */       str = SyntheticaLookAndFeel.getString(str, jPopupMenu);
/*  94 */       boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenu.iconSeparator.clip", jPopupMenu, true);
/*  95 */       if (jPopupMenu != null && bool && (SyntheticaLookAndFeel.preservePopupIconSpace(jPopupMenu) || SyntheticaLookAndFeel.popupHasCheckRadio(jPopupMenu)) && 
/*  96 */         !SyntheticaLookAndFeel.popupHasCheckRadioWithIcon(jPopupMenu)) {
/*  98 */         Insets insets = jPopupMenu.getInsets();
/*  99 */         boolean bool3 = jPopupMenu.getComponentOrientation().isLeftToRight();
/* 100 */         int i = SyntheticaLookAndFeel.getInt("Synthetica.popupMenuSeparator.iconSeparatorGap", jPopupMenu);
/* 101 */         int j = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparator.gap", jPopupMenu, 24);
/* 103 */         Integer integer = (Integer)jPopupMenu.getClientProperty("Synthetica.menuItem.maxIconWidth");
/* 104 */         if (integer != null && integer.intValue() > 16)
/* 105 */           j += integer.intValue() - 16; 
/* 106 */         int k = SyntheticaLookAndFeel.getInt("Synthetica.popupMenu.iconSeparator.width", jPopupMenu, 1);
/* 107 */         int m = j + k + i - insets.left;
/* 108 */         paramInt1 += bool3 ? m : 0;
/* 109 */         paramInt3 -= m;
/*     */       } 
/* 112 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenuSeparator.insets", jPopupMenu, false);
/* 113 */       Insets insets2 = insets1;
/* 114 */       boolean bool1 = false;
/* 115 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenuSeparator.horizontalTiled", jPopupMenu))
/* 116 */         bool1 = true; 
/* 117 */       boolean bool2 = false;
/* 118 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.popupMenuSeparator.verticalTiled", jPopupMenu))
/* 119 */         bool2 = true; 
/* 120 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, bool1, bool2);
/* 121 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintSeparatorForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 129 */     String str = "Synthetica.separator";
/* 130 */     JComponent jComponent = paramSynthContext.getComponent();
/* 133 */     Insets insets1 = paramSynthContext.getStyle().getInsets(paramSynthContext, null);
/* 135 */     Insets insets2 = jComponent.getInsets();
/* 137 */     paramInt3 -= insets2.left + insets2.right - insets1.left - insets1.right;
/* 138 */     paramInt4 -= insets2.top + insets2.bottom - insets1.top - insets1.bottom;
/* 139 */     paramInt1 += insets2.left - insets1.left;
/* 140 */     paramInt2 += insets2.top - insets1.top;
/* 141 */     boolean bool = jComponent instanceof JToolBar.Separator;
/* 144 */     if (bool) {
/* 146 */       str = String.valueOf(str) + ".toolBar";
/* 148 */     } else if (jComponent.getParent() instanceof JComponent && ((
/* 149 */       (JComponent)jComponent.getParent()).getUIClassID().equals("StatusBarUI") || "StatusBar".equals(SyntheticaLookAndFeel.getStyleName(jComponent.getParent())))) {
/* 151 */       str = String.valueOf(str) + ".statusBar";
/*     */     } 
/* 153 */     str = String.valueOf(str) + ".image";
/* 155 */     if (paramInt5 == 0) {
/* 156 */       str = String.valueOf(str) + ".x";
/*     */     } else {
/* 158 */       str = String.valueOf(str) + ".y";
/*     */     } 
/* 160 */     if (bool) {
/* 162 */       Container container = jComponent.getRootPane().getParent();
/* 163 */       boolean bool4 = true;
/* 164 */       if (container instanceof Window) {
/* 165 */         bool4 = ((Window)container).isActive();
/* 166 */       } else if (container instanceof JInternalFrame) {
/* 167 */         bool4 = ((JInternalFrame)container).isSelected();
/*     */       } 
/* 168 */       if (!bool4 && SyntheticaLookAndFeel.get(String.valueOf(str) + ".inactive", jComponent) != null)
/* 169 */         str = String.valueOf(str) + ".inactive"; 
/*     */     } 
/* 172 */     UIKey uIKey = new UIKey(str, new SyntheticaState(0), "");
/* 173 */     Insets insets3 = (Insets)uIKey.findProperty(paramSynthContext, "insets", true, 2);
/* 174 */     Insets insets4 = insets3;
/* 175 */     str = SyntheticaLookAndFeel.getString(str, jComponent);
/* 177 */     if (bool) {
/* 179 */       if (str == null)
/*     */         return; 
/* 180 */       Image image = imgCache.get(str);
/* 181 */       if (image == null) {
/* 183 */         image = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(str))).getImage();
/* 184 */         imgCache.put(str, image);
/*     */       } 
/* 186 */       adjustToolBarSeparatorSize((JToolBar.Separator)jComponent, image.getWidth(null), image.getHeight(null));
/*     */     } 
/* 189 */     boolean bool1 = bool ? false : ((Integer)paramSynthContext.getStyle().get(paramSynthContext, "Separator.thickness")).intValue();
/* 190 */     boolean bool2 = (paramInt5 == 0 || bool) ? paramInt3 : bool1;
/* 191 */     boolean bool3 = (paramInt5 == 1 || bool) ? paramInt4 : bool1;
/* 193 */     if (str == null) {
/* 195 */       paramGraphics.setColor(paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND));
/* 196 */       paramGraphics.fillRect(paramInt1, paramInt2, bool2, bool3);
/*     */     } else {
/* 202 */       ImagePainter imagePainter = new ImagePainter(jComponent, 1, 50, 0, 0, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets3, insets4, 0, 0);
/* 203 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void adjustToolBarSeparatorSize(JToolBar.Separator paramSeparator, int paramInt1, int paramInt2) {
/* 211 */     if (SyntheticaLookAndFeel.getToolbarSeparatorDimension() == null) {
/* 214 */       int i = 0;
/* 215 */       int j = 0;
/*     */       byte b;
/*     */       int k;
/*     */       Component[] arrayOfComponent;
/* 216 */       for (k = (arrayOfComponent = paramSeparator.getParent().getComponents()).length, b = 0; b < k; ) {
/* 216 */         Component component = arrayOfComponent[b];
/* 218 */         if (!(component instanceof JToolBar.Separator)) {
/* 220 */           if ((component.getMinimumSize()).width > i)
/* 221 */             i = (component.getMinimumSize()).width; 
/* 222 */           if ((component.getMinimumSize()).height > j)
/* 223 */             j = (component.getMinimumSize()).height; 
/*     */         } 
/*     */         b++;
/*     */       } 
/* 225 */       DimensionUIResource dimensionUIResource = null;
/* 226 */       if (paramSeparator.getOrientation() == 1) {
/* 227 */         dimensionUIResource = new DimensionUIResource(paramInt1, j);
/*     */       } else {
/* 229 */         dimensionUIResource = new DimensionUIResource(i, paramInt2);
/*     */       } 
/* 230 */       if (!dimensionUIResource.equals(paramSeparator.getSize())) {
/* 232 */         paramSeparator.setSeparatorSize(dimensionUIResource);
/* 233 */         paramSeparator.revalidate();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SeparatorPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */