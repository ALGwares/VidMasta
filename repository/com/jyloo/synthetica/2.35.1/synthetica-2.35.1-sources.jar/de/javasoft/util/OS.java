/*    */ package de.javasoft.util;
/*    */ 
/*    */ import java.security.AccessController;
/*    */ import java.security.PrivilegedAction;
/*    */ 
/*    */ public enum OS {
/* 23 */   Windows, Mac, Linux, FreeBSD, Solaris, Unknown;
/*    */   
/*    */   private static final String OS_NAME;
/*    */   
/*    */   private static final String OS_VERSION;
/*    */   
/*    */   static {
/* 30 */     OS_NAME = AccessController.<String>doPrivileged(new PrivilegedAction<String>() {
/*    */           public String run() {
/* 33 */             return System.getProperty("os.name");
/*    */           }
/*    */         });
/* 37 */     OS_VERSION = AccessController.<String>doPrivileged(new PrivilegedAction<String>() {
/*    */           public String run() {
/* 40 */             return System.getProperty("os.version");
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   public static OS getCurrentOS() {
/* 46 */     if (OS_NAME.startsWith("Windows"))
/* 47 */       return Windows; 
/* 48 */     if (OS_NAME.startsWith("Mac"))
/* 49 */       return Mac; 
/* 50 */     if (OS_NAME.startsWith("Linux") || OS_NAME.toUpperCase().startsWith("LINUX"))
/* 51 */       return Linux; 
/* 52 */     if (OS_NAME.startsWith("FreeBSD") || OS_NAME.toUpperCase().startsWith("FREEBSD"))
/* 53 */       return FreeBSD; 
/* 54 */     if (OS_NAME.startsWith("Solaris"))
/* 55 */       return Solaris; 
/* 56 */     return Unknown;
/*    */   }
/*    */   
/*    */   public static String getName() {
/* 61 */     return OS_NAME;
/*    */   }
/*    */   
/*    */   public static String getVersion() {
/* 66 */     return OS_VERSION;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasof\\util\OS.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */