/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ToolTipStyle extends StyleWrapper {
/* 26 */   private static ToolTipStyle instance = new ToolTipStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 35 */     paramJComponent.setOpaque(false);
/* 37 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 39 */       instance.setStyle(paramSynthStyle);
/* 40 */       return instance;
/*    */     } 
/* 42 */     ToolTipStyle toolTipStyle = new ToolTipStyle();
/* 43 */     toolTipStyle.setStyle(paramSynthStyle);
/* 44 */     return toolTipStyle;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ToolTipStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */