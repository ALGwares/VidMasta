/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.GraphicsUtils;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Container;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ public class CheckBoxPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.CheckBoxPainter";
/*     */   
/*     */   private static boolean cellRendererSelectionBackgroundEnabled;
/*     */   
/*     */   private static SynthStyle tableStyle;
/*     */   
/*     */   private static int tableHash;
/*     */   
/*     */   private static SynthStyle listStyle;
/*     */   
/*     */   private static int listHash;
/*     */   
/*     */   public static CheckBoxPainter getInstance() {
/*  73 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static CheckBoxPainter getInstance(SynthContext paramSynthContext) {
/*  82 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, CheckBoxPainter.class, "Synthetica.CheckBoxPainter"));
/*  83 */     if (syntheticaComponentPainter == null)
/*  84 */       syntheticaComponentPainter = getInstance(paramSynthContext, CheckBoxPainter.class, "Synthetica.CheckBoxPainter"); 
/*  85 */     return (CheckBoxPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public static void reinitialize() {
/*  90 */     cellRendererSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.selectionBackground.enabled", null, false);
/*  91 */     tableHash = 0;
/*     */   }
/*     */   
/*     */   public void paintCheckBoxBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  99 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/* 100 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/* 101 */     Container container1 = abstractButton.getParent();
/* 102 */     Container container2 = (container1 == null) ? null : container1.getParent();
/* 103 */     String str = abstractButton.getName();
/* 105 */     if (cellRendererSelectionBackgroundEnabled && "Table.cellRenderer".equals(str) && container2 instanceof JTable) {
/* 107 */       JTable jTable = (JTable)container2;
/* 108 */       int i = getHashCode(jTable);
/* 109 */       if (i != tableHash) {
/* 111 */         tableHash = i;
/* 112 */         tableStyle = SynthLookAndFeel.getStyle(jTable, Region.TABLE);
/*     */       } 
/* 114 */       SynthStyle synthStyle = tableStyle;
/* 115 */       SynthContext synthContext = new SynthContext(jTable, Region.TABLE, synthStyle, 512);
/* 116 */       if (abstractButton.getBackground().equals(synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND)))
/* 117 */         ((GraphicsUtils)synthStyle.getGraphicsUtils(synthContext)).paintTableCellRendererSelectionBackground(jTable, abstractButton, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 120 */     } else if (cellRendererSelectionBackgroundEnabled && (isListCellRenderer(str) || JAVA5) && container2 instanceof JList) {
/* 122 */       JList jList = (JList)container2;
/* 123 */       int i = getHashCode(jList);
/* 124 */       if (i != listHash) {
/* 126 */         listHash = i;
/* 127 */         listStyle = SynthLookAndFeel.getStyle(jList, Region.LIST);
/*     */       } 
/* 129 */       SynthStyle synthStyle = listStyle;
/* 130 */       SynthContext synthContext = new SynthContext(jList, Region.LIST, synthStyle, 512);
/* 131 */       if (abstractButton.getBackground().equals(synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND)))
/* 132 */         ((GraphicsUtils)synthStyle.getGraphicsUtils(synthContext)).paintListCellRendererSelectionBackground(jList, abstractButton, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */     } 
/* 135 */     if (SyntheticaLookAndFeel.get("Synthetica.checkBox.image", abstractButton) != null) {
/* 137 */       UIKey uIKey = new UIKey("checkBox", syntheticaPainterState);
/* 138 */       Insets insets1 = new Insets(0, 0, 0, 0);
/* 139 */       Insets insets2 = insets1;
/* 140 */       Insets insets3 = abstractButton.getInsets();
/* 142 */       String str1 = SyntheticaLookAndFeel.getString(uIKey.get("image"), abstractButton);
/* 144 */       if (abstractButton.hasFocus() && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused.image", abstractButton) != null)
/* 145 */         str1 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused.image", abstractButton); 
/* 147 */       int i = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), abstractButton, 1);
/* 148 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), abstractButton, 50);
/* 149 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), abstractButton, 2);
/* 150 */       if (syntheticaPainterState.isSet(SyntheticaState.State.HOVER) || syntheticaPainterState.isSet(SyntheticaState.State.PRESSED))
/* 151 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), abstractButton, 1); 
/* 153 */       Rectangle rectangle1 = new Rectangle(paramInt1 + insets3.left, paramInt2 + insets3.top, paramInt3 - insets3.left - insets3.right, paramInt4 - insets3.top - insets3.bottom);
/* 154 */       Rectangle rectangle2 = new Rectangle();
/* 155 */       Rectangle rectangle3 = new Rectangle();
/* 157 */       Icon icon = paramSynthContext.getStyle().getIcon(paramSynthContext, "CheckBox.icon");
/* 158 */       paramSynthContext.getStyle().getGraphicsUtils(paramSynthContext).layoutText(paramSynthContext, paramGraphics.getFontMetrics(), abstractButton.getText(), icon, abstractButton.getHorizontalAlignment(), abstractButton.getVerticalAlignment(), abstractButton.getHorizontalTextPosition(), abstractButton.getVerticalTextPosition(), 
/* 159 */           rectangle1, rectangle3, rectangle2, abstractButton.getIconTextGap());
/* 161 */       boolean bool = (abstractButton.getIcon() != null) ? true : false;
/* 162 */       if (!bool) {
/* 164 */         ImagePainter imagePainter = new ImagePainter(abstractButton, i, j, k, syntheticaPainterState.getState(), paramGraphics, rectangle3.x, rectangle3.y, rectangle3.width, rectangle3.height, str1, insets1, insets2, 0, 0);
/* 165 */         if (!syntheticaPainterState.isSet(SyntheticaState.State.PRESSED) || abstractButton.getPressedIcon() == null)
/* 168 */           imagePainter.drawCenter(); 
/*     */       } 
/* 172 */       if (syntheticaPainterState.isSet(SyntheticaState.State.FOCUSED) && abstractButton.isFocusPainted() && SyntheticaLookAndFeel.get("Synthetica.checkBox.focus", abstractButton) != null) {
/* 174 */         String str2 = SyntheticaLookAndFeel.getStyleName(abstractButton);
/* 175 */         String str3 = "focus.checkBox";
/* 176 */         i = SyntheticaLookAndFeel.getInt(str3, "animation.cycles", str2, true, -1);
/* 177 */         j = SyntheticaLookAndFeel.getInt(str3, "animation.delay", str2, true, 60);
/* 178 */         k = SyntheticaLookAndFeel.getInt(str3, "animation.type", str2, true, 3);
/* 179 */         str1 = SyntheticaLookAndFeel.getString("Synthetica.checkBox.focus", abstractButton);
/* 180 */         ImagePainter imagePainter = new ImagePainter(abstractButton, "", i, j, k, syntheticaPainterState.getState(), paramGraphics, rectangle3.x, rectangle3.y, rectangle3.width, rectangle3.height, str1, insets1, insets2, 0, 0);
/* 181 */         imagePainter.drawCenter();
/*     */       } 
/*     */     } 
/* 185 */     if (syntheticaPainterState.isSet(SyntheticaState.State.FOCUSED) && abstractButton.isFocusPainted()) {
/* 188 */       Icon icon = (abstractButton.getIcon() == null) ? paramSynthContext.getStyle().getIcon(paramSynthContext, "CheckBox.icon") : abstractButton.getIcon();
/* 189 */       String str1 = abstractButton.getText();
/* 190 */       byte b = (str1 == null || str1.length() == 0) ? 0 : abstractButton.getIconTextGap();
/* 191 */       int i = (abstractButton.getInsets()).left + (abstractButton.getInsets()).right + b + ((icon == null) ? 0 : icon.getIconWidth());
/* 192 */       boolean bool = (abstractButton.getClientProperty("html") != null) ? true : false;
/* 193 */       if (!bool) {
/* 195 */         FontMetrics fontMetrics = abstractButton.getFontMetrics(abstractButton.getFont());
/* 196 */         if (str1 != null)
/* 197 */           i += fontMetrics.stringWidth(str1); 
/*     */       } else {
/* 200 */         i = (int)(i + ((View)abstractButton.getClientProperty("html")).getPreferredSpan(0));
/*     */       } 
/* 201 */       FocusPainter.paintFocus("focus.checkBox", paramSynthContext, paramGraphics, paramInt1, paramInt2, i, paramInt4);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isListCellRenderer(String paramString) {
/* 207 */     return (paramString == null) ? false : paramString.startsWith("List.cellRenderer");
/*     */   }
/*     */   
/*     */   public void paintCheckBoxBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 215 */     JCheckBox jCheckBox = (JCheckBox)paramSynthContext.getComponent();
/* 216 */     if (jCheckBox.isBorderPainted()) {
/* 218 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.checkBox.border.insets", jCheckBox);
/* 219 */       Insets insets2 = insets1;
/* 220 */       String str = SyntheticaLookAndFeel.getString("Synthetica.checkBox.border", jCheckBox);
/* 221 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 222 */       imagePainter.drawBorder();
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getHashCode(JComponent paramJComponent) {
/* 228 */     int i = paramJComponent.hashCode();
/* 229 */     String str = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/* 230 */     if (str == null)
/* 231 */       return i; 
/* 232 */     return 31 * i + str.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\CheckBoxPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */