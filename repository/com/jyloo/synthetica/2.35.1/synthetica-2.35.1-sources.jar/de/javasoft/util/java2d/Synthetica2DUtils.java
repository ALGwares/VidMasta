/*     */ package de.javasoft.util.java2d;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ConvolveOp;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.Kernel;
/*     */ 
/*     */ public class Synthetica2DUtils {
/*     */   public static BufferedImage createBlurredImage(BufferedImage paramBufferedImage, int paramInt) {
/*  41 */     ConvolveOp convolveOp = createBlurOp(paramInt);
/*  42 */     BufferedImage bufferedImage = convolveOp.createCompatibleDestImage(paramBufferedImage, paramBufferedImage.getColorModel());
/*  43 */     convolveOp.filter(paramBufferedImage, bufferedImage);
/*  44 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public static ConvolveOp createBlurOp(int paramInt) {
/*  57 */     float[] arrayOfFloat = new float[paramInt * paramInt];
/*  58 */     float f = 1.0F / (paramInt * paramInt);
/*  59 */     for (byte b = 0; b < arrayOfFloat.length; b++)
/*  60 */       arrayOfFloat[b] = f; 
/*  61 */     return new ConvolveOp(new Kernel(paramInt, paramInt, arrayOfFloat));
/*     */   }
/*     */   
/*     */   public static BufferedImage createAlphaImage(BufferedImage paramBufferedImage, float paramFloat) {
/*  74 */     BufferedImage bufferedImage = new BufferedImage(paramBufferedImage.getWidth(), paramBufferedImage.getHeight(), 2);
/*  75 */     Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/*  76 */     graphics2D.setComposite(AlphaComposite.getInstance(3, paramFloat));
/*  77 */     graphics2D.drawImage(paramBufferedImage, 0, 0, (ImageObserver)null);
/*  78 */     graphics2D.dispose();
/*  79 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public static BufferedImage createColorizedImage(BufferedImage paramBufferedImage, Color paramColor, float paramFloat) {
/*  93 */     BufferedImage bufferedImage = new BufferedImage(paramBufferedImage.getWidth(), paramBufferedImage.getHeight(), 2);
/*  94 */     colorizeImage(paramBufferedImage, bufferedImage, paramColor, paramFloat);
/*  95 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public static void colorizeImage(BufferedImage paramBufferedImage1, BufferedImage paramBufferedImage2, Color paramColor, float paramFloat) {
/* 109 */     Graphics2D graphics2D = (Graphics2D)paramBufferedImage2.getGraphics();
/* 110 */     graphics2D.drawImage(paramBufferedImage1, 0, 0, (ImageObserver)null);
/* 111 */     graphics2D.setComposite(AlphaComposite.getInstance(10, paramFloat));
/* 112 */     graphics2D.setColor(paramColor);
/* 113 */     graphics2D.fillRect(0, 0, paramBufferedImage2.getWidth(), paramBufferedImage2.getHeight());
/* 114 */     graphics2D.dispose();
/*     */   }
/*     */   
/*     */   public static Image flipHorizontal(Image paramImage) {
/* 125 */     BufferedImage bufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
/* 126 */     Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/* 127 */     graphics2D.scale(-1.0D, 1.0D);
/* 128 */     graphics2D.translate(-paramImage.getWidth(null), 0);
/* 129 */     graphics2D.drawImage(paramImage, 0, 0, (ImageObserver)null);
/* 130 */     graphics2D.dispose();
/* 131 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public static Image flipVertical(Image paramImage) {
/* 142 */     BufferedImage bufferedImage = new BufferedImage(paramImage.getWidth(null), paramImage.getHeight(null), 2);
/* 143 */     Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/* 144 */     graphics2D.scale(1.0D, -1.0D);
/* 145 */     graphics2D.translate(0, -paramImage.getHeight(null));
/* 146 */     graphics2D.drawImage(paramImage, 0, 0, (ImageObserver)null);
/* 147 */     graphics2D.dispose();
/* 148 */     return bufferedImage;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasof\\util\java2d\Synthetica2DUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */