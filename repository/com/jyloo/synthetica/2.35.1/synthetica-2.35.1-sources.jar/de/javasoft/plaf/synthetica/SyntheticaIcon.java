/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import sun.swing.plaf.synth.SynthIcon;
/*    */ 
/*    */ public abstract class SyntheticaIcon extends SynthIcon {
/*    */   public static int getIconWidth(Icon paramIcon, SynthContext paramSynthContext) {
/* 27 */     if (paramIcon == null)
/* 28 */       return 0; 
/* 30 */     if (paramIcon instanceof SynthIcon)
/* 31 */       return ((SynthIcon)paramIcon).getIconWidth(paramSynthContext); 
/* 33 */     return paramIcon.getIconWidth();
/*    */   }
/*    */   
/*    */   public static int getIconHeight(Icon paramIcon, SynthContext paramSynthContext) {
/* 37 */     if (paramIcon == null)
/* 38 */       return 0; 
/* 40 */     if (paramIcon instanceof SynthIcon)
/* 41 */       return ((SynthIcon)paramIcon).getIconHeight(paramSynthContext); 
/* 43 */     return paramIcon.getIconHeight();
/*    */   }
/*    */   
/*    */   public static void paintIcon(Icon paramIcon, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 48 */     if (paramIcon instanceof SynthIcon) {
/* 49 */       ((SynthIcon)paramIcon).paintIcon(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/* 51 */     } else if (paramIcon != null) {
/* 52 */       paramIcon.paintIcon(paramSynthContext.getComponent(), paramGraphics, paramInt1, paramInt2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaIcon.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */