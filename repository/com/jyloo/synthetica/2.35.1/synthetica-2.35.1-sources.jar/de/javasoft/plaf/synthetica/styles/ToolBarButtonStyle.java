/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Font;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.FontUIResource;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ToolBarButtonStyle extends StyleWrapper {
/* 31 */   private static ToolBarButtonStyle instance = new ToolBarButtonStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 39 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 41 */       instance.setStyle(paramSynthStyle);
/* 42 */       return instance;
/*    */     } 
/* 44 */     ToolBarButtonStyle toolBarButtonStyle = new ToolBarButtonStyle();
/* 45 */     toolBarButtonStyle.setStyle(paramSynthStyle);
/* 46 */     return toolBarButtonStyle;
/*    */   }
/*    */   
/*    */   public Font getFont(SynthContext paramSynthContext) {
/* 52 */     Font font = this.synthStyle.getFont(paramSynthContext);
/* 53 */     JComponent jComponent = paramSynthContext.getComponent();
/* 54 */     if (SyntheticaLookAndFeel.get("Synthetica.toolBar.button.font.style", jComponent) != null) {
/* 56 */       int i = 0;
/* 57 */       String str = SyntheticaLookAndFeel.getString("Synthetica.toolBar.button.font.style", jComponent);
/* 58 */       if (str.contains("BOLD"))
/* 59 */         i |= 0x1; 
/* 60 */       if (str.contains("ITALIC"))
/* 61 */         i |= 0x2; 
/* 62 */       float f = SyntheticaLookAndFeel.scaleFontSize(SyntheticaLookAndFeel.getInt("Synthetica.toolBar.button.font.size", jComponent, 0));
/* 63 */       if (f == 0.0F)
/* 64 */         f = font.getSize2D(); 
/* 65 */       font = new FontUIResource(font.deriveFont(i, f));
/* 67 */     } else if (SyntheticaLookAndFeel.get("Synthetica.toolBar.toggleButton.font.style", jComponent) != null) {
/* 69 */       int i = 0;
/* 70 */       String str = SyntheticaLookAndFeel.getString("Synthetica.toolBar.toggleButton.font.style", jComponent);
/* 71 */       if (str.contains("BOLD"))
/* 72 */         i |= 0x1; 
/* 73 */       if (str.contains("ITALIC"))
/* 74 */         i |= 0x2; 
/* 75 */       float f = SyntheticaLookAndFeel.scaleFontSize(SyntheticaLookAndFeel.getInt("Synthetica.toolBar.toggleButton.font.size", jComponent, 0));
/* 76 */       if (f == 0.0F)
/* 77 */         f = font.getSize2D(); 
/* 78 */       font = new FontUIResource(font.deriveFont(i, f));
/*    */     } 
/* 80 */     return font;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ToolBarButtonStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */