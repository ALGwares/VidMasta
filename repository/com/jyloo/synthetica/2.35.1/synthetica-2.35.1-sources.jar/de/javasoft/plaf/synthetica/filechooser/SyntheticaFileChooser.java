/*    */ package de.javasoft.plaf.synthetica.filechooser;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JFileChooser;
/*    */ import javax.swing.filechooser.FileSystemView;
/*    */ 
/*    */ public class SyntheticaFileChooser extends JFileChooser {
/*    */   public Icon getIcon(File paramFile) {
/* 32 */     FileSystemView fileSystemView = FileSystemView.getFileSystemView();
/* 33 */     return fileSystemView.getSystemIcon(paramFile);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\filechooser\SyntheticaFileChooser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */