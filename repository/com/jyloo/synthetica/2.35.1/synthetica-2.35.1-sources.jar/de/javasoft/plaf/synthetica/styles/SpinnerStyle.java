/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class SpinnerStyle extends StyleWrapper {
/* 29 */   private static SpinnerStyle instance = new SpinnerStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 37 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 39 */       instance.setStyle(paramSynthStyle);
/* 40 */       return instance;
/*    */     } 
/* 42 */     SpinnerStyle spinnerStyle = new SpinnerStyle();
/* 43 */     spinnerStyle.setStyle(paramSynthStyle);
/* 44 */     return spinnerStyle;
/*    */   }
/*    */   
/*    */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/* 49 */     paramInsets = this.synthStyle.getInsets(paramSynthContext, paramInsets);
/* 50 */     if (!paramSynthContext.getComponent().getComponentOrientation().isLeftToRight()) {
/* 52 */       int i = paramInsets.left;
/* 53 */       paramInsets.left = paramInsets.right;
/* 54 */       paramInsets.right = i;
/*    */     } 
/* 56 */     return paramInsets;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\SpinnerStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */