/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class EditorPanePainter extends TextComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.EditorPanePainter";
/*    */   
/*    */   public static EditorPanePainter getInstance() {
/* 42 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static EditorPanePainter getInstance(SynthContext paramSynthContext) {
/* 51 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, EditorPanePainter.class, "Synthetica.EditorPanePainter"));
/* 52 */     if (syntheticaComponentPainter == null)
/* 53 */       syntheticaComponentPainter = getInstance(paramSynthContext, EditorPanePainter.class, "Synthetica.EditorPanePainter"); 
/* 54 */     return (EditorPanePainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintEditorPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintEditorPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 66 */     paintBackground("editorPane", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */   
/*    */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 72 */     return Cacheable.ScaleType.NINE_SQUARE;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\EditorPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */