/*      */ package de.javasoft.plaf.synthetica;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.painter.RootPanePainter;
/*      */ import de.javasoft.plaf.synthetica.painter.SyntheticaPainter;
/*      */ import de.javasoft.util.JavaVersion;
/*      */ import de.javasoft.util.OS;
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.AWTException;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.HeadlessException;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.LayoutManager2;
/*      */ import java.awt.MouseInfo;
/*      */ import java.awt.Point;
/*      */ import java.awt.PointerInfo;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Robot;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.AWTEventListener;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Method;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLayeredPane;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.JWindow;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.event.MouseInputListener;
/*      */ import javax.swing.plaf.ComponentUI;
/*      */ import javax.swing.plaf.basic.BasicRootPaneUI;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ 
/*      */ public class SyntheticaRootPaneUI extends BasicRootPaneUI {
/*      */   private Window window;
/*      */   
/*      */   private JRootPane rootPane;
/*      */   
/*      */   private LayoutManager layoutManager;
/*      */   
/*      */   private LayoutManager oldLayoutManager;
/*      */   
/*      */   private AWTEventListener awtMouseListener;
/*      */   
/*      */   private MouseInputListener mouseInputListener;
/*      */   
/*      */   private WindowListener windowListener;
/*      */   
/*      */   private ComponentListener windowShapeResizeListener;
/*      */   
/*      */   private ComponentListener windowMenuBarResizeListener;
/*      */   
/*      */   private ComponentListener rootPaneResizeListener;
/*      */   
/*      */   private MouseEventProcessor mouseEventProcessor;
/*      */   
/*      */   private JComponent titlePane;
/*      */   
/*      */   private Insets resizeInsets;
/*      */   
/*      */   public static final boolean EVAL_COPY = true;
/*      */   
/*      */   public static final int EVAL_HEIGHT = 16;
/*      */   
/*      */   public static final String EVAL_TEXT = "Synthetica - Unregistered Evaluation Copy!";
/*      */   
/*      */   private class MouseInputHandler implements MouseInputListener {
/*      */     private static final int WINDOW_MOVE = 1;
/*      */     
/*      */     private static final int WINDOW_RESIZE = 2;
/*      */     
/*      */     private int windowAction;
/*      */     
/*      */     private int dragXOffset;
/*      */     
/*      */     private int dragYOffset;
/*      */     
/*      */     private Dimension dragDimension;
/*      */     
/*      */     private int resizeType;
/*      */     
/*      */     private int minimumYPos;
/*      */     
/*      */     private int maximumYPos;
/*      */     
/* 1178 */     private boolean liveResize = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.liveResizeEnabled", SyntheticaRootPaneUI.this.window, true);
/*      */     
/* 1179 */     private boolean liveDrag = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.liveDragEnabled", SyntheticaRootPaneUI.this.window, true);
/*      */     
/*      */     private Rectangle resizeBounds;
/*      */     
/*      */     private JWindow dragResizeWindow;
/*      */     
/*      */     private JWindow snapWindow;
/*      */     
/*      */     private SyntheticaRootPaneUI.SnapState tmpSnapState;
/*      */     
/*      */     private int preSnapXOffset;
/*      */     
/*      */     private Point dragStart;
/*      */     
/*      */     private Point dragStartOnScreen;
/*      */     
/*      */     private boolean windowMenuKeyEmulationRunning;
/*      */     
/* 1189 */     private final PrivilegedExceptionAction<?> locationAction = new PrivilegedExceptionAction() {
/*      */         public Object run() throws HeadlessException {
/* 1193 */           PointerInfo pointerInfo = MouseInfo.getPointerInfo();
/* 1194 */           return (pointerInfo == null) ? null : pointerInfo.getLocation();
/*      */         }
/*      */       };
/*      */     
/* 1198 */     private Frame frame = null;
/*      */     
/* 1199 */     private Dialog dialog = null;
/*      */     
/*      */     private MouseInputHandler() {
/* 1201 */       if (SyntheticaRootPaneUI.this.window instanceof Frame) {
/* 1202 */         this.frame = (Frame)SyntheticaRootPaneUI.this.window;
/* 1203 */       } else if (SyntheticaRootPaneUI.this.window instanceof Dialog) {
/* 1204 */         this.dialog = (Dialog)SyntheticaRootPaneUI.this.window;
/*      */       } 
/*      */     }
/*      */     
/*      */     private Point getPoint(MouseEvent param1MouseEvent) {
/* 1210 */       return SwingUtilities.convertPoint(param1MouseEvent.getComponent(), param1MouseEvent.getPoint(), SyntheticaRootPaneUI.this.window);
/*      */     }
/*      */     
/*      */     private boolean isInTitlePane(MouseEvent param1MouseEvent) {
/* 1215 */       Point point = SwingUtilities.convertPoint(SyntheticaRootPaneUI.this.window, getPoint(param1MouseEvent), SyntheticaRootPaneUI.this.titlePane);
/* 1216 */       return SyntheticaRootPaneUI.this.titlePane.contains(point);
/*      */     }
/*      */     
/*      */     public void mousePressed(MouseEvent param1MouseEvent) {
/* 1223 */       if (!SyntheticaRootPaneUI.this.isDecorated(SyntheticaRootPaneUI.this.rootPane) || this.windowMenuKeyEmulationRunning)
/*      */         return; 
/* 1225 */       SyntheticaRootPaneUI.this.window.toFront();
/* 1227 */       Rectangle rectangle = SyntheticaRootPaneUI.this.window.getGraphicsConfiguration().getBounds();
/* 1228 */       this.minimumYPos = rectangle.y;
/* 1229 */       this.maximumYPos = rectangle.y + rectangle.height;
/* 1231 */       this.dragStart = getPoint(param1MouseEvent);
/* 1232 */       this.dragStartOnScreen = new Point(this.dragStart);
/* 1233 */       SwingUtilities.convertPointToScreen(this.dragStartOnScreen, SyntheticaRootPaneUI.this.window);
/* 1234 */       Point point = SwingUtilities.convertPoint(SyntheticaRootPaneUI.this.window, this.dragStart, SyntheticaRootPaneUI.this.titlePane);
/* 1235 */       int i = position2Cursor(SyntheticaRootPaneUI.this.window, this.dragStart.x, this.dragStart.y);
/* 1238 */       if (i == 0 && SyntheticaRootPaneUI.this.titlePane != null && 
/* 1239 */         SyntheticaRootPaneUI.this.titlePane.contains(point) && (
/* 1240 */         this.dialog != null || (this.frame != null && this.frame.getExtendedState() != 6))) {
/* 1242 */         this.windowAction = 1;
/* 1243 */         this.dragXOffset = this.dragStart.x;
/* 1244 */         this.dragYOffset = this.dragStart.y;
/* 1245 */         if (!this.liveDrag && this.dragResizeWindow == null) {
/* 1247 */           this.dragResizeWindow = createDragResizeWindow();
/* 1248 */           this.dragResizeWindow.setBounds(SyntheticaRootPaneUI.this.window.getBounds());
/* 1249 */           this.dragResizeWindow.setVisible(true);
/*      */         } 
/* 1253 */       } else if (isWindowResizable()) {
/* 1255 */         this.dragXOffset = this.dragStart.x;
/* 1256 */         this.dragYOffset = this.dragStart.y;
/* 1257 */         this.dragDimension = new Dimension(SyntheticaRootPaneUI.this.window.getWidth(), SyntheticaRootPaneUI.this.window.getHeight());
/* 1258 */         this.resizeType = position2Cursor(SyntheticaRootPaneUI.this.window, this.dragStart.x, this.dragStart.y);
/* 1259 */         if (this.resizeType != 0)
/* 1260 */           this.windowAction = 2; 
/* 1261 */         if (!this.liveResize && this.resizeType != 0 && this.dragResizeWindow == null) {
/* 1263 */           this.dragResizeWindow = createDragResizeWindow();
/* 1264 */           this.dragResizeWindow.setCursor(Cursor.getPredefinedCursor(i));
/* 1265 */           this.dragResizeWindow.setBounds(SyntheticaRootPaneUI.this.window.getBounds());
/* 1266 */           this.dragResizeWindow.setVisible(true);
/*      */         } 
/*      */       } 
/* 1270 */       if (SyntheticaRootPaneUI.this.isSnapEnabled(SyntheticaRootPaneUI.this.window) && SyntheticaRootPaneUI.this.snapState == null) {
/* 1272 */         SyntheticaRootPaneUI.this.preSnapBounds = SyntheticaRootPaneUI.this.window.getBounds();
/* 1273 */         this.preSnapXOffset = this.dragXOffset;
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseReleased(MouseEvent param1MouseEvent) {
/* 1281 */       if (this.windowMenuKeyEmulationRunning)
/*      */         return; 
/* 1284 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.nativeWindowMenuSupport.enabled", SyntheticaRootPaneUI.this.window, false) && param1MouseEvent.getButton() == 3 && isInTitlePane(param1MouseEvent) && (
/* 1285 */         OS.getCurrentOS() == OS.Windows || OS.getCurrentOS() == OS.Linux) && this.snapWindow == null) {
/* 1287 */         this.windowMenuKeyEmulationRunning = true;
/*      */         try {
/* 1290 */           final Robot robot = new Robot();
/* 1291 */           if (OS.getCurrentOS() == OS.Windows) {
/* 1293 */             robot.keyPress(18);
/* 1294 */             robot.keyPress(32);
/* 1296 */           } else if (OS.getCurrentOS() == OS.Linux) {
/* 1298 */             robot.keyPress(18);
/* 1299 */             robot.mousePress(4);
/* 1300 */             robot.mouseRelease(4);
/*      */           } 
/* 1302 */           SwingUtilities.invokeLater(new Runnable() {
/*      */                 public void run() {
/*      */                   try {
/* 1307 */                     Thread.sleep(100L);
/* 1307 */                   } catch (InterruptedException interruptedException) {}
/* 1308 */                   if (OS.getCurrentOS() == OS.Windows)
/* 1309 */                     robot.keyRelease(32); 
/* 1310 */                   robot.keyRelease(18);
/* 1311 */                   SwingUtilities.invokeLater(new Runnable() {
/*      */                         public void run() {
/* 1316 */                           (SyntheticaRootPaneUI.MouseInputHandler.null.access$0(SyntheticaRootPaneUI.MouseInputHandler.null.this)).windowMenuKeyEmulationRunning = false;
/*      */                         }
/*      */                       });
/*      */                 }
/*      */               });
/* 1322 */         } catch (AWTException aWTException) {
/* 1324 */           aWTException.printStackTrace();
/*      */         } 
/*      */         return;
/*      */       } 
/* 1329 */       if (this.dragResizeWindow != null && ((this.windowAction == 2 && !this.liveResize) || (this.windowAction == 1 && !this.liveDrag))) {
/* 1331 */         Rectangle rectangle = this.dragResizeWindow.getBounds();
/* 1332 */         this.dragResizeWindow.setVisible(false);
/* 1333 */         this.dragResizeWindow.dispose();
/* 1334 */         if (this.windowAction == 2 && this.resizeBounds != null) {
/* 1335 */           SyntheticaRootPaneUI.this.window.setBounds(this.resizeBounds);
/*      */         } else {
/* 1337 */           SyntheticaRootPaneUI.this.window.setBounds(rectangle);
/*      */         } 
/* 1338 */         this.dragResizeWindow = null;
/* 1339 */         this.resizeBounds = null;
/*      */       } 
/* 1342 */       if (this.snapWindow != null) {
/* 1344 */         Rectangle rectangle = this.snapWindow.getBounds();
/* 1345 */         if (this.tmpSnapState == SyntheticaRootPaneUI.SnapState.SNAP_MAXIMIZED && SyntheticaRootPaneUI.this.titlePane instanceof SyntheticaTitlePane) {
/* 1346 */           ((SyntheticaTitlePane)SyntheticaRootPaneUI.this.titlePane).maximize();
/*      */         } else {
/* 1348 */           SyntheticaRootPaneUI.this.window.setBounds(SyntheticaRootPaneUI.this.justifySnapBounds(rectangle, this.tmpSnapState));
/*      */         } 
/* 1349 */         disposeSnapWindow();
/* 1350 */         SyntheticaRootPaneUI.this.snapState = this.tmpSnapState;
/* 1351 */         this.tmpSnapState = null;
/*      */       } 
/* 1355 */       if (this.windowAction == 2 && !SyntheticaRootPaneUI.this.window.isValid()) {
/* 1357 */         SyntheticaRootPaneUI.this.window.validate();
/* 1358 */         SyntheticaRootPaneUI.this.rootPane.repaint();
/*      */       } 
/* 1360 */       this.windowAction = -1;
/* 1361 */       this.resizeType = -1;
/* 1362 */       SyntheticaRootPaneUI.this.window.setCursor(Cursor.getDefaultCursor());
/*      */     }
/*      */     
/*      */     private void cancelDragResize() {
/* 1367 */       if (this.dragResizeWindow != null && ((this.windowAction == 2 && !this.liveResize) || (this.windowAction == 1 && !this.liveDrag))) {
/* 1369 */         this.dragResizeWindow.setVisible(false);
/* 1370 */         this.dragResizeWindow.dispose();
/* 1371 */         this.dragResizeWindow = null;
/* 1372 */         this.resizeBounds = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseMoved(MouseEvent param1MouseEvent) {
/* 1380 */       if (!SyntheticaRootPaneUI.this.isDecorated(SyntheticaRootPaneUI.this.rootPane) || this.windowMenuKeyEmulationRunning)
/*      */         return; 
/* 1383 */       Point point = getPoint(param1MouseEvent);
/* 1384 */       int i = position2Cursor(SyntheticaRootPaneUI.this.window, point.x, point.y);
/* 1385 */       if (i != 0 && isWindowResizable()) {
/* 1386 */         SyntheticaRootPaneUI.this.window.setCursor(Cursor.getPredefinedCursor(i));
/*      */       } else {
/* 1390 */         SyntheticaRootPaneUI.this.window.setCursor(Cursor.getDefaultCursor());
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseEntered(MouseEvent param1MouseEvent) {
/* 1399 */       mouseMoved(param1MouseEvent);
/*      */     }
/*      */     
/*      */     public void mouseExited(MouseEvent param1MouseEvent) {
/* 1408 */       SyntheticaRootPaneUI.this.window.setCursor(Cursor.getDefaultCursor());
/*      */     }
/*      */     
/*      */     private void cancelSnap() {
/* 1413 */       if (this.windowAction == 1 || this.windowAction == 2)
/* 1414 */         resetSnapState(); 
/*      */     }
/*      */     
/*      */     private void resetSnapState() {
/* 1419 */       if (this.snapWindow != null)
/* 1420 */         disposeSnapWindow(); 
/* 1421 */       this.tmpSnapState = null;
/* 1422 */       SyntheticaRootPaneUI.this.snapState = null;
/*      */     }
/*      */     
/*      */     private void disposeSnapWindow() {
/* 1429 */       this.snapWindow.setVisible(false);
/* 1430 */       this.snapWindow.dispose();
/* 1431 */       this.snapWindow = null;
/*      */     }
/*      */     
/*      */     private void unsnap(Window param1Window) {
/* 1436 */       SyntheticaRootPaneUI.this.restoreSnappedWindow(param1Window, param1Window.getGraphicsConfiguration(), false);
/* 1437 */       this.dragXOffset = this.preSnapXOffset;
/*      */     }
/*      */     
/*      */     public void mouseDragged(MouseEvent param1MouseEvent) {
/* 1444 */       if (this.windowMenuKeyEmulationRunning)
/*      */         return; 
/* 1446 */       GraphicsConfiguration graphicsConfiguration = (!this.liveDrag && this.dragResizeWindow != null) ? this.dragResizeWindow.getGraphicsConfiguration() : SyntheticaRootPaneUI.this.window.getGraphicsConfiguration();
/* 1447 */       Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(graphicsConfiguration);
/* 1448 */       this.minimumYPos = (graphicsConfiguration.getBounds()).y + insets.top;
/* 1449 */       this.maximumYPos = (graphicsConfiguration.getBounds()).y + (graphicsConfiguration.getBounds()).height - insets.bottom - SyntheticaRootPaneUI.this.titlePane.getHeight() - (SyntheticaRootPaneUI.this.rootPane.getInsets()).top;
/* 1451 */       Rectangle rectangle = SyntheticaRootPaneUI.this.getMultiScreenBounds();
/* 1452 */       int i = rectangle.x + insets.left;
/* 1453 */       int j = rectangle.x + rectangle.width - insets.left - insets.right;
/* 1455 */       boolean bool1 = SyntheticaLookAndFeel.isSystemPropertySet("synthetica.window.respectMinimumYPos");
/* 1456 */       boolean bool2 = SyntheticaLookAndFeel.isSystemPropertySet("synthetica.window.respectMaximumYPos");
/* 1459 */       if (SyntheticaRootPaneUI.this.isMaximized(SyntheticaRootPaneUI.this.window) && this.dragStart != null && param1MouseEvent.getComponent() instanceof Window && isInTitlePane(param1MouseEvent) && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.restoreByDragFromMaximized.enabled", SyntheticaRootPaneUI.this.window, true)) {
/* 1461 */         int k = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.restoreByDragFromMaximized.threshold", SyntheticaRootPaneUI.this.window, 4);
/* 1462 */         boolean bool = (Math.abs(this.dragStart.x - param1MouseEvent.getX()) <= k && Math.abs(this.dragStart.y - param1MouseEvent.getY()) <= k) ? false : true;
/* 1463 */         if (bool) {
/* 1465 */           if (SyntheticaRootPaneUI.this.titlePane instanceof SyntheticaTitlePane)
/* 1466 */             ((SyntheticaTitlePane)SyntheticaRootPaneUI.this.titlePane).restore(); 
/* 1467 */           this.windowAction = 1;
/* 1470 */           if (this.dragXOffset <= 0)
/* 1471 */             this.dragXOffset = SyntheticaRootPaneUI.this.window.getWidth() / 2; 
/* 1472 */           if (this.dragYOffset <= 0)
/* 1473 */             this.dragYOffset = SyntheticaRootPaneUI.this.titlePane.getHeight() / 2; 
/* 1475 */           if (!this.liveDrag) {
/* 1477 */             this.dragResizeWindow = createDragResizeWindow();
/* 1478 */             this.dragResizeWindow.setBounds(SyntheticaRootPaneUI.this.window.getBounds());
/* 1479 */             this.dragResizeWindow.setVisible(true);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1484 */       if (this.windowAction == 1) {
/*      */         try {
/* 1492 */           Point point = (Point)AccessController.doPrivileged(this.locationAction);
/* 1494 */           if (point == null) {
/* 1496 */             point = getPoint(param1MouseEvent);
/* 1497 */             SwingUtilities.convertPointToScreen(point, (Component)param1MouseEvent.getSource());
/*      */           } 
/* 1500 */           point.x -= this.dragXOffset;
/* 1501 */           point.y -= this.dragYOffset;
/* 1504 */           if (bool1 && point.y < this.minimumYPos)
/* 1505 */             point.y = this.minimumYPos; 
/* 1506 */           if (bool2 && point.y > this.maximumYPos)
/* 1507 */             point.y = this.maximumYPos; 
/* 1509 */           boolean bool = SyntheticaRootPaneUI.this.isSnapEnabled(SyntheticaRootPaneUI.this.window);
/* 1511 */           if (bool && SyntheticaRootPaneUI.this.snapState == SyntheticaRootPaneUI.SnapState.SNAP_HEIGHT && point.y < this.minimumYPos + SyntheticaRootPaneUI.this.snapHeightThreshold)
/* 1512 */             point.y = this.minimumYPos - (SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.snap.insets", SyntheticaRootPaneUI.this.window, false)).top; 
/* 1514 */           if (this.liveDrag) {
/* 1515 */             SyntheticaRootPaneUI.this.window.setLocation(point);
/*      */           } else {
/* 1517 */             this.dragResizeWindow.setLocation(point);
/*      */           } 
/* 1519 */           if (bool) {
/* 1521 */             GraphicsConfiguration graphicsConfiguration1 = this.liveDrag ? SyntheticaRootPaneUI.this.window.getGraphicsConfiguration() : this.dragResizeWindow.getGraphicsConfiguration();
/* 1522 */             Point point1 = new Point(point.x + this.dragXOffset, point.y + this.dragYOffset);
/* 1524 */             if (point1.y <= this.minimumYPos) {
/* 1526 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_MAXIMIZED;
/* 1527 */               if (this.snapWindow == null)
/* 1528 */                 this.snapWindow = createSnapWindow(); 
/* 1529 */               this.snapWindow.setBounds(SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true));
/* 1530 */               this.snapWindow.setVisible(true);
/* 1533 */             } else if (point1.x <= i) {
/* 1535 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_LEFT;
/* 1536 */               if (this.snapWindow == null)
/* 1537 */                 this.snapWindow = createSnapWindow(); 
/* 1538 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1539 */               rectangle1.width /= 2;
/* 1540 */               this.snapWindow.setBounds(rectangle1);
/* 1541 */               this.snapWindow.setVisible(true);
/* 1544 */             } else if (point1.x >= j - 1) {
/* 1546 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_RIGHT;
/* 1547 */               if (this.snapWindow == null)
/* 1548 */                 this.snapWindow = createSnapWindow(); 
/* 1549 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1550 */               rectangle1.width /= 2;
/* 1551 */               rectangle1.x += rectangle1.width;
/* 1552 */               this.snapWindow.setBounds(rectangle1);
/* 1553 */               this.snapWindow.setVisible(true);
/* 1556 */             } else if (point1.y <= this.minimumYPos + SyntheticaRootPaneUI.this.snapCornerSize && point1.x <= i + SyntheticaRootPaneUI.this.snapCornerSize) {
/* 1558 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_TOP_LEFT;
/* 1559 */               if (this.snapWindow == null)
/* 1560 */                 this.snapWindow = createSnapWindow(); 
/* 1561 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1562 */               rectangle1.width /= 2;
/* 1563 */               rectangle1.height /= 2;
/* 1564 */               this.snapWindow.setBounds(rectangle1);
/* 1565 */               this.snapWindow.setVisible(true);
/* 1568 */             } else if (point1.y <= this.minimumYPos + SyntheticaRootPaneUI.this.snapCornerSize && point1.x >= j - 1 - SyntheticaRootPaneUI.this.snapCornerSize) {
/* 1570 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_TOP_RIGHT;
/* 1571 */               if (this.snapWindow == null)
/* 1572 */                 this.snapWindow = createSnapWindow(); 
/* 1573 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1574 */               rectangle1.width /= 2;
/* 1575 */               rectangle1.height /= 2;
/* 1576 */               rectangle1.x += rectangle1.width;
/* 1577 */               this.snapWindow.setBounds(rectangle1);
/* 1578 */               this.snapWindow.setVisible(true);
/* 1581 */             } else if (point1.y >= this.maximumYPos - 1 - SyntheticaRootPaneUI.this.snapCornerSize && point1.x <= i + SyntheticaRootPaneUI.this.snapCornerSize) {
/* 1583 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_BOTTOM_LEFT;
/* 1584 */               if (this.snapWindow == null)
/* 1585 */                 this.snapWindow = createSnapWindow(); 
/* 1586 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1588 */               rectangle1.height++;
/* 1589 */               rectangle1.width /= 2;
/* 1590 */               rectangle1.height /= 2;
/* 1591 */               rectangle1.y += rectangle1.height - 1;
/* 1592 */               this.snapWindow.setBounds(rectangle1);
/* 1593 */               this.snapWindow.setVisible(true);
/* 1596 */             } else if (point1.y >= this.maximumYPos - 1 - SyntheticaRootPaneUI.this.snapCornerSize && point1.x >= j - 1 - SyntheticaRootPaneUI.this.snapCornerSize) {
/* 1598 */               this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_BOTTOM_RIGHT;
/* 1599 */               if (this.snapWindow == null)
/* 1600 */                 this.snapWindow = createSnapWindow(); 
/* 1601 */               Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(graphicsConfiguration1, true, true);
/* 1603 */               rectangle1.height++;
/* 1604 */               rectangle1.width /= 2;
/* 1605 */               rectangle1.height /= 2;
/* 1606 */               rectangle1.x += rectangle1.width;
/* 1607 */               rectangle1.y += rectangle1.height - 1;
/* 1608 */               this.snapWindow.setBounds(rectangle1);
/* 1609 */               this.snapWindow.setVisible(true);
/* 1613 */             } else if (this.snapWindow != null && point1.y > this.minimumYPos + SyntheticaRootPaneUI.this.snapThreshold && 
/* 1614 */               point1.x > i + SyntheticaRootPaneUI.this.snapThreshold && point1.x < j - SyntheticaRootPaneUI.this.snapThreshold) {
/* 1617 */               disposeSnapWindow();
/*      */             } 
/* 1620 */             if (SyntheticaRootPaneUI.this.snapState != null && this.snapWindow == null)
/* 1622 */               if (SyntheticaRootPaneUI.this.snapState != SyntheticaRootPaneUI.SnapState.SNAP_HEIGHT || point.y >= this.minimumYPos + SyntheticaRootPaneUI.this.snapHeightThreshold) {
/* 1626 */                 int k = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.snap.restoreThreshold", SyntheticaRootPaneUI.this.window, 0);
/* 1627 */                 boolean bool3 = (Math.abs(this.dragStartOnScreen.x - param1MouseEvent.getXOnScreen()) <= k && Math.abs(this.dragStartOnScreen.y - param1MouseEvent.getYOnScreen()) <= k) ? false : true;
/* 1628 */                 if (bool3) {
/* 1630 */                   unsnap((!this.liveDrag && this.dragResizeWindow != null) ? this.dragResizeWindow : SyntheticaRootPaneUI.this.window);
/* 1632 */                   if (this.dragXOffset <= 0)
/* 1633 */                     this.dragXOffset = SyntheticaRootPaneUI.this.window.getWidth() / 2; 
/* 1634 */                   if (this.dragYOffset <= 0)
/* 1635 */                     this.dragYOffset = SyntheticaRootPaneUI.this.titlePane.getHeight() / 2; 
/*      */                 } 
/*      */               }  
/*      */           } 
/* 1642 */         } catch (PrivilegedActionException privilegedActionException) {}
/* 1647 */       } else if (this.windowAction == 2) {
/* 1650 */         if (SyntheticaRootPaneUI.this.isSnapEnabled(SyntheticaRootPaneUI.this.window) && (this.resizeType == 9 || this.resizeType == 8) && SyntheticaRootPaneUI.this.snapState != null)
/* 1651 */           resetSnapState(); 
/* 1653 */         Point point = getPoint(param1MouseEvent);
/* 1654 */         Dimension dimension = (Dimension)SyntheticaLookAndFeel.get("Synthetica.rootPane.minimumWindowSize", SyntheticaRootPaneUI.this.window);
/* 1657 */         if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.fallBelowMinimumWindowSize", SyntheticaRootPaneUI.this.window, true) && (param1MouseEvent.getModifiers() & 0x2) != 0)
/* 1658 */           dimension = new Dimension(4, 4); 
/* 1660 */         if (dimension == null)
/* 1661 */           dimension = SyntheticaRootPaneUI.this.window.getMinimumSize(); 
/* 1662 */         this.resizeBounds = SyntheticaRootPaneUI.this.window.getBounds();
/* 1663 */         Rectangle rectangle1 = new Rectangle(this.resizeBounds);
/* 1665 */         if (this.resizeType == 11 || 
/* 1666 */           this.resizeType == 7 || 
/* 1667 */           this.resizeType == 5)
/* 1669 */           this.resizeBounds.width = Math.max(dimension.width, this.dragDimension.width + point.x - this.dragXOffset); 
/* 1672 */         if (this.resizeType == 9 || 
/* 1673 */           this.resizeType == 4 || 
/* 1674 */           this.resizeType == 5) {
/* 1676 */           this.resizeBounds.height = Math.max(dimension.height, this.dragDimension.height + point.y - this.dragYOffset);
/* 1677 */           if (SyntheticaRootPaneUI.this.isSnapEnabled(SyntheticaRootPaneUI.this.window) && this.resizeType == 9)
/* 1678 */             setSnapHeightState(param1MouseEvent); 
/*      */         } 
/* 1681 */         if (this.resizeType == 8 || 
/* 1682 */           this.resizeType == 6 || 
/* 1683 */           this.resizeType == 7) {
/* 1685 */           int k = point.y - this.dragYOffset;
/* 1686 */           this.resizeBounds.y += k;
/* 1687 */           this.resizeBounds.height -= k;
/* 1688 */           if (this.resizeBounds.height < dimension.height) {
/* 1690 */             this.resizeBounds.y += this.resizeBounds.height - dimension.height;
/* 1691 */             this.resizeBounds.height = dimension.height;
/*      */           } 
/* 1693 */           if (SyntheticaRootPaneUI.this.isSnapEnabled(SyntheticaRootPaneUI.this.window) && this.resizeType == 8)
/* 1694 */             setSnapHeightState(param1MouseEvent); 
/*      */         } 
/* 1697 */         if (this.resizeType == 10 || 
/* 1698 */           this.resizeType == 6 || 
/* 1699 */           this.resizeType == 4) {
/* 1701 */           int k = point.x - this.dragXOffset;
/* 1702 */           this.resizeBounds.x += k;
/* 1703 */           this.resizeBounds.width -= k;
/* 1704 */           if (this.resizeBounds.width < dimension.width) {
/* 1706 */             this.resizeBounds.x += this.resizeBounds.width - dimension.width;
/* 1707 */             this.resizeBounds.width = dimension.width;
/*      */           } 
/*      */         } 
/* 1712 */         if (bool1 && this.resizeBounds.y < this.minimumYPos)
/* 1713 */           this.resizeBounds.y = this.minimumYPos; 
/* 1715 */         if (!this.resizeBounds.equals(rectangle1))
/* 1717 */           if (this.liveResize) {
/* 1718 */             SyntheticaRootPaneUI.this.window.setBounds(this.resizeBounds);
/*      */           } else {
/* 1720 */             this.dragResizeWindow.setBounds(this.resizeBounds);
/*      */           }  
/*      */       } 
/*      */     }
/*      */     
/*      */     private void setSnapHeightState(MouseEvent param1MouseEvent) {
/*      */       try {
/* 1729 */         Point point = (Point)AccessController.doPrivileged(this.locationAction);
/* 1731 */         if (point == null) {
/* 1733 */           point = getPoint(param1MouseEvent);
/* 1734 */           SwingUtilities.convertPointToScreen(point, (Component)param1MouseEvent.getSource());
/*      */         } 
/* 1736 */         int i = this.maximumYPos + (SyntheticaRootPaneUI.this.rootPane.getInsets()).top + SyntheticaRootPaneUI.this.titlePane.getHeight() - 1;
/* 1737 */         if ((point.y <= this.minimumYPos || point.y >= i) && this.snapWindow == null) {
/* 1739 */           this.tmpSnapState = SyntheticaRootPaneUI.SnapState.SNAP_HEIGHT;
/* 1740 */           this.snapWindow = createSnapWindow();
/* 1741 */           this.snapWindow.setCursor(Cursor.getPredefinedCursor(8));
/* 1742 */           Rectangle rectangle1 = SyntheticaRootPaneUI.this.getMaximizedBounds(SyntheticaRootPaneUI.this.window.getGraphicsConfiguration(), true, true);
/* 1743 */           Rectangle rectangle2 = SyntheticaRootPaneUI.this.window.getBounds();
/* 1744 */           rectangle1.x = rectangle2.x;
/* 1745 */           rectangle1.width = rectangle2.width;
/* 1746 */           this.snapWindow.setBounds(rectangle1);
/* 1747 */           this.snapWindow.setVisible(true);
/* 1749 */         } else if (this.snapWindow != null && point.y > this.minimumYPos + SyntheticaRootPaneUI.this.snapThreshold && point.y < i - SyntheticaRootPaneUI.this.snapThreshold) {
/* 1750 */           disposeSnapWindow();
/*      */         } 
/* 1752 */       } catch (PrivilegedActionException privilegedActionException) {}
/*      */     }
/*      */     
/*      */     public void mouseClicked(MouseEvent param1MouseEvent) {
/* 1761 */       if (this.frame == null || this.windowMenuKeyEmulationRunning)
/*      */         return; 
/* 1764 */       Point point = SwingUtilities.convertPoint(SyntheticaRootPaneUI.this.window, getPoint(param1MouseEvent), SyntheticaRootPaneUI.this.titlePane);
/* 1765 */       if (SyntheticaRootPaneUI.this.titlePane != null && SyntheticaRootPaneUI.this.titlePane.contains(point) && 
/* 1766 */         param1MouseEvent.getClickCount() == 2 && (
/* 1767 */         param1MouseEvent.getModifiers() & 0x10) == 16)
/* 1769 */         if (SyntheticaRootPaneUI.this.snapState != null) {
/* 1771 */           if (SyntheticaRootPaneUI.this.isMaximized(this.frame) && SyntheticaRootPaneUI.this.titlePane instanceof SyntheticaTitlePane)
/* 1772 */             ((SyntheticaTitlePane)SyntheticaRootPaneUI.this.titlePane).restore(); 
/* 1773 */           SyntheticaRootPaneUI.this.restoreSnappedWindow(this.frame, this.frame.getGraphicsConfiguration(), true);
/* 1775 */         } else if (this.frame.isResizable() && isFrameResizable() && SyntheticaRootPaneUI.this.titlePane instanceof SyntheticaTitlePane) {
/* 1777 */           ((SyntheticaTitlePane)SyntheticaRootPaneUI.this.titlePane).maximize();
/* 1779 */         } else if (this.frame.isResizable() && !isFrameResizable() && SyntheticaRootPaneUI.this.titlePane instanceof SyntheticaTitlePane) {
/* 1781 */           ((SyntheticaTitlePane)SyntheticaRootPaneUI.this.titlePane).restore();
/*      */         }  
/*      */     }
/*      */     
/*      */     private int position2Cursor(Window param1Window, int param1Int1, int param1Int2) {
/* 1790 */       int i = param1Window.getWidth();
/* 1791 */       int j = param1Window.getHeight();
/* 1793 */       if (param1Int1 < SyntheticaRootPaneUI.this.resizeInsets.left && param1Int2 < SyntheticaRootPaneUI.this.resizeInsets.top)
/* 1794 */         return 6; 
/* 1795 */       if (param1Int1 > i - SyntheticaRootPaneUI.this.resizeInsets.right && param1Int2 < SyntheticaRootPaneUI.this.resizeInsets.top)
/* 1796 */         return 7; 
/* 1797 */       if (param1Int1 < SyntheticaRootPaneUI.this.resizeInsets.left && param1Int2 > j - SyntheticaRootPaneUI.this.resizeInsets.bottom)
/* 1798 */         return 4; 
/* 1799 */       if (param1Int1 > i - SyntheticaRootPaneUI.this.resizeInsets.right && param1Int2 > j - SyntheticaRootPaneUI.this.resizeInsets.bottom)
/* 1800 */         return 5; 
/* 1802 */       if (param1Int1 < SyntheticaRootPaneUI.this.resizeInsets.left)
/* 1803 */         return 10; 
/* 1804 */       if (param1Int1 > i - SyntheticaRootPaneUI.this.resizeInsets.right)
/* 1805 */         return 11; 
/* 1806 */       if (param1Int2 < SyntheticaRootPaneUI.this.resizeInsets.top)
/* 1807 */         return 8; 
/* 1808 */       if (param1Int2 > j - SyntheticaRootPaneUI.this.resizeInsets.bottom)
/* 1809 */         return 9; 
/* 1811 */       return 0;
/*      */     }
/*      */     
/*      */     private JWindow createDragResizeWindow() {
/* 1817 */       JWindow jWindow = new JWindow(SyntheticaRootPaneUI.this.window);
/* 1819 */       if (OS.getCurrentOS() == OS.Mac)
/* 1820 */         jWindow.getRootPane().putClientProperty("Window.shadow", Boolean.FALSE); 
/* 1821 */       jWindow.getRootPane().setContentPane(new JComponent() {
/*      */             public void paintComponent(Graphics param2Graphics) {
/* 1825 */               paintComponents(param2Graphics);
/* 1826 */               SyntheticaRootPaneUI.MouseInputHandler.this.paintResizeBackground((SyntheticaRootPaneUI.MouseInputHandler.access$6(SyntheticaRootPaneUI.MouseInputHandler.this)).rootPane, param2Graphics, 0, 0, getWidth(), getHeight());
/*      */             }
/*      */           });
/* 1829 */       SyntheticaLookAndFeel.setWindowOpaque(jWindow, false);
/* 1830 */       return jWindow;
/*      */     }
/*      */     
/*      */     private JWindow createSnapWindow() {
/* 1836 */       JWindow jWindow = new JWindow();
/* 1838 */       if (OS.getCurrentOS() == OS.Mac)
/* 1839 */         jWindow.getRootPane().putClientProperty("Window.shadow", Boolean.FALSE); 
/* 1840 */       jWindow.getRootPane().setContentPane(new JComponent() {
/*      */             public void paintComponent(Graphics param2Graphics) {
/* 1844 */               paintComponents(param2Graphics);
/* 1845 */               SyntheticaRootPaneUI.MouseInputHandler.this.paintSnapBackground((SyntheticaRootPaneUI.MouseInputHandler.access$6(SyntheticaRootPaneUI.MouseInputHandler.this)).rootPane, param2Graphics, 0, 0, getWidth(), getHeight());
/*      */             }
/*      */           });
/* 1848 */       SyntheticaLookAndFeel.setWindowOpaque(jWindow, false);
/* 1849 */       return jWindow;
/*      */     }
/*      */     
/*      */     private void paintResizeBackground(JRootPane param1JRootPane, Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 1854 */       RootPanePainter.getInstance().paintResizeBackground(param1JRootPane, null, param1Graphics, param1Int1, param1Int2, param1Int3, param1Int4);
/*      */     }
/*      */     
/*      */     private void paintSnapBackground(JRootPane param1JRootPane, Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 1859 */       RootPanePainter.getInstance().paintSnapBackground(param1JRootPane, null, param1Graphics, param1Int1, param1Int2, param1Int3, param1Int4);
/*      */     }
/*      */     
/*      */     private boolean isFrameResizable() {
/* 1866 */       return (this.frame != null && this.frame.isResizable() && (this.frame.getExtendedState() & 0x6) == 0);
/*      */     }
/*      */     
/*      */     private boolean isDialogResizable() {
/* 1873 */       return (this.dialog != null && this.dialog.isResizable());
/*      */     }
/*      */     
/*      */     private boolean isWindowResizable() {
/* 1880 */       return !(!isFrameResizable() && !isDialogResizable());
/*      */     }
/*      */     
/*      */     public boolean isResizing() {
/* 1888 */       return (this.windowAction == 2);
/*      */     }
/*      */   }
/*      */   
/*      */   private enum SnapState {
/*      */     SNAP_LEFT, SNAP_RIGHT, SNAP_HEIGHT, SNAP_MAXIMIZED, SNAP_TOP_LEFT, SNAP_TOP_RIGHT, SNAP_BOTTOM_LEFT, SNAP_BOTTOM_RIGHT;
/*      */   }
/*      */   
/*      */   private enum HeaderShadowType {
/*      */     NONE, NORMAL, SHADOW_COMPONENT_MENUBAR_ONLY, SHADOW_COMPONENT_ONLY, TITLEPANE_ONLY;
/*      */   }
/*      */   
/*      */   private int snapThreshold = 12;
/*      */   
/*      */   private int snapHeightThreshold = 24;
/*      */   
/*      */   private int snapCornerSize = 24;
/*      */   
/*      */   private SnapState snapState;
/*      */   
/*      */   private Rectangle preSnapBounds;
/*      */   
/*      */   private WeakReference<JComponent> headerShadowComponent;
/*      */   
/*      */   private JComponent headerShadow;
/*      */   
/*      */   public static ComponentUI createUI(JComponent paramJComponent) {
/*      */     return new SyntheticaRootPaneUI();
/*      */   }
/*      */   
/*      */   public static final boolean isEvalCopy() {
/*      */     return true;
/*      */   }
/*      */   
/*      */   public void installUI(JComponent paramJComponent) {
/*      */     super.installUI(paramJComponent);
/*      */     this.rootPane = (JRootPane)paramJComponent;
/*      */     if (isDecorated(this.rootPane))
/*      */       installClientDecorations(this.rootPane); 
/*      */     if (isHeaderShadowEnabled())
/*      */       installHeaderListener(this.rootPane); 
/*      */   }
/*      */   
/*      */   public void uninstallUI(JComponent paramJComponent) {
/*      */     super.uninstallUI(paramJComponent);
/*      */     uninstallClientDecorations(this.rootPane);
/*      */     uninstallHeaderListener(this.rootPane);
/*      */     this.rootPane = null;
/*      */   }
/*      */   
/*      */   private void installClientDecorations(JRootPane paramJRootPane) {
/*      */     SyntheticaTitlePane syntheticaTitlePane = new SyntheticaTitlePane(paramJRootPane, this);
/*      */     setTitlePane(paramJRootPane, syntheticaTitlePane);
/*      */     installBorder(paramJRootPane);
/*      */     installWindowListeners(paramJRootPane, paramJRootPane.getParent());
/*      */     installLayout(paramJRootPane);
/*      */     if (this.window instanceof Dialog && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.dialogStyle.enabled", this.window, false) && SyntheticaLookAndFeel.getClientProperty("Synthetica.style", this.rootPane, null) == null) {
/*      */       String str = SyntheticaLookAndFeel.getString("Synthetica.rootPane.dialogStyle.defaultName", this.window, "Dialog");
/*      */       this.rootPane.putClientProperty("Synthetica.style", str);
/*      */       Container container = this.rootPane.getContentPane();
/*      */       if (container == null || container.getName().startsWith("null."));
/*      */       container.setName(String.valueOf(str) + ".contentPane");
/*      */     } else if (this.window instanceof Frame && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.frameStyle.enabled", this.window, false) && SyntheticaLookAndFeel.getClientProperty("Synthetica.style", this.rootPane, null) == null) {
/*      */       String str = SyntheticaLookAndFeel.getString("Synthetica.rootPane.frameStyle.defaultName", this.window, "Frame");
/*      */       this.rootPane.putClientProperty("Synthetica.style", str);
/*      */       Container container = this.rootPane.getContentPane();
/*      */       if (container == null || container.getName().startsWith("null."));
/*      */       container.setName(String.valueOf(str) + ".contentPane");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void uninstallClientDecorations(JRootPane paramJRootPane) {
/*      */     if (this.titlePane != null && this.titlePane instanceof SyntheticaTitlePane)
/*      */       ((SyntheticaTitlePane)this.titlePane).uninstallListeners(paramJRootPane); 
/*      */     setTitlePane(paramJRootPane, null);
/*      */     uninstallBorder(paramJRootPane);
/*      */     uninstallWindowListeners(paramJRootPane);
/*      */     uninstallLayout(paramJRootPane);
/*      */   }
/*      */   
/*      */   public JComponent getTitlePane() {
/*      */     return this.titlePane;
/*      */   }
/*      */   
/*      */   void installBorder(JRootPane paramJRootPane) {
/*      */     if (isDecorated(paramJRootPane))
/*      */       paramJRootPane.setBorder(new Border() {
/*      */             public void paintBorder(Component param1Component, Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/*      */               SynthContext synthContext = SyntheticaLookAndFeel.createContext((JComponent)param1Component, Region.ROOT_PANE, 0);
/*      */               SyntheticaPainter.getInstance().paintRootPaneBorder(synthContext, param1Graphics, param1Int1, param1Int2, param1Int3, param1Int4);
/*      */             }
/*      */             
/*      */             public Insets getBorderInsets(Component param1Component) {
/*      */               if (SyntheticaRootPaneUI.this.isMaximized(SyntheticaRootPaneUI.this.window))
/*      */                 return new Insets(0, 0, 0, 0); 
/*      */               Insets insets = SyntheticaRootPaneUI.this.getDefaultBorderInsets();
/*      */               insets = (Insets)insets.clone();
/*      */               insets.bottom += 16;
/*      */               insets.left += SyntheticaLookAndFeel.getInt("Synthetica.rootPane.margin.left", SyntheticaRootPaneUI.this.window, 0);
/*      */               return insets;
/*      */             }
/*      */             
/*      */             public boolean isBorderOpaque() {
/*      */               return false;
/*      */             }
/*      */           }); 
/*      */   }
/*      */   
/*      */   private Insets getDefaultBorderInsets() {
/*      */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.size", this.window);
/*      */     if (insets == null)
/*      */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.border.insets", this.window); 
/*      */     return insets;
/*      */   }
/*      */   
/*      */   public String getRootPaneBorderText() {
/*      */     return SyntheticaLookAndFeel.getString("Synthetica.rootPane.borderText", this.window);
/*      */   }
/*      */   
/*      */   private void uninstallBorder(JRootPane paramJRootPane) {
/*      */     paramJRootPane.setBorder((Border)null);
/*      */   }
/*      */   
/*      */   private void installWindowListeners(JRootPane paramJRootPane, Component paramComponent) {
/*      */     this.window = (paramComponent == null) ? null : ((paramComponent instanceof Window) ? (Window)paramComponent : SwingUtilities.getWindowAncestor(paramComponent));
/*      */     this.resizeInsets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.resizeInsets", this.window, getDefaultBorderInsets());
/*      */     if (this.window != null) {
/*      */       if (getMouseInputListener() == null)
/*      */         setMouseInputListener(new MouseInputHandler(null)); 
/*      */       if (getAWTMouseInputListener() == null)
/*      */         setAWTMouseInputListener(new AWTMouseInputHandler(null)); 
/*      */       if (this.windowListener == null) {
/*      */         if (!SyntheticaLookAndFeel.isWindowOpacityEnabled(this.window))
/*      */           if (OS.getCurrentOS() == OS.Mac) {
/*      */             SyntheticaLookAndFeel.setWindowOpaque(this.window, false);
/*      */           } else {
/*      */             try {
/*      */               SyntheticaLookAndFeel.setWindowOpaque(this.window, false);
/*      */             } catch (Exception exception) {}
/*      */           }  
/*      */         boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.window.contentPane.opaque", this.window, true);
/*      */         setContentPaneOpaque(this.window, bool);
/*      */         this.windowListener = new WindowAdapter() {
/*      */             public void windowOpened(WindowEvent param1WindowEvent) {
/*      */               Window window = param1WindowEvent.getWindow();
/*      */               if (!SyntheticaLookAndFeel.isWindowOpacityEnabled(SyntheticaRootPaneUI.this.window)) {
/*      */                 SyntheticaLookAndFeel.setWindowOpaque(window, false);
/*      */                 if (SyntheticaLookAndFeel.getBoolean("Synthetica.window.contentPane.opaque", SyntheticaRootPaneUI.this.window, true))
/*      */                   SyntheticaRootPaneUI.this.setContentPaneOpaque(window, true); 
/*      */               } 
/*      */               if (SyntheticaRootPaneUI.this.snapState == null && SyntheticaRootPaneUI.this.preSnapBounds == null)
/*      */                 SyntheticaRootPaneUI.this.preSnapBounds = param1WindowEvent.getWindow().getBounds(); 
/*      */             }
/*      */             
/*      */             public void windowDeactivated(WindowEvent param1WindowEvent) {
/*      */               if (SyntheticaRootPaneUI.this.mouseInputListener instanceof SyntheticaRootPaneUI.MouseInputHandler) {
/*      */                 ((SyntheticaRootPaneUI.MouseInputHandler)SyntheticaRootPaneUI.this.mouseInputListener).cancelDragResize();
/*      */                 ((SyntheticaRootPaneUI.MouseInputHandler)SyntheticaRootPaneUI.this.mouseInputListener).cancelSnap();
/*      */               } 
/*      */             }
/*      */           };
/*      */         this.window.addWindowListener(this.windowListener);
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.isWindowShapeEnabled(this.window))
/*      */         if (this.windowShapeResizeListener == null && SyntheticaLookAndFeel.isWindowShapeSupported(this.window)) {
/*      */           this.windowShapeResizeListener = new ComponentAdapter() {
/*      */               public void componentResized(ComponentEvent param1ComponentEvent) {
/*      */                 Window window = (Window)param1ComponentEvent.getComponent();
/*      */                 SyntheticaLookAndFeel.updateWindowShape(window);
/*      */               }
/*      */             };
/*      */           this.window.addComponentListener(this.windowShapeResizeListener);
/*      */         } else if (OS.getCurrentOS() == OS.Mac) {
/*      */           SyntheticaLookAndFeel.updateWindowShape(this.window);
/*      */         }  
/*      */       if (this.titlePane instanceof SyntheticaTitlePane && ((SyntheticaTitlePane)this.titlePane).showMenuBarInTitlePane() && this.windowMenuBarResizeListener == null) {
/*      */         this.windowMenuBarResizeListener = new ComponentAdapter() {
/*      */             public void componentResized(ComponentEvent param1ComponentEvent) {
/*      */               SyntheticaRootPaneUI.this.rootPane.doLayout();
/*      */             }
/*      */           };
/*      */         this.window.addComponentListener(this.windowMenuBarResizeListener);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installHeaderListener(JRootPane paramJRootPane) {
/*      */     if (this.rootPaneResizeListener == null) {
/*      */       this.rootPaneResizeListener = new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent param1ComponentEvent) {
/*      */             if (SyntheticaRootPaneUI.this.getHeaderShadowComponent() == null)
/*      */               SyntheticaRootPaneUI.this.updateHeaderShadow(); 
/*      */           }
/*      */         };
/*      */       paramJRootPane.addComponentListener(this.rootPaneResizeListener);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void uninstallHeaderListener(JRootPane paramJRootPane) {
/*      */     if (this.rootPaneResizeListener != null) {
/*      */       paramJRootPane.removeComponentListener(this.rootPaneResizeListener);
/*      */       this.rootPaneResizeListener = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setContentPaneOpaque(Window paramWindow, boolean paramBoolean) {
/*      */     if (paramWindow instanceof JDialog && ((JDialog)paramWindow).getContentPane() instanceof JComponent) {
/*      */       ((JComponent)((JDialog)paramWindow).getContentPane()).setOpaque(paramBoolean);
/*      */     } else if (paramWindow instanceof JFrame && ((JFrame)paramWindow).getContentPane() instanceof JComponent) {
/*      */       ((JComponent)((JFrame)paramWindow).getContentPane()).setOpaque(paramBoolean);
/*      */     } else if (paramWindow instanceof JWindow && ((JWindow)paramWindow).getContentPane() instanceof JComponent) {
/*      */       ((JComponent)((JWindow)paramWindow).getContentPane()).setOpaque(paramBoolean);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void uninstallWindowListeners(JRootPane paramJRootPane) {
/*      */     if (this.window != null) {
/*      */       if (this.awtMouseListener != null)
/*      */         removeAWTMouseListener(this.awtMouseListener); 
/*      */       this.window.removeWindowListener(this.windowListener);
/*      */       this.window.removeComponentListener(this.windowShapeResizeListener);
/*      */       this.window.removeComponentListener(this.windowMenuBarResizeListener);
/*      */     } 
/*      */     this.awtMouseListener = null;
/*      */     if (this.mouseInputListener instanceof MouseInputHandler)
/*      */       this.mouseInputListener = null; 
/*      */     this.windowListener = null;
/*      */     this.windowShapeResizeListener = null;
/*      */     this.windowMenuBarResizeListener = null;
/*      */     this.window = null;
/*      */   }
/*      */   
/*      */   private void installLayout(JRootPane paramJRootPane) {
/*      */     if (this.layoutManager == null)
/*      */       this.layoutManager = new SyntheticaRootLayout(null); 
/*      */     this.oldLayoutManager = paramJRootPane.getLayout();
/*      */     paramJRootPane.setLayout(this.layoutManager);
/*      */   }
/*      */   
/*      */   private void uninstallLayout(JRootPane paramJRootPane) {
/*      */     if (this.oldLayoutManager != null)
/*      */       paramJRootPane.setLayout(this.oldLayoutManager); 
/*      */     this.oldLayoutManager = null;
/*      */     this.layoutManager = null;
/*      */   }
/*      */   
/*      */   private void setTitlePane(JRootPane paramJRootPane, JComponent paramJComponent) {
/*      */     JLayeredPane jLayeredPane = paramJRootPane.getLayeredPane();
/*      */     if (this.titlePane != null) {
/*      */       this.titlePane.setVisible(false);
/*      */       jLayeredPane.remove(this.titlePane);
/*      */     } 
/*      */     if (paramJComponent != null) {
/*      */       jLayeredPane.add(paramJComponent, JLayeredPane.FRAME_CONTENT_LAYER);
/*      */       paramJComponent.setVisible(true);
/*      */     } 
/*      */     this.titlePane = paramJComponent;
/*      */   }
/*      */   
/*      */   public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     super.propertyChange(paramPropertyChangeEvent);
/*      */     String str = paramPropertyChangeEvent.getPropertyName();
/*      */     if (str == null)
/*      */       return; 
/*      */     if (str.equals("windowDecorationStyle")) {
/*      */       uninstallClientDecorations(this.rootPane);
/*      */       if (isDecorated(this.rootPane))
/*      */         installClientDecorations(this.rootPane); 
/*      */     } else if (str.equals("ancestor")) {
/*      */       uninstallWindowListeners(this.rootPane);
/*      */       if (isDecorated(this.rootPane) && paramPropertyChangeEvent.getNewValue() != null)
/*      */         installWindowListeners(this.rootPane, this.rootPane.getParent()); 
/*      */     } else if (str.equals("Synthetica.style") && this.titlePane instanceof SyntheticaTitlePane) {
/*      */       ((SyntheticaTitlePane)this.titlePane).updateLayoutStyle();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setMaximizedBounds(Frame paramFrame) {
/*      */     if (SyntheticaLookAndFeel.isSystemPropertySet("synthetica.frame.fullscreen", SyntheticaLookAndFeel.isUIScalingEnabled()))
/*      */       return; 
/*      */     Boolean bool1 = SyntheticaLookAndFeel.isSystemPropertySet("synthetica.frame.respectScreenBoundsX", (Boolean)null);
/*      */     Boolean bool2 = SyntheticaLookAndFeel.isSystemPropertySet("synthetica.frame.respectScreenBoundsY", (Boolean)null);
/*      */     if ((((bool1 == null) ? 1 : 0) & ((bool2 == null) ? 1 : 0)) != 0 && (JavaVersion.JAVA11 || JavaVersion.JAVA15_OR_ABOVE))
/*      */       bool1 = bool2 = Boolean.valueOf(true); 
/*      */     paramFrame.setMaximizedBounds(getMaximizedBounds(paramFrame.getGraphicsConfiguration(), (bool1 == null) ? false : bool1.booleanValue(), (bool2 == null) ? false : bool2.booleanValue()));
/*      */   }
/*      */   
/*      */   private Rectangle getMaximizedBounds(GraphicsConfiguration paramGraphicsConfiguration, boolean paramBoolean1, boolean paramBoolean2) {
/*      */     Rectangle rectangle = paramGraphicsConfiguration.getBounds();
/*      */     if (!paramBoolean1)
/*      */       rectangle.x = 0; 
/*      */     if (!paramBoolean2)
/*      */       rectangle.y = 0; 
/*      */     Insets insets = Toolkit.getDefaultToolkit().getScreenInsets(paramGraphicsConfiguration);
/*      */     if (SyntheticaLookAndFeel.isSystemPropertySet("synthetica.frame.ignoreScreenInsets"))
/*      */       return rectangle; 
/*      */     if (!SyntheticaLookAndFeel.isSystemPropertySet("synthetica.frame.disableAutoHideTaskBarCorrection") && insets.bottom == 0)
/*      */       insets.bottom++; 
/*      */     return new Rectangle(rectangle.x + insets.left, rectangle.y + insets.top, rectangle.width - insets.left + insets.right, rectangle.height - insets.top + insets.bottom);
/*      */   }
/*      */   
/*      */   private boolean isDecorated(JRootPane paramJRootPane) {
/*      */     return (paramJRootPane.getWindowDecorationStyle() != 0);
/*      */   }
/*      */   
/*      */   public MouseInputListener getMouseInputListener() {
/*      */     return this.mouseInputListener;
/*      */   }
/*      */   
/*      */   public void setMouseInputListener(MouseInputListener paramMouseInputListener) {
/*      */     this.mouseInputListener = paramMouseInputListener;
/*      */   }
/*      */   
/*      */   private AWTEventListener getAWTMouseInputListener() {
/*      */     return this.awtMouseListener;
/*      */   }
/*      */   
/*      */   private void setAWTMouseInputListener(AWTEventListener paramAWTEventListener) {
/*      */     if (this.awtMouseListener != null && this.window != null)
/*      */       removeAWTMouseListener(this.awtMouseListener); 
/*      */     this.awtMouseListener = paramAWTEventListener;
/*      */     if (this.awtMouseListener != null && this.window != null)
/*      */       addAWTMouseListener(this.awtMouseListener); 
/*      */     if (getMouseEventProcesor() == null)
/*      */       this.mouseEventProcessor = new MouseEventProcessor(); 
/*      */   }
/*      */   
/*      */   private void addAWTMouseListener(AWTEventListener paramAWTEventListener) {
/*      */     Toolkit.getDefaultToolkit().addAWTEventListener(paramAWTEventListener, 48L);
/*      */   }
/*      */   
/*      */   private void removeAWTMouseListener(AWTEventListener paramAWTEventListener) {
/*      */     Toolkit.getDefaultToolkit().removeAWTEventListener(paramAWTEventListener);
/*      */   }
/*      */   
/*      */   public MouseEventProcessor getMouseEventProcesor() {
/*      */     return this.mouseEventProcessor;
/*      */   }
/*      */   
/*      */   public void setMouseEventProcessor(MouseEventProcessor paramMouseEventProcessor) {
/*      */     this.mouseEventProcessor = paramMouseEventProcessor;
/*      */   }
/*      */   
/*      */   public void setHeaderShadowComponent(JComponent paramJComponent) {
/*      */     if (paramJComponent == null) {
/*      */       uninstallHeaderShadowComponent();
/*      */     } else if (paramJComponent != getHeaderShadowComponent()) {
/*      */       installHeaderShadowComponent(paramJComponent);
/*      */     } 
/*      */     updateHeaderShadow();
/*      */   }
/*      */   
/*      */   public JComponent getHeaderShadowComponent() {
/*      */     return (this.headerShadowComponent == null) ? null : this.headerShadowComponent.get();
/*      */   }
/*      */   
/*      */   public boolean isHeaderShadowEnabled() {
/*      */     return !getHeaderShadowType().equals(HeaderShadowType.NONE);
/*      */   }
/*      */   
/*      */   private void installHeaderShadowComponent(JComponent paramJComponent) {
/*      */     PropertyChangeListener propertyChangeListener = (PropertyChangeListener)paramJComponent.getClientProperty("Synthetica.headerShadow.ancestorListener");
/*      */     if (propertyChangeListener == null) {
/*      */       propertyChangeListener = new PropertyChangeListener() {
/*      */           public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */             if ("ancestor".equals(param1PropertyChangeEvent.getPropertyName())) {
/*      */               if (param1PropertyChangeEvent.getNewValue() == null)
/*      */                 SyntheticaRootPaneUI.this.uninstallHeaderShadowComponent(); 
/*      */               SyntheticaRootPaneUI.this.updateHeaderShadow();
/*      */             } 
/*      */           }
/*      */         };
/*      */       paramJComponent.putClientProperty("Synthetica.headerShadow.ancestorListener", propertyChangeListener);
/*      */       paramJComponent.addPropertyChangeListener(propertyChangeListener);
/*      */     } 
/*      */     ComponentListener componentListener = (ComponentListener)paramJComponent.getClientProperty("Synthetica.headerShadow.componentListener");
/*      */     if (componentListener == null) {
/*      */       componentListener = new ComponentAdapter() {
/*      */           public void componentResized(ComponentEvent param1ComponentEvent) {
/*      */             SyntheticaRootPaneUI.this.updateHeaderShadow();
/*      */           }
/*      */         };
/*      */       paramJComponent.putClientProperty("Synthetica.headerShadow.componentListener", componentListener);
/*      */       paramJComponent.addComponentListener(componentListener);
/*      */     } 
/*      */     JComponent jComponent = getHeaderShadowComponent();
/*      */     if (jComponent == null || paramJComponent == null || (paramJComponent != jComponent && (paramJComponent.getLocationOnScreen()).y + paramJComponent.getHeight() > (jComponent.getLocationOnScreen()).y + jComponent.getHeight()))
/*      */       this.headerShadowComponent = new WeakReference<JComponent>(paramJComponent); 
/*      */   }
/*      */   
/*      */   private void uninstallHeaderShadowComponent() {
/*      */     this.headerShadowComponent = null;
/*      */   }
/*      */   
/*      */   private void updateHeaderShadow() {
/*      */     if (this.headerShadow == null && !"ToolBar.FloatingWindow".equals(this.rootPane.getName())) {
/*      */       this.headerShadow = new JComponent() {
/*      */           protected void paintComponent(Graphics param1Graphics) {
/*      */             JComponent jComponent = SyntheticaRootPaneUI.this.getProperHeaderShadowComponent();
/*      */             if (jComponent != null) {
/*      */               super.paintComponent(param1Graphics);
/*      */               SyntheticaRootPaneUI.this.paintHeaderShadowBackground(SyntheticaRootPaneUI.this.rootPane, param1Graphics, 0, 0, getWidth(), getHeight());
/*      */             } 
/*      */           }
/*      */         };
/*      */       this.headerShadow.setName("HeaderShadow");
/*      */       this.headerShadow.setOpaque(false);
/*      */       this.rootPane.getLayeredPane().add(this.headerShadow, new Integer(JLayeredPane.PALETTE_LAYER.intValue() + 1));
/*      */     } 
/*      */     JComponent jComponent = getProperHeaderShadowComponent();
/*      */     if (this.headerShadow != null && jComponent != null) {
/*      */       Point point1 = jComponent.getLocation();
/*      */       Point point2 = SwingUtilities.convertPoint(jComponent.getParent(), point1, this.headerShadow.getParent());
/*      */       this.headerShadow.setBounds(point2.x, point2.y + jComponent.getHeight(), jComponent.getWidth(), SyntheticaLookAndFeel.getInt("Synthetica.rootPane.headerShadow.size", this.rootPane, 6));
/*      */     } 
/*      */   }
/*      */   
/*      */   private JComponent getProperHeaderShadowComponent() {
/*      */     if (this.rootPane == null)
/*      */       return null; 
/*      */     HeaderShadowType headerShadowType = getHeaderShadowType();
/*      */     if (headerShadowType == HeaderShadowType.TITLEPANE_ONLY)
/*      */       return getTitlePane(); 
/*      */     if (isHeaderShadowComponentValid())
/*      */       return getHeaderShadowComponent(); 
/*      */     if (headerShadowType == HeaderShadowType.NORMAL || headerShadowType == HeaderShadowType.SHADOW_COMPONENT_MENUBAR_ONLY) {
/*      */       JComponent jComponent = (this.rootPane.getJMenuBar() == null) ? ((headerShadowType == HeaderShadowType.SHADOW_COMPONENT_MENUBAR_ONLY) ? null : getTitlePane()) : this.rootPane.getJMenuBar();
/*      */       return (jComponent instanceof SyntheticaTitlePane && !((SyntheticaTitlePane)jComponent).isTitlePaneEnabled()) ? null : jComponent;
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   private boolean isHeaderShadowComponentValid() {
/*      */     JComponent jComponent = getHeaderShadowComponent();
/*      */     if (this.headerShadow != null && jComponent != null && jComponent.getRootPane() == this.rootPane) {
/*      */       Point point = jComponent.getLocation();
/*      */       point = SwingUtilities.convertPoint(jComponent.getParent(), point, this.headerShadow.getParent());
/*      */       return (point.y + jComponent.getHeight() < this.headerShadow.getParent().getHeight());
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private HeaderShadowType getHeaderShadowType() {
/*      */     String str = SyntheticaLookAndFeel.getString("Synthetica.rootPane.headerShadow.type", this.window);
/*      */     return (str == null) ? HeaderShadowType.NONE : HeaderShadowType.valueOf(str);
/*      */   }
/*      */   
/*      */   private void paintHeaderShadowBackground(JRootPane paramJRootPane, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*      */     RootPanePainter.getInstance().paintHeaderShadowBackground(paramJRootPane, null, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   private static class SyntheticaRootLayout implements LayoutManager2 {
/*      */     private SyntheticaRootLayout() {}
/*      */     
/*      */     public void addLayoutComponent(String param1String, Component param1Component) {}
/*      */     
/*      */     public void removeLayoutComponent(Component param1Component) {}
/*      */     
/*      */     public void addLayoutComponent(Component param1Component, Object param1Object) {}
/*      */     
/*      */     public float getLayoutAlignmentX(Container param1Container) {
/*      */       return 0.0F;
/*      */     }
/*      */     
/*      */     public float getLayoutAlignmentY(Container param1Container) {
/*      */       return 0.0F;
/*      */     }
/*      */     
/*      */     public void invalidateLayout(Container param1Container) {}
/*      */     
/*      */     public Dimension preferredLayoutSize(Container param1Container) {
/*      */       Insets insets = param1Container.getInsets();
/*      */       JRootPane jRootPane = (JRootPane)param1Container;
/*      */       JComponent jComponent = ((SyntheticaRootPaneUI)jRootPane.getUI()).titlePane;
/*      */       Dimension dimension1 = new Dimension(0, 0);
/*      */       if (jRootPane.getContentPane() != null) {
/*      */         dimension1 = jRootPane.getContentPane().getPreferredSize();
/*      */       } else {
/*      */         dimension1 = jRootPane.getSize();
/*      */       } 
/*      */       dimension1 = (dimension1 == null) ? new Dimension(0, 0) : dimension1;
/*      */       Dimension dimension2 = new Dimension(0, 0);
/*      */       if (jRootPane.getJMenuBar() != null)
/*      */         dimension2 = jRootPane.getJMenuBar().getPreferredSize(); 
/*      */       dimension2 = (dimension2 == null) ? new Dimension(0, 0) : dimension2;
/*      */       Dimension dimension3 = jComponent.getPreferredSize();
/*      */       dimension3 = (dimension3 == null) ? new Dimension(0, 0) : dimension3;
/*      */       int i = Math.max(dimension1.width, Math.max(dimension2.width, dimension3.width)) + insets.left + insets.right;
/*      */       int j = dimension1.height + dimension2.height + dimension3.height + insets.top + insets.bottom;
/*      */       return new Dimension(i, j);
/*      */     }
/*      */     
/*      */     public Dimension minimumLayoutSize(Container param1Container) {
/*      */       Insets insets = param1Container.getInsets();
/*      */       JRootPane jRootPane = (JRootPane)param1Container;
/*      */       JComponent jComponent = ((SyntheticaRootPaneUI)jRootPane.getUI()).titlePane;
/*      */       Dimension dimension1 = new Dimension(0, 0);
/*      */       if (jRootPane.getContentPane() != null) {
/*      */         dimension1 = jRootPane.getContentPane().getMinimumSize();
/*      */       } else {
/*      */         dimension1 = jRootPane.getSize();
/*      */       } 
/*      */       dimension1 = (dimension1 == null) ? new Dimension(0, 0) : dimension1;
/*      */       Dimension dimension2 = new Dimension(0, 0);
/*      */       if (jRootPane.getJMenuBar() != null)
/*      */         dimension2 = jRootPane.getJMenuBar().getMinimumSize(); 
/*      */       dimension2 = (dimension2 == null) ? new Dimension(0, 0) : dimension2;
/*      */       Dimension dimension3 = jComponent.getMinimumSize();
/*      */       dimension3 = (dimension3 == null) ? new Dimension(0, 0) : dimension3;
/*      */       int i = Math.max(dimension1.width, Math.max(dimension2.width, dimension3.width)) + insets.left + insets.right;
/*      */       int j = dimension1.height + dimension2.height + dimension3.height + insets.top + insets.bottom;
/*      */       return new Dimension(i, j);
/*      */     }
/*      */     
/*      */     public Dimension maximumLayoutSize(Container param1Container) {
/*      */       Insets insets = param1Container.getInsets();
/*      */       JRootPane jRootPane = (JRootPane)param1Container;
/*      */       JComponent jComponent = ((SyntheticaRootPaneUI)jRootPane.getUI()).titlePane;
/*      */       Dimension dimension1 = new Dimension(0, 0);
/*      */       if (jRootPane.getContentPane() != null) {
/*      */         dimension1 = jRootPane.getContentPane().getMaximumSize();
/*      */       } else {
/*      */         dimension1 = jRootPane.getSize();
/*      */       } 
/*      */       dimension1 = (dimension1 == null) ? new Dimension(2147483647, 2147483647) : dimension1;
/*      */       Dimension dimension2 = new Dimension(0, 0);
/*      */       if (jRootPane.getJMenuBar() != null)
/*      */         dimension2 = jRootPane.getJMenuBar().getMaximumSize(); 
/*      */       dimension2 = (dimension2 == null) ? new Dimension(2147483647, 2147483647) : dimension2;
/*      */       Dimension dimension3 = jComponent.getMaximumSize();
/*      */       dimension3 = (dimension3 == null) ? new Dimension(2147483647, 2147483647) : dimension3;
/*      */       int i = Math.max(dimension1.width, Math.max(dimension2.width, dimension3.width));
/*      */       if (i != Integer.MAX_VALUE)
/*      */         i += insets.left + insets.right; 
/*      */       int j = Math.max(dimension1.height, Math.max(dimension2.height, dimension3.height));
/*      */       if (j != Integer.MAX_VALUE)
/*      */         j += insets.top + insets.bottom; 
/*      */       return new Dimension(i, j);
/*      */     }
/*      */     
/*      */     public void layoutContainer(Container param1Container) {
/*      */       JRootPane jRootPane = (JRootPane)param1Container;
/*      */       Rectangle rectangle = jRootPane.getBounds();
/*      */       Insets insets = (jRootPane.getInsets() != null) ? jRootPane.getInsets() : new Insets(0, 0, 0, 0);
/*      */       int i = rectangle.width - insets.right - insets.left;
/*      */       int j = rectangle.height - insets.top - insets.bottom;
/*      */       int k = 0;
/*      */       if (jRootPane.getLayeredPane() != null)
/*      */         jRootPane.getLayeredPane().setBounds(insets.left, insets.top, i, j); 
/*      */       if (jRootPane.getGlassPane() != null)
/*      */         jRootPane.getGlassPane().setBounds(insets.left, insets.top, i, j); 
/*      */       JComponent jComponent = ((SyntheticaRootPaneUI)jRootPane.getUI()).titlePane;
/*      */       Dimension dimension = null;
/*      */       if (jComponent.isEnabled()) {
/*      */         dimension = jComponent.getPreferredSize();
/*      */         if (dimension != null) {
/*      */           jComponent.setBounds(0, 0, i, dimension.height);
/*      */           k += dimension.height;
/*      */         } 
/*      */       } 
/*      */       JMenuBar jMenuBar = jRootPane.getJMenuBar();
/*      */       if (jMenuBar != null && jComponent instanceof SyntheticaTitlePane) {
/*      */         SyntheticaTitlePane syntheticaTitlePane = (SyntheticaTitlePane)jComponent;
/*      */         Dimension dimension1 = jMenuBar.getPreferredSize();
/*      */         if (syntheticaTitlePane.showMenuBarInTitlePane()) {
/*      */           boolean bool = jMenuBar.getComponentOrientation().isLeftToRight();
/*      */           JComponent jComponent1 = (JComponent)SyntheticaLookAndFeel.findComponent("RootPane.menuBar", jComponent);
/*      */           if (jComponent1 != null) {
/*      */             Insets insets1 = jComponent1.getInsets();
/*      */             k = jComponent1.getY() + insets1.top;
/*      */             byte b = syntheticaTitlePane.clipMenuBarWidth() ? jComponent1.getX() : (bool ? jComponent1.getX() : 0);
/*      */             int m = syntheticaTitlePane.clipMenuBarWidth() ? (jComponent1.getWidth() - insets1.left - insets1.right) : (bool ? (i - jComponent1.getX()) : (jComponent1.getX() + jComponent1.getWidth()));
/*      */             jMenuBar.setBounds(b + insets1.left, k, m, dimension1.height);
/*      */             k += insets1.top + insets1.bottom + dimension1.height;
/*      */             JComponent jComponent2 = syntheticaTitlePane.getUserComponent();
/*      */             if (jComponent2 != null && syntheticaTitlePane.getLayoutStyle() == SyntheticaTitlePane.LayoutStyle.SECONDARYMENU)
/*      */               k += (jComponent2.getPreferredSize()).height; 
/*      */             k = Math.max(k, (dimension == null) ? 0 : dimension.height);
/*      */           } 
/*      */         } else {
/*      */           jMenuBar.setBounds(0, k, i, dimension1.height);
/*      */           k += dimension1.height;
/*      */         } 
/*      */       } 
/*      */       Container container = jRootPane.getContentPane();
/*      */       if (container != null)
/*      */         container.setBounds(0, k, i, (j < k) ? 0 : (j - k)); 
/*      */     }
/*      */   }
/*      */   
/*      */   void snapNext(Window paramWindow) {
/*      */     if (this.snapState == null && !isMaximized(paramWindow)) {
/*      */       this.preSnapBounds = paramWindow.getBounds();
/*      */     } else if (isMaximized(paramWindow) && this.titlePane instanceof SyntheticaTitlePane) {
/*      */       ((SyntheticaTitlePane)this.titlePane).restore();
/*      */       this.snapState = null;
/*      */     } 
/*      */     GraphicsConfiguration graphicsConfiguration = paramWindow.getGraphicsConfiguration();
/*      */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */     byte b;
/*      */     int i;
/*      */     GraphicsDevice[] arrayOfGraphicsDevice;
/*      */     for (i = (arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices()).length, b = 0; b < i; ) {
/*      */       GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/*      */       GraphicsConfiguration graphicsConfiguration1 = graphicsDevice.getDefaultConfiguration();
/*      */       if (graphicsConfiguration == graphicsConfiguration1 && this.snapState == SnapState.SNAP_LEFT) {
/*      */         restoreSnappedWindow(paramWindow, graphicsConfiguration1, true);
/*      */         break;
/*      */       } 
/*      */       if (this.snapState == SnapState.SNAP_RIGHT) {
/*      */         Rectangle rectangle = getMultiScreenBounds();
/*      */         boolean bool1 = ((graphicsConfiguration.getBounds()).x + (graphicsConfiguration.getBounds()).width == rectangle.x + rectangle.width) ? true : false;
/*      */         boolean bool2 = ((graphicsConfiguration1.getBounds()).x == rectangle.x) ? true : false;
/*      */         if ((bool1 && bool2) || (graphicsConfiguration1.getBounds()).x > (graphicsConfiguration.getBounds()).x + (graphicsConfiguration.getBounds()).width - 1) {
/*      */           snapLeft(graphicsConfiguration1, paramWindow);
/*      */           break;
/*      */         } 
/*      */       } else if (graphicsConfiguration == graphicsConfiguration1) {
/*      */         snapRight(graphicsConfiguration1, paramWindow);
/*      */         break;
/*      */       } 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   void snapPrev(Window paramWindow) {
/*      */     if (this.snapState == null && !isMaximized(paramWindow)) {
/*      */       this.preSnapBounds = paramWindow.getBounds();
/*      */     } else if (isMaximized(paramWindow) && this.titlePane instanceof SyntheticaTitlePane) {
/*      */       ((SyntheticaTitlePane)this.titlePane).restore();
/*      */       this.snapState = null;
/*      */     } 
/*      */     GraphicsConfiguration graphicsConfiguration = paramWindow.getGraphicsConfiguration();
/*      */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */     byte b;
/*      */     int i;
/*      */     GraphicsDevice[] arrayOfGraphicsDevice;
/*      */     for (i = (arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices()).length, b = 0; b < i; ) {
/*      */       GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/*      */       GraphicsConfiguration graphicsConfiguration1 = graphicsDevice.getDefaultConfiguration();
/*      */       if (graphicsConfiguration == graphicsConfiguration1 && this.snapState == SnapState.SNAP_RIGHT) {
/*      */         restoreSnappedWindow(paramWindow, graphicsConfiguration1, true);
/*      */         break;
/*      */       } 
/*      */       if (this.snapState == SnapState.SNAP_LEFT) {
/*      */         Rectangle rectangle = getMultiScreenBounds();
/*      */         boolean bool1 = ((graphicsConfiguration.getBounds()).x == rectangle.x) ? true : false;
/*      */         boolean bool2 = ((graphicsConfiguration1.getBounds()).x + (graphicsConfiguration1.getBounds()).width == rectangle.x + rectangle.width) ? true : false;
/*      */         if ((bool1 && bool2) || (graphicsConfiguration1.getBounds()).x + (graphicsConfiguration1.getBounds()).width - 1 < (graphicsConfiguration.getBounds()).x) {
/*      */           snapRight(graphicsConfiguration1, paramWindow);
/*      */           break;
/*      */         } 
/*      */       } else if (graphicsConfiguration == graphicsConfiguration1) {
/*      */         snapLeft(graphicsConfiguration1, paramWindow);
/*      */         break;
/*      */       } 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void snapLeft(GraphicsConfiguration paramGraphicsConfiguration, Window paramWindow) {
/*      */     this.snapState = SnapState.SNAP_LEFT;
/*      */     Rectangle rectangle = getMaximizedBounds(paramGraphicsConfiguration, true, true);
/*      */     rectangle.width /= 2;
/*      */     paramWindow.setBounds(justifySnapBounds(rectangle, this.snapState));
/*      */   }
/*      */   
/*      */   private void snapRight(GraphicsConfiguration paramGraphicsConfiguration, Window paramWindow) {
/*      */     this.snapState = SnapState.SNAP_RIGHT;
/*      */     Rectangle rectangle = getMaximizedBounds(paramGraphicsConfiguration, true, true);
/*      */     rectangle.width /= 2;
/*      */     rectangle.x += rectangle.width;
/*      */     paramWindow.setBounds(justifySnapBounds(rectangle, this.snapState));
/*      */   }
/*      */   
/*      */   void restoreSnappedWindow(Window paramWindow, GraphicsConfiguration paramGraphicsConfiguration, boolean paramBoolean) {
/*      */     if (this.preSnapBounds != null) {
/*      */       if (paramBoolean) {
/*      */         Rectangle rectangle = getMaximizedBounds(paramGraphicsConfiguration, true, true);
/*      */         if (rectangle.intersects(this.preSnapBounds)) {
/*      */           paramWindow.setLocation(this.preSnapBounds.x, this.preSnapBounds.y);
/*      */         } else {
/*      */           Rectangle rectangle1 = toRelativeScreenBounds(this.preSnapBounds);
/*      */           paramWindow.setLocation(Math.max(rectangle.x, Math.min(rectangle.x + rectangle.width - rectangle1.width, rectangle.x + rectangle1.x)), Math.max(rectangle.y, Math.min(rectangle.y + rectangle.height - rectangle1.height, rectangle.y + rectangle1.y)));
/*      */         } 
/*      */       } 
/*      */       paramWindow.setSize(this.preSnapBounds.width, this.preSnapBounds.height);
/*      */     } 
/*      */     this.snapState = null;
/*      */   }
/*      */   
/*      */   private Rectangle toRelativeScreenBounds(Rectangle paramRectangle) {
/*      */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */     byte b;
/*      */     int i;
/*      */     GraphicsDevice[] arrayOfGraphicsDevice;
/*      */     for (i = (arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices()).length, b = 0; b < i; ) {
/*      */       GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/*      */       GraphicsConfiguration graphicsConfiguration = graphicsDevice.getDefaultConfiguration();
/*      */       Rectangle rectangle1 = graphicsConfiguration.getBounds();
/*      */       Rectangle rectangle2 = new Rectangle(paramRectangle.x - rectangle1.x, paramRectangle.y - rectangle1.y, paramRectangle.width, paramRectangle.height);
/*      */       if (rectangle1.intersects(paramRectangle))
/*      */         return rectangle2; 
/*      */       b++;
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   private Rectangle getMultiScreenBounds() {
/*      */     Rectangle rectangle = new Rectangle();
/*      */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */     byte b;
/*      */     int i;
/*      */     GraphicsDevice[] arrayOfGraphicsDevice;
/*      */     for (i = (arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices()).length, b = 0; b < i; ) {
/*      */       GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/*      */       rectangle = rectangle.union(graphicsDevice.getDefaultConfiguration().getBounds());
/*      */       b++;
/*      */     } 
/*      */     return rectangle;
/*      */   }
/*      */   
/*      */   private Rectangle justifySnapBounds(Rectangle paramRectangle, SnapState paramSnapState) {
/*      */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.snap.insets", this.window, false);
/*      */     Rectangle rectangle = new Rectangle(paramRectangle);
/*      */     switch (paramSnapState) {
/*      */       case SNAP_LEFT:
/*      */         rectangle.x -= insets.left;
/*      */         rectangle.y -= insets.top;
/*      */         rectangle.width += insets.left;
/*      */         rectangle.height += insets.top + insets.bottom;
/*      */         break;
/*      */       case SNAP_RIGHT:
/*      */         rectangle.y -= insets.top;
/*      */         rectangle.width += insets.right;
/*      */         rectangle.height += insets.top + insets.bottom;
/*      */         break;
/*      */       case SNAP_HEIGHT:
/*      */         rectangle.y -= insets.top;
/*      */         rectangle.height += insets.top + insets.bottom;
/*      */         break;
/*      */     } 
/*      */     return rectangle;
/*      */   }
/*      */   
/*      */   boolean isSnapEnabled(Window paramWindow) {
/*      */     boolean bool = true;
/*      */     if (JavaVersion.JAVA7_OR_ABOVE && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.snap.translucencyCheck.enabled", null, false)) {
/*      */       GraphicsConfiguration graphicsConfiguration = paramWindow.getGraphicsConfiguration();
/*      */       try {
/*      */         Method method = GraphicsConfiguration.class.getMethod("isTranslucencyCapable", new Class[0]);
/*      */         Object object = method.invoke(graphicsConfiguration, null);
/*      */         bool = (object instanceof Boolean) ? ((Boolean)object).booleanValue() : false;
/*      */       } catch (Exception exception) {
/*      */         throw new RuntimeException(exception);
/*      */       } 
/*      */     } 
/*      */     return (bool && paramWindow instanceof Frame && ((Frame)paramWindow).isResizable() && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.snap.enabled", this.window, true));
/*      */   }
/*      */   
/*      */   private boolean isMaximized(Window paramWindow) {
/*      */     return (paramWindow instanceof Frame && (((Frame)paramWindow).getExtendedState() & 0x6) == 6);
/*      */   }
/*      */   
/*      */   private class AWTMouseInputHandler implements AWTEventListener {
/*      */     private AWTMouseInputHandler() {}
/*      */     
/*      */     public void eventDispatched(AWTEvent param1AWTEvent) {
/*      */       Object object = param1AWTEvent.getSource();
/*      */       if (object instanceof Component) {
/*      */         Component component = (Component)object;
/*      */         Window window = (component instanceof Window) ? (Window)component : SwingUtilities.getWindowAncestor(component);
/*      */         if (SyntheticaRootPaneUI.this.window != window || !(param1AWTEvent instanceof MouseEvent) || SyntheticaRootPaneUI.this.rootPane == null)
/*      */           return; 
/*      */         SyntheticaRootPaneUI.this.mouseEventProcessor.process(SyntheticaRootPaneUI.this.rootPane, (MouseEvent)param1AWTEvent);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public static class MouseEventProcessor {
/*      */     public void process(JRootPane param1JRootPane, MouseEvent param1MouseEvent) {
/* 1909 */       Component component = param1MouseEvent.getComponent();
/* 1910 */       int i = param1MouseEvent.getID();
/* 1912 */       boolean bool1 = (SwingUtilities.getAncestorOfClass(SyntheticaTitlePane.class, component) != null) ? true : false;
/* 1913 */       if (component.getCursor() != Cursor.getDefaultCursor() && (bool1 || component instanceof javax.swing.MenuElement)) {
/* 1915 */         Window window = SwingUtilities.getWindowAncestor(param1JRootPane);
/* 1916 */         window.setCursor(Cursor.getDefaultCursor());
/*      */       } 
/* 1919 */       boolean bool2 = (!bool1 && !(component instanceof javax.swing.MenuElement)) ? false : true;
/* 1920 */       if (bool2)
/*      */         return; 
/* 1923 */       MouseInputListener mouseInputListener = ((SyntheticaRootPaneUI)param1JRootPane.getUI()).getMouseInputListener();
/* 1924 */       if (mouseInputListener == null)
/*      */         return; 
/* 1927 */       if (i == 500) {
/* 1928 */         mouseInputListener.mouseClicked(param1MouseEvent);
/* 1929 */       } else if (i == 506) {
/* 1930 */         mouseInputListener.mouseDragged(param1MouseEvent);
/* 1931 */       } else if (i == 504) {
/* 1932 */         mouseInputListener.mouseEntered(param1MouseEvent);
/* 1933 */       } else if (i == 505) {
/* 1934 */         mouseInputListener.mouseExited(param1MouseEvent);
/* 1935 */       } else if (i == 503) {
/* 1936 */         mouseInputListener.mouseMoved(param1MouseEvent);
/* 1937 */       } else if (i == 501) {
/* 1938 */         mouseInputListener.mousePressed(param1MouseEvent);
/* 1939 */       } else if (i == 502) {
/* 1940 */         mouseInputListener.mouseReleased(param1MouseEvent);
/*      */       } 
/* 1942 */       if (mouseInputListener instanceof SyntheticaRootPaneUI.MouseInputHandler && ((SyntheticaRootPaneUI.MouseInputHandler)mouseInputListener).isResizing())
/* 1943 */         param1MouseEvent.consume(); 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaRootPaneUI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */