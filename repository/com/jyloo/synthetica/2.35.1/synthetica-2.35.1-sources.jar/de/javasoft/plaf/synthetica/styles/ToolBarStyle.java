/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ContainerEvent;
/*     */ import java.awt.event.ContainerListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class ToolBarStyle extends StyleWrapper {
/*     */   private static final String ORG_FILLERS = "Synthetica.toolBarStyle.orgFillers";
/*     */   
/*     */   private static final String ORG_X_ALIGNMENTS = "Synthetica.toolBarStyle.orgXAlignments";
/*     */   
/*     */   private static final String ORG_Y_ALIGNMENTS = "Synthetica.toolBarStyle.orgYAlignments";
/*     */   
/*     */   private static final String ORG_MARGIN = "Synthetica.toolBarStyle.orgMargin";
/*     */   
/*     */   private static final String ORG_LAYOUT_MANAGER = "Synthetica.toolBarStyle.orgLayoutManager";
/*     */   
/*     */   private static final String ORIENTATION_LISTENER = "Synthetica.toolBarStyle.orientationListener";
/*     */   
/*     */   private static final String CONTAINER_LISTENER = "Synthetica.toolBarStyle.containerListener";
/*     */   
/*  54 */   private static ToolBarStyle instance = new ToolBarStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  62 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  64 */       instance.setStyle(paramSynthStyle);
/*  65 */       return instance;
/*     */     } 
/*  67 */     ToolBarStyle toolBarStyle = new ToolBarStyle();
/*  68 */     toolBarStyle.setStyle(paramSynthStyle);
/*  69 */     return toolBarStyle;
/*     */   }
/*     */   
/*     */   public void installDefaults(SynthContext paramSynthContext) {
/*  76 */     this.synthStyle.installDefaults(paramSynthContext);
/*  78 */     JToolBar jToolBar = (JToolBar)paramSynthContext.getComponent();
/*  79 */     if (jToolBar.getClientProperty("Synthetica.toolBarStyle.orgFillers") == null)
/*  80 */       jToolBar.putClientProperty("Synthetica.toolBarStyle.orgFillers", new HashMap<Object, Object>()); 
/*  81 */     HashMap<Integer, Component> hashMap = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgFillers");
/*  83 */     if (jToolBar.getClientProperty("Synthetica.toolBarStyle.orgXAlignments") == null)
/*  84 */       jToolBar.putClientProperty("Synthetica.toolBarStyle.orgXAlignments", new HashMap<Object, Object>()); 
/*  85 */     HashMap<Component, Float> hashMap1 = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgXAlignments");
/*  87 */     if (jToolBar.getClientProperty("Synthetica.toolBarStyle.orgYAlignments") == null)
/*  88 */       jToolBar.putClientProperty("Synthetica.toolBarStyle.orgYAlignments", new HashMap<Object, Object>()); 
/*  89 */     HashMap<Component, Float> hashMap2 = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgYAlignments");
/* 100 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgLayoutManager", jToolBar.getLayout());
/* 101 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgMargin", jToolBar.getMargin());
/* 102 */     jToolBar.addPropertyChangeListener(getOrientationListener(jToolBar));
/* 105 */     Component[] arrayOfComponent = jToolBar.getComponents();
/* 106 */     for (byte b = 0; b < arrayOfComponent.length; b++) {
/* 108 */       Component component = arrayOfComponent[b];
/* 109 */       hashMap1.put(component, Float.valueOf(component.getAlignmentX()));
/* 110 */       hashMap2.put(component, Float.valueOf(component.getAlignmentY()));
/* 111 */       if (component instanceof Box.Filler)
/* 112 */         hashMap.put(Integer.valueOf(b), component); 
/* 114 */       ((JComponent)component).setAlignmentX(0.5F);
/* 115 */       ((JComponent)component).setAlignmentY(0.5F);
/*     */     } 
/* 119 */     jToolBar.addContainerListener(getContainerListener(jToolBar));
/* 120 */     setLayoutManager(jToolBar);
/*     */   }
/*     */   
/*     */   private PropertyChangeListener getOrientationListener(final JToolBar toolBar) {
/* 125 */     PropertyChangeListener propertyChangeListener = (PropertyChangeListener)toolBar.getClientProperty("Synthetica.toolBarStyle.orientationListener");
/* 126 */     if (propertyChangeListener == null) {
/* 128 */       propertyChangeListener = new PropertyChangeListener() {
/*     */           public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 132 */             String str = param1PropertyChangeEvent.getPropertyName();
/* 133 */             if (str.equals("orientation")) {
/* 135 */               ToolBarStyle.this.setLayoutManager(toolBar);
/* 139 */             } else if (str.equals("floatable")) {
/* 141 */               ToolBarStyle.this.setMargin(toolBar, ((Boolean)param1PropertyChangeEvent.getNewValue()).booleanValue());
/* 143 */             } else if (str.equals("componentOrientation")) {
/* 145 */               ToolBarStyle.this.setMargin(toolBar, toolBar.isFloatable());
/*     */             } 
/*     */           }
/*     */         };
/* 149 */       toolBar.putClientProperty("Synthetica.toolBarStyle.orientationListener", propertyChangeListener);
/*     */     } 
/* 151 */     return propertyChangeListener;
/*     */   }
/*     */   
/*     */   private ContainerListener getContainerListener(final JToolBar toolBar) {
/* 156 */     ContainerListener containerListener = (ContainerListener)toolBar.getClientProperty("Synthetica.toolBarStyle.containerListener");
/* 157 */     if (containerListener == null) {
/* 159 */       containerListener = new ContainerListener() {
/*     */           public void componentAdded(ContainerEvent param1ContainerEvent) {
/* 164 */             HashMap<Integer, Component> hashMap = (HashMap)toolBar.getClientProperty("Synthetica.toolBarStyle.orgFillers");
/* 165 */             HashMap<Component, Float> hashMap1 = (HashMap)toolBar.getClientProperty("Synthetica.toolBarStyle.orgXAlignments");
/* 166 */             HashMap<Component, Float> hashMap2 = (HashMap)toolBar.getClientProperty("Synthetica.toolBarStyle.orgYAlignments");
/* 168 */             Component component = param1ContainerEvent.getChild();
/* 169 */             hashMap1.put(component, Float.valueOf(component.getAlignmentX()));
/* 170 */             hashMap2.put(component, Float.valueOf(component.getAlignmentY()));
/* 171 */             if (component instanceof Box.Filler)
/* 172 */               hashMap.put(Integer.valueOf((toolBar.getComponents()).length - 1), component); 
/* 199 */             if (component instanceof JComponent) {
/* 201 */               ((JComponent)component).setAlignmentX(0.5F);
/* 202 */               ((JComponent)component).setAlignmentY(0.5F);
/*     */             } 
/*     */           }
/*     */           
/*     */           public void componentRemoved(ContainerEvent param1ContainerEvent) {
/* 209 */             HashMap hashMap1 = (HashMap)toolBar.getClientProperty("Synthetica.toolBarStyle.orgXAlignments");
/* 210 */             hashMap1.remove(param1ContainerEvent.getChild());
/* 212 */             HashMap hashMap2 = (HashMap)toolBar.getClientProperty("Synthetica.toolBarStyle.orgYAlignments");
/* 213 */             hashMap2.remove(param1ContainerEvent.getChild());
/*     */           }
/*     */         };
/* 248 */       toolBar.putClientProperty("Synthetica.toolBarStyle.containerListener", containerListener);
/*     */     } 
/* 250 */     return containerListener;
/*     */   }
/*     */   
/*     */   public void uninstallDefaults(SynthContext paramSynthContext) {
/* 259 */     this.synthStyle.uninstallDefaults(paramSynthContext);
/* 261 */     JToolBar jToolBar = (JToolBar)paramSynthContext.getComponent();
/* 262 */     jToolBar.removePropertyChangeListener(getOrientationListener(jToolBar));
/* 263 */     jToolBar.removeContainerListener(getContainerListener(jToolBar));
/* 265 */     HashMap hashMap1 = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgFillers");
/* 266 */     HashMap hashMap2 = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgXAlignments");
/* 267 */     HashMap hashMap3 = (HashMap)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgYAlignments");
/* 270 */     for (Map.Entry entry : hashMap1.entrySet()) {
/* 273 */       int i = ((Integer)entry.getKey()).intValue();
/* 275 */       Component component = (Component)entry.getValue();
/* 276 */       jToolBar.remove(i);
/* 277 */       jToolBar.add(component, i);
/*     */     } 
/* 281 */     for (Map.Entry entry : hashMap2.entrySet()) {
/* 284 */       JComponent jComponent = (JComponent)entry.getKey();
/* 285 */       float f = ((Float)entry.getValue()).floatValue();
/* 286 */       jComponent.setAlignmentX(f);
/*     */     } 
/* 289 */     for (Map.Entry entry : hashMap3.entrySet()) {
/* 292 */       JComponent jComponent = (JComponent)entry.getKey();
/* 293 */       float f = ((Float)entry.getValue()).floatValue();
/* 294 */       jComponent.setAlignmentY(f);
/*     */     } 
/* 297 */     jToolBar.setMargin((Insets)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgMargin"));
/* 298 */     jToolBar.setLayout((LayoutManager)jToolBar.getClientProperty("Synthetica.toolBarStyle.orgLayoutManager"));
/* 300 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgFillers", (Object)null);
/* 301 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgXAlignments", (Object)null);
/* 302 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgYAlignments", (Object)null);
/* 303 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgMargin", (Object)null);
/* 304 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orgLayoutManager", (Object)null);
/* 305 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.orientationListener", (Object)null);
/* 306 */     jToolBar.putClientProperty("Synthetica.toolBarStyle.containerListener", (Object)null);
/*     */   }
/*     */   
/*     */   private void setLayoutManager(JToolBar paramJToolBar) {
/* 314 */     if (useSynthLayout(paramJToolBar))
/*     */       return; 
/* 317 */     HashMap hashMap = (HashMap)paramJToolBar.getClientProperty("Synthetica.toolBarStyle.orgFillers");
/* 319 */     paramJToolBar.removeContainerListener(getContainerListener(paramJToolBar));
/* 320 */     Component[] arrayOfComponent = paramJToolBar.getComponents();
/* 321 */     SyntheticaToolBarLayout syntheticaToolBarLayout = null;
/* 322 */     if (paramJToolBar.getOrientation() == 0) {
/* 324 */       syntheticaToolBarLayout = new SyntheticaToolBarLayout(paramJToolBar, 2);
/*     */       byte b;
/* 325 */       for (b = 0; b < arrayOfComponent.length; b++) {
/* 327 */         if (arrayOfComponent[b] instanceof Box.Filler && fillerIsGlue((Box.Filler)arrayOfComponent[b])) {
/* 329 */           paramJToolBar.remove(arrayOfComponent[b]);
/* 330 */           paramJToolBar.add(Box.createHorizontalGlue(), b);
/* 332 */         } else if (arrayOfComponent[b] instanceof Box.Filler && !fillerIsGlue((Box.Filler)arrayOfComponent[b])) {
/* 334 */           paramJToolBar.remove(arrayOfComponent[b]);
/* 335 */           Component component = (Component)hashMap.get(Integer.valueOf(b));
/* 336 */           Dimension dimension = component.getPreferredSize();
/* 338 */           int i = Math.max(dimension.width, dimension.height);
/* 339 */           paramJToolBar.add(Box.createHorizontalStrut(i), b);
/*     */         } 
/*     */       } 
/* 342 */       setMargin(paramJToolBar, paramJToolBar.isFloatable());
/* 343 */       for (b = 0; b < arrayOfComponent.length; b++)
/* 344 */         ((JComponent)arrayOfComponent[b]).setAlignmentY(0.5F); 
/*     */     } else {
/* 348 */       syntheticaToolBarLayout = new SyntheticaToolBarLayout(paramJToolBar, 3);
/*     */       byte b;
/* 349 */       for (b = 0; b < arrayOfComponent.length; b++) {
/* 351 */         if (arrayOfComponent[b] instanceof Box.Filler && fillerIsGlue((Box.Filler)arrayOfComponent[b])) {
/* 353 */           paramJToolBar.remove(arrayOfComponent[b]);
/* 354 */           paramJToolBar.add(Box.createVerticalGlue(), b);
/* 356 */         } else if (arrayOfComponent[b] instanceof Box.Filler && !fillerIsGlue((Box.Filler)arrayOfComponent[b])) {
/* 358 */           paramJToolBar.remove(arrayOfComponent[b]);
/* 359 */           Component component = (Component)hashMap.get(Integer.valueOf(b));
/* 360 */           Dimension dimension = component.getPreferredSize();
/* 362 */           int i = Math.max(dimension.width, dimension.height);
/* 363 */           paramJToolBar.add(Box.createVerticalStrut(i), b);
/*     */         } 
/*     */       } 
/* 366 */       setMargin(paramJToolBar, paramJToolBar.isFloatable());
/* 367 */       for (b = 0; b < arrayOfComponent.length; b++)
/* 368 */         ((JComponent)arrayOfComponent[b]).setAlignmentX(0.5F); 
/*     */     } 
/* 370 */     LayoutManager layoutManager = paramJToolBar.getLayout();
/* 371 */     if (layoutManager != null && (layoutManager.getClass().getName().contains("SynthToolBar") || layoutManager instanceof SyntheticaToolBarLayout))
/* 372 */       paramJToolBar.setLayout(syntheticaToolBarLayout); 
/* 373 */     paramJToolBar.addContainerListener(getContainerListener(paramJToolBar));
/*     */   }
/*     */   
/*     */   private void setMargin(JToolBar paramJToolBar, boolean paramBoolean) {
/* 380 */     if (useSynthLayout(paramJToolBar))
/*     */       return; 
/* 383 */     Insets insets1 = null;
/* 384 */     if (paramJToolBar.getOrientation() == 0) {
/* 386 */       insets1 = (Insets)SyntheticaLookAndFeel.getInsets("Synthetica.toolBar.margin.horizontal", paramJToolBar).clone();
/* 387 */       if (paramBoolean && paramJToolBar.getComponentOrientation().isLeftToRight()) {
/* 388 */         insets1.left += SyntheticaLookAndFeel.getInt("Synthetica.toolBar.handle.size", paramJToolBar, 0);
/* 389 */       } else if (paramBoolean) {
/* 390 */         insets1.right += SyntheticaLookAndFeel.getInt("Synthetica.toolBar.handle.size", paramJToolBar, 0);
/*     */       } 
/*     */     } else {
/* 394 */       insets1 = (Insets)SyntheticaLookAndFeel.getInsets("Synthetica.toolBar.margin.vertical", paramJToolBar).clone();
/* 395 */       if (paramBoolean)
/* 396 */         insets1.top += SyntheticaLookAndFeel.getInt("Synthetica.toolBar.handle.size", paramJToolBar, 0); 
/*     */     } 
/* 398 */     Insets insets2 = (Insets)paramJToolBar.getClientProperty("Synthetica.toolBarStyle.orgMargin");
/* 399 */     if (insets2 != null && insets1 != null) {
/* 401 */       insets1.bottom += insets2.bottom;
/* 402 */       insets1.left += insets2.left;
/* 403 */       insets1.top += insets2.top;
/* 404 */       insets1.right += insets2.right;
/* 405 */       paramJToolBar.setMargin(insets1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean useSynthLayout(JComponent paramJComponent) {
/* 412 */     return SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.useSynthLayoutManager", paramJComponent, JavaVersion.JAVA5 ? false : false);
/*     */   }
/*     */   
/*     */   private boolean fillerIsGlue(Box.Filler paramFiller) {
/* 419 */     Dimension dimension = new Dimension(0, 0);
/* 420 */     if (paramFiller.getMinimumSize().equals(dimension) && paramFiller.getPreferredSize().equals(dimension))
/* 421 */       return true; 
/* 422 */     return false;
/*     */   }
/*     */   
/*     */   private static class SyntheticaToolBarLayout extends BoxLayout {
/*     */     private static final long serialVersionUID = 6806218476946368742L;
/*     */     
/*     */     SyntheticaToolBarLayout(Container param1Container, int param1Int) {
/* 430 */       super(param1Container, param1Int);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ToolBarStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */