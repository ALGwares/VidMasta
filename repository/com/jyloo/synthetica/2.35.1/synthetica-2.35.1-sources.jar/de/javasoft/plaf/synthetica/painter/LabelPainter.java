/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.GraphicsUtils;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.lang.reflect.Field;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ 
/*     */ public class LabelPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.LabelPainter";
/*     */   
/*     */   private static boolean cellRendererSelectionBackgroundEnabled;
/*     */   
/*     */   private static boolean listSelectionBackgroundEnabled;
/*     */   
/*     */   private static boolean treeSelectionBackgroundEnabled;
/*     */   
/*     */   private static boolean tableSelectionBackgroundEnabled;
/*     */   
/*     */   private static SynthStyle listStyle;
/*     */   
/*     */   private static int listHash;
/*     */   
/*     */   private static SynthStyle treeStyle;
/*     */   
/*     */   private static int treeHash;
/*     */   
/*     */   private static SynthStyle tableStyle;
/*     */   
/*     */   private static int tableHash;
/*     */   
/*     */   public static LabelPainter getInstance() {
/*  70 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static LabelPainter getInstance(SynthContext paramSynthContext) {
/*  79 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, LabelPainter.class, "Synthetica.LabelPainter"));
/*  80 */     if (syntheticaComponentPainter == null)
/*  81 */       syntheticaComponentPainter = getInstance(paramSynthContext, LabelPainter.class, "Synthetica.LabelPainter"); 
/*  82 */     return (LabelPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public static void reinitialize() {
/*  87 */     cellRendererSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.selectionBackground.enabled", null, false);
/*  88 */     listSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.list.labelCellRenderer.selectionBackground.enabled", null, true);
/*  89 */     treeSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.tree.labelCellRenderer.selectionBackground.enabled", null, true);
/*  90 */     tableSelectionBackgroundEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.table.labelCellRenderer.selectionBackground.enabled", null, true);
/*  91 */     listHash = 0;
/*  92 */     treeHash = 0;
/*  93 */     tableHash = 0;
/*     */   }
/*     */   
/*     */   public void paintLabelBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintLabelBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 105 */     JLabel jLabel = (JLabel)paramSynthContext.getComponent();
/* 106 */     Container container1 = jLabel.getParent();
/* 107 */     Container container2 = (container1 == null) ? null : container1.getParent();
/* 108 */     String str = jLabel.getName();
/* 111 */     if (container1 instanceof javax.swing.CellRendererPane)
/* 114 */       if (str != null && str.startsWith("ComboBox.") && !(container2 instanceof JComboBox)) {
/* 116 */         if (cellRendererSelectionBackgroundEnabled && container2 instanceof JComponent) {
/* 118 */           JComponent jComponent = (JComponent)container2;
/* 119 */           SynthStyle synthStyle = SynthLookAndFeel.getStyle(jComponent, Region.LIST);
/* 120 */           SynthContext synthContext = new SynthContext(jComponent, Region.LIST, synthStyle, 512);
/* 121 */           String str1 = SyntheticaLookAndFeel.getString("Synthetica.comboBox.listSelectionBackground", jLabel);
/* 122 */           if (str1 != null && jLabel.getBackground().equals(synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND))) {
/* 124 */             Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.comboBox.listSelectionBackground.insets", jLabel, false);
/* 125 */             ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str1, insets, insets, 0, 0);
/* 126 */             imagePainter.draw();
/*     */           } else {
/* 130 */             Color color = paramGraphics.getColor();
/* 131 */             paramGraphics.setColor(jLabel.getBackground());
/* 132 */             paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 133 */             paramGraphics.setColor(color);
/*     */           } 
/*     */         } else {
/* 138 */           Color color = paramGraphics.getColor();
/* 139 */           paramGraphics.setColor(jLabel.getBackground());
/* 140 */           paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 141 */           paramGraphics.setColor(color);
/*     */         } 
/* 145 */       } else if (cellRendererSelectionBackgroundEnabled && listSelectionBackgroundEnabled && (isListCellRenderer(str) || JAVA5) && container2 instanceof JList) {
/* 147 */         JList jList = (JList)container2;
/* 148 */         int i = getHashCode(jList);
/* 149 */         if (i != listHash) {
/* 151 */           listHash = i;
/* 152 */           listStyle = SynthLookAndFeel.getStyle(jList, Region.LIST);
/*     */         } 
/* 154 */         SynthStyle synthStyle = listStyle;
/* 155 */         SynthContext synthContext = new SynthContext(jList, Region.LIST, synthStyle, 512);
/* 156 */         if (jLabel.getBackground().equals(synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND)))
/* 157 */           ((GraphicsUtils)synthStyle.getGraphicsUtils(synthContext)).paintListCellRendererSelectionBackground(jList, jLabel, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 160 */       } else if (cellRendererSelectionBackgroundEnabled && treeSelectionBackgroundEnabled && (isTreeCellRenderer(str) || JAVA5) && container2 instanceof JTree && jLabel instanceof DefaultTreeCellRenderer) {
/* 162 */         JTree jTree = (JTree)container2;
/* 163 */         int i = getHashCode(jTree);
/* 164 */         if (i != treeHash) {
/* 166 */           treeHash = i;
/* 167 */           treeStyle = SynthLookAndFeel.getStyle(jTree, Region.TREE);
/*     */         } 
/* 169 */         SynthStyle synthStyle = treeStyle;
/* 170 */         SynthContext synthContext = new SynthContext(jTree, Region.TREE, synthStyle, 512);
/*     */         try {
/* 173 */           Field field = DefaultTreeCellRenderer.class.getDeclaredField("selected");
/* 174 */           field.setAccessible(true);
/* 175 */           boolean bool = ((Boolean)field.get(jLabel)).booleanValue();
/* 176 */           if (bool)
/* 177 */             ((GraphicsUtils)synthStyle.getGraphicsUtils(synthContext)).paintTreeCellRendererSelectionBackground(jTree, jLabel, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 179 */         } catch (Exception exception) {
/* 181 */           throw new RuntimeException(exception);
/*     */         } 
/* 184 */       } else if (cellRendererSelectionBackgroundEnabled && tableSelectionBackgroundEnabled && "Table.cellRenderer".equals(str) && container2 instanceof JTable) {
/* 186 */         JTable jTable = (JTable)container2;
/* 187 */         int i = getHashCode(jTable);
/* 188 */         if (i != tableHash) {
/* 190 */           tableHash = i;
/* 191 */           tableStyle = SynthLookAndFeel.getStyle(jTable, Region.TABLE);
/*     */         } 
/* 193 */         SynthStyle synthStyle = tableStyle;
/* 194 */         SynthContext synthContext = new SynthContext(jTable, Region.TABLE, synthStyle, 512);
/* 195 */         if (jLabel.getBackground().equals(synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND)))
/* 196 */           ((GraphicsUtils)synthStyle.getGraphicsUtils(synthContext)).paintTableCellRendererSelectionBackground(jTable, jLabel, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 198 */       } else if (((str != null && str.startsWith("TableHeader.")) || "Table.cellRenderer".equals(str)) && container2 instanceof JTableHeader) {
/* 200 */         JTableHeader jTableHeader = (JTableHeader)container2;
/* 201 */         if (SyntheticaLookAndFeel.getBoolean("Synthetica.tableHeader.forceFontUpdate", jTableHeader, false))
/* 202 */           jLabel.setFont(jTableHeader.getFont()); 
/* 203 */         if (SyntheticaLookAndFeel.getBoolean("Synthetica.tableHeader.showVerticalGrid", jTableHeader, true)) {
/* 205 */           Color color1 = paramGraphics.getColor();
/* 206 */           Color color2 = SyntheticaLookAndFeel.getColor("Synthetica.tableHeader.gridColor", jTableHeader);
/* 207 */           paramGraphics.setColor(color2);
/* 208 */           paramGraphics.drawLine(paramInt1 + paramInt3 - 1, paramInt2, paramInt1 + paramInt3 - 1, paramInt2 + paramInt4 - 1);
/* 209 */           paramGraphics.setColor(color1);
/*     */         } 
/*     */         return;
/*     */       }  
/* 215 */     if (container1 instanceof javax.swing.CellRendererPane && container2 instanceof JComboBox) {
/* 217 */       JComboBox jComboBox = (JComboBox)container2;
/* 218 */       boolean bool = SyntheticaLookAndFeel.isOpaque(jComboBox);
/* 219 */       Color color = (SyntheticaLookAndFeel.get("Synthetica.comboBox.border.locked", jComboBox) == null) ? (color = SyntheticaLookAndFeel.getColor("Synthetica.comboBox.focused.backgroundColor", jComboBox)) : null;
/* 222 */       if ((jComboBox.isEnabled() && !jComboBox.isEditable() && color == null) || (bool && color == null))
/*     */         return; 
/* 225 */       if (jComboBox.hasFocus() && !jComboBox.isEditable()) {
/* 227 */         if (!(jComboBox.getBackground() instanceof javax.swing.plaf.UIResource) && SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.useBackgroundColorAsFocus", jComboBox, false))
/*     */           return; 
/* 229 */         Color color1 = paramGraphics.getColor();
/* 230 */         paramGraphics.setColor(color);
/* 231 */         paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 232 */         paramGraphics.setColor(color1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isListCellRenderer(String paramString) {
/* 239 */     return (paramString == null) ? false : paramString.startsWith("List.cellRenderer");
/*     */   }
/*     */   
/*     */   private boolean isTreeCellRenderer(String paramString) {
/* 244 */     return (paramString == null) ? false : paramString.startsWith("Tree.cellRenderer");
/*     */   }
/*     */   
/*     */   private int getHashCode(JComponent paramJComponent) {
/* 249 */     int i = paramJComponent.hashCode();
/* 250 */     String str = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/* 251 */     if (str == null)
/* 252 */       return i; 
/* 253 */     return 31 * i + str.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\LabelPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */