/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Paint;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Window;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Area;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ class SyntheticaComponentPainter implements Cacheable {
/*  44 */   static final boolean JAVA5 = JavaVersion.JAVA5;
/*     */   
/*  45 */   static final boolean JAVA6 = JavaVersion.JAVA6;
/*     */   
/*  46 */   static final boolean JAVA7U8_OR_ABOVE = JavaVersion.JAVA7U8_OR_ABOVE;
/*     */   
/*     */   private Object antialiasing_old;
/*     */   
/*     */   private Object strokeControl_old;
/*     */   
/*     */   private AffineTransform at_old;
/*     */   
/*     */   private Paint paint_old;
/*     */   
/*     */   private Stroke stroke_old;
/*     */   
/*  54 */   private static final boolean OS_X_QUARTZ_ENABLED = SyntheticaLookAndFeel.isSystemPropertySet("apple.awt.graphics.UseQuartz");
/*     */   
/*  55 */   private static final boolean RESPECT_PARENT_BACKGROUND = SyntheticaLookAndFeel.getBoolean("Synthetica.background.respectParent", null, false);
/*     */   
/*  57 */   protected static HashMap<String, SyntheticaComponentPainter> instances = new HashMap<String, SyntheticaComponentPainter>();
/*     */   
/*     */   protected static SyntheticaComponentPainter getInstance(SynthContext paramSynthContext, Class<?> paramClass, String paramString) {
/*  64 */     SyntheticaComponentPainter syntheticaComponentPainter = null;
/*  65 */     Object object = (paramSynthContext == null) ? UIManager.get(paramString) : SyntheticaLookAndFeel.get(paramString, paramSynthContext.getComponent());
/*     */     try {
/*  69 */       if (object == null && paramClass != null) {
/*  70 */         syntheticaComponentPainter = (SyntheticaComponentPainter)paramClass.newInstance();
/*  73 */       } else if (object == null) {
/*  75 */         String str = paramString.substring(paramString.lastIndexOf('.') + 1);
/*  76 */         syntheticaComponentPainter = (SyntheticaComponentPainter)Class.forName(String.valueOf(SyntheticaComponentPainter.class.getPackage().getName()) + "." + str).newInstance();
/*  79 */       } else if (object instanceof SyntheticaComponentPainter) {
/*  80 */         syntheticaComponentPainter = (SyntheticaComponentPainter)object;
/*  82 */       } else if (object instanceof String) {
/*  83 */         syntheticaComponentPainter = (SyntheticaComponentPainter)Class.forName((String)object).newInstance();
/*     */       } 
/*  85 */     } catch (Exception exception) {
/*  87 */       throw new RuntimeException(exception);
/*     */     } 
/*  89 */     instances.put(syntheticaComponentPainter.getClass().getName(), syntheticaComponentPainter);
/*  90 */     return syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   protected static String getPainterClassName(SynthContext paramSynthContext, Class<?> paramClass, String paramString) {
/*  96 */     Object object = (paramSynthContext == null) ? UIManager.get(paramString) : SyntheticaLookAndFeel.get(paramString, paramSynthContext.getComponent());
/*  97 */     if (object == null)
/*  98 */       return paramClass.getName(); 
/*  99 */     if (object instanceof SyntheticaComponentPainter)
/* 100 */       return object.getClass().getName(); 
/* 101 */     return (String)object;
/*     */   }
/*     */   
/*     */   protected Graphics2D prepareGraphics2D(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, BasicStroke paramBasicStroke) {
/* 122 */     Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 123 */     this.antialiasing_old = graphics2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/* 124 */     this.strokeControl_old = graphics2D.getRenderingHint(RenderingHints.KEY_STROKE_CONTROL);
/* 125 */     this.at_old = graphics2D.getTransform();
/* 126 */     this.paint_old = graphics2D.getPaint();
/* 127 */     this.stroke_old = graphics2D.getStroke();
/* 129 */     if (paramBoolean1)
/* 130 */       graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); 
/* 131 */     graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
/* 133 */     if (paramBasicStroke == null)
/* 134 */       paramBasicStroke = createStroke(paramSynthContext); 
/* 135 */     graphics2D.setStroke(paramBasicStroke);
/* 138 */     if (paramBoolean2) {
/* 140 */       double d1 = (paramInt1 + paramBasicStroke.getLineWidth() / 2.0F);
/* 141 */       double d2 = (paramInt2 + paramBasicStroke.getLineWidth() / 2.0F);
/* 148 */       if (OS.getCurrentOS() == OS.Mac && OS_X_QUARTZ_ENABLED) {
/* 150 */         d1 = Math.round(d1 - 0.5D);
/* 151 */         d2 = Math.round(d2 - 0.5D);
/*     */       } 
/* 153 */       graphics2D.translate(d1, d2);
/*     */     } 
/* 155 */     return graphics2D;
/*     */   }
/*     */   
/*     */   protected Graphics2D prepareGraphics2D(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 168 */     return prepareGraphics2D(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramBoolean, true, (BasicStroke)null);
/*     */   }
/*     */   
/*     */   protected Graphics2D prepareGraphics2D(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
/* 178 */     return prepareGraphics2D(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramBoolean1, paramBoolean2, (BasicStroke)null);
/*     */   }
/*     */   
/*     */   protected Graphics2D prepareGraphics2D(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, BasicStroke paramBasicStroke) {
/* 188 */     return prepareGraphics2D(paramSynthContext, paramGraphics, paramInt1, paramInt2, true, true, paramBasicStroke);
/*     */   }
/*     */   
/*     */   protected Graphics2D prepareGraphics2D(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 198 */     return prepareGraphics2D(paramSynthContext, paramGraphics, paramInt1, paramInt2, true, true, (BasicStroke)null);
/*     */   }
/*     */   
/*     */   protected void restoreGraphics2D(Graphics2D paramGraphics2D) {
/* 206 */     paramGraphics2D.setStroke(this.stroke_old);
/* 207 */     paramGraphics2D.setPaint(this.paint_old);
/* 208 */     paramGraphics2D.setTransform(this.at_old);
/* 209 */     paramGraphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, this.antialiasing_old);
/* 210 */     paramGraphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, this.strokeControl_old);
/*     */   }
/*     */   
/*     */   protected float getScale() {
/* 218 */     return 1.0F;
/*     */   }
/*     */   
/*     */   protected BasicStroke createStroke(SynthContext paramSynthContext) {
/* 226 */     return new BasicStroke(1.0F * getScale());
/*     */   }
/*     */   
/*     */   float scaleArc(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
/* 249 */     float f = Math.min(paramFloat3, paramFloat4);
/* 250 */     if (f < paramFloat2 * getScale()) {
/* 251 */       paramFloat1 = f - (paramFloat2 - paramFloat1) / paramFloat2 * f;
/*     */     } else {
/* 253 */       paramFloat1 = scaleArc(paramFloat1);
/*     */     } 
/* 254 */     return paramFloat1;
/*     */   }
/*     */   
/*     */   protected float scaleArc(float paramFloat) {
/* 265 */     return paramFloat * getScale();
/*     */   }
/*     */   
/*     */   protected float calcRelativeArc(Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2) {
/* 279 */     float f = ((BasicStroke)paramGraphics2D.getStroke()).getLineWidth();
/* 280 */     return paramFloat1 + f * paramFloat2;
/*     */   }
/*     */   
/*     */   protected float calcRelativePos(Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2) {
/* 294 */     float f = ((BasicStroke)paramGraphics2D.getStroke()).getLineWidth();
/* 295 */     return paramFloat1 + f * paramFloat2;
/*     */   }
/*     */   
/*     */   protected float calcRelativeGradientPos(Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2) {
/* 310 */     return calcRelativePos(paramGraphics2D, paramFloat1, paramFloat2) - getScale() / 2.0F;
/*     */   }
/*     */   
/*     */   protected static float calcRelativeLength(Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2) {
/* 324 */     float f = ((BasicStroke)paramGraphics2D.getStroke()).getLineWidth();
/* 325 */     return paramFloat1 + paramFloat2 * f - f;
/*     */   }
/*     */   
/*     */   protected static Shape subtractStroke(Graphics2D paramGraphics2D, Shape paramShape) {
/* 337 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.2D.subtractStrokeEnabled", null))
/* 338 */       return paramShape; 
/* 339 */     Area area1 = new Area(((BasicStroke)paramGraphics2D.getStroke()).createStrokedShape(paramShape));
/* 340 */     Area area2 = new Area(paramShape);
/* 341 */     area2.subtract(area1);
/* 342 */     return area2;
/*     */   }
/*     */   
/*     */   public static Color getSyntheticaBackgroundColor(JComponent paramJComponent) {
/* 356 */     Color color1 = null;
/* 357 */     Color color2 = RESPECT_PARENT_BACKGROUND ? paramJComponent.getBackground() : (paramJComponent.isBackgroundSet() ? paramJComponent.getBackground() : null);
/* 358 */     if (color2 != null && !(color2 instanceof javax.swing.plaf.ColorUIResource))
/* 359 */       color1 = color2; 
/* 360 */     if (paramJComponent.getClientProperty("Synthetica.background") != null)
/* 361 */       color1 = (Color)paramJComponent.getClientProperty("Synthetica.background"); 
/* 362 */     float f = SyntheticaLookAndFeel.getInt("Synthetica.background.alpha", paramJComponent, 10) / 100.0F;
/* 363 */     if (paramJComponent.getClientProperty("Synthetica.background.alpha") != null)
/* 364 */       f = ((Float)paramJComponent.getClientProperty("Synthetica.background.alpha")).floatValue(); 
/* 365 */     byte b = (color1 == null) ? 255 : color1.getAlpha();
/* 366 */     if (b < 'ÿ')
/* 367 */       f = b / 255.0F; 
/* 368 */     return createAlphaColor(color1, Float.valueOf(f));
/*     */   }
/*     */   
/*     */   public static Color createAlphaColor(Color paramColor, Float paramFloat) {
/* 382 */     if (paramColor != null) {
/* 384 */       paramFloat = Float.valueOf((paramFloat == null) ? 0.1F : paramFloat.floatValue());
/* 385 */       int i = paramColor.getRGB();
/* 386 */       if (i >>> 24 < 255)
/* 389 */         i = 0xFF000000 | i; 
/* 391 */       int j = i & ((int)(paramFloat.floatValue() * 255.0F) << 24 | 0xFFFFFF);
/* 392 */       paramColor = new Color(j, true);
/*     */     } 
/* 394 */     return paramColor;
/*     */   }
/*     */   
/*     */   protected Paint createLinearGradientPaint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float[] paramArrayOffloat, Color[] paramArrayOfColor) {
/* 403 */     return SyntheticaLookAndFeel.createLinearGradientPaint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramArrayOffloat, paramArrayOfColor);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 409 */     JComponent jComponent = paramSynthContext.getComponent();
/* 410 */     Border border = jComponent.getBorder();
/* 411 */     Boolean bool = (Boolean)jComponent.getClientProperty("Synthetica.opaque");
/* 412 */     Color color1 = (Color)jComponent.getClientProperty("Synthetica.background");
/* 413 */     Float float_ = (Float)jComponent.getClientProperty("Synthetica.background.alpha");
/* 414 */     Color color2 = jComponent.getBackground();
/* 415 */     String str = SyntheticaLookAndFeel.getStyleName(jComponent);
/* 416 */     Window window = SwingUtilities.getWindowAncestor(jComponent);
/* 418 */     int i = paramString.hashCode();
/* 419 */     if (getCacheScaleType(paramString) != Cacheable.ScaleType.NINE_SQUARE) {
/* 421 */       i = 31 * i + paramInt1;
/* 422 */       i = 31 * i + paramInt2;
/*     */     } 
/* 424 */     i = 31 * i + paramInt3;
/* 425 */     i = 31 * i + (int)getScale() * 100;
/* 426 */     i = 31 * i + getClass().hashCode();
/* 427 */     i = 31 * i + jComponent.getClass().hashCode();
/* 428 */     i = 31 * i + jComponent.getComponentOrientation().hashCode();
/* 429 */     i = 31 * i + paramSynthContext.getComponentState();
/* 430 */     i = (border == null) ? i : (31 * i + getBorderHashCode(border));
/* 431 */     i = (bool == null) ? i : (31 * i + (bool.booleanValue() ? 0 : 1));
/* 432 */     i = (color1 == null) ? i : (i * 31 + color1.getRGB());
/* 433 */     i = (float_ == null) ? i : (i * 31 + (int)(float_.floatValue() * 100.0F));
/* 434 */     i = (color2 == null) ? i : (i * 31 + color2.getRGB());
/* 435 */     i = (str == null) ? i : (31 * i + str.hashCode());
/* 436 */     i = 31 * i + ((window == null || window.isActive()) ? 0 : 1);
/* 437 */     return i;
/*     */   }
/*     */   
/*     */   private int getBorderHashCode(Border paramBorder) {
/* 442 */     int i = (paramBorder == null) ? 0 : paramBorder.getClass().hashCode();
/* 443 */     if (paramBorder instanceof CompoundBorder) {
/* 445 */       i = 31 * i + getBorderHashCode(((CompoundBorder)paramBorder).getInsideBorder());
/* 446 */       i = 31 * i + getBorderHashCode(((CompoundBorder)paramBorder).getOutsideBorder());
/*     */     } 
/* 448 */     return i;
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 453 */     return Cacheable.ScaleType.NONE;
/*     */   }
/*     */   
/*     */   public Insets getCacheScaleInsets(SynthContext paramSynthContext, String paramString) {
/* 458 */     JComponent jComponent = paramSynthContext.getComponent();
/* 460 */     int i = (int)(getScale() * 10.0F);
/* 461 */     return (jComponent == null) ? new Insets(i, i, i, i) : jComponent.getInsets();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaComponentPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */