/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ public class TextFieldStyle extends StyleWrapper {
/* 36 */   private static TextFieldStyle instance = new TextFieldStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 45 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null && ((JTextComponent)paramJComponent).isEditable()) {
/* 47 */       instance.setStyle(paramSynthStyle);
/* 48 */       return instance;
/*    */     } 
/* 50 */     TextFieldStyle textFieldStyle = new TextFieldStyle();
/* 51 */     textFieldStyle.setStyle(paramSynthStyle);
/* 52 */     return textFieldStyle;
/*    */   }
/*    */   
/*    */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/* 58 */     String str = paramSynthContext.getComponent().getName();
/* 59 */     if ("ComboBox.textField".equals(str))
/* 61 */       return new Insets(0, 1, 0, 1); 
/* 62 */     return this.synthStyle.getInsets(paramSynthContext, paramInsets);
/*    */   }
/*    */   
/*    */   public Color getColorForState(SynthContext paramSynthContext, ColorType paramColorType) {
/* 68 */     JComponent jComponent = paramSynthContext.getComponent();
/* 69 */     if (paramColorType == ColorType.TEXT_FOREGROUND && jComponent.getForeground() instanceof javax.swing.plaf.ColorUIResource && !((JTextComponent)jComponent).isEditable()) {
/* 71 */       Color color = SyntheticaLookAndFeel.getColor("Synthetica.textField.locked.textColor", jComponent);
/* 72 */       return (color == null) ? super.getColorForState(paramSynthContext, paramColorType) : color;
/*    */     } 
/* 74 */     return super.getColorForState(paramSynthContext, paramColorType);
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 80 */     JComponent jComponent = paramSynthContext.getComponent();
/* 81 */     Color color = jComponent.getBackground();
/* 83 */     if (jComponent.isOpaque() && color != null && !(color instanceof javax.swing.plaf.UIResource) && paramColorType == ColorType.BACKGROUND)
/* 84 */       return color; 
/* 85 */     return super.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\TextFieldStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */