/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.plaf.synth.SynthStyleFactory;
/*     */ import sun.swing.BakedArrayList;
/*     */ import sun.swing.plaf.synth.DefaultSynthStyle;
/*     */ import sun.swing.plaf.synth.StyleAssociation;
/*     */ 
/*     */ class SyntheticaStyleFactory {
/*     */   public static final int NAME = 0;
/*     */   
/*     */   public static final int REGION = 1;
/*     */   
/*     */   private List<StyleAssociation> styles;
/*     */   
/*     */   private BakedArrayList tmpList;
/*     */   
/*     */   private Map<BakedArrayList, SynthStyle> resolvedStyles;
/*     */   
/*     */   private SynthStyle defaultStyle;
/*     */   
/*     */   SyntheticaStyleFactory(SynthStyleFactory paramSynthStyleFactory) {
/*     */     try {
/*  50 */       Class<?> clazz = Class.forName("javax.swing.plaf.synth.DefaultSynthStyleFactory");
/*  51 */       Field field1 = clazz.getDeclaredField("_styles");
/*  52 */       field1.setAccessible(true);
/*  53 */       this.styles = (List<StyleAssociation>)field1.get(paramSynthStyleFactory);
/*  55 */       Field field2 = clazz.getDeclaredField("_tmpList");
/*  56 */       field2.setAccessible(true);
/*  57 */       this.tmpList = (BakedArrayList)field2.get(paramSynthStyleFactory);
/*  59 */       Field field3 = clazz.getDeclaredField("_resolvedStyles");
/*  60 */       field3.setAccessible(true);
/*  61 */       this.resolvedStyles = (Map<BakedArrayList, SynthStyle>)field3.get(paramSynthStyleFactory);
/*  63 */       Field field4 = clazz.getDeclaredField("_defaultStyle");
/*  64 */       field4.setAccessible(true);
/*  65 */       this.defaultStyle = (SynthStyle)field4.get(paramSynthStyleFactory);
/*  67 */     } catch (Exception exception) {
/*  69 */       throw new RuntimeException(exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized SynthStyle getStyle(JComponent paramJComponent, Region paramRegion) {
/*  76 */     BakedArrayList<Object> bakedArrayList = this.tmpList;
/*  77 */     bakedArrayList.clear();
/*  78 */     getMatchingStyles(bakedArrayList, this.styles, paramJComponent, paramRegion);
/*  80 */     if (bakedArrayList.size() == 0) {
/*  82 */       if (this.defaultStyle == null) {
/*  84 */         this.defaultStyle = new DefaultSynthStyle();
/*  85 */         ((DefaultSynthStyle)this.defaultStyle).setFont(new FontUIResource("Dialog", 0, 12));
/*     */       } 
/*  87 */       return this.defaultStyle;
/*     */     } 
/*  91 */     bakedArrayList.cacheHashCode();
/*  92 */     SynthStyle synthStyle = (bakedArrayList.size() == 0) ? null : this.resolvedStyles.get(bakedArrayList);
/*  93 */     if (synthStyle == null) {
/*  95 */       synthStyle = mergeStyles(bakedArrayList);
/*  97 */       if (synthStyle != null)
/*  98 */         this.resolvedStyles.put(new BakedArrayList(bakedArrayList), synthStyle); 
/*     */     } 
/* 100 */     return synthStyle;
/*     */   }
/*     */   
/*     */   private void getMatchingStyles(List<Object> paramList, List<StyleAssociation> paramList1, JComponent paramJComponent, Region paramRegion) {
/* 105 */     String str1 = paramRegion.getName().toLowerCase(Locale.ENGLISH);
/* 106 */     String str2 = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/* 107 */     if (str2 == null)
/* 108 */       str2 = ""; 
/* 109 */     for (int i = paramList1.size() - 1; i >= 0; i--) {
/* 111 */       StyleAssociation styleAssociation = paramList1.get(i);
/* 112 */       String str = (styleAssociation.getID() == 0) ? str2 : str1;
/* 113 */       if (styleAssociation.matches(str) && paramList.indexOf(styleAssociation.getStyle()) == -1)
/* 114 */         paramList.add(styleAssociation.getStyle()); 
/*     */     } 
/*     */   }
/*     */   
/*     */   private SynthStyle mergeStyles(BakedArrayList<DefaultSynthStyle> paramBakedArrayList) {
/* 120 */     int i = paramBakedArrayList.size();
/* 122 */     if (i == 0)
/* 123 */       return null; 
/* 124 */     if (i == 1)
/* 125 */       return (SynthStyle)((DefaultSynthStyle)paramBakedArrayList.get(0)).clone(); 
/* 127 */     DefaultSynthStyle defaultSynthStyle = paramBakedArrayList.get(i - 1);
/* 128 */     defaultSynthStyle = (DefaultSynthStyle)defaultSynthStyle.clone();
/* 129 */     for (int j = i - 2; j >= 0; j--)
/* 130 */       defaultSynthStyle = ((DefaultSynthStyle)paramBakedArrayList.get(j)).addTo(defaultSynthStyle); 
/* 131 */     return defaultSynthStyle;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaStyleFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */