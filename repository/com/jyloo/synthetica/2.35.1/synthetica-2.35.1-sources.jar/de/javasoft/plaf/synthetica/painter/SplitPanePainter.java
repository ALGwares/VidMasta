/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class SplitPanePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.SplitPanePainter";
/*     */   
/*  43 */   private static HashMap<String, Image> imgCache = new HashMap<String, Image>();
/*     */   
/*     */   public static SplitPanePainter getInstance() {
/*  57 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static SplitPanePainter getInstance(SynthContext paramSynthContext) {
/*  66 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, SplitPanePainter.class, "Synthetica.SplitPanePainter"));
/*  67 */     if (syntheticaComponentPainter == null)
/*  68 */       syntheticaComponentPainter = getInstance(paramSynthContext, SplitPanePainter.class, "Synthetica.SplitPanePainter"); 
/*  69 */     return (SplitPanePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintSplitPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSplitPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSplitPaneDividerBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintSplitPaneDragDivider(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*     */   
/*     */   public void paintSplitPaneDividerForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  93 */     JComponent jComponent = paramSynthContext.getComponent();
/*  94 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.splitPaneDivider.background.insets", jComponent, false);
/*  95 */     Insets insets2 = insets1;
/*  97 */     String str1 = null;
/*  98 */     String str2 = "Synthetica.splitPaneDivider";
/*  99 */     if (paramInt5 == 0) {
/* 101 */       str1 = String.valueOf(str2) + ".x.grip";
/* 102 */       str2 = String.valueOf(str2) + ".x.background";
/*     */     } else {
/* 106 */       str1 = String.valueOf(str2) + ".y.grip";
/* 107 */       str2 = String.valueOf(str2) + ".y.background";
/*     */     } 
/* 110 */     if ((paramSynthContext.getComponentState() & 0x2) > 0)
/* 112 */       str1 = String.valueOf(str1) + ".hover"; 
/* 115 */     str2 = SyntheticaLookAndFeel.getString(str2, jComponent);
/* 116 */     str1 = SyntheticaLookAndFeel.getString(str1, jComponent);
/* 119 */     if (str2 != null) {
/* 121 */       boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.splitPaneDivider.background.horizontalTiled", jComponent, false) ? true : false;
/* 122 */       boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.splitPaneDivider.background.verticalTiled", jComponent, false) ? true : false;
/* 123 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, bool1, bool2);
/* 124 */       imagePainter.draw();
/*     */     } 
/* 128 */     if (str1 != null) {
/* 130 */       Image image = imgCache.get(str1);
/* 131 */       if (image == null) {
/* 133 */         image = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(str1))).getImage();
/* 134 */         imgCache.put(str1, image);
/*     */       } 
/* 136 */       int i = image.getWidth(null);
/* 137 */       int j = image.getHeight(null);
/* 138 */       int k = paramInt1 + (paramInt3 - i) / 2;
/* 139 */       int m = paramInt2 + (paramInt4 - j) / 2;
/* 140 */       if (paramInt5 == 1 && paramInt3 - 2 < i)
/*     */         return; 
/* 142 */       if (paramInt5 == 0 && paramInt4 - 2 < j)
/*     */         return; 
/* 144 */       paramGraphics.drawImage(image, k, m, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 151 */     if (paramString.equals("paintSplitPaneBorder") || paramString.equals("paintSplitPaneBackground"))
/* 152 */       return Cacheable.ScaleType.NINE_SQUARE; 
/* 153 */     return super.getCacheScaleType(paramString);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 159 */     if (paramString.equals("paintSplitPaneBorder") || paramString.equals("paintSplitPaneBackground"))
/* 160 */       return -1; 
/* 161 */     return super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SplitPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */