/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.JToolBar;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ToolBarHandle extends SyntheticaIconPainter {
/* 34 */   private SyntheticaState state = new SyntheticaState();
/*    */   
/*    */   public int getIconHeight() {
/* 38 */     return UIManager.getInt("Synthetica.toolBar.handle.size");
/*    */   }
/*    */   
/*    */   public int getIconWidth() {
/* 43 */     return UIManager.getInt("Synthetica.toolBar.handle.size");
/*    */   }
/*    */   
/*    */   public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 48 */     JToolBar jToolBar = (JToolBar)paramComponent;
/* 49 */     int i = jToolBar.getOrientation();
/* 51 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.handle.stateSupportEnabled", paramComponent);
/* 52 */     SynthContext synthContext = null;
/* 53 */     if (bool) {
/* 55 */       SynthStyle synthStyle = SynthLookAndFeel.getStyle(jToolBar, Region.TOOL_BAR);
/* 56 */       synthContext = new SynthContext(jToolBar, Region.TOOL_BAR, synthStyle, 0);
/* 57 */       this.state = new SyntheticaPainterState(synthContext);
/*    */     } 
/* 60 */     int j = SyntheticaLookAndFeel.getInt("Synthetica.toolBar.handle.size", paramComponent);
/* 61 */     int k = j;
/* 63 */     if (j <= 0)
/*    */       return; 
/* 64 */     Insets insets = null;
/* 66 */     if (i == 0) {
/* 68 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.toolBar.margin.horizontal", paramComponent);
/* 69 */       k = paramComponent.getHeight() - insets.top - insets.bottom;
/*    */     } else {
/* 74 */       paramInt1 = paramComponent.getComponentOrientation().isLeftToRight() ? paramInt1 : 0;
/* 75 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.toolBar.margin.vertical", paramComponent);
/* 76 */       j = paramComponent.getWidth() - insets.left - insets.right;
/*    */     } 
/* 78 */     paramInt1 += insets.left;
/* 79 */     paramInt2 += insets.top;
/* 81 */     ToolBarHandlePainter.getInstance(synthContext).paintHandle(jToolBar, this.state, i, paramGraphics, paramInt1, paramInt2, j, k);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ToolBarHandle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */