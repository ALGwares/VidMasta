package de.javasoft.plaf.synthetica;

public interface AddonsXMLProvider {
  String[] getXMLFileNames();
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\AddonsXMLProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */