/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.GraphicsUtils;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.java2d.Synthetica2DUtils;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Window;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class MenuStyle extends StyleWrapper {
/*  40 */   private static MenuStyle instance = new MenuStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  49 */     paramJComponent.setOpaque(false);
/*  51 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  53 */       instance.setStyle(paramSynthStyle);
/*  54 */       return instance;
/*     */     } 
/*  56 */     MenuStyle menuStyle = new MenuStyle();
/*  57 */     menuStyle.setStyle(paramSynthStyle);
/*  58 */     return menuStyle;
/*     */   }
/*     */   
/*     */   public Font getFont(SynthContext paramSynthContext) {
/*  64 */     MenuItemStyle.menuItemHtmlColorCorrection(paramSynthContext);
/*  65 */     Font font = this.synthStyle.getFont(paramSynthContext);
/*  66 */     JMenu jMenu = (JMenu)paramSynthContext.getComponent();
/*  67 */     Object object = SyntheticaLookAndFeel.get("Synthetica.menu.toplevel.fontSize", jMenu);
/*  68 */     if (object != null && jMenu.isTopLevelMenu()) {
/*  70 */       float f = SyntheticaLookAndFeel.scaleFontSize((new Float(object.toString())).floatValue());
/*  71 */       font = font.deriveFont(f);
/*     */     } 
/*  73 */     return font;
/*     */   }
/*     */   
/*     */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/*  79 */     JMenu jMenu = (JMenu)paramSynthContext.getComponent();
/*  80 */     Boolean bool = (Boolean)jMenu.getClientProperty("Synthetica.MOUSE_OVER");
/*  81 */     boolean bool1 = (bool == null) ? false : bool.booleanValue();
/*  82 */     boolean bool2 = ((paramSynthContext.getComponentState() & 0x200) > 0) ? true : false;
/*  83 */     boolean bool3 = ((paramSynthContext.getComponentState() & 0x1) > 0) ? true : false;
/*  84 */     if (jMenu.isTopLevelMenu() && paramColorType.equals(ColorType.TEXT_FOREGROUND)) {
/*  87 */       String str = "Synthetica.menu.toplevel.textColor";
/*  88 */       Window window = SwingUtilities.getWindowAncestor(jMenu);
/*  89 */       if (!window.isActive() && SyntheticaLookAndFeel.getBoolean("Synthetica.window.decoration", window) && SyntheticaLookAndFeel.get(String.valueOf(str) + ".inactive", window) != null && !bool2 && !bool1) {
/*  90 */         str = String.valueOf(str) + ".inactive";
/*  91 */       } else if (!bool3) {
/*  92 */         str = String.valueOf(str) + ".disabled";
/*  93 */       } else if (bool2 || bool1) {
/*  94 */         str = String.valueOf(str) + ".selected";
/*     */       } 
/*  95 */       Color color = SyntheticaLookAndFeel.getColor(str, jMenu);
/*  96 */       if (color != null)
/*  97 */         return color; 
/*  99 */     } else if (paramColorType.equals(ColorType.TEXT_FOREGROUND)) {
/* 101 */       Color color = jMenu.getForeground();
/* 102 */       if (!(color instanceof javax.swing.plaf.UIResource))
/* 103 */         return color; 
/*     */     } 
/* 105 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*     */   }
/*     */   
/*     */   public Icon getIcon(SynthContext paramSynthContext, Object paramObject) {
/* 111 */     Icon icon = super.getIcon(paramSynthContext, paramObject);
/* 112 */     if ("Menu.arrowIcon".equals(paramObject) && !paramSynthContext.getComponent().getComponentOrientation().isLeftToRight())
/* 113 */       icon = new ImageIcon(Synthetica2DUtils.flipHorizontal(GraphicsUtils.iconToImage(paramSynthContext, icon))); 
/* 114 */     return icon;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\MenuStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */