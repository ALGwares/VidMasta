/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.text.NumberFormat;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class SyntheticaDefaultTableCellEditor extends DefaultCellEditor {
/*     */   private static final long serialVersionUID = -4003145629974364170L;
/*     */   
/*     */   private Constructor<?> constructor;
/*     */   
/*     */   private Object value;
/*     */   
/*     */   private boolean respectNumberLocale;
/*     */   
/*     */   public SyntheticaDefaultTableCellEditor() {
/*  54 */     this(new JTextField());
/*     */   }
/*     */   
/*     */   public SyntheticaDefaultTableCellEditor(JTextField paramJTextField) {
/*  59 */     this(paramJTextField, null);
/*     */   }
/*     */   
/*     */   public SyntheticaDefaultTableCellEditor(JTextField paramJTextField, Boolean paramBoolean) {
/*  64 */     super(paramJTextField);
/*  65 */     getComponent().setName("Table.editor");
/*  66 */     this.respectNumberLocale = (paramBoolean != null) ? paramBoolean.booleanValue() : SyntheticaLookAndFeel.getBoolean("Synthetica.table.cellEditor.respectNumberLocale", null, false);
/*     */   }
/*     */   
/*     */   public Component getTableCellEditorComponent(JTable paramJTable, Object paramObject, boolean paramBoolean, int paramInt1, int paramInt2) {
/*  72 */     this.value = null;
/*  73 */     JComponent jComponent = (JComponent)getComponent();
/*  75 */     jComponent.setBorder(createCellFocusBorder(paramJTable));
/*  76 */     jComponent.setOpaque(SyntheticaLookAndFeel.getBoolean("Synthetica.table.cellEditor.opaque", paramJTable));
/*     */     try {
/*  79 */       Class<?> clazz = paramJTable.getColumnClass(paramInt2);
/*  82 */       if (this.respectNumberLocale && Number.class.isAssignableFrom(clazz))
/*  83 */         paramObject = NumberFormat.getInstance().format(paramObject); 
/*  85 */       if (clazz == Object.class)
/*  86 */         clazz = String.class; 
/*  87 */       this.constructor = clazz.getConstructor(new Class[] { String.class });
/*  90 */     } catch (Exception exception) {}
/*  92 */     return super.getTableCellEditorComponent(paramJTable, paramObject, paramBoolean, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public Object getCellEditorValue() {
/*  98 */     return this.value;
/*     */   }
/*     */   
/*     */   public boolean stopCellEditing() {
/* 104 */     String str = (String)super.getCellEditorValue();
/* 106 */     if (str != null && str.length() == 0) {
/* 108 */       if (this.constructor.getDeclaringClass() == String.class)
/* 109 */         this.value = ""; 
/* 110 */       super.stopCellEditing();
/*     */     } 
/*     */     try {
/*     */       Number number;
/* 115 */       if (this.respectNumberLocale && Number.class.isAssignableFrom(this.constructor.getDeclaringClass()))
/* 116 */         number = NumberFormat.getNumberInstance().parse(str); 
/* 117 */       this.value = this.constructor.newInstance(new Object[] { number });
/* 119 */     } catch (Exception exception) {
/* 121 */       JComponent jComponent = (JComponent)getComponent();
/* 122 */       jComponent.setBorder(createErrorCellFocusBorder((JTable)jComponent.getParent()));
/* 123 */       return false;
/*     */     } 
/* 125 */     return super.stopCellEditing();
/*     */   }
/*     */   
/*     */   protected Border createCellFocusBorder(JTable paramJTable) {
/* 130 */     Color color = SyntheticaLookAndFeel.getColor("Synthetica.table.focusCellHighlightBorder.color", paramJTable);
/* 131 */     return new CellFocusBorder(SyntheticaLookAndFeel.getColor("Synthetica.table.cellEditor.focus.color", paramJTable, color));
/*     */   }
/*     */   
/*     */   protected Border createErrorCellFocusBorder(JTable paramJTable) {
/* 136 */     return new CellFocusBorder(SyntheticaLookAndFeel.getColor("Synthetica.table.cellEditor.focus.errorColor", paramJTable, new Color(15138816)));
/*     */   }
/*     */   
/*     */   public static class NumberEditor extends SyntheticaDefaultTableCellEditor {
/*     */     private static final long serialVersionUID = 966057265129092767L;
/*     */     
/*     */     public NumberEditor() {
/* 148 */       ((JTextField)getComponent()).setHorizontalAlignment(4);
/*     */     }
/*     */   }
/*     */   
/*     */   public static class CellFocusBorder implements Border {
/* 159 */     private Color color = Color.GRAY;
/*     */     
/*     */     public CellFocusBorder(Color param1Color) {
/* 163 */       if (param1Color != null)
/* 164 */         this.color = param1Color; 
/*     */     }
/*     */     
/*     */     public Insets getBorderInsets(Component param1Component) {
/* 169 */       int i = getBorderSize(param1Component);
/* 170 */       if (param1Component.getParent() instanceof JTable) {
/* 172 */         JLabel jLabel = new JLabel();
/* 173 */         jLabel.setName("Table.cellRenderer");
/* 174 */         SynthStyle synthStyle = SynthLookAndFeel.getStyleFactory().getStyle(jLabel, Region.LABEL);
/* 175 */         return synthStyle.getInsets(new SynthContext(jLabel, Region.LABEL, synthStyle, 0), null);
/*     */       } 
/* 178 */       return new Insets(i, i, i, i);
/*     */     }
/*     */     
/*     */     public boolean isBorderOpaque() {
/* 183 */       return false;
/*     */     }
/*     */     
/*     */     public void paintBorder(Component param1Component, Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 188 */       Graphics2D graphics2D = (Graphics2D)param1Graphics;
/* 189 */       graphics2D.setPaint(this.color);
/* 190 */       int i = getBorderSize(param1Component);
/* 191 */       for (byte b = 0; b < i; b++)
/* 192 */         graphics2D.draw(createShape((param1Int1 + b), (param1Int2 + b), (param1Int3 - b * 2 - 1), (param1Int4 - b * 2 - 1))); 
/*     */     }
/*     */     
/*     */     private int getBorderSize(Component param1Component) {
/* 197 */       return SyntheticaLookAndFeel.getInt("Synthetica.table.cellEditor.focus.size", param1Component, 1);
/*     */     }
/*     */     
/*     */     private Shape createShape(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
/* 202 */       return new Rectangle2D.Float(param1Float1, param1Float2, param1Float3, param1Float4);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDefaultTableCellEditor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */