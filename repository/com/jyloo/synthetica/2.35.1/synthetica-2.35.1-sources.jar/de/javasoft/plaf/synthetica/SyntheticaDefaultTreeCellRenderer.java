package de.javasoft.plaf.synthetica;

import javax.swing.tree.DefaultTreeCellRenderer;

public class SyntheticaDefaultTreeCellRenderer extends DefaultTreeCellRenderer {
  private static final long serialVersionUID = 2137161279889738534L;
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDefaultTreeCellRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */