/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.DimensionUIResource;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ToolBarSeparatorStyle extends StyleWrapper {
/* 31 */   private static ToolBarSeparatorStyle instance = new ToolBarSeparatorStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 39 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 41 */       instance.setStyle(paramSynthStyle);
/* 42 */       return instance;
/*    */     } 
/* 44 */     ToolBarSeparatorStyle toolBarSeparatorStyle = new ToolBarSeparatorStyle();
/* 45 */     toolBarSeparatorStyle.setStyle(paramSynthStyle);
/* 46 */     return toolBarSeparatorStyle;
/*    */   }
/*    */   
/*    */   public Object get(SynthContext paramSynthContext, Object paramObject) {
/* 51 */     if (paramObject.equals("ToolBar.separatorSize")) {
/* 53 */       Dimension dimension = SyntheticaLookAndFeel.getToolbarSeparatorDimension();
/* 54 */       if (dimension != null)
/* 55 */         return new DimensionUIResource(dimension.width, dimension.height); 
/*    */     } 
/* 57 */     return this.synthStyle.get(paramSynthContext, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ToolBarSeparatorStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */