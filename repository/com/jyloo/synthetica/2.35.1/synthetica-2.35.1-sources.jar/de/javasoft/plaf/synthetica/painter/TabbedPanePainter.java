/*      */ package de.javasoft.plaf.synthetica.painter;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*      */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.TreeMap;
/*      */ import java.util.WeakHashMap;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.plaf.basic.BasicTabbedPaneUI;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*      */ import javax.swing.plaf.synth.SynthStyle;
/*      */ 
/*      */ public class TabbedPanePainter extends SyntheticaComponentPainter {
/*      */   public static final String UI_KEY = "Synthetica.TabbedPanePainter";
/*      */   
/*      */   public static final int UNDEFINED = -1;
/*      */   
/*      */   public static final int LEFT = 0;
/*      */   
/*      */   public static final int RIGHT = 1;
/*      */   
/*      */   public static final int LEFT_RIGHT = 2;
/*      */   
/*      */   public static final int TOP = 3;
/*      */   
/*      */   public static final int BOTTOM = 4;
/*      */   
/*      */   public static final int TOP_BOTTOM = 5;
/*      */   
/*      */   private static final String FOCUS_PLACEMENT_KEY = "JTabbedPane.focusPlacement";
/*      */   
/*   90 */   private static WeakHashMap<JComponent, Object> translucentTabbedPanes = new WeakHashMap<JComponent, Object>();
/*      */   
/*      */   private static final String TRANSLUCENT_KEY = "Synthetica.childsAreTranslucent";
/*      */   
/*   92 */   private static HashMap<String, Image> imgCache = new HashMap<String, Image>();
/*      */   
/*      */   public static TabbedPanePainter getInstance() {
/*  106 */     return getInstance((SynthContext)null);
/*      */   }
/*      */   
/*      */   public static TabbedPanePainter getInstance(SynthContext paramSynthContext) {
/*  115 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TabbedPanePainter.class, "Synthetica.TabbedPanePainter"));
/*  116 */     if (syntheticaComponentPainter == null)
/*  117 */       syntheticaComponentPainter = getInstance(paramSynthContext, TabbedPanePainter.class, "Synthetica.TabbedPanePainter"); 
/*  118 */     return (TabbedPanePainter)syntheticaComponentPainter;
/*      */   }
/*      */   
/*      */   public static void reinitialize() {
/*  125 */     for (JComponent jComponent : translucentTabbedPanes.keySet())
/*  126 */       jComponent.putClientProperty("Synthetica.childsAreTranslucent", Boolean.valueOf(false)); 
/*  127 */     translucentTabbedPanes = new WeakHashMap<JComponent, Object>();
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*      */   
/*      */   public void paintTabbedPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*      */   
/*      */   public void paintTabbedPaneContentBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  140 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  141 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.contentBorder.paintBackground", jTabbedPane, false))
/*      */       return; 
/*  144 */     int i = jTabbedPane.getTabPlacement();
/*  145 */     SyntheticaState syntheticaState = new SyntheticaState(paramSynthContext.getComponentState());
/*  146 */     String str = getContentBorderImagePath(jTabbedPane, syntheticaState, i);
/*  148 */     UIKey uIKey = new UIKey("tabbedPane.contentBorder.image", syntheticaState, -1, i, -1);
/*  149 */     Insets insets1 = (Insets)UIKey.findProperty(jTabbedPane, uIKey.get(), "sourceInsets", true, 1);
/*  150 */     Insets insets2 = (Insets)insets1.clone();
/*  151 */     ImagePainter imagePainter = new ImagePainter(jTabbedPane, null, -1, -1, -1, -1, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0, flipOnRTL(jTabbedPane), false);
/*  152 */     imagePainter.drawCenter();
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneContentBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  160 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  161 */     paramGraphics.setColor(SyntheticaLookAndFeel.getColor("Synthetica.tabbedPane.hideBorderColor", jTabbedPane));
/*  163 */     modifyChildOpacity(paramSynthContext);
/*  165 */     paintTabbedPaneContentBorder(jTabbedPane, new SyntheticaState(paramSynthContext.getComponentState()), jTabbedPane.getTabPlacement(), true, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneContentBorder(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, boolean paramBoolean, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  175 */     paintTabbedPaneContentBorder(paramJComponent, paramSyntheticaState, paramInt1, paramBoolean, 0, paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneContentBorder(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, boolean paramBoolean, int paramInt2, Graphics paramGraphics, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  195 */     String str = getContentBorderImagePath(paramJComponent, paramSyntheticaState, paramInt1);
/*  196 */     UIKey uIKey = new UIKey("tabbedPane.contentBorder.image", paramSyntheticaState, -1, paramInt1, -1);
/*  197 */     Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "sourceInsets", true, 1);
/*  200 */     if (insets1 == null)
/*  200 */       insets1 = new Insets(0, 0, 0, 0); 
/*  201 */     Insets insets2 = (Insets)insets1.clone();
/*  202 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.contentBorder.horizontalTiled", paramJComponent, false) ? true : false;
/*  203 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.contentBorder.verticalTiled", paramJComponent, false) ? true : false;
/*  204 */     ImagePainter imagePainter = new ImagePainter(paramJComponent, null, -1, -1, -1, -1, paramGraphics, paramInt3, paramInt4, paramInt5, paramInt6, str, insets1, insets2, bool1, bool2, flipOnRTL(paramJComponent), false);
/*  205 */     imagePainter.drawBorder();
/*  207 */     if (paramBoolean && paramJComponent instanceof JTabbedPane && !SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.selected.paintOverContentBorder.disabled", paramJComponent))
/*  208 */       drawContentBorderLine4SelectedTab((JTabbedPane)paramJComponent, paramInt1, paramInt2, paramGraphics, paramInt3, paramInt4, paramInt5, paramInt6); 
/*      */   }
/*      */   
/*      */   private String getContentBorderImagePath(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt) {
/*  213 */     boolean bool = paramJComponent.getComponentOrientation().isLeftToRight();
/*  214 */     if (paramInt == 2 && !bool) {
/*  215 */       paramInt = 4;
/*  216 */     } else if (paramInt == 4 && !bool) {
/*  217 */       paramInt = 2;
/*      */     } 
/*  218 */     UIKey uIKey = new UIKey("tabbedPane.contentBorder.image", paramSyntheticaState, -1, paramInt, -1);
/*  219 */     return (String)UIKey.findProperty(paramJComponent, uIKey.get(), (String)null, true, 1);
/*      */   }
/*      */   
/*      */   protected void modifyChildOpacity(SynthContext paramSynthContext) {
/*  226 */     JComponent jComponent = paramSynthContext.getComponent();
/*  227 */     boolean bool = (jComponent.getClientProperty("Synthetica.childsAreTranslucent") == null) ? false : ((Boolean)jComponent.getClientProperty("Synthetica.childsAreTranslucent")).booleanValue();
/*  228 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.keepOpacity", jComponent) && !bool && 
/*  229 */       !jComponent.getParent().getClass().getName().equals("org.flexdock.view.Viewport")) {
/*  231 */       jComponent.putClientProperty("Synthetica.childsAreTranslucent", Boolean.TRUE);
/*  232 */       translucentTabbedPanes.put(jComponent, null);
/*  233 */       Component[] arrayOfComponent1 = jComponent.getComponents();
/*      */       byte b;
/*      */       int i;
/*      */       Component[] arrayOfComponent2;
/*  234 */       for (i = (arrayOfComponent2 = arrayOfComponent1).length, b = 0; b < i; ) {
/*  234 */         Component component = arrayOfComponent2[b];
/*  236 */         if (component instanceof Container && !(component instanceof java.awt.Window) && !(component instanceof javax.swing.JRootPane))
/*  237 */           setComponentsTranslucent((Container)component, true); 
/*      */         b++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void setAllNonOpaque(Container paramContainer) {
/*  251 */     setComponentsTranslucent(paramContainer, false);
/*      */   }
/*      */   
/*      */   private static void setComponentsTranslucent(Container paramContainer, boolean paramBoolean) {
/*      */     // Byte code:
/*      */     //   0: iload_1
/*      */     //   1: ifeq -> 13
/*      */     //   4: invokestatic getStyleFactory : ()Ljavax/swing/plaf/synth/SynthStyleFactory;
/*      */     //   7: checkcast de/javasoft/plaf/synthetica/StyleFactory
/*      */     //   10: goto -> 14
/*      */     //   13: aconst_null
/*      */     //   14: astore_2
/*      */     //   15: iconst_0
/*      */     //   16: istore_3
/*      */     //   17: iconst_0
/*      */     //   18: istore #4
/*      */     //   20: aload_0
/*      */     //   21: instanceof javax/swing/JComponent
/*      */     //   24: ifeq -> 94
/*      */     //   27: aload_0
/*      */     //   28: checkcast javax/swing/JComponent
/*      */     //   31: ldc 'Synthetica.tabbedPane.keepOpacity'
/*      */     //   33: invokevirtual getClientProperty : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   36: ifnonnull -> 43
/*      */     //   39: iconst_0
/*      */     //   40: goto -> 58
/*      */     //   43: aload_0
/*      */     //   44: checkcast javax/swing/JComponent
/*      */     //   47: ldc 'Synthetica.tabbedPane.keepOpacity'
/*      */     //   49: invokevirtual getClientProperty : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   52: checkcast java/lang/Boolean
/*      */     //   55: invokevirtual booleanValue : ()Z
/*      */     //   58: istore_3
/*      */     //   59: aload_0
/*      */     //   60: checkcast javax/swing/JComponent
/*      */     //   63: ldc_w 'Synthetica.tabbedPane.keepChildrenOpacity'
/*      */     //   66: invokevirtual getClientProperty : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   69: ifnonnull -> 76
/*      */     //   72: iconst_0
/*      */     //   73: goto -> 92
/*      */     //   76: aload_0
/*      */     //   77: checkcast javax/swing/JComponent
/*      */     //   80: ldc_w 'Synthetica.tabbedPane.keepChildrenOpacity'
/*      */     //   83: invokevirtual getClientProperty : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   86: checkcast java/lang/Boolean
/*      */     //   89: invokevirtual booleanValue : ()Z
/*      */     //   92: istore #4
/*      */     //   94: aload_0
/*      */     //   95: instanceof javax/swing/JPanel
/*      */     //   98: ifne -> 115
/*      */     //   101: aload_0
/*      */     //   102: instanceof javax/swing/JScrollPane
/*      */     //   105: ifne -> 115
/*      */     //   108: aload_0
/*      */     //   109: instanceof javax/swing/JViewport
/*      */     //   112: ifeq -> 160
/*      */     //   115: iload_3
/*      */     //   116: ifne -> 160
/*      */     //   119: aload_2
/*      */     //   120: ifnull -> 134
/*      */     //   123: aload_2
/*      */     //   124: invokevirtual getComponentPropertyStore : ()Lde/javasoft/plaf/synthetica/StyleFactory$ComponentPropertyStore;
/*      */     //   127: aload_0
/*      */     //   128: ldc_w 'SYCP_OPAQUE'
/*      */     //   131: invokevirtual storeComponentProperty : (Ljava/awt/Component;Ljava/lang/String;)V
/*      */     //   134: aconst_null
/*      */     //   135: invokestatic isWindowOpacityEnabled : (Ljava/awt/Window;)Z
/*      */     //   138: ifne -> 149
/*      */     //   141: aload_0
/*      */     //   142: checkcast javax/swing/JComponent
/*      */     //   145: iconst_0
/*      */     //   146: invokevirtual setDoubleBuffered : (Z)V
/*      */     //   149: aload_0
/*      */     //   150: checkcast javax/swing/JComponent
/*      */     //   153: iconst_0
/*      */     //   154: invokevirtual setOpaque : (Z)V
/*      */     //   157: goto -> 266
/*      */     //   160: aload_0
/*      */     //   161: instanceof javax/swing/JComponent
/*      */     //   164: ifeq -> 266
/*      */     //   167: iload_3
/*      */     //   168: ifne -> 266
/*      */     //   171: aload_0
/*      */     //   172: checkcast javax/swing/JComponent
/*      */     //   175: astore #5
/*      */     //   177: aload #5
/*      */     //   179: instanceof javax/swing/JRadioButton
/*      */     //   182: ifne -> 212
/*      */     //   185: aload #5
/*      */     //   187: instanceof javax/swing/JCheckBox
/*      */     //   190: ifne -> 212
/*      */     //   193: aload #5
/*      */     //   195: instanceof javax/swing/JTextArea
/*      */     //   198: ifeq -> 266
/*      */     //   201: aload #5
/*      */     //   203: invokevirtual getParent : ()Ljava/awt/Container;
/*      */     //   206: instanceof javax/swing/JViewport
/*      */     //   209: ifne -> 266
/*      */     //   212: aload #5
/*      */     //   214: invokevirtual getBackground : ()Ljava/awt/Color;
/*      */     //   217: ifnull -> 231
/*      */     //   220: aload #5
/*      */     //   222: invokevirtual getBackground : ()Ljava/awt/Color;
/*      */     //   225: instanceof javax/swing/plaf/ColorUIResource
/*      */     //   228: ifeq -> 266
/*      */     //   231: aload_2
/*      */     //   232: ifnull -> 247
/*      */     //   235: aload_2
/*      */     //   236: invokevirtual getComponentPropertyStore : ()Lde/javasoft/plaf/synthetica/StyleFactory$ComponentPropertyStore;
/*      */     //   239: aload #5
/*      */     //   241: ldc_w 'SYCP_OPAQUE'
/*      */     //   244: invokevirtual storeComponentProperty : (Ljava/awt/Component;Ljava/lang/String;)V
/*      */     //   247: aconst_null
/*      */     //   248: invokestatic isWindowOpacityEnabled : (Ljava/awt/Window;)Z
/*      */     //   251: ifne -> 260
/*      */     //   254: aload #5
/*      */     //   256: iconst_0
/*      */     //   257: invokevirtual setDoubleBuffered : (Z)V
/*      */     //   260: aload #5
/*      */     //   262: iconst_0
/*      */     //   263: invokevirtual setOpaque : (Z)V
/*      */     //   266: iload #4
/*      */     //   268: ifeq -> 272
/*      */     //   271: return
/*      */     //   272: aload_0
/*      */     //   273: invokevirtual getComponents : ()[Ljava/awt/Component;
/*      */     //   276: astore #5
/*      */     //   278: aload #5
/*      */     //   280: dup
/*      */     //   281: astore #9
/*      */     //   283: arraylength
/*      */     //   284: istore #8
/*      */     //   286: iconst_0
/*      */     //   287: istore #7
/*      */     //   289: goto -> 335
/*      */     //   292: aload #9
/*      */     //   294: iload #7
/*      */     //   296: aaload
/*      */     //   297: astore #6
/*      */     //   299: aload #6
/*      */     //   301: instanceof java/awt/Container
/*      */     //   304: ifeq -> 332
/*      */     //   307: aload #6
/*      */     //   309: instanceof java/awt/Window
/*      */     //   312: ifne -> 332
/*      */     //   315: aload #6
/*      */     //   317: instanceof javax/swing/JRootPane
/*      */     //   320: ifne -> 332
/*      */     //   323: aload #6
/*      */     //   325: checkcast java/awt/Container
/*      */     //   328: iload_1
/*      */     //   329: invokestatic setComponentsTranslucent : (Ljava/awt/Container;Z)V
/*      */     //   332: iinc #7, 1
/*      */     //   335: iload #7
/*      */     //   337: iload #8
/*      */     //   339: if_icmplt -> 292
/*      */     //   342: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #258	-> 0
/*      */     //   #259	-> 15
/*      */     //   #260	-> 17
/*      */     //   #261	-> 20
/*      */     //   #263	-> 27
/*      */     //   #264	-> 59
/*      */     //   #267	-> 94
/*      */     //   #268	-> 115
/*      */     //   #270	-> 119
/*      */     //   #271	-> 123
/*      */     //   #272	-> 134
/*      */     //   #273	-> 141
/*      */     //   #274	-> 149
/*      */     //   #275	-> 157
/*      */     //   #276	-> 160
/*      */     //   #278	-> 171
/*      */     //   #279	-> 177
/*      */     //   #282	-> 193
/*      */     //   #283	-> 212
/*      */     //   #285	-> 231
/*      */     //   #286	-> 235
/*      */     //   #287	-> 247
/*      */     //   #288	-> 254
/*      */     //   #289	-> 260
/*      */     //   #293	-> 266
/*      */     //   #294	-> 271
/*      */     //   #296	-> 272
/*      */     //   #297	-> 278
/*      */     //   #299	-> 299
/*      */     //   #300	-> 323
/*      */     //   #297	-> 332
/*      */     //   #302	-> 342
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabAreaBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*      */   
/*      */   public void paintTabbedPaneTabAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  316 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  317 */     paintTabbedPaneTabAreaBackground(jTabbedPane, new SyntheticaPainterState(paramSynthContext), jTabbedPane.getTabPlacement(), 0, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabAreaBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, int paramInt2, Graphics paramGraphics, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  336 */     boolean bool = paramJComponent.getComponentOrientation().isLeftToRight();
/*  337 */     if (paramInt1 == 2 && !bool) {
/*  338 */       paramInt1 = 4;
/*  339 */     } else if (paramInt1 == 4 && !bool) {
/*  340 */       paramInt1 = 2;
/*      */     } 
/*  341 */     UIKey uIKey = new UIKey("tabbedPane.tabArea.background.image", paramSyntheticaState, -1, paramInt1, -1);
/*  342 */     Insets insets1 = SyntheticaLookAndFeel.getInsets(uIKey.get("insets"), paramJComponent);
/*  343 */     Insets insets2 = insets1;
/*  344 */     String str = SyntheticaLookAndFeel.getString(uIKey.get(), paramJComponent);
/*  345 */     if (str != null) {
/*  347 */       boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tabArea.background.horizontalTiled", paramJComponent, false) ? true : false;
/*  348 */       boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tabArea.background.verticalTiled", paramJComponent, false) ? true : false;
/*  349 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, null, -1, -1, -1, -1, paramGraphics, paramInt3, paramInt4, paramInt5, paramInt6, str, insets1, insets2, bool1, bool2, flipOnRTL(paramJComponent), false);
/*  350 */       imagePainter.setAngle(paramInt2);
/*  351 */       imagePainter.draw();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  360 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  362 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.selected.bold", jTabbedPane) && 
/*  363 */       jTabbedPane.getSelectedIndex() == paramInt5 && jTabbedPane.hasFocus()) {
/*  368 */       JButton jButton = new JButton();
/*  369 */       SynthStyle synthStyle = SynthLookAndFeel.getStyle(jButton, Region.BUTTON);
/*  370 */       paramSynthContext = new SynthContext(jButton, Region.BUTTON, synthStyle, 256);
/*  371 */       synthStyle.getPainter(paramSynthContext).paintButtonBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTab(JComponent paramJComponent, SyntheticaState paramSyntheticaState, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Graphics paramGraphics, int paramInt5, int paramInt6, int paramInt7, int paramInt8) {
/*      */     ImagePainter imagePainter;
/*  394 */     Color color1 = (Color)paramJComponent.getClientProperty("Synthetica.background");
/*  395 */     Float float_ = (Float)paramJComponent.getClientProperty("Synthetica.background.alpha");
/*  396 */     String str1 = "Synthetica.tabbedPane.tab." + paramInt1 + ".background";
/*  398 */     Color color2 = (Color)paramJComponent.getClientProperty(str1);
/*  399 */     if (color2 == null && paramJComponent instanceof JTabbedPane && !(((JTabbedPane)paramJComponent).getBackgroundAt(paramInt1) instanceof javax.swing.plaf.UIResource))
/*  400 */       color2 = ((JTabbedPane)paramJComponent).getBackgroundAt(paramInt1); 
/*  401 */     if (color2 != null) {
/*  403 */       paramJComponent.putClientProperty("Synthetica.background", color2);
/*  404 */       if (paramJComponent.getClientProperty(String.valueOf(str1) + ".alpha") != null)
/*  405 */         paramJComponent.putClientProperty("Synthetica.background.alpha", paramJComponent.getClientProperty(String.valueOf(str1) + ".alpha")); 
/*      */     } 
/*  409 */     String str2 = String.valueOf(paramInt2) + "/" + paramInt1;
/*  412 */     String str3 = null;
/*  413 */     Insets insets1 = null;
/*  414 */     String str4 = "tabbedPane.tab";
/*  416 */     if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && !paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && !paramSyntheticaState.isSet(SyntheticaState.State.DISABLED)) {
/*  417 */       str4 = String.valueOf(str4) + ".hover";
/*  418 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED)) {
/*  419 */       str4 = String.valueOf(str4) + ".selected";
/*  420 */     } else if (paramSyntheticaState.isSet(SyntheticaState.State.DISABLED)) {
/*  421 */       str4 = String.valueOf(str4) + ".disabled";
/*      */     } 
/*  423 */     if (paramInt2 == 1) {
/*  424 */       str4 = String.valueOf(str4) + ".top";
/*  425 */     } else if (paramInt2 == 2) {
/*  426 */       str4 = String.valueOf(str4) + ".left";
/*  427 */     } else if (paramInt2 == 3) {
/*  428 */       str4 = String.valueOf(str4) + ".bottom";
/*  429 */     } else if (paramInt2 == 4) {
/*  430 */       str4 = String.valueOf(str4) + ".right";
/*      */     } 
/*  432 */     String str5 = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/*  433 */     str3 = SyntheticaLookAndFeel.getString(str4, null, str5, true);
/*  434 */     insets1 = SyntheticaLookAndFeel.getInsets(str4, "insets", str5, true);
/*  436 */     if (str3 == null)
/*  438 */       if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED)) {
/*  440 */         str3 = getTabImagePath(paramJComponent, paramInt2, paramInt3, ".selected");
/*  442 */         if (str3 == null)
/*  444 */           if (paramInt2 == 1 || paramInt2 == 3) {
/*  445 */             str3 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.x.image.selected", paramJComponent);
/*      */           } else {
/*  447 */             str3 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.y.image.selected", paramJComponent);
/*      */           }  
/*  450 */       } else if (paramSyntheticaState.isSet(SyntheticaState.State.DISABLED)) {
/*  451 */         str3 = getTabImagePath(paramJComponent, paramInt2, paramInt3, ".disabled");
/*      */       } else {
/*  455 */         if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER))
/*  456 */           str3 = getTabImagePath(paramJComponent, paramInt2, paramInt3, ".hover"); 
/*  457 */         if (str3 == null)
/*  458 */           str3 = getTabImagePath(paramJComponent, paramInt2, paramInt3, (String)null); 
/*      */       }  
/*  462 */     Insets insets2 = SyntheticaLookAndFeel.getInsets("Synthetica.tabbedPane.tab.noneSelected.background.insets", paramJComponent);
/*  463 */     if (!paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && insets2 != null)
/*  465 */       if (paramInt2 == 1) {
/*  466 */         paramInt6 += insets2.top;
/*  467 */       } else if (paramInt2 == 3) {
/*  468 */         paramInt8 -= insets2.bottom;
/*  469 */       } else if (paramInt2 == 2) {
/*  470 */         paramInt5 += insets2.left;
/*  471 */       } else if (paramInt2 == 4) {
/*  473 */         if (paramInt4 == 0) {
/*  474 */           paramInt7 -= insets2.right;
/*      */         } else {
/*  476 */           paramInt8 -= insets2.right;
/*      */         } 
/*      */       }  
/*  481 */     if (paramInt2 == 3)
/*  482 */       insets1 = new Insets(insets1.bottom, insets1.left, insets1.top, insets1.right); 
/*  485 */     if (paramInt2 == 4)
/*  486 */       insets1 = new Insets(insets1.top, insets1.right, insets1.bottom, insets1.left); 
/*  489 */     if (insets1 == null)
/*  489 */       insets1 = new Insets(0, 0, 0, 0); 
/*  490 */     Insets insets3 = (Insets)insets1.clone();
/*  492 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.removeDoubleBorder", paramJComponent))
/*  494 */       if ((paramInt2 == 1 || paramInt2 == 3) && (
/*  495 */         paramInt3 == 0 || paramInt3 == -1)) {
/*  496 */         insets3.right = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.doubleBorderXCorrection", paramJComponent, 0);
/*  497 */       } else if (paramInt2 == 2 && (paramInt3 == 4 || paramInt3 == -1) && paramInt4 != 0) {
/*  498 */         insets3.right = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.doubleBorderYCorrection", paramJComponent, 0);
/*  499 */       } else if (paramInt2 == 4 && (paramInt3 == 3 || paramInt3 == -1) && paramInt4 != 0) {
/*  500 */         insets3.right = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.doubleBorderYCorrection", paramJComponent, 0);
/*  501 */       } else if ((paramInt2 == 2 || paramInt2 == 4) && (
/*  502 */         paramInt3 == 3 || paramInt3 == -1)) {
/*  503 */         insets3.bottom = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.doubleBorderYCorrection", paramJComponent, 0);
/*      */       }  
/*  506 */     if (paramInt2 == 1) {
/*  507 */       insets3.bottom = 0;
/*  508 */     } else if (paramInt2 == 2) {
/*  510 */       if (paramInt4 == 0) {
/*  511 */         insets3.right = 0;
/*      */       } else {
/*  513 */         insets3.bottom = 0;
/*      */       } 
/*  515 */     } else if (paramInt2 == 3) {
/*  516 */       insets3.top = 0;
/*  517 */     } else if (paramInt2 == 4) {
/*  519 */       if (paramInt4 == 0) {
/*  520 */         insets3.left = 0;
/*      */       } else {
/*  522 */         insets3.bottom = 0;
/*      */       } 
/*      */     } 
/*  525 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbePane.tab.imageClippingEnabled", paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.imageClippingEnabled", paramJComponent, true));
/*  528 */     if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && !paramSyntheticaState.isSet(SyntheticaState.State.DISABLED) && !paramSyntheticaState.isSet(SyntheticaState.State.SELECTED) && 
/*  529 */       SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.red", paramJComponent, -2147483648) != Integer.MIN_VALUE) {
/*  531 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.red", paramJComponent);
/*  532 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.green", paramJComponent);
/*  533 */       int k = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.blue", paramJComponent);
/*  534 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.tabbedPane.tab.hover.insets", paramJComponent);
/*  535 */       if (insets == null)
/*  535 */         insets = new Insets(0, 0, 0, 0); 
/*  536 */       imagePainter = new ImagePainter(paramJComponent, i, j, k, insets, paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8, str3, insets1, bool ? insets3 : insets1, 0, 0, flipOnRTL(paramJComponent), false);
/*      */     } else {
/*  540 */       int i = 0;
/*  541 */       int j = 0;
/*  542 */       int k = 0;
/*  543 */       if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER)) {
/*  545 */         j = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.animation.cycles", paramJComponent, 1);
/*  546 */         i = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.animation.delay", paramJComponent, 50);
/*  547 */         k = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.hover.animation.type", paramJComponent, 1);
/*      */       } else {
/*  551 */         j = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.animation.cycles", paramJComponent, 1);
/*  552 */         i = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.animation.delay", paramJComponent, 50);
/*  553 */         k = SyntheticaLookAndFeel.getInt("Synthetica.tabbedPane.tab.animation.type", paramJComponent, 2);
/*      */       } 
/*  555 */       imagePainter = new ImagePainter(paramJComponent, str2, j, i, k, paramSyntheticaState.getState(), paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8, str3, insets1, bool ? insets3 : insets1, 0, 0, flipOnRTL(paramJComponent), false);
/*      */     } 
/*  557 */     imagePainter.setAngle(paramInt4);
/*  559 */     if (!bool) {
/*  560 */       imagePainter.draw();
/*      */     } else {
/*  563 */       if (paramInt2 != 3) {
/*  565 */         imagePainter.drawTopLeft();
/*  566 */         imagePainter.drawTopCenter();
/*  567 */         imagePainter.drawTopRight();
/*      */       } 
/*  569 */       if (paramInt2 != 4 || paramInt4 != 0)
/*  571 */         imagePainter.drawLeft(); 
/*  573 */       if (paramInt2 != 1) {
/*  575 */         imagePainter.drawBottomLeft();
/*  576 */         imagePainter.drawBottomCenter();
/*  577 */         imagePainter.drawBottomRight();
/*      */       } 
/*  579 */       if (paramInt2 != 2 || paramInt4 != 0)
/*  581 */         imagePainter.drawRight(); 
/*  583 */       imagePainter.drawCenter();
/*      */     } 
/*  586 */     paramJComponent.putClientProperty("Synthetica.background", color1);
/*  587 */     paramJComponent.putClientProperty("Synthetica.background.alpha", float_);
/*  589 */     if (paramSyntheticaState.isSet(SyntheticaState.State.FOCUSED)) {
/*  591 */       boolean bool1 = (paramJComponent.getClientProperty("JTabbedPane.focusPlacement") == null) ? true : ((Integer)paramJComponent.getClientProperty("JTabbedPane.focusPlacement")).intValue();
/*  592 */       if (bool1 != -1)
/*  593 */         paramInt2 = bool1; 
/*  595 */       String str = "";
/*  596 */       if (paramInt2 == 1) {
/*  597 */         str = "focus.tabbedPane.tab.top";
/*  598 */       } else if (paramInt2 == 3) {
/*  599 */         str = "focus.tabbedPane.tab.bottom";
/*  600 */       } else if (paramInt2 == 2) {
/*  601 */         str = "focus.tabbedPane.tab.left";
/*  602 */       } else if (paramInt2 == 4) {
/*  603 */         str = "focus.tabbedPane.tab.right";
/*      */       } 
/*  604 */       FocusPainter.paintFocus(str, paramJComponent, paramSyntheticaState.getState(), str2, paramInt4, paramGraphics, paramInt5, paramInt6, paramInt7, paramInt8);
/*      */     } 
/*      */   }
/*      */   
/*      */   private String getTabImagePath(JComponent paramJComponent, int paramInt1, int paramInt2, String paramString) {
/*  610 */     String str = null;
/*  611 */     if (paramString == null)
/*  612 */       paramString = ""; 
/*  615 */     if (paramInt2 == 0) {
/*  616 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.left.image" + paramString, paramJComponent);
/*  617 */     } else if (paramInt2 == 1) {
/*  618 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.right.image" + paramString, paramJComponent);
/*  619 */     } else if (paramInt2 == 2) {
/*  620 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.leftRight.image" + paramString, paramJComponent);
/*  621 */     } else if (paramInt2 == 3) {
/*  622 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.top.image" + paramString, paramJComponent);
/*  623 */     } else if (paramInt2 == 4) {
/*  624 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.bottom.image" + paramString, paramJComponent);
/*  625 */     } else if (paramInt2 == 5) {
/*  626 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.topBottom.image" + paramString, paramJComponent);
/*  629 */     } else if (paramInt1 == 1 || paramInt1 == 3) {
/*  630 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.middle.image" + paramString, paramJComponent);
/*      */     } else {
/*  632 */       str = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.center.image" + paramString, paramJComponent);
/*      */     } 
/*  634 */     return str;
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  643 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  645 */     int i = jTabbedPane.getTabPlacement();
/*  646 */     int j = getTabPosition(jTabbedPane, paramInt5);
/*  648 */     SyntheticaState syntheticaState = new SyntheticaState(paramSynthContext.getComponentState());
/*  650 */     Integer integer = (Integer)jTabbedPane.getClientProperty("Synthetica.MOUSE_OVER");
/*  651 */     int k = (integer == null) ? -1 : integer.intValue();
/*  652 */     if (k == paramInt5)
/*  653 */       syntheticaState.setState(SyntheticaState.State.HOVER); 
/*  654 */     if (!jTabbedPane.isEnabledAt(paramInt5))
/*  655 */       syntheticaState.setState(SyntheticaState.State.DISABLED); 
/*  657 */     paintTabbedPaneTab(jTabbedPane, syntheticaState, paramInt5, i, j, 0, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   protected int getTabPosition(JTabbedPane paramJTabbedPane, int paramInt) {
/*  665 */     if (paramInt < 0)
/*  665 */       return -1; 
/*  667 */     boolean bool1 = false;
/*  668 */     boolean bool2 = false;
/*  669 */     boolean bool3 = false;
/*  670 */     boolean bool4 = false;
/*  672 */     if (paramJTabbedPane.getTabPlacement() == 1 || 
/*  673 */       paramJTabbedPane.getTabPlacement() == 3) {
/*  675 */       TreeMap<Object, Object> treeMap1 = new TreeMap<Object, Object>(
/*  676 */           new Comparator() {
/*      */             public int compare(Object param1Object1, Object param1Object2) {
/*  680 */               Rectangle rectangle1 = (Rectangle)param1Object1;
/*  681 */               Rectangle rectangle2 = (Rectangle)param1Object2;
/*  682 */               if (rectangle1.x > rectangle2.x)
/*  682 */                 return 1; 
/*  683 */               if (rectangle1.x < rectangle2.x)
/*  683 */                 return -1; 
/*  684 */               return 0;
/*      */             }
/*      */           });
/*  688 */       TreeMap<Object, Object> treeMap2 = new TreeMap<Object, Object>(
/*  689 */           new Comparator() {
/*      */             public int compare(Object param1Object1, Object param1Object2) {
/*  693 */               Rectangle rectangle1 = (Rectangle)param1Object1;
/*  694 */               Rectangle rectangle2 = (Rectangle)param1Object2;
/*  695 */               if (rectangle1.x + rectangle1.width < rectangle2.x + rectangle2.width)
/*  696 */                 return 1; 
/*  697 */               if (rectangle1.x + rectangle1.width > rectangle2.x + rectangle2.width)
/*  697 */                 return -1; 
/*  698 */               return 0;
/*      */             }
/*      */           });
/*      */       byte b;
/*  702 */       for (b = 0; b < paramJTabbedPane.getTabCount(); b++)
/*  703 */         treeMap1.put(paramJTabbedPane.getBoundsAt(b), new Integer(b)); 
/*  705 */       if (treeMap1.headMap(paramJTabbedPane.getBoundsAt(paramInt)).size() == 0)
/*  706 */         bool1 = true; 
/*  708 */       for (b = 0; b < paramJTabbedPane.getTabCount(); b++)
/*  709 */         treeMap2.put(paramJTabbedPane.getBoundsAt(b), new Integer(b)); 
/*  711 */       if (treeMap2.headMap(paramJTabbedPane.getBoundsAt(paramInt)).size() == 0)
/*  712 */         bool2 = true; 
/*  714 */       if (bool1 && bool2)
/*  715 */         return 2; 
/*  716 */       if (bool1)
/*  717 */         return 0; 
/*  718 */       if (bool2)
/*  718 */         return 1; 
/*      */     } else {
/*  723 */       TreeMap<Object, Object> treeMap1 = new TreeMap<Object, Object>(
/*  724 */           new Comparator() {
/*      */             public int compare(Object param1Object1, Object param1Object2) {
/*  728 */               Rectangle rectangle1 = (Rectangle)param1Object1;
/*  729 */               Rectangle rectangle2 = (Rectangle)param1Object2;
/*  730 */               if (rectangle1.y > rectangle2.y)
/*  730 */                 return 1; 
/*  731 */               if (rectangle1.y < rectangle2.y)
/*  731 */                 return -1; 
/*  732 */               return 0;
/*      */             }
/*      */           });
/*  736 */       TreeMap<Object, Object> treeMap2 = new TreeMap<Object, Object>(
/*  737 */           new Comparator() {
/*      */             public int compare(Object param1Object1, Object param1Object2) {
/*  741 */               Rectangle rectangle1 = (Rectangle)param1Object1;
/*  742 */               Rectangle rectangle2 = (Rectangle)param1Object2;
/*  743 */               if (rectangle1.y + rectangle1.height < rectangle2.y + rectangle2.height)
/*  744 */                 return 1; 
/*  745 */               if (rectangle1.y + rectangle1.height > rectangle2.y + rectangle2.height)
/*  745 */                 return -1; 
/*  746 */               return 0;
/*      */             }
/*      */           });
/*      */       byte b;
/*  750 */       for (b = 0; b < paramJTabbedPane.getTabCount(); b++)
/*  751 */         treeMap1.put(paramJTabbedPane.getBoundsAt(b), new Integer(b)); 
/*  753 */       if (treeMap1.headMap(paramJTabbedPane.getBoundsAt(paramInt)).size() == 0)
/*  754 */         bool3 = true; 
/*  756 */       for (b = 0; b < paramJTabbedPane.getTabCount(); b++)
/*  757 */         treeMap2.put(paramJTabbedPane.getBoundsAt(b), new Integer(b)); 
/*  759 */       if (treeMap2.headMap(paramJTabbedPane.getBoundsAt(paramInt)).size() == 0)
/*  760 */         bool4 = true; 
/*  762 */       if (bool3 && bool4)
/*  763 */         return 5; 
/*  764 */       if (bool3)
/*  765 */         return 3; 
/*  766 */       if (bool4)
/*  766 */         return 4; 
/*      */     } 
/*  768 */     return -1;
/*      */   }
/*      */   
/*      */   private void drawContentBorderLine4SelectedTab(JTabbedPane paramJTabbedPane, int paramInt1, int paramInt2, Graphics paramGraphics, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*      */     String str1;
/*  779 */     if (SyntheticaLookAndFeel.get("Synthetica.tabbedPane.rotateTabRuns", paramJTabbedPane) != null && 
/*  780 */       !SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.rotateTabRuns", paramJTabbedPane) && 
/*  781 */       getSelectedRun(paramJTabbedPane) != 0)
/*      */       return; 
/*  789 */     if (paramInt1 == 1 && SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.top", paramJTabbedPane) != null) {
/*  790 */       str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.top", paramJTabbedPane);
/*  791 */     } else if (paramInt1 == 3 && SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.bottom", paramJTabbedPane) != null) {
/*  792 */       str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.bottom", paramJTabbedPane);
/*  793 */     } else if (paramInt1 == 2 && SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.left", paramJTabbedPane) != null) {
/*  794 */       str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.left", paramJTabbedPane);
/*  795 */     } else if (paramInt1 == 4 && SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.right", paramJTabbedPane) != null) {
/*  796 */       str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.selected.right", paramJTabbedPane);
/*      */     } else {
/*  800 */       int j = getTabPosition(paramJTabbedPane, paramJTabbedPane.getSelectedIndex());
/*  801 */       str1 = getTabImagePath(paramJTabbedPane, paramInt1, j, ".selected");
/*  803 */       if (str1 == null)
/*  805 */         if (paramInt1 == 1 || paramInt1 == 3) {
/*  806 */           str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.x.image.selected", paramJTabbedPane);
/*      */         } else {
/*  808 */           str1 = SyntheticaLookAndFeel.getString("Synthetica.tabbedPane.tab.y.image.selected", paramJTabbedPane);
/*      */         }  
/*      */     } 
/*  812 */     if (str1 == null)
/*      */       return; 
/*  814 */     Image image = imgCache.get(str1);
/*  815 */     if (image == null) {
/*  817 */       image = (new ImageIcon(SyntheticaLookAndFeel.class.getResource(str1))).getImage();
/*  818 */       imgCache.put(str1, image);
/*      */     } 
/*  821 */     byte b = 0;
/*  822 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.removeDoubleBorder", paramJTabbedPane)) {
/*  824 */       boolean bool1 = false;
/*  825 */       int j = getTabPosition(paramJTabbedPane, paramJTabbedPane.getSelectedIndex());
/*  826 */       if ((paramInt1 == 1 || paramInt1 == 3) && j == 1) {
/*  827 */         bool1 = true;
/*  828 */       } else if (paramInt2 != 0 && paramInt1 == 4 && j == 4) {
/*  829 */         bool1 = true;
/*  831 */       } else if (paramInt2 != 0 && paramInt1 == 2 && j == 3) {
/*  832 */         bool1 = true;
/*      */       } 
/*  834 */       if (!bool1)
/*  835 */         b = 1; 
/*      */     } 
/*  837 */     int i = paramJTabbedPane.getSelectedIndex();
/*  838 */     if (i == -1)
/*      */       return; 
/*  840 */     Rectangle rectangle = (Rectangle)paramJTabbedPane.getClientProperty("JTabbedPane.visibleSelectedTabRect");
/*  841 */     if (rectangle == null)
/*  842 */       rectangle = paramJTabbedPane.getBoundsAt(i); 
/*  844 */     String str2 = "tabbedPane.tab.selected";
/*  845 */     if (paramInt1 == 1) {
/*  846 */       str2 = String.valueOf(str2) + ".top";
/*  847 */     } else if (paramInt1 == 2) {
/*  848 */       str2 = String.valueOf(str2) + ".left";
/*  849 */     } else if (paramInt1 == 3) {
/*  850 */       str2 = String.valueOf(str2) + ".bottom";
/*  851 */     } else if (paramInt1 == 4) {
/*  852 */       str2 = String.valueOf(str2) + ".right";
/*      */     } 
/*  853 */     Insets insets1 = SyntheticaLookAndFeel.getInsets(str2, "insets", SyntheticaLookAndFeel.getStyleName(paramJTabbedPane), true);
/*  855 */     insets1 = (Insets)insets1.clone();
/*  857 */     if (rectangle.width < insets1.left + insets1.right || rectangle.height < insets1.top + insets1.bottom)
/*      */       return; 
/*  861 */     if (paramInt1 == 3) {
/*  862 */       insets1 = new Insets(insets1.bottom, insets1.left, insets1.top, insets1.right);
/*  864 */     } else if (paramInt1 == 4) {
/*  865 */       insets1 = new Insets(insets1.top, insets1.right, insets1.bottom, insets1.left);
/*      */     } 
/*  866 */     Insets insets2 = new Insets(0, 0, 0, 0);
/*  868 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.tab.selected.useFillAsContentBorder", paramJTabbedPane, true);
/*  869 */     if (paramInt1 == 1) {
/*  871 */       insets1.top = image.getHeight(null) + (bool ? (-insets1.bottom - 1) : 0);
/*  872 */       insets2.left = insets1.left;
/*  873 */       insets1.right -= b;
/*  874 */       paramInt3 = rectangle.x;
/*  875 */       paramInt5 = rectangle.width + b;
/*  876 */       paramInt6 = 1;
/*  878 */     } else if (paramInt1 == 3) {
/*  880 */       insets1.bottom = image.getHeight(null) + (bool ? (-insets1.top - 1) : 0);
/*  881 */       insets2.left = insets1.left;
/*  882 */       insets1.right -= b;
/*  883 */       paramInt3 = rectangle.x;
/*  884 */       paramInt4 = paramInt4 + paramInt6 - 1;
/*  885 */       paramInt5 = rectangle.width + b;
/*  886 */       paramInt6 = 1;
/*  888 */     } else if (paramInt1 == 2) {
/*  890 */       if (paramInt2 == 0) {
/*  892 */         insets1.left = image.getWidth(null) + (bool ? (-insets1.right - 1) : 0);
/*  893 */         insets2.top = insets1.top;
/*  894 */         insets1.bottom -= b;
/*      */       } else {
/*  898 */         insets1.top = image.getHeight(null) + (bool ? (-insets1.bottom - 1) : 0);
/*  899 */         insets2.left = insets1.left;
/*  900 */         insets1.right -= b;
/*      */       } 
/*  902 */       paramInt3 = rectangle.x + rectangle.width;
/*  904 */       paramInt4 = (paramInt2 == 0) ? rectangle.y : (rectangle.y - b);
/*  905 */       paramInt5 = (paramInt2 == 0) ? 1 : (rectangle.height + b);
/*  906 */       paramInt6 = (paramInt2 == 0) ? (rectangle.height + b) : 1;
/*  908 */     } else if (paramInt1 == 4) {
/*  910 */       if (paramInt2 == 0) {
/*  912 */         insets1.right = image.getWidth(null) + (bool ? (-insets1.left - 1) : 0);
/*  913 */         insets2.top = insets1.top;
/*  914 */         insets1.bottom -= b;
/*      */       } else {
/*  918 */         insets1.top = image.getHeight(null) + (bool ? (-insets1.bottom - 1) : 0);
/*  919 */         insets2.left = insets1.left;
/*  920 */         insets1.right -= b;
/*      */       } 
/*  922 */       paramInt3 = rectangle.x - 1;
/*  923 */       paramInt4 = rectangle.y;
/*  924 */       paramInt5 = (paramInt2 == 0) ? 1 : (rectangle.height + b);
/*  925 */       paramInt6 = (paramInt2 == 0) ? (rectangle.height + b) : 1;
/*      */     } 
/*  928 */     ImagePainter imagePainter = new ImagePainter(paramJTabbedPane, null, -1, -1, -1, -1, paramGraphics, paramInt3, paramInt4, paramInt5, paramInt6, str1, insets1, insets2, 0, 0, flipOnRTL(paramJTabbedPane), false);
/*  929 */     imagePainter.setAngle(paramInt2);
/*  931 */     if (paramInt2 != 0 || paramInt1 == 1 || paramInt1 == 3) {
/*  933 */       imagePainter.drawLeft();
/*  934 */       imagePainter.drawRight();
/*      */     } else {
/*  938 */       imagePainter.drawTopCenter();
/*  939 */       imagePainter.drawBottomCenter();
/*      */     } 
/*  941 */     imagePainter.drawCenter();
/*      */   }
/*      */   
/*      */   public boolean paintTabbedPaneTabText(SynthContext paramSynthContext, Graphics paramGraphics, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/*  947 */     return true;
/*      */   }
/*      */   
/*      */   protected boolean flipOnRTL(JComponent paramJComponent) {
/*  960 */     if (paramJComponent.getComponentOrientation() == ComponentOrientation.RIGHT_TO_LEFT && SyntheticaLookAndFeel.getBoolean("Synthetica.tabbedPane.horizontalFlipOnRTL.enabled", paramJComponent))
/*  961 */       return true; 
/*  962 */     return false;
/*      */   }
/*      */   
/*      */   protected int getSelectedRun(JTabbedPane paramJTabbedPane) {
/*  967 */     if (!(paramJTabbedPane.getUI() instanceof BasicTabbedPaneUI))
/*  968 */       return -1; 
/*  970 */     BasicTabbedPaneUI basicTabbedPaneUI = (BasicTabbedPaneUI)paramJTabbedPane.getUI();
/*  971 */     int i = paramJTabbedPane.getSelectedIndex();
/*  972 */     int j = paramJTabbedPane.getTabCount();
/*  973 */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */       try {
/*  977 */         Class<?> clazz = Class.forName("javax.swing.plaf.basic.BasicTabbedPaneUI");
/*  978 */         Method method = clazz.getDeclaredMethod("getRunForTab", new Class[] { int.class, int.class });
/*  979 */         method.setAccessible(true);
/*  980 */         return ((Integer)method.invoke(basicTabbedPaneUI, new Object[] { Integer.valueOf(j), Integer.valueOf(i) })).intValue();
/*  982 */       } catch (Exception exception) {
/*  984 */         throw new RuntimeException(exception);
/*      */       }  
/*  987 */     return -1;
/*      */   }
/*      */   
/*      */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/*  993 */     if (paramString.equals("paintTabbedPaneBorder") || paramString.equals("paintTabbedPaneBackground") || 
/*  994 */       paramString.equals("paintTabbedPaneContentBorder") || paramString.equals("paintTabbedPaneContentBackground"))
/*  995 */       return Cacheable.ScaleType.NINE_SQUARE; 
/*  996 */     return super.getCacheScaleType(paramString);
/*      */   }
/*      */   
/*      */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 1003 */     if (paramString.equals("paintTabbedPaneBorder") || paramString.equals("paintTabbedPaneBackground") || 
/* 1004 */       paramString.equals("paintTabbedPaneContentBorder") || paramString.equals("paintTabbedPaneContentBackground"))
/* 1005 */       return -1; 
/* 1007 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/* 1008 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 1009 */     if (paramString.equals("paintTabbedPaneTabBackground") || paramString.equals("paintTabbedPaneTabBorder")) {
/* 1011 */       i = i * 31 + jTabbedPane.getTabPlacement();
/* 1012 */       i = i * 31 + getTabPosition(jTabbedPane, paramInt3);
/* 1013 */       Integer integer = (Integer)jTabbedPane.getClientProperty("Synthetica.MOUSE_OVER");
/* 1014 */       i = i * 31 + ((integer == null) ? 1000 : integer.intValue());
/*      */     } 
/* 1016 */     return i;
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TabbedPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */