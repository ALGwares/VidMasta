/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Insets;
/*     */ import java.lang.reflect.Field;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ public class FormattedTextFieldStyle extends StyleWrapper {
/*  41 */   private static FormattedTextFieldStyle instance = new FormattedTextFieldStyle();
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  50 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null && ((JTextComponent)paramJComponent).isEditable()) {
/*  52 */       instance.setStyle(paramSynthStyle);
/*  53 */       return instance;
/*     */     } 
/*  55 */     FormattedTextFieldStyle formattedTextFieldStyle = new FormattedTextFieldStyle();
/*  56 */     formattedTextFieldStyle.setStyle(paramSynthStyle);
/*  57 */     return formattedTextFieldStyle;
/*     */   }
/*     */   
/*     */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/*  63 */     Insets insets = this.synthStyle.getInsets(paramSynthContext, paramInsets);
/*  64 */     String str = paramSynthContext.getComponent().getName();
/*  67 */     if ("Spinner.formattedTextField".equals(str)) {
/*  69 */       if ((insets.left > 10 || insets.right > 10) && (JavaVersion.JAVA7 || JavaVersion.JAVA8) && SyntheticaLookAndFeel.getBoolean("Synthetica.ColorChooserPanel.workaround.enabled", null, true))
/*  70 */         colorChooserPanelWorkaround(paramSynthContext); 
/*  71 */       return paramSynthContext.getComponent().getComponentOrientation().isLeftToRight() ? new Insets(0, 0, 0, insets.right) : new Insets(0, insets.right, 0, 0);
/*     */     } 
/*  74 */     if ("ComboBox.textField".equals(str))
/*  77 */       return new Insets(0, 1, 0, 1); 
/*  78 */     return insets;
/*     */   }
/*     */   
/*     */   private void colorChooserPanelWorkaround(final SynthContext sc) {
/*  86 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/*  91 */             if (sc == null)
/*     */               return; 
/*  93 */             JComponent jComponent = sc.getComponent();
/*  94 */             if (jComponent != null && jComponent.getParent() != null) {
/*  96 */               Container container = jComponent.getParent().getParent();
/*  97 */               if (container != null && container.getClass().getName().equals("javax.swing.colorchooser.ColorChooserPanel"))
/*     */                 try {
/* 101 */                   Class<?> clazz = Class.forName("javax.swing.colorchooser.ColorChooserPanel");
/* 102 */                   Field field = clazz.getDeclaredField("slider");
/* 103 */                   field.setAccessible(true);
/* 104 */                   JComponent jComponent1 = (JComponent)field.get(container);
/* 105 */                   jComponent1.setBorder(new EmptyBorder(0, 0, 0, 0));
/* 107 */                   field = clazz.getDeclaredField("diagram");
/* 108 */                   field.setAccessible(true);
/* 109 */                   JComponent jComponent2 = (JComponent)field.get(container);
/* 110 */                   jComponent2.setBorder(new EmptyBorder(0, 0, 0, 0));
/* 112 */                 } catch (Exception exception) {
/* 114 */                   exception.printStackTrace();
/*     */                 }  
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public Color getColorForState(SynthContext paramSynthContext, ColorType paramColorType) {
/* 125 */     JComponent jComponent = paramSynthContext.getComponent();
/* 126 */     if (paramColorType == ColorType.TEXT_FOREGROUND && jComponent.getForeground() instanceof javax.swing.plaf.ColorUIResource && !((JTextComponent)jComponent).isEditable()) {
/* 128 */       Color color = SyntheticaLookAndFeel.getColor("Synthetica.formattedTextField.locked.textColor", jComponent);
/* 129 */       return (color == null) ? super.getColorForState(paramSynthContext, paramColorType) : color;
/*     */     } 
/* 131 */     return super.getColorForState(paramSynthContext, paramColorType);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\FormattedTextFieldStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */