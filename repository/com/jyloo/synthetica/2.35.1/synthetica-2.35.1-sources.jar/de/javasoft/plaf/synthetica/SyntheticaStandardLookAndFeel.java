/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ 
/*    */ public class SyntheticaStandardLookAndFeel extends SyntheticaLookAndFeel {
/*    */   public SyntheticaStandardLookAndFeel() throws ParseException {
/* 30 */     super("standard/xml/synth.xml");
/*    */   }
/*    */   
/*    */   public String getID() {
/* 36 */     return "SyntheticaStandardLookAndFeel";
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return "Synthetica Standard Look and Feel";
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaStandardLookAndFeel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */