/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class PanelPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.PanelPainter";
/*     */   
/*     */   public static PanelPainter getInstance() {
/*  64 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static PanelPainter getInstance(SynthContext paramSynthContext) {
/*  73 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, PanelPainter.class, "Synthetica.PanelPainter"));
/*  74 */     if (syntheticaComponentPainter == null)
/*  75 */       syntheticaComponentPainter = getInstance(paramSynthContext, PanelPainter.class, "Synthetica.PanelPainter"); 
/*  76 */     return (PanelPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintPanelBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintPanelBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  88 */     paintPanelBackground(paramSynthContext.getComponent(), new SyntheticaState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintPanelBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  93 */     if (paramJComponent.isOpaque() || SyntheticaLookAndFeel.getBoolean("Synthetica.panel.background.opaque", paramJComponent, false)) {
/*  95 */       Color color = paramJComponent.getBackground();
/*  96 */       String str1 = SyntheticaLookAndFeel.getString("Synthetica.panel.inactive.background.image", paramJComponent);
/*  97 */       boolean bool1 = false;
/*  98 */       if (str1 != null) {
/* 100 */         Window window = SwingUtilities.getWindowAncestor(paramJComponent);
/* 101 */         bool1 = (window != null && !window.isActive()) ? true : false;
/*     */       } 
/* 103 */       String str2 = bool1 ? str1 : SyntheticaLookAndFeel.getString("Synthetica.panel.background.image", paramJComponent);
/* 104 */       boolean bool2 = (SyntheticaLookAndFeel.getBoolean("Synthetica.panel.background.image.enabled", paramJComponent, true) && !(paramJComponent.getParent() instanceof javax.swing.CellRendererPane)) ? true : false;
/* 105 */       if (color != null && !(color instanceof javax.swing.plaf.ColorUIResource) && (!bool2 || str2 == null || isInternalFrameContentPane(paramJComponent))) {
/* 107 */         paramGraphics.setColor(color);
/* 108 */         paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 110 */       } else if (bool2 && str2 != null && (color == null || (color != null && color instanceof javax.swing.plaf.ColorUIResource))) {
/* 112 */         boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica.panel.background.horizontalTiled", paramJComponent, false) ? true : false;
/* 113 */         boolean bool4 = SyntheticaLookAndFeel.getBoolean("Synthetica.panel.background.verticalTiled", paramJComponent, false) ? true : false;
/* 114 */         Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.panel.background.image.insets", paramJComponent, false);
/* 115 */         Insets insets2 = insets1;
/* 116 */         String str = SyntheticaLookAndFeel.getString("Synthetica.panel.background.image.origin", paramJComponent);
/* 117 */         if (str != null && str.equals("PANEL")) {
/* 119 */           ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, bool3, bool4);
/* 120 */           imagePainter.draw();
/*     */         } else {
/* 124 */           Container container = (str != null && str.equals("CONTENT_PANE")) ? paramJComponent.getRootPane().getContentPane() : paramJComponent.getRootPane();
/* 125 */           if (container == null)
/*     */             return; 
/* 127 */           Rectangle rectangle1 = container.getBounds();
/* 128 */           rectangle1.width = Math.max(rectangle1.width, SyntheticaLookAndFeel.getInt("Synthetica.panel.minimumBackgroundWidth", paramJComponent, rectangle1.width));
/* 129 */           rectangle1.height = Math.max(rectangle1.height, SyntheticaLookAndFeel.getInt("Synthetica.panel.minimumBackgroundHeight", paramJComponent, rectangle1.height));
/* 132 */           boolean bool = ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.panel.paintViewportAware", paramJComponent, Boolean.valueOf(true))).booleanValue();
/* 133 */           Component component = bool ? findRelevantParent(paramJComponent) : paramJComponent;
/* 134 */           Rectangle rectangle2 = SwingUtilities.convertRectangle(component, new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4), container);
/* 135 */           if (component instanceof JViewport) {
/* 137 */             JViewport jViewport = (JViewport)component;
/* 138 */             Point point1 = SwingUtilities.convertPoint(paramJComponent, new Point(), jViewport);
/* 139 */             Point point2 = jViewport.getViewPosition();
/* 140 */             rectangle2.x += point1.x + point2.x;
/* 141 */             rectangle2.y += point1.y + point2.y;
/* 143 */             Point point3 = SwingUtilities.convertPoint(jViewport, new Point(), container);
/* 144 */             Dimension dimension = jViewport.getViewSize();
/* 145 */             rectangle1.width = dimension.width + point3.x;
/* 146 */             rectangle1.height = dimension.height + point3.y;
/*     */           } 
/* 148 */           ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1 - rectangle2.x, paramInt2 - rectangle2.y, rectangle1.width, rectangle1.height, str2, insets1, insets2, bool3, bool4);
/* 149 */           imagePainter.draw();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isInternalFrameContentPane(JComponent paramJComponent) {
/* 157 */     return (SwingUtilities.getAncestorOfClass(JInternalFrame.class, paramJComponent) != null);
/*     */   }
/*     */   
/*     */   private Component findRelevantParent(Component paramComponent) {
/* 163 */     Container container1 = null;
/* 164 */     Container container2 = paramComponent.getParent();
/* 165 */     while (container2 != null) {
/* 167 */       if (container2 instanceof JViewport)
/* 168 */         container1 = container2; 
/* 169 */       container2 = container2.getParent();
/*     */     } 
/* 171 */     return (container1 == null) ? paramComponent : container1;
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 177 */     return Cacheable.ScaleType.NINE_SQUARE;
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 183 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\PanelPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */