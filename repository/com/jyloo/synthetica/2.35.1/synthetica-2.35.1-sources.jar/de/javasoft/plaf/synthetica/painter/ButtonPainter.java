/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class ButtonPainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ButtonPainter";
/*     */   
/*  52 */   protected static WeakHashMap<AbstractButton, Object> buttons = new WeakHashMap<AbstractButton, Object>();
/*     */   
/*     */   public static ButtonPainter getInstance() {
/*  66 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ButtonPainter getInstance(SynthContext paramSynthContext) {
/*  75 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ButtonPainter.class, "Synthetica.ButtonPainter"));
/*  76 */     if (syntheticaComponentPainter == null)
/*  77 */       syntheticaComponentPainter = getInstance(paramSynthContext, ButtonPainter.class, "Synthetica.ButtonPainter"); 
/*  78 */     return (ButtonPainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  93 */     if (!paintCheck(paramSynthContext))
/*     */       return; 
/*  96 */     JComponent jComponent = paramSynthContext.getComponent();
/*  97 */     String str = (String)jComponent.getClientProperty("JButton.segmentPosition");
/*  98 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/*  99 */     paintButtonBackground(jComponent, syntheticaPainterState, str, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintButtonBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, String paramString, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 119 */     paintButtonBackground(paramJComponent, paramSyntheticaState, paramString, 0, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintButtonBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, String paramString, int paramInt1, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 138 */     if (!paintCheck(paramJComponent, paramSyntheticaState))
/*     */       return; 
/* 142 */     if (paramSyntheticaState.isSet(SyntheticaState.State.SELECTED)) {
/* 144 */       paramSyntheticaState = new SyntheticaState(paramSyntheticaState.getState());
/* 145 */       paramSyntheticaState.resetState(SyntheticaState.State.SELECTED);
/* 146 */       paramSyntheticaState.setState(SyntheticaState.State.PRESSED);
/*     */     } 
/* 149 */     String str1 = createSuffix(paramString);
/* 150 */     UIKey uIKey = new UIKey("button.border" + str1, paramSyntheticaState);
/* 151 */     int i = SyntheticaLookAndFeel.getInt("Synthetica.button.smallSizeThreshold", paramJComponent, 12);
/* 152 */     if (paramInt4 <= i || paramInt5 <= i) {
/* 154 */       uIKey = new UIKey("button.12x12.border", paramSyntheticaState);
/* 155 */       str1 = ".12x12";
/*     */     } 
/* 158 */     Insets insets1 = (Insets)UIKey.findProperty(paramJComponent, uIKey.get(), "insets", true, 2);
/* 159 */     Insets insets2 = insets1;
/* 160 */     if (isToolBarButton(paramJComponent) && !SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.buttons.paintBorder", paramJComponent)) {
/* 162 */       uIKey = new UIKey("toolBar.button.border" + str1, paramSyntheticaState);
/* 163 */       if (SyntheticaLookAndFeel.get(uIKey.get(), paramJComponent) == null)
/* 164 */         uIKey = new UIKey("toolBar.button.border", paramSyntheticaState); 
/* 166 */     } else if (isToolBarButtonBarButton(paramJComponent)) {
/* 168 */       UIKey uIKey1 = new UIKey("toolBar.buttonBar.button.border" + str1, paramSyntheticaState);
/* 169 */       if (SyntheticaLookAndFeel.get(uIKey1.get(), paramJComponent) != null)
/* 170 */         uIKey = uIKey1; 
/*     */     } 
/* 174 */     String str2 = SyntheticaLookAndFeel.getString(uIKey.get(), paramJComponent);
/* 176 */     if (paramJComponent.hasFocus() && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused", paramJComponent) != null)
/* 177 */       str2 = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused", paramJComponent); 
/* 180 */     uIKey = new UIKey("button", paramSyntheticaState);
/* 181 */     if (str2 != null && SyntheticaLookAndFeel.isOpaque(paramJComponent)) {
/* 183 */       int j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, 1);
/* 184 */       int k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 50);
/* 185 */       int m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 2);
/* 186 */       if (paramSyntheticaState.isSet(SyntheticaState.State.DEFAULT)) {
/* 188 */         j = SyntheticaLookAndFeel.getInt(uIKey.get("animation.cycles"), paramJComponent, -1);
/* 189 */         k = SyntheticaLookAndFeel.getInt(uIKey.get("animation.delay"), paramJComponent, 70);
/* 190 */         m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 0);
/* 192 */       } else if (paramSyntheticaState.isSet(SyntheticaState.State.HOVER)) {
/* 193 */         m = SyntheticaLookAndFeel.getInt(uIKey.get("animation.type"), paramJComponent, 1);
/*     */       } 
/* 195 */       ImagePainter imagePainter = new ImagePainter(paramJComponent, j, k, m, paramSyntheticaState.getState(), paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5, str2, insets1, insets2, 0, 0);
/* 196 */       imagePainter.setAngle(paramInt1);
/* 197 */       imagePainter.draw();
/*     */     } 
/* 200 */     if ((paramJComponent.hasFocus() || paramSyntheticaState.isSet(SyntheticaState.State.FOCUSED)) && ((AbstractButton)paramJComponent).isFocusPainted())
/* 201 */       paintFocus(paramJComponent, paramSyntheticaState, paramString, paramInt1, paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5); 
/*     */   }
/*     */   
/*     */   protected void paintFocus(JComponent paramJComponent, SyntheticaState paramSyntheticaState, String paramString, int paramInt1, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 220 */     String str1 = createSuffix(paramString);
/* 221 */     int i = SyntheticaLookAndFeel.getInt("Synthetica.button.smallSizeThreshold", paramJComponent, 12);
/* 222 */     if (paramInt4 <= i || paramInt5 <= i)
/* 223 */       str1 = ".12x12"; 
/* 224 */     String str2 = "focus.button" + str1;
/* 225 */     if (isToolBarButton(paramJComponent)) {
/* 226 */       str2 = String.valueOf(str2) + ".toolBar";
/* 227 */     } else if (isToolBarButtonBarButton(paramJComponent)) {
/* 228 */       str2 = String.valueOf(str2) + ".buttonBar.toolBar";
/*     */     } 
/* 229 */     FocusPainter.paintFocus(str2, paramJComponent, paramSyntheticaState.getState(), null, paramInt1, paramGraphics, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   private String createSuffix(String paramString) {
/* 234 */     return (paramString == null || paramString.length() == 0) ? "" : (paramString.startsWith(".") ? paramString : ("." + paramString));
/*     */   }
/*     */   
/*     */   protected boolean paintCheck(SynthContext paramSynthContext) {
/* 245 */     return paintCheck(paramSynthContext.getComponent(), new SyntheticaPainterState(paramSynthContext));
/*     */   }
/*     */   
/*     */   protected boolean paintCheck(JComponent paramJComponent, SyntheticaState paramSyntheticaState) {
/* 250 */     if (!(paramJComponent instanceof AbstractButton))
/* 251 */       return false; 
/* 253 */     AbstractButton abstractButton = (AbstractButton)paramJComponent;
/* 254 */     Container container = abstractButton.getParent();
/* 256 */     if (container != null) {
/* 259 */       if (container instanceof javax.swing.plaf.basic.BasicInternalFrameTitlePane && !SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.titlePane.buttons.paintBorder", abstractButton))
/* 260 */         return false; 
/* 263 */       if (container instanceof de.javasoft.plaf.synthetica.SyntheticaTitlePane && !SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.buttons.paintBorder", abstractButton))
/* 264 */         return false; 
/* 267 */       if (isToolBarButton(paramJComponent)) {
/* 269 */         SynthStyle synthStyle = SynthLookAndFeel.getStyle(paramJComponent, Region.BUTTON);
/* 270 */         SynthContext synthContext = new SynthContext(paramJComponent, Region.BUTTON, synthStyle, 0);
/* 271 */         Insets insets1 = (Insets)synthContext.getStyle().get(synthContext, "Button.margin");
/* 272 */         Insets insets2 = (abstractButton.getMargin() == null) ? new Insets(0, 0, 0, 0) : abstractButton.getMargin();
/* 275 */         if (insets2.equals(insets1) || (!buttons.containsKey(abstractButton) && (abstractButton.getText() == null || "".equals(abstractButton.getText().trim()))))
/* 277 */           if (SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.button.marginCorrection.enabled", paramJComponent, true) && insets2.equals(insets1))
/* 278 */             abstractButton.setMargin(new Insets(insets2.bottom - insets1.bottom, insets2.left - insets1.left, insets2.top - insets1.top, insets2.right - insets1.right));  
/* 280 */         buttons.put(abstractButton, null);
/* 282 */         boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.buttons.paintBorder", abstractButton);
/* 285 */         if (!bool && !paramSyntheticaState.isSet(SyntheticaState.State.HOVER) && SyntheticaLookAndFeel.get("Synthetica.toolBar.button.border", abstractButton) == null && (
/* 286 */           !paramSyntheticaState.isSet(SyntheticaState.State.PRESSED) || !SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.button.pressed.paintBorder", abstractButton)))
/* 287 */           return false; 
/*     */       } 
/*     */     } 
/* 291 */     if (abstractButton.isBorderPainted() || abstractButton.getText() == null || abstractButton.getText().length() == 0) {
/* 293 */       if (!abstractButton.isBorderPainted() && !paramSyntheticaState.isSet(SyntheticaState.State.HOVER))
/* 294 */         return false; 
/* 295 */       if (!abstractButton.isContentAreaFilled())
/* 296 */         return false; 
/* 298 */       return true;
/*     */     } 
/* 301 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isToolBarButton(JComponent paramJComponent) {
/* 306 */     Boolean bool = (Boolean)paramJComponent.getClientProperty("Synthetica.useToolBarStyle");
/* 307 */     return (bool == null || bool.booleanValue()) ? (paramJComponent.getParent() instanceof javax.swing.JToolBar) : false;
/*     */   }
/*     */   
/*     */   private boolean isToolBarButtonBarButton(JComponent paramJComponent) {
/* 312 */     Container container = paramJComponent.getParent();
/* 313 */     return (container != null && container.getParent() instanceof javax.swing.JToolBar && "ButtonBar".equals(SyntheticaLookAndFeel.getStyleName(container)));
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 319 */     AbstractButton abstractButton = (AbstractButton)paramSynthContext.getComponent();
/* 322 */     if (abstractButton.getParent() instanceof javax.swing.JToolBar)
/* 323 */       return -1; 
/* 325 */     String str = (String)abstractButton.getClientProperty("JButton.segmentPosition");
/* 326 */     Border border = abstractButton.getBorder();
/* 328 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 329 */     i = (str == null) ? i : (31 * i + str.hashCode());
/* 330 */     i = (border == null) ? i : (31 * i + (abstractButton.isBorderPainted() ? 0 : 1));
/* 331 */     i = 31 * i + (abstractButton.isContentAreaFilled() ? 0 : 1);
/* 334 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ButtonPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */