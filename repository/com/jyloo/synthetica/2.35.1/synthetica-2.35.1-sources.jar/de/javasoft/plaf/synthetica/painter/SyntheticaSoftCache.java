/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import java.awt.Image;
/*     */ import java.lang.ref.ReferenceQueue;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ class SyntheticaSoftCache {
/*     */   private final int maxCacheSize;
/*     */   
/*     */   private final int maxImageSize;
/*     */   
/*  35 */   private final LinkedHashMap<Integer, ImageReference> cache = new LinkedHashMap<Integer, ImageReference>();
/*     */   
/*  37 */   private ReferenceQueue<Image> referenceQueue = new ReferenceQueue<Image>();
/*     */   
/*  39 */   private int pixelCount = 0;
/*     */   
/*  41 */   private static final SyntheticaSoftCache instance = new SyntheticaSoftCache();
/*     */   
/*     */   private SyntheticaSoftCache() {
/*  48 */     int i = SyntheticaLookAndFeel.getInt("Synthetica.cache.maxSize", null, 4);
/*  49 */     this.maxCacheSize = i * 1024 * 1024;
/*  50 */     this.maxImageSize = SyntheticaLookAndFeel.getInt("Synthetica.cache.maxImageSize", null, 200000);
/*     */   }
/*     */   
/*     */   static SyntheticaSoftCache getInstance() {
/*  59 */     return instance;
/*     */   }
/*     */   
/*     */   public boolean isCacheable(int paramInt1, int paramInt2) {
/*  71 */     return (paramInt1 * paramInt2 < this.maxImageSize && paramInt1 > 0 && paramInt2 > 0);
/*     */   }
/*     */   
/*     */   public Image getImage(int paramInt) {
/*  82 */     ImageReference imageReference = this.cache.get(Integer.valueOf(paramInt));
/*  83 */     if (imageReference != null)
/*  84 */       return imageReference.get(); 
/*  86 */     return null;
/*     */   }
/*     */   
/*     */   public boolean setImage(Image paramImage, int paramInt) {
/*  98 */     ImageReference imageReference = this.cache.get(Integer.valueOf(paramInt));
/* 101 */     if (imageReference != null && imageReference.get() != null)
/* 102 */       return true; 
/* 105 */     int i = paramImage.getWidth(null) * paramImage.getHeight(null);
/* 106 */     this.pixelCount += i;
/* 109 */     while ((imageReference = (ImageReference)this.referenceQueue.poll()) != null) {
/* 111 */       this.cache.remove(Integer.valueOf(imageReference.cacheHash));
/* 112 */       this.pixelCount -= imageReference.pixelCount;
/*     */     } 
/* 116 */     if (this.pixelCount > this.maxCacheSize) {
/* 118 */       Iterator<Map.Entry> iterator = this.cache.entrySet().iterator();
/* 119 */       while (this.pixelCount > this.maxCacheSize / 2 && iterator.hasNext()) {
/* 121 */         Map.Entry entry = iterator.next();
/* 122 */         ImageReference imageReference1 = (ImageReference)entry.getValue();
/* 123 */         Image image = imageReference1.get();
/* 124 */         if (image != null)
/* 125 */           image.flush(); 
/* 126 */         iterator.remove();
/* 127 */         this.pixelCount -= imageReference1.pixelCount;
/*     */       } 
/*     */     } 
/* 131 */     this.cache.put(Integer.valueOf(paramInt), new ImageReference(paramImage, paramInt, this.referenceQueue));
/* 143 */     return true;
/*     */   }
/*     */   
/*     */   public void clear() {
/* 151 */     this.pixelCount = 0;
/* 152 */     this.cache.clear();
/*     */   }
/*     */   
/*     */   private static class ImageReference extends SoftReference<Image> {
/*     */     private int cacheHash;
/*     */     
/*     */     private int pixelCount;
/*     */     
/*     */     public ImageReference(Image param1Image, int param1Int, ReferenceQueue<Image> param1ReferenceQueue) {
/* 167 */       super(param1Image, param1ReferenceQueue);
/* 168 */       this.cacheHash = param1Int;
/* 169 */       this.pixelCount = param1Image.getWidth(null) * param1Image.getHeight(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaSoftCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */