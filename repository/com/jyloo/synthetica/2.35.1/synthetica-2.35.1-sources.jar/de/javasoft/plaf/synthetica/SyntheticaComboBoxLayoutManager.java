/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager2;
/*     */ import java.awt.Rectangle;
/*     */ import java.lang.reflect.Field;
/*     */ import javax.swing.ComboBoxEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicComboBoxUI;
/*     */ 
/*     */ public class SyntheticaComboBoxLayoutManager implements LayoutManager2 {
/*     */   private int cachedMinWidth;
/*     */   
/*     */   public void addLayoutComponent(String paramString, Component paramComponent) {}
/*     */   
/*     */   public void removeLayoutComponent(Component paramComponent) {}
/*     */   
/*     */   public Dimension preferredLayoutSize(Container paramContainer) {
/*  49 */     return paramContainer.getPreferredSize();
/*     */   }
/*     */   
/*     */   public Dimension minimumLayoutSize(Container paramContainer) {
/*  54 */     return paramContainer.getMinimumSize();
/*     */   }
/*     */   
/*     */   public void layoutContainer(Container paramContainer) {
/*  59 */     layoutComboBox(paramContainer);
/*     */   }
/*     */   
/*     */   private void layoutComboBox(Container paramContainer) {
/*  64 */     JComboBox jComboBox = (JComboBox)paramContainer;
/*  65 */     JButton jButton = (JButton)SyntheticaLookAndFeel.findComponent(JButton.class, paramContainer);
/*  66 */     if (jButton != null) {
/*  68 */       Insets insets1 = jComboBox.getInsets();
/*  69 */       Insets insets2 = jButton.getInsets();
/*  70 */       int i = (jButton.getPreferredSize()).width + insets2.left + insets2.right;
/*  71 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.comboBox.button.xOffset", jComboBox, 0);
/*  72 */       if (((Boolean)SyntheticaLookAndFeel.<Boolean>getClientProperty("JComboBox.isTableCellEditor", jComboBox, Boolean.valueOf(false))).booleanValue() && !"JFileChooser.DirectoryComboBox".equals(jComboBox.getName()))
/*  73 */         j = SyntheticaLookAndFeel.getInt("Synthetica.comboBox.button.tableCellEditor.xOffset", jComboBox, 0); 
/*  74 */       jButton.setBounds(jComboBox.getComponentOrientation().isLeftToRight() ? (jComboBox.getWidth() - insets1.right - i + j) : (insets1.left - j), insets1.top, i, jComboBox.getHeight() - insets1.top - insets1.bottom);
/*     */     } 
/*  77 */     ComboBoxEditor comboBoxEditor = jComboBox.getEditor();
/*  78 */     if (comboBoxEditor != null) {
/*  80 */       Insets insets = jComboBox.getInsets();
/*  81 */       Rectangle rectangle = null;
/*  82 */       int i = jComboBox.getWidth();
/*  83 */       int j = jComboBox.getHeight();
/*  84 */       int k = (jButton == null) ? (j - insets.top + insets.bottom) : jButton.getWidth();
/*  85 */       if (jComboBox.getComponentOrientation().isLeftToRight()) {
/*  86 */         rectangle = new Rectangle(insets.left, insets.top, i - insets.left + insets.right + k, j - insets.top + insets.bottom);
/*     */       } else {
/*  88 */         rectangle = new Rectangle(insets.left + k, insets.top, i - insets.left + insets.right + k, j - insets.top + insets.bottom);
/*     */       } 
/*  89 */       comboBoxEditor.getEditorComponent().setBounds(rectangle);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addLayoutComponent(Component paramComponent, Object paramObject) {}
/*     */   
/*     */   public float getLayoutAlignmentX(Container paramContainer) {
/*  99 */     return 0.5F;
/*     */   }
/*     */   
/*     */   public float getLayoutAlignmentY(Container paramContainer) {
/* 104 */     return 0.5F;
/*     */   }
/*     */   
/*     */   public void invalidateLayout(Container paramContainer) {
/* 109 */     if (!JavaVersion.JAVA5)
/*     */       return; 
/* 112 */     JComboBox jComboBox = (JComboBox)paramContainer;
/* 113 */     Dimension dimension = jComboBox.getPreferredSize();
/* 114 */     JButton jButton = (JButton)SyntheticaLookAndFeel.findComponent(JButton.class, jComboBox);
/* 115 */     int i = (jButton == null) ? 0 : ((jButton.getInsets()).left + (jButton.getInsets()).right + (jButton.getPreferredSize()).width - 16);
/* 118 */     Insets insets = UIManager.getInsets("Synthetica.comboPopup.insets");
/* 119 */     if (insets == null)
/* 120 */       insets = new Insets(0, 0, 0, 0); 
/* 121 */     int j = insets.left + insets.right - (jComboBox.getInsets()).left - (jComboBox.getInsets()).right;
/* 122 */     insets = UIManager.getInsets("Synthetica.comboBox.viewport.border.insets");
/* 123 */     j += (insets == null) ? 0 : (insets.left + insets.right);
/* 124 */     i = Math.max(i, j);
/* 126 */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN) {
/* 128 */       BasicComboBoxUI basicComboBoxUI = (BasicComboBoxUI)jComboBox.getUI();
/*     */       try {
/* 132 */         Class<?> clazz = Class.forName("javax.swing.plaf.basic.BasicComboBoxUI");
/* 133 */         Field field = clazz.getDeclaredField("cachedMinimumSize");
/* 134 */         field.setAccessible(true);
/* 135 */         Dimension dimension1 = (Dimension)field.get(basicComboBoxUI);
/* 136 */         if (this.cachedMinWidth != dimension1.width) {
/* 138 */           this.cachedMinWidth = dimension.width + i;
/* 139 */           field.set(basicComboBoxUI, new Dimension(this.cachedMinWidth, dimension.height));
/*     */         } 
/* 142 */       } catch (Exception exception) {
/* 144 */         throw new RuntimeException(exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension maximumLayoutSize(Container paramContainer) {
/* 151 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaComboBoxLayoutManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */