/*      */ package de.javasoft.plaf.synthetica;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.batik.LinearGradientPaint;
/*      */ import de.javasoft.plaf.synthetica.painter.CheckBoxPainter;
/*      */ import de.javasoft.plaf.synthetica.painter.ImagePainter;
/*      */ import de.javasoft.plaf.synthetica.painter.LabelPainter;
/*      */ import de.javasoft.plaf.synthetica.painter.MenuPainter;
/*      */ import de.javasoft.plaf.synthetica.painter.TabbedPanePainter;
/*      */ import de.javasoft.plaf.synthetica.painter.TreePainter;
/*      */ import de.javasoft.util.IVersion;
/*      */ import de.javasoft.util.JavaVersion;
/*      */ import de.javasoft.util.OS;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Font;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.KeyEventPostProcessor;
/*      */ import java.awt.KeyboardFocusManager;
/*      */ import java.awt.LinearGradientPaint;
/*      */ import java.awt.Paint;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.geom.RoundRectangle2D;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.File;
/*      */ import java.io.FileFilter;
/*      */ import java.lang.reflect.Method;
/*      */ import java.net.JarURLConnection;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.security.AccessControlException;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.SecureRandom;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.ResourceBundle;
/*      */ import java.util.TreeMap;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.swing.FocusManager;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JScrollBar;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.JTextPane;
/*      */ import javax.swing.JToolTip;
/*      */ import javax.swing.JTree;
/*      */ import javax.swing.JWindow;
/*      */ import javax.swing.LookAndFeel;
/*      */ import javax.swing.MenuSelectionManager;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIDefaults;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.UnsupportedLookAndFeelException;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.CompoundBorder;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ChangeListener;
/*      */ import javax.swing.plaf.BorderUIResource;
/*      */ import javax.swing.plaf.ColorUIResource;
/*      */ import javax.swing.plaf.DimensionUIResource;
/*      */ import javax.swing.plaf.FontUIResource;
/*      */ import javax.swing.plaf.IconUIResource;
/*      */ import javax.swing.plaf.InsetsUIResource;
/*      */ import javax.swing.plaf.UIResource;
/*      */ import javax.swing.plaf.synth.ColorType;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*      */ import javax.swing.plaf.synth.SynthStyle;
/*      */ import javax.swing.plaf.synth.SynthStyleFactory;
/*      */ import sun.swing.DefaultLookup;
/*      */ import sun.swing.plaf.synth.DefaultSynthStyle;
/*      */ 
/*      */ public abstract class SyntheticaLookAndFeel extends SynthLookAndFeel {
/*  143 */   public static final Logger logger = Logger.getLogger(SyntheticaLookAndFeel.class.getName());
/*      */   
/*  144 */   private static final boolean JAVA5 = JavaVersion.JAVA5;
/*      */   
/*  145 */   private static final boolean JAVA6 = JavaVersion.JAVA6;
/*      */   
/*  146 */   private static final boolean JAVA6_OR_ABOVE = !JAVA5;
/*      */   
/*  147 */   private static final boolean JAVA6U10_OR_ABOVE = JavaVersion.JAVA6U10_OR_ABOVE;
/*      */   
/*  148 */   private static final boolean JAVA7_OR_ABOVE = (!JAVA5 && !JAVA6);
/*      */   
/*  149 */   private static final boolean JAVA7U8_OR_ABOVE = JavaVersion.JAVA7U8_OR_ABOVE;
/*      */   
/*      */   private static Font defaultFont;
/*      */   
/*      */   private static boolean antiAliasEnabled;
/*      */   
/*      */   private static Dimension toolbarSeparatorDimension;
/*      */   
/*  153 */   private static HashMap<String, Icon> iconCache = new HashMap<String, Icon>();
/*      */   
/*      */   private static Boolean uiScaleEnabled;
/*      */   
/*      */   private static boolean decorated = true;
/*      */   
/*      */   private static boolean extendedFileChooserEnabled = true;
/*      */   
/*      */   private static Boolean rememberFileChooserPreferences;
/*      */   
/*      */   private static boolean useSystemFileIcons = true;
/*      */   
/*      */   private static boolean defaultsCompatibilityMode = true;
/*      */   
/*      */   private KeyEventPostProcessor extKeyEventProcessor;
/*      */   
/*      */   private PropertyChangeListener lafChangeListener;
/*      */   
/*      */   private UIDefaults orgDefaults;
/*      */   
/*  167 */   private static boolean debug = isSystemPropertySet("synthetica.debug");
/*      */   
/*  168 */   private static boolean outputVersion = isSystemPropertySet("synthetica.version");
/*      */   
/*      */   private static final boolean NOSTYLE = false;
/*      */   
/*      */   private static UIDefaults uiDefaults;
/*      */   
/*      */   private String lafXMLFile;
/*      */   
/*      */   public enum JVMCompatibilityMode {
/*  174 */     COMMON, SUN;
/*      */   }
/*      */   
/*      */   static {
/*  180 */     Thread thread = new Thread() {
/*      */         private boolean dialogOpen;
/*      */         
/*  183 */         private int millis = 15000;
/*      */         
/*      */         public void run() {
/*      */           while (true) {
/*      */             try {
/*  191 */               sleep(this.millis);
/*  192 */               this.millis = (1800 + (new SecureRandom()).nextInt(3600)) * 1000;
/*  193 */               if (check())
/*      */                 break; 
/*  197 */               if (!this.dialogOpen)
/*  199 */                 EventQueue.invokeLater(new Runnable() {
/*      */                       public void run() {
/*  203 */                         SyntheticaLookAndFeel.null.this.showDialog();
/*      */                       }
/*      */                     }); 
/*  209 */             } catch (InterruptedException interruptedException) {}
/*      */           } 
/*      */         }
/*      */         
/*      */         private boolean check() {
/*  216 */           String str1 = "Synthetica.license.info";
/*  217 */           String str2 = "Synthetica.license.key";
/*      */           try {
/*  220 */             String[] arrayOfString = (String[])UIManager.get(str1);
/*  221 */             String str = (String)UIManager.get(str2);
/*  222 */             if (arrayOfString == null) {
/*      */               try {
/*  226 */                 Properties properties = new Properties();
/*  227 */                 properties.load(getClass().getResourceAsStream("/de/javasoft/resources/license/synthetica.lic"));
/*  228 */                 arrayOfString = ((String)properties.get(str1)).split(",");
/*  229 */                 str = (String)properties.get(str2);
/*  231 */               } catch (Exception exception) {}
/*  234 */               if (arrayOfString == null)
/*      */                 try {
/*  238 */                   arrayOfString = System.getProperty(str1).split(",");
/*  239 */                   str = System.getProperty(str2);
/*  241 */                 } catch (Exception exception) {} 
/*      */             } 
/*  246 */             if (arrayOfString != null && str != null)
/*      */               try {
/*  250 */                 TreeMap<Object, Object> treeMap = new TreeMap<Object, Object>();
/*      */                 byte b;
/*      */                 int i;
/*      */                 String[] arrayOfString1;
/*  251 */                 for (i = (arrayOfString1 = arrayOfString).length, b = 0; b < i; ) {
/*  251 */                   String str5 = arrayOfString1[b];
/*  253 */                   String[] arrayOfString2 = str5.split("=");
/*  254 */                   treeMap.put(arrayOfString2[0], arrayOfString2[1]);
/*      */                   b++;
/*      */                 } 
/*  256 */                 if (!str.equals(createKey((TreeMap)treeMap)) || !"Synthetica".equals(treeMap.get("Product")))
/*  257 */                   throw new RuntimeException(); 
/*  259 */                 String str3 = (String)treeMap.get("ExpireDate");
/*  260 */                 if (!"--.--.----".equals(str3)) {
/*  262 */                   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
/*  263 */                   Date date = simpleDateFormat.parse(str3);
/*  264 */                   if ((new Date()).after(date))
/*  265 */                     throw new RuntimeException(); 
/*      */                 } 
/*  268 */                 String str4 = (String)treeMap.get("LicenseRegistrationNumber");
/*  269 */                 HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*  270 */                 hashMap.put("347713735", "01.01.2004");
/*  271 */                 hashMap.put("139066605", "01.01.2004");
/*  272 */                 for (Map.Entry<Object, Object> entry : hashMap.entrySet()) {
/*  274 */                   if (((String)entry.getKey()).equals(str4)) {
/*  276 */                     Date date1 = new Date();
/*  277 */                     Date date2 = (new SimpleDateFormat("dd.MM.yyyy")).parse((String)entry.getValue());
/*  278 */                     if (date1.after(date2) && date1.getTime() % 3L == 0L)
/*  279 */                       throw new RuntimeException(); 
/*      */                   } 
/*      */                 } 
/*  283 */                 arrayOfString1 = ((String)treeMap.get("MaxVersion")).split("\\.");
/*  284 */                 int j = Integer.parseInt(arrayOfString1[0]);
/*  285 */                 int k = Integer.parseInt(arrayOfString1[1]);
/*  286 */                 int m = Integer.parseInt(arrayOfString1[2]);
/*  287 */                 SyntheticaLookAndFeel.Version version = new SyntheticaLookAndFeel.Version();
/*  288 */                 if (version.getMajor() > j || (version.getMajor() == j && version.getMinor() > k) || (version.getMajor() == j && version.getMinor() == k && version.getRevision() > m))
/*  289 */                   throw new RuntimeException(); 
/*  291 */                 return true;
/*  293 */               } catch (Exception exception) {} 
/*  299 */           } catch (Exception exception) {}
/*  302 */           return false;
/*      */         }
/*      */         
/*      */         private String createKey(TreeMap<String, String> param1TreeMap) throws Exception {
/*  307 */           StringBuilder stringBuilder1 = new StringBuilder();
/*  308 */           for (Map.Entry<String, String> entry : param1TreeMap.entrySet())
/*  309 */             stringBuilder1.append(entry).append("\n"); 
/*  311 */           MessageDigest messageDigest = MessageDigest.getInstance("MD5");
/*  312 */           messageDigest.reset();
/*  313 */           messageDigest.update(stringBuilder1.toString().getBytes("UTF-8"));
/*  314 */           byte[] arrayOfByte = messageDigest.digest();
/*  315 */           StringBuilder stringBuilder2 = new StringBuilder(arrayOfByte.length * 2);
/*  316 */           for (byte b = 0; b < arrayOfByte.length; b++) {
/*  318 */             int i = arrayOfByte[b] & 0xFF;
/*  319 */             if (i < 16)
/*  320 */               stringBuilder2.append('0'); 
/*  321 */             stringBuilder2.append(Integer.toHexString(i));
/*  322 */             if (b % 4 == 3 && b < arrayOfByte.length - 1)
/*  323 */               stringBuilder2.append("-"); 
/*      */           } 
/*  325 */           return stringBuilder2.toString().toUpperCase();
/*      */         }
/*      */         
/*      */         private void showDialog() {
/*  330 */           this.dialogOpen = true;
/*  331 */           String str = "<html>It looks like you are using an invalid or outdated <b>Synthetica</b> license.<br>Please post your License Registration Number to the <b>Support Center</b><br> and request a valid license key.";
/*  333 */           Window window = FocusManager.getCurrentManager().getActiveWindow();
/*  334 */           JOptionPane.showMessageDialog(window, str, "Synthetica License Warning", 2);
/*  335 */           this.dialogOpen = false;
/*      */         }
/*      */       };
/*  338 */     thread.setDaemon(true);
/*  339 */     if (!SyntheticaRootPaneUI.isEvalCopy())
/*  340 */       thread.start(); 
/*      */   }
/*      */   
/*      */   public SyntheticaLookAndFeel() throws ParseException {}
/*      */   
/*      */   public SyntheticaLookAndFeel(String paramString) throws ParseException {
/*  359 */     this.lafXMLFile = paramString;
/*  360 */     loadXMLConfig(paramString);
/*  361 */     if (paramString.endsWith(".xml")) {
/*  363 */       String str = paramString.substring(0, paramString.lastIndexOf("/"));
/*  364 */       loadAddonsXMLConfig(str);
/*      */     } 
/*  366 */     loadCustomXML();
/*      */   }
/*      */   
/*      */   public String getConfigFileName() {
/*  374 */     return this.lafXMLFile;
/*      */   }
/*      */   
/*      */   protected void loadCustomXML() throws ParseException {
/*  382 */     Object object = UIManager.get("Synthetica.customXML");
/*  383 */     if (object instanceof String) {
/*  384 */       loadXMLConfig((String)object);
/*  385 */     } else if (object instanceof String[]) {
/*      */       byte b;
/*      */       int i;
/*      */       String[] arrayOfString;
/*  387 */       for (i = (arrayOfString = (String[])object).length, b = 0; b < i; ) {
/*  387 */         String str = arrayOfString[b];
/*  388 */         loadXMLConfig(str);
/*      */         b++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadAddonsXMLConfig(String paramString) throws ParseException {
/*  397 */     Class<SyntheticaLookAndFeel> clazz = SyntheticaLookAndFeel.class;
/*  398 */     String str = paramString.replace("/", ".");
/*  399 */     if (str.startsWith(".")) {
/*  400 */       str = str.substring(1);
/*      */     } else {
/*  402 */       str = String.valueOf(clazz.getPackage().getName()) + "." + paramString.replace("/", ".");
/*      */     } 
/*      */     try {
/*  406 */       Class<?> clazz1 = Class.forName(String.valueOf(str) + ".XMLProvider");
/*  407 */       AddonsXMLProvider addonsXMLProvider = (AddonsXMLProvider)clazz1.newInstance();
/*      */       byte b;
/*      */       int i;
/*      */       String[] arrayOfString;
/*  408 */       for (i = (arrayOfString = addonsXMLProvider.getXMLFileNames()).length, b = 0; b < i; ) {
/*  408 */         String str1 = arrayOfString[b];
/*  409 */         load(clazz.getResourceAsStream(String.valueOf(paramString) + "/" + str1), clazz);
/*      */         b++;
/*      */       } 
/*  411 */     } catch (ClassNotFoundException classNotFoundException) {
/*      */     
/*  414 */     } catch (InstantiationException instantiationException) {
/*  416 */       throw new RuntimeException(instantiationException);
/*  418 */     } catch (IllegalAccessException illegalAccessException) {
/*  420 */       throw new RuntimeException(illegalAccessException);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void loadXMLConfig(String paramString) throws ParseException {
/*  434 */     long l1 = System.currentTimeMillis();
/*  435 */     Class<SyntheticaLookAndFeel> clazz = SyntheticaLookAndFeel.class;
/*  437 */     if (paramString.endsWith(".xml")) {
/*  438 */       load(clazz.getResourceAsStream(paramString), clazz);
/*      */     } else {
/*  442 */       String[] arrayOfString1 = { paramString };
/*  444 */       String str = clazz.getPackage().getName().replace(".", "/");
/*      */       byte b;
/*      */       int i;
/*      */       String[] arrayOfString2;
/*  447 */       for (i = (arrayOfString2 = arrayOfString1).length, b = 0; b < i; ) {
/*  447 */         String str1 = arrayOfString2[b];
/*      */         try {
/*  451 */           String str2 = str1.startsWith("/") ? (str2 = str1.substring(1)) : (String.valueOf(str) + "/" + str1);
/*  452 */           Enumeration<URL> enumeration = clazz.getClassLoader().getResources(str2);
/*  453 */           while (enumeration.hasMoreElements()) {
/*  455 */             URL uRL = enumeration.nextElement();
/*  456 */             if (uRL.getProtocol().equalsIgnoreCase("jar")) {
/*  458 */               JarURLConnection jarURLConnection = (JarURLConnection)uRL.openConnection();
/*  459 */               JarFile jarFile = jarURLConnection.getJarFile();
/*  460 */               for (JarEntry jarEntry : Collections.<JarEntry>list(jarFile.entries())) {
/*  462 */                 if (jarEntry.getName().endsWith(".xml") && jarEntry.getName().startsWith(str2))
/*  463 */                   load(clazz.getResourceAsStream("/" + jarEntry.getName()), clazz); 
/*      */               } 
/*      */               continue;
/*      */             } 
/*  469 */             URI uRI = new URI(uRL.toString());
/*  470 */             File[] arrayOfFile1 = (new File(uRI.getPath())).listFiles(new FileFilter() {
/*      */                   public boolean accept(File param1File) {
/*  474 */                     return param1File.getName().endsWith(".xml");
/*      */                   }
/*      */                 });
/*      */             byte b1;
/*      */             int j;
/*      */             File[] arrayOfFile2;
/*  477 */             for (j = (arrayOfFile2 = arrayOfFile1).length, b1 = 0; b1 < j; ) {
/*  477 */               File file = arrayOfFile2[b1];
/*  478 */               load(file.toURI().toURL().openStream(), clazz);
/*      */               b1++;
/*      */             } 
/*      */           } 
/*  482 */         } catch (Exception exception) {
/*  484 */           throw new RuntimeException(exception);
/*      */         } 
/*      */         b++;
/*      */       } 
/*      */     } 
/*  489 */     if (isSystemPropertySet("synthetica.enhancedXMLLookup")) {
/*      */       try {
/*  494 */         String str1 = "Synthetica.xml";
/*  495 */         load(clazz.getResourceAsStream("/" + str1), clazz);
/*  496 */         if (debug)
/*  497 */           System.out.println("[Info] Found '" + str1 + "' configuration file."); 
/*  499 */       } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  503 */       } catch (Exception exception) {
/*  505 */         exception.printStackTrace();
/*      */       } 
/*  509 */       String str = getClass().getName();
/*      */       try {
/*  512 */         String str1 = String.valueOf(str.substring(str.lastIndexOf(".") + 1)) + ".xml";
/*  513 */         load(clazz.getResourceAsStream("/" + str1), clazz);
/*  514 */         if (debug)
/*  515 */           System.out.println("[Info] Found '" + str1 + "' configuration file."); 
/*  517 */       } catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  521 */       } catch (Exception exception) {
/*  523 */         exception.printStackTrace();
/*      */       } 
/*      */     } 
/*  527 */     long l2 = System.currentTimeMillis();
/*  528 */     if (isSystemPropertySet("synthetica.loadTime"))
/*  530 */       System.out.println("Time for loading LAF: " + (l2 - l1) + "ms"); 
/*  534 */     if (isSystemPropertySet("synthetica.blockLAFChange")) {
/*  536 */       System.out.println("LAF switchings will be blocked!");
/*  537 */       blockLAFChange();
/*      */     } 
/*  540 */     if (debug)
/*  541 */       System.out.println("Synthetica debug mode is enabled!"); 
/*  543 */     if (outputVersion)
/*  544 */       System.out.format("Synthetica V%s\n%s V%s\n", new Object[] { getSyntheticaVersion().toString(), getName(), getVersion().toString() }); 
/*      */   }
/*      */   
/*      */   public String getDescription() {
/*  552 */     return "Synthetica - the extended Synth Look and Feel.";
/*      */   }
/*      */   
/*      */   public IVersion getVersion() {
/*  562 */     ResourceBundle resourceBundle = getResourceBundle(String.valueOf(getID()) + "Version", new Locale("", ""));
/*  563 */     final int major = Integer.parseInt(resourceBundle.getString("major"));
/*  564 */     final int minor = Integer.parseInt(resourceBundle.getString("minor"));
/*  565 */     final int revision = Integer.parseInt(resourceBundle.getString("revision"));
/*  566 */     final int build = Integer.parseInt(resourceBundle.getString("build"));
/*  567 */     return new IVersion() {
/*      */         public int getMajor() {
/*  574 */           return major;
/*      */         }
/*      */         
/*      */         public int getMinor() {
/*  581 */           return minor;
/*      */         }
/*      */         
/*      */         public int getRevision() {
/*  588 */           return revision;
/*      */         }
/*      */         
/*      */         public int getBuild() {
/*  595 */           return build;
/*      */         }
/*      */         
/*      */         public String toString() {
/*  602 */           return String.valueOf(major) + "." + minor + "." + revision + " Build " + build;
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   static boolean shouldUpdateStyle(PropertyChangeEvent paramPropertyChangeEvent) {
/*  609 */     LookAndFeel lookAndFeel = UIManager.getLookAndFeel();
/*  610 */     return (lookAndFeel instanceof SyntheticaLookAndFeel && ((SyntheticaLookAndFeel)lookAndFeel).shouldUpdateStyleOnEvent(paramPropertyChangeEvent));
/*      */   }
/*      */   
/*      */   public boolean getSupportsWindowDecorations() {
/*  616 */     return true;
/*      */   }
/*      */   
/*      */   public UIDefaults getDefaults() {
/*  625 */     return super.getDefaults();
/*      */   }
/*      */   
/*      */   private void addResourceBundleToDefaults(String paramString, Map<Object, Object> paramMap) {
/*  656 */     ResourceBundle resourceBundle = getResourceBundle(paramString, Locale.getDefault());
/*  657 */     for (Enumeration<String> enumeration = resourceBundle.getKeys(); enumeration.hasMoreElements(); ) {
/*  659 */       String str1 = enumeration.nextElement();
/*  660 */       String str2 = resourceBundle.getString(str1);
/*  661 */       paramMap.put(str1, str2);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void initialize() {
/*  671 */     super.initialize();
/*  673 */     this.orgDefaults = (UIDefaults)UIManager.getDefaults().clone();
/*  678 */     if (getJVMCompatibilityMode() == JVMCompatibilityMode.SUN)
/*      */       try {
/*  682 */         Class<?> clazz = Class.forName("sun.swing.DefaultLookup");
/*  683 */         Method method = clazz.getMethod("setDefaultLookup", new Class[] { DefaultLookup.class });
/*  684 */         method.invoke(clazz, new Object[] { new SyntheticaDefaultLookup() });
/*  686 */       } catch (Exception exception) {
/*  688 */         exception.printStackTrace();
/*      */       }  
/*  692 */     StyleFactory styleFactory = new StyleFactory(getStyleFactory());
/*  693 */     SynthLookAndFeel.setStyleFactory(styleFactory);
/*  694 */     PopupFactory.install();
/*  699 */     this.lafChangeListener = new PropertyChangeListener() {
/*      */         public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*  704 */           SyntheticaLookAndFeel.setFont((Font)null);
/*  705 */           SyntheticaLookAndFeel.this.reinit();
/*  706 */           SyntheticaLookAndFeel.this.installSyntheticaDefaults();
/*  707 */           if (SyntheticaLookAndFeel.defaultsCompatibilityMode)
/*  708 */             SyntheticaLookAndFeel.this.installCompatibilityDefaults(); 
/*  710 */           String str1 = System.getProperty("synthetica.font");
/*  711 */           if (str1 != null)
/*  712 */             SyntheticaLookAndFeel.setFont(new Font(str1, SyntheticaLookAndFeel.getFont().getStyle(), SyntheticaLookAndFeel.getFont().getSize())); 
/*  713 */           String str2 = System.getProperty("synthetica.fontsize");
/*  714 */           if (str2 != null)
/*  715 */             SyntheticaLookAndFeel.setFont(SyntheticaLookAndFeel.getFont().deriveFont(Float.parseFloat(str2))); 
/*  717 */           SyntheticaLookAndFeel.updateAllWindowShapes();
/*      */         }
/*      */       };
/*  721 */     PropertyChangeListener[] arrayOfPropertyChangeListener1 = UIManager.getPropertyChangeListeners();
/*      */     byte b;
/*      */     int i;
/*      */     PropertyChangeListener[] arrayOfPropertyChangeListener2;
/*  722 */     for (i = (arrayOfPropertyChangeListener2 = arrayOfPropertyChangeListener1).length, b = 0; b < i; ) {
/*  722 */       PropertyChangeListener propertyChangeListener = arrayOfPropertyChangeListener2[b];
/*  723 */       UIManager.removePropertyChangeListener(propertyChangeListener);
/*      */       b++;
/*      */     } 
/*  724 */     UIManager.addPropertyChangeListener(this.lafChangeListener);
/*  725 */     for (i = (arrayOfPropertyChangeListener2 = arrayOfPropertyChangeListener1).length, b = 0; b < i; ) {
/*  725 */       PropertyChangeListener propertyChangeListener = arrayOfPropertyChangeListener2[b];
/*  726 */       UIManager.addPropertyChangeListener(propertyChangeListener);
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void reinit() {
/*  757 */     iconCache.clear();
/*  758 */     LabelPainter.reinitialize();
/*  759 */     CheckBoxPainter.reinitialize();
/*  760 */     MenuPainter.reinitialize();
/*  761 */     TreePainter.reinitialize();
/*  762 */     TabbedPanePainter.reinitialize();
/*  763 */     ImagePainter.clearImageCache();
/*  764 */     StyleFactory.reinitialize();
/*      */   }
/*      */   
/*      */   protected void installSyntheticaDefaults() {
/*  769 */     uiDefaults = UIManager.getDefaults();
/*  771 */     if (isSystemPropertySet("Synthetica.installSwingXUIs", true)) {
/*  773 */       uiDefaults.put("HyperlinkUI", "de.javasoft.plaf.synthetica.HyperlinkUI");
/*  774 */       uiDefaults.put("StatusBarUI", "de.javasoft.plaf.synthetica.StatusBarUI");
/*  776 */       uiDefaults.put("LoginPanelUI", "de.javasoft.plaf.synthetica.LoginPanelUI");
/*  778 */       uiDefaults.put("LoginPaneUI", "de.javasoft.plaf.synthetica.LoginPanelUI");
/*  779 */       uiDefaults.put("MonthViewUI", "de.javasoft.plaf.synthetica.MonthViewUI");
/*  780 */       uiDefaults.put("TitledPanelUI", "de.javasoft.plaf.synthetica.TitledPanelUI");
/*  781 */       uiDefaults.put("HeaderUI", "de.javasoft.plaf.synthetica.HeaderUI");
/*  782 */       uiDefaults.put("swingx/GroupableTableHeaderUI", "de.javasoft.plaf.synthetica.GroupableTableHeaderUI");
/*  783 */       uiDefaults.put("swingx/TaskPaneUI", "de.javasoft.plaf.synthetica.TaskPaneUI");
/*  784 */       uiDefaults.put("swingx/TaskPaneContainerUI", "de.javasoft.plaf.synthetica.TaskPaneContainerUI");
/*  785 */       uiDefaults.put("swingx/TipOfTheDayUI", "de.javasoft.plaf.synthetica.TipOfTheDayUI");
/*  786 */       uiDefaults.put("Flexdock.view", "de.javasoft.plaf.synthetica.flexdock.ViewUI");
/*  787 */       uiDefaults.put("Flexdock.titlebar", "de.javasoft.plaf.synthetica.flexdock.TitlebarUI");
/*  788 */       uiDefaults.put("Flexdock.titlebar.button", "de.javasoft.plaf.synthetica.flexdock.ButtonUI");
/*      */     } 
/*  816 */     addResourceBundleToDefaults("synthetica", uiDefaults);
/*  818 */     if (UIManager.getBoolean("Synthetica.window.decoration")) {
/*  819 */       uiDefaults.put("RootPaneUI", "de.javasoft.plaf.synthetica.SyntheticaRootPaneUI");
/*      */     } else {
/*  821 */       decorated = false;
/*      */     } 
/*  822 */     JFrame.setDefaultLookAndFeelDecorated(decorated);
/*  823 */     JDialog.setDefaultLookAndFeelDecorated(decorated);
/*  825 */     if (!UIManager.getBoolean("Synthetica.menuItem.useSynthUIDelegates")) {
/*  827 */       uiDefaults.put("MenuUI", "de.javasoft.plaf.synthetica.SyntheticaMenuUI");
/*  828 */       uiDefaults.put("MenuItemUI", "de.javasoft.plaf.synthetica.SyntheticaMenuItemUI");
/*  829 */       uiDefaults.put("CheckBoxMenuItemUI", "de.javasoft.plaf.synthetica.SyntheticaCheckBoxMenuItemUI");
/*  830 */       uiDefaults.put("RadioButtonMenuItemUI", "de.javasoft.plaf.synthetica.SyntheticaRadioButtonMenuItemUI");
/*      */     } 
/*  833 */     extendedFileChooserEnabled = UIManager.getBoolean("Synthetica.extendedFileChooser.enabled");
/*  834 */     setExtendedFileChooserEnabled(extendedFileChooserEnabled);
/*  835 */     useSystemFileIcons = UIManager.getBoolean("Synthetica.extendedFileChooser.useSystemFileIcons");
/*  839 */     UIDefaults uIDefaults = UIManager.getLookAndFeelDefaults();
/*  840 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*  841 */     for (Map.Entry<Object, Object> entry : uIDefaults.entrySet()) {
/*  843 */       if (!uiDefaults.containsKey(entry.getKey()))
/*  844 */         hashMap.put(entry.getKey(), entry.getValue()); 
/*      */     } 
/*  846 */     uiDefaults.putAll(hashMap);
/*  848 */     this.extKeyEventProcessor = new ExtKeyEventProcessor();
/*  849 */     KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(this.extKeyEventProcessor);
/*  850 */     if (ExtKeyEventProcessor.showMnemonicsOnAltKeyOnly())
/*  852 */       MenuSelectionManager.defaultManager().addChangeListener(new ChangeListener() {
/*      */             boolean repaint = true;
/*      */             
/*      */             public void stateChanged(ChangeEvent param1ChangeEvent) {
/*  857 */               Window window = FocusManager.getCurrentManager().getFocusedWindow();
/*  858 */               JMenuBar jMenuBar = null;
/*  859 */               if (window instanceof JFrame) {
/*  860 */                 jMenuBar = ((JFrame)window).getJMenuBar();
/*  861 */               } else if (window instanceof JDialog) {
/*  862 */                 jMenuBar = ((JDialog)window).getJMenuBar();
/*      */               } 
/*  864 */               boolean bool = ((MenuSelectionManager.defaultManager().getSelectedPath()).length == 0) ? true : false;
/*  865 */               if (bool)
/*  866 */                 ExtKeyEventProcessor.setMenuActive(false); 
/*  868 */               if (jMenuBar != null && (this.repaint || bool)) {
/*  870 */                 jMenuBar.repaint();
/*  871 */                 this.repaint = bool;
/*      */               } 
/*      */             }
/*      */           }); 
/*      */   }
/*      */   
/*      */   protected void installCompatibilityDefaults() {
/*  885 */     installCompatibilityDefaults(UIManager.getDefaults());
/*  886 */     if (isSystemPropertySet("synthetica.defaults.initLAFDefaults") || (System.getProperty("synthetica.defaults.initLAFDefaults") == null && isSystemPropertySet("nb.forceui", "de.javasoft.synthetica.netbeans.SyntheticaLFCustoms")))
/*  887 */       installCompatibilityDefaults(UIManager.getLookAndFeelDefaults()); 
/*      */   }
/*      */   
/*      */   private void installCompatibilityDefaults(UIDefaults paramUIDefaults) {
/*  893 */     initSystemColorDefaults(paramUIDefaults);
/*  905 */     Object[] arrayOfObject1 = { 
/*  907 */         "OptionPane.errorSound", 
/*  908 */         "OptionPane.informationSound", 
/*  909 */         "OptionPane.questionSound", 
/*  910 */         "OptionPane.warningSound", 
/*  911 */         "InternalFrame.closeSound", 
/*  912 */         "InternalFrame.maximizeSound", 
/*  913 */         "InternalFrame.minimizeSound", 
/*  914 */         "InternalFrame.restoreDownSound", 
/*  915 */         "InternalFrame.restoreUpSound", 
/*  916 */         "PopupMenu.popupSound", 
/*  917 */         "MenuItem.commandSound", 
/*  918 */         "CheckBoxMenuItem.commandSound", 
/*  919 */         "RadioButtonMenuItem.commandSound" };
/*  922 */     Object[] arrayOfObject2 = { 
/*  924 */         "FileChooser.usesSingleFilePane", Boolean.valueOf(true), 
/*  925 */         "FileChooser.ancestorInputMap", new UIDefaults.LazyInputMap(new Object[] { "ESCAPE", "cancelSelection", "F2", "editFileName", "F5", "refresh", "ENTER", "approveSelection", "BACK_SPACE", "Go Up" }), "List.selectionForeground", new ColorUIResource(Color.white), 
/*  927 */         "SplitPane.dividerSize", Integer.valueOf(8), 
/*  928 */         "List.focusCellHighlightBorder", new BorderUIResource.LineBorderUIResource(paramUIDefaults.getColor("Synthetica.list.focusCellHighlightBorder.color")), 
/*  931 */         "Table.focusCellHighlightBorder", new BorderUIResource.LineBorderUIResource(paramUIDefaults.getColor("Synthetica.table.focusCellHighlightBorder.color")), 
/*  932 */         "TitledBorder.border", new BorderUIResource(new SyntheticaTitledBorder()), 
/*  933 */         "RootPane.defaultButtonWindowKeyBindings", { "ENTER", "press", "released ENTER", "release", "ctrl ENTER", "press", "ctrl released ENTER", "release" }, "controlLtHighlight", new ColorUIResource(Color.WHITE), 
/*  938 */         "controlHighlight", new ColorUIResource(Color.LIGHT_GRAY), 
/*  939 */         "controlShadow", new ColorUIResource(Color.DARK_GRAY), 
/*  940 */         "controlDkShadow", new ColorUIResource(Color.BLACK), 
/*      */         
/*  942 */         "ScrollBar.minimumThumbSize", new DimensionUIResource(8, 8), 
/*  943 */         "ScrollBar.maximumThumbSize", new DimensionUIResource(4096, 4096), 
/*      */         
/*  946 */         "AuditoryCues.cueList", arrayOfObject1, 
/*  947 */         "AuditoryCues.defaultCueList", { "OptionPane.informationSound", 
/*  950 */           "OptionPane.warningSound", 
/*  951 */           "OptionPane.questionSound", 
/*  952 */           "OptionPane.errorSound" }, "AuditoryCues.allAuditoryCues", arrayOfObject1, 
/*  955 */         "AuditoryCues.noAuditoryCues", { "mute" }, "OptionPane.informationSound", "/javax/swing/plaf/metal/sounds/OptionPaneInformation.wav", 
/*  958 */         "OptionPane.warningSound", "/javax/swing/plaf/metal/sounds/OptionPaneWarning.wav", 
/*  959 */         "OptionPane.errorSound", "/javax/swing/plaf/metal/sounds/OptionPaneError.wav", 
/*  960 */         "OptionPane.questionSound", "/javax/swing/plaf/metal/sounds/OptionPaneQuestion.wav", 
/*  961 */         "InternalFrame.closeSound", "/javax/swing/plaf/metal/sounds/FrameClose.wav", 
/*  962 */         "InternalFrame.maximizeSound", "/javax/swing/plaf/metal/sounds/FrameMaximize.wav", 
/*  963 */         "InternalFrame.minimizeSound", "/javax/swing/plaf/metal/sounds/FrameMinimize.wav", 
/*  964 */         "InternalFrame.restoreDownSound", "/javax/swing/plaf/metal/sounds/FrameRestoreDown.wav", 
/*  965 */         "InternalFrame.restoreUpSound", "/javax/swing/plaf/metal/sounds/FrameRestoreUp.wav", 
/*  966 */         "MenuItem.commandSound", "/javax/swing/plaf/metal/sounds/MenuItemCommand.wav", 
/*  967 */         "PopupMenu.popupSound", "/javax/swing/plaf/metal/sounds/PopupMenuPopup.wav", 
/*  968 */         "CheckBoxMenuItem.commandSound", "/javax/swing/plaf/metal/sounds/MenuItemCommand.wav", 
/*  969 */         "RadioButtonMenuItem.commandSound", "/javax/swing/plaf/metal/sounds/MenuItemCommand.wav" };
/*  971 */     paramUIDefaults.putDefaults(arrayOfObject2);
/*  973 */     paramUIDefaults.putDefaults(SyntheticaInputDefaults.getInputMapDefaults());
/*  975 */     SynthStyle synthStyle = null;
/*  976 */     SynthContext synthContext = null;
/*  977 */     SynthStyleFactory synthStyleFactory = getStyleFactory();
/*  978 */     String[] arrayOfString1 = null;
/*  979 */     String[] arrayOfString2 = null;
/*  980 */     Font font = null;
/*  983 */     JButton jButton = new JButton();
/*  984 */     synthStyle = synthStyleFactory.getStyle(jButton, Region.BUTTON);
/*  985 */     synthContext = new SynthContext(jButton, Region.BUTTON, synthStyle, 1);
/*  986 */     paramUIDefaults.put("Button.focusInputMap", synthStyle.get(synthContext, "Button.focusInputMap"));
/*  987 */     font = synthStyle.getFont(synthContext);
/*  988 */     paramUIDefaults.put("Button.font", font);
/*  989 */     paramUIDefaults.put("ToggleButton.font", font);
/*  990 */     paramUIDefaults.put("Button.textShiftOffset", Integer.valueOf(synthStyle.getInt(synthContext, "Button.textShiftOffset", 0)));
/*  991 */     paramUIDefaults.put("Button.foreground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/*  992 */     synthContext = new SynthContext(jButton, Region.BUTTON, synthStyle, 8);
/*  993 */     paramUIDefaults.put("Button.disabledForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/*  996 */     JComboBox jComboBox = new JComboBox();
/*  997 */     synthStyle = synthStyleFactory.getStyle(jComboBox, Region.COMBO_BOX);
/*  999 */     synthContext = new SynthContext(jComboBox, Region.COMBO_BOX, synthStyle, 0);
/* 1000 */     paramUIDefaults.put("ComboBox.focusInputMap", synthStyle.get(synthContext, "ComboBox.focusInputMap"));
/* 1001 */     Color color1 = synthStyle.getColor(synthContext, ColorType.BACKGROUND);
/* 1002 */     paramUIDefaults.put("ComboBox.background", color1);
/* 1003 */     Color color2 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1004 */     paramUIDefaults.put("ComboBox.foreground", color2);
/* 1006 */     paramUIDefaults.put("ComboBox.font", synthStyle.getFont(synthContext));
/* 1008 */     synthStyle = synthStyleFactory.getStyle(jComboBox, Region.LIST);
/* 1009 */     synthContext = new SynthContext(jComboBox, Region.LIST, synthStyle, 512);
/* 1010 */     paramUIDefaults.put("ComboBox.selectionForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1011 */     paramUIDefaults.put("ComboBox.selectionBackground", synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND));
/* 1014 */     JLabel jLabel = new JLabel();
/* 1015 */     synthStyle = synthStyleFactory.getStyle(jLabel, Region.LABEL);
/* 1016 */     synthContext = new SynthContext(jLabel, Region.LABEL, synthStyle, 0);
/* 1019 */     font = synthStyle.getFont(synthContext);
/* 1020 */     paramUIDefaults.put("Label.font", font);
/* 1021 */     if (paramUIDefaults.get("JXMonthView.font") == null)
/* 1022 */       paramUIDefaults.put("JXMonthView.font", font); 
/* 1023 */     if (paramUIDefaults.get("JXTitledPanel.titleFont") == null)
/* 1024 */       paramUIDefaults.put("JXTitledPanel.titleFont", font.deriveFont(1)); 
/* 1027 */     Color color3 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1028 */     paramUIDefaults.put("Label.foreground", color3);
/* 1029 */     synthContext = new SynthContext(jLabel, Region.LABEL, synthStyle, 8);
/* 1030 */     color3 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1031 */     paramUIDefaults.put("Label.disabledForeground", color3);
/* 1033 */     Insets insets = jLabel.getInsets();
/* 1034 */     jLabel.setName("Table.cellRenderer");
/* 1036 */     if (!insets.equals(jLabel.getInsets())) {
/* 1038 */       Border border1 = jLabel.getBorder();
/* 1039 */       Insets insets1 = border1.getBorderInsets(jLabel);
/* 1040 */       paramUIDefaults.put("Table.cellNoFocusBorder", border1);
/* 1042 */       Border border2 = paramUIDefaults.getBorder("Table.focusCellHighlightBorder");
/* 1043 */       Insets insets2 = border2.getBorderInsets(jLabel);
/* 1044 */       Insets insets3 = new Insets(insets1.top - insets2.top, insets1.left - insets2.left, insets1.bottom - insets2.bottom, insets1.right - insets2.right);
/* 1046 */       border2 = new BorderUIResource(new CompoundBorder(border2, new EmptyBorder(insets3)));
/* 1047 */       paramUIDefaults.put("Table.focusCellHighlightBorder", border2);
/*      */     } 
/* 1051 */     JPanel jPanel = new JPanel();
/* 1052 */     synthStyle = synthStyleFactory.getStyle(jPanel, Region.PANEL);
/* 1053 */     synthContext = new SynthContext(jPanel, Region.PANEL, synthStyle, 0);
/* 1054 */     Color color4 = synthStyle.getColor(synthContext, ColorType.BACKGROUND);
/* 1055 */     paramUIDefaults.put("Panel.background", color4);
/* 1056 */     paramUIDefaults.put("SplitPane.background", color4);
/* 1057 */     paramUIDefaults.put("Label.background", color4);
/* 1058 */     paramUIDefaults.put("ColorChooser.swatchesDefaultRecentColor", color4);
/* 1059 */     paramUIDefaults.put("control", color4);
/* 1060 */     Color color5 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1061 */     paramUIDefaults.put("Panel.foreground", color5);
/* 1063 */     font = synthStyle.getFont(synthContext);
/* 1064 */     paramUIDefaults.put("Panel.font", font);
/* 1065 */     paramUIDefaults.put("TitledBorder.font", getTitledBorderFont(font));
/* 1068 */     JList jList = new JList();
/* 1069 */     synthStyle = synthStyleFactory.getStyle(jList, Region.LIST);
/* 1071 */     synthContext = new SynthContext(jList, Region.LIST, synthStyle, 0);
/* 1072 */     paramUIDefaults.put("List.focusInputMap", synthStyle.get(synthContext, "List.focusInputMap"));
/* 1073 */     Color color6 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1074 */     paramUIDefaults.put("List.background", color6);
/* 1075 */     Color color7 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1076 */     paramUIDefaults.put("List.foreground", color7);
/* 1078 */     synthContext = new SynthContext(jList, Region.LIST, synthStyle, 512);
/* 1079 */     color6 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1080 */     paramUIDefaults.put("List.selectionBackground", color6);
/* 1081 */     color7 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1082 */     paramUIDefaults.put("List.selectionForeground", color7);
/* 1084 */     if (paramUIDefaults.get("List.dropLineColor") == null)
/* 1085 */       paramUIDefaults.put("List.dropLineColor", new ColorUIResource(Color.RED)); 
/* 1088 */     JTable jTable = new JTable();
/* 1090 */     synthStyle = synthStyleFactory.getStyle(jTable, Region.TABLE_HEADER);
/* 1091 */     synthContext = new SynthContext(jTable, Region.TABLE_HEADER, synthStyle, 0);
/* 1093 */     Color color8 = synthStyle.getColor(synthContext, ColorType.BACKGROUND);
/* 1094 */     paramUIDefaults.put("TableHeader.background", color8);
/* 1095 */     Color color9 = synthStyle.getColor(synthContext, ColorType.FOREGROUND);
/* 1096 */     paramUIDefaults.put("TableHeader.foreground", color9);
/* 1097 */     paramUIDefaults.put("TableHeader.font", synthStyle.getFont(synthContext));
/* 1099 */     synthStyle = synthStyleFactory.getStyle(jTable, Region.TABLE);
/* 1100 */     synthContext = new SynthContext(jTable, Region.TABLE, synthStyle, 0);
/* 1101 */     paramUIDefaults.put("Table.gridColor", synthStyle.get(synthContext, "Table.gridColor"));
/* 1103 */     Color color10 = synthStyle.getColor(synthContext, ColorType.BACKGROUND);
/* 1104 */     paramUIDefaults.put("Table.background", color10);
/* 1105 */     Color color11 = synthStyle.getColor(synthContext, ColorType.FOREGROUND);
/* 1106 */     paramUIDefaults.put("Table.foreground", color11);
/* 1107 */     paramUIDefaults.put("Table.font", synthStyle.getFont(synthContext));
/* 1109 */     synthContext = new SynthContext(jTable, Region.TABLE, synthStyle, 512);
/* 1110 */     color10 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1111 */     paramUIDefaults.put("Table.selectionBackground", color10);
/* 1112 */     color11 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1113 */     paramUIDefaults.put("Table.selectionForeground", color11);
/* 1115 */     Border border = null;
/* 1116 */     if (paramUIDefaults.get("Synthetica.table.scrollPaneBorder.className") != null) {
/*      */       try {
/* 1120 */         border = (Border)Class.forName(paramUIDefaults.getString("Synthetica.table.scrollPaneBorder.className")).newInstance();
/* 1122 */       } catch (Exception exception) {
/* 1124 */         throw new RuntimeException(exception);
/*      */       } 
/* 1127 */     } else if (paramUIDefaults.getBoolean("Synthetica.table.useScrollPaneBorder")) {
/* 1128 */       border = (new JScrollPane()).getBorder();
/*      */     } else {
/* 1131 */       boolean bool = paramUIDefaults.containsKey("Synthetica.table.scrollPane.border.size") ? paramUIDefaults.getInt("Synthetica.table.scrollPane.border.size") : true;
/* 1132 */       border = new BorderUIResource.LineBorderUIResource(paramUIDefaults.getColor("Synthetica.table.scrollPane.border.color"), bool);
/*      */     } 
/* 1134 */     paramUIDefaults.put("Table.scrollPaneBorder", border);
/* 1136 */     if (paramUIDefaults.getBoolean("Synthetica.scrollPane.cornerPainter.enabled"))
/* 1137 */       paramUIDefaults.put("Table.scrollPaneCornerComponent", SyntheticaScrollPaneCorner.TableUpperTrailingCorner.class); 
/* 1140 */     if (paramUIDefaults.get("JXTable.rowHeight") == null) {
/* 1142 */       Integer integer = (Integer)synthStyle.get(synthContext, "Table.rowHeight");
/* 1143 */       if (integer != null)
/* 1144 */         paramUIDefaults.put("JXTable.rowHeight", integer); 
/*      */     } 
/* 1146 */     paramUIDefaults.put("ColumnHeaderRenderer.upIcon", loadIcon("Synthetica.arrow.up"));
/* 1147 */     paramUIDefaults.put("ColumnHeaderRenderer.downIcon", loadIcon("Synthetica.arrow.down"));
/* 1150 */     Icon icon = loadIcon("Synthetica.tableHeader.ascendingSort.icon", (Component)null);
/* 1151 */     paramUIDefaults.put("Table.ascendingSortIcon", (icon == null) ? loadIcon("Synthetica.arrow.up") : icon);
/* 1152 */     icon = loadIcon("Synthetica.tableHeader.descendingSort.icon", (Component)null);
/* 1153 */     paramUIDefaults.put("Table.descendingSortIcon", (icon == null) ? loadIcon("Synthetica.arrow.down") : icon);
/* 1155 */     String str = paramUIDefaults.getString("Synthetica.tableHeader.cellBorder.className");
/* 1156 */     if (paramUIDefaults.get("TableHeader.cellBorder") == null && str != null)
/*      */       try {
/* 1160 */         paramUIDefaults.put("TableHeader.cellBorder", Class.forName(str).newInstance());
/* 1162 */       } catch (Exception exception) {
/* 1164 */         throw new RuntimeException(exception);
/*      */       }  
/* 1168 */     if (paramUIDefaults.get("Table.dropLineColor") == null)
/* 1169 */       paramUIDefaults.put("Table.dropLineColor", paramUIDefaults.get("Table.foreground")); 
/* 1170 */     if (paramUIDefaults.get("Table.dropLineShortColor") == null)
/* 1171 */       paramUIDefaults.put("Table.dropLineShortColor", new ColorUIResource(Color.RED)); 
/* 1174 */     JTree jTree = new JTree();
/* 1175 */     synthStyle = synthStyleFactory.getStyle(jTree, Region.TREE);
/* 1176 */     if (getJVMCompatibilityMode() == JVMCompatibilityMode.SUN) {
/* 1178 */       font = ((DefaultSynthStyle)synthStyle).getFont(jTree, Region.TREE, 1);
/* 1179 */       paramUIDefaults.put("Tree.font", font);
/*      */     } 
/* 1182 */     synthContext = new SynthContext(jTree, Region.TREE, synthStyle, 0);
/* 1183 */     paramUIDefaults.put("Tree.focusInputMap", synthStyle.get(synthContext, "Tree.focusInputMap"));
/* 1184 */     paramUIDefaults.put("Tree.foreground", synthStyle.getColor(synthContext, ColorType.FOREGROUND));
/* 1185 */     paramUIDefaults.put("Tree.background", synthStyle.getColor(synthContext, ColorType.BACKGROUND));
/* 1186 */     arrayOfString2 = new String[] { "Tree.expandedIcon", "Tree.collapsedIcon" };
/* 1187 */     putIcons2Defaults(paramUIDefaults, arrayOfString2, arrayOfString2, synthStyle, synthContext);
/* 1189 */     paramUIDefaults.put("Tree.rowHeight", synthStyle.get(synthContext, "Tree.rowHeight"));
/* 1190 */     paramUIDefaults.put("Tree.leftChildIndent", synthStyle.get(synthContext, "Tree.leftChildIndent"));
/* 1191 */     paramUIDefaults.put("Tree.rightChildIndent", synthStyle.get(synthContext, "Tree.rightChildIndent"));
/* 1193 */     synthStyle = synthStyleFactory.getStyle(jTree, Region.TREE_CELL);
/* 1194 */     synthContext = new SynthContext(jTree, Region.TREE_CELL, synthStyle, 0);
/* 1195 */     paramUIDefaults.put("Tree.textForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1196 */     paramUIDefaults.put("Tree.textBackground", synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND));
/* 1197 */     synthContext = new SynthContext(jTree, Region.TREE_CELL, synthStyle, 512);
/* 1198 */     paramUIDefaults.put("Tree.selectionForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1199 */     paramUIDefaults.put("Tree.selectionBackground", synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND));
/* 1201 */     paramUIDefaults.put("Tree.hash", paramUIDefaults.get("Synthetica.tree.line.color.vertical"));
/* 1203 */     if (paramUIDefaults.get("Tree.dropLineColor") == null)
/* 1204 */       paramUIDefaults.put("Tree.dropLineColor", new ColorUIResource(Color.RED)); 
/* 1208 */     JInternalFrame jInternalFrame = new JInternalFrame();
/* 1209 */     synthStyle = synthStyleFactory.getStyle(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE);
/* 1210 */     if (getJVMCompatibilityMode() == JVMCompatibilityMode.SUN) {
/* 1212 */       Color color15 = ((DefaultSynthStyle)synthStyle).getColor(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, 512, ColorType.FOREGROUND);
/* 1213 */       paramUIDefaults.put("InternalFrame.activeTitleForeground", color15);
/* 1214 */       color15 = ((DefaultSynthStyle)synthStyle).getColor(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, 0, ColorType.FOREGROUND);
/* 1215 */       paramUIDefaults.put("InternalFrame.inactiveTitleForeground", color15);
/* 1217 */       Color color16 = ((DefaultSynthStyle)synthStyle).getColor(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, 512, ColorType.BACKGROUND);
/* 1218 */       paramUIDefaults.put("InternalFrame.activeTitleBackground", color16);
/* 1219 */       paramUIDefaults.put("activeCaption", color16);
/* 1220 */       color16 = ((DefaultSynthStyle)synthStyle).getColor(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, 0, ColorType.BACKGROUND);
/* 1221 */       paramUIDefaults.put("InternalFrame.inactiveTitleBackground", color16);
/* 1222 */       paramUIDefaults.put("inactiveCaption", color16);
/*      */     } 
/* 1227 */     synthContext = new SynthContext(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, synthStyle, 0);
/* 1228 */     arrayOfString1 = new String[] { "InternalFrameTitlePane.closeIcon", "InternalFrameTitlePane.maximizeIcon", "InternalFrameTitlePane.minimizeIcon", "InternalFrameTitlePane.iconifyIcon" };
/* 1229 */     arrayOfString2 = new String[] { "InternalFrame.closeIcon", "InternalFrame.maximizeIcon", "InternalFrame.minimizeIcon", "InternalFrame.iconifyIcon" };
/* 1230 */     putIcons2Defaults(paramUIDefaults, arrayOfString1, arrayOfString2, synthStyle, synthContext);
/* 1233 */     synthStyle = synthStyleFactory.getStyle(jInternalFrame, Region.INTERNAL_FRAME);
/* 1234 */     synthContext = new SynthContext(jInternalFrame, Region.INTERNAL_FRAME, synthStyle, 0);
/* 1235 */     arrayOfString2 = new String[] { "InternalFrame.icon" };
/* 1236 */     putIcons2Defaults(paramUIDefaults, arrayOfString2, arrayOfString2, synthStyle, synthContext);
/* 1239 */     JMenu jMenu = new JMenu();
/* 1240 */     synthStyle = synthStyleFactory.getStyle(jMenu, Region.MENU);
/* 1241 */     synthContext = new SynthContext(jMenu, Region.MENU, synthStyle, 0);
/* 1242 */     paramUIDefaults.put("MenuItem.background", synthStyle.getColor(synthContext, ColorType.BACKGROUND));
/* 1243 */     Color color12 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1244 */     paramUIDefaults.put("Menu.foreground", color12);
/* 1245 */     paramUIDefaults.put("MenuItem.foreground", color12);
/* 1248 */     JOptionPane jOptionPane = new JOptionPane();
/* 1249 */     synthStyle = synthStyleFactory.getStyle(jOptionPane, Region.OPTION_PANE);
/* 1250 */     synthContext = new SynthContext(jOptionPane, Region.OPTION_PANE, synthStyle, 0);
/* 1251 */     arrayOfString2 = new String[] { "OptionPane.informationIcon", "OptionPane.questionIcon", "OptionPane.warningIcon", "OptionPane.errorIcon" };
/* 1252 */     putIcons2Defaults(paramUIDefaults, arrayOfString2, arrayOfString2, synthStyle, synthContext);
/* 1255 */     JCheckBox jCheckBox = new JCheckBox();
/* 1256 */     synthStyle = synthStyleFactory.getStyle(jCheckBox, Region.CHECK_BOX);
/* 1257 */     synthContext = new SynthContext(jCheckBox, Region.CHECK_BOX, synthStyle, 0);
/* 1258 */     paramUIDefaults.put("CheckBox.focusInputMap", synthStyle.get(synthContext, "CheckBox.focusInputMap"));
/* 1259 */     arrayOfString2 = new String[] { "CheckBox.icon" };
/* 1260 */     putIcons2Defaults(paramUIDefaults, arrayOfString2, arrayOfString2, synthStyle, synthContext);
/* 1263 */     JRadioButton jRadioButton = new JRadioButton();
/* 1264 */     synthStyle = synthStyleFactory.getStyle(jRadioButton, Region.RADIO_BUTTON);
/* 1265 */     synthContext = new SynthContext(jRadioButton, Region.RADIO_BUTTON, synthStyle, 0);
/* 1266 */     paramUIDefaults.put("RadioButton.focusInputMap", synthStyle.get(synthContext, "RadioButton.focusInputMap"));
/* 1267 */     arrayOfString2 = new String[] { "RadioButton.icon" };
/* 1268 */     putIcons2Defaults(paramUIDefaults, arrayOfString2, arrayOfString2, synthStyle, synthContext);
/* 1271 */     JScrollBar jScrollBar = new JScrollBar();
/* 1272 */     synthStyle = synthStyleFactory.getStyle(jScrollBar, Region.SCROLL_BAR);
/* 1273 */     synthContext = new SynthContext(jScrollBar, Region.SCROLL_BAR, synthStyle, 0);
/* 1274 */     paramUIDefaults.put("ScrollBar.width", synthStyle.get(synthContext, "ScrollBar.thumbHeight"));
/* 1277 */     JTabbedPane jTabbedPane = new JTabbedPane();
/* 1278 */     synthStyle = synthStyleFactory.getStyle(jTabbedPane, Region.TABBED_PANE);
/* 1279 */     synthContext = new SynthContext(jTabbedPane, Region.TABBED_PANE, synthStyle, 0);
/* 1280 */     paramUIDefaults.put("TabbedPane.focusInputMap", synthStyle.get(synthContext, "TabbedPane.focusInputMap"));
/* 1282 */     synthStyle = synthStyleFactory.getStyle(jTabbedPane, Region.TABBED_PANE_TAB_AREA);
/* 1283 */     synthContext = new SynthContext(jTabbedPane, Region.TABBED_PANE_TAB_AREA, synthStyle, 0);
/* 1284 */     paramUIDefaults.put("TabbedPane.tabAreaInsets", synthStyle.getInsets(synthContext, null));
/* 1286 */     synthStyle = synthStyleFactory.getStyle(jTabbedPane, Region.TABBED_PANE_TAB);
/* 1287 */     synthContext = new SynthContext(jTabbedPane, Region.TABBED_PANE_TAB, synthStyle, 0);
/* 1288 */     paramUIDefaults.put("TabbedPane.tabInsets", synthStyle.getInsets(synthContext, null));
/* 1289 */     paramUIDefaults.put("TabbedPane.tabForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1291 */     synthStyle = synthStyleFactory.getStyle(jTabbedPane, Region.TABBED_PANE_TAB);
/* 1292 */     synthContext = new SynthContext(jTabbedPane, Region.TABBED_PANE_TAB, synthStyle, 512);
/* 1293 */     paramUIDefaults.put("TabbedPane.selectedTabPadInsets", synthStyle.getInsets(synthContext, null));
/* 1294 */     paramUIDefaults.put("TabbedPane.selectedTabForeground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1296 */     synthStyle = synthStyleFactory.getStyle(jTabbedPane, Region.TABBED_PANE_CONTENT);
/* 1297 */     synthContext = new SynthContext(jTabbedPane, Region.TABBED_PANE_CONTENT, synthStyle, 0);
/* 1298 */     paramUIDefaults.put("TabbedPane.contentBorderInsets", synthStyle.getInsets(synthContext, null));
/* 1300 */     paramUIDefaults.put("TabbedPane.foreground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1301 */     paramUIDefaults.put("TabbedPane.shadow", Color.GRAY);
/* 1304 */     JTextField jTextField = new JTextField();
/* 1305 */     paramUIDefaults.put("TextField.border", jTextField.getBorder());
/* 1306 */     paramUIDefaults.put("FormattedTextField.border", jTextField.getBorder());
/* 1307 */     synthStyle = synthStyleFactory.getStyle(jTextField, Region.TEXT_FIELD);
/* 1309 */     synthContext = new SynthContext(jTextField, Region.TEXT_FIELD, synthStyle, 0);
/* 1310 */     Object object = synthStyle.get(synthContext, "TextField.focusInputMap");
/* 1311 */     paramUIDefaults.put("TextField.focusInputMap", object);
/* 1312 */     paramUIDefaults.put("PasswordField.focusInputMap", object);
/* 1313 */     font = synthStyle.getFont(synthContext);
/* 1314 */     paramUIDefaults.put("TextField.font", font);
/* 1315 */     paramUIDefaults.put("FormattedTextField.font", font);
/* 1316 */     paramUIDefaults.put("PasswordField.font", font);
/* 1317 */     paramUIDefaults.put("TextArea.font", font);
/* 1318 */     Color color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1319 */     paramUIDefaults.put("TextField.foreground", color13);
/* 1320 */     paramUIDefaults.put("FormattedTextField.foreground", color13);
/* 1321 */     paramUIDefaults.put("PasswordField.foreground", color13);
/* 1322 */     paramUIDefaults.put("TextArea.foreground", color13);
/* 1323 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1324 */     paramUIDefaults.put("TextField.background", color13);
/* 1325 */     paramUIDefaults.put("FormattedTextField.background", color13);
/* 1326 */     paramUIDefaults.put("PasswordField.background", color13);
/* 1327 */     paramUIDefaults.put("TextArea.background", color13);
/* 1329 */     synthContext = new SynthContext(jTextField, Region.TEXT_FIELD, synthStyle, 8);
/* 1330 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1331 */     paramUIDefaults.put("TextField.inactiveForeground", color13);
/* 1332 */     paramUIDefaults.put("FormattedTextField.inactiveForeground", color13);
/* 1333 */     paramUIDefaults.put("PasswordField.inactiveForeground", color13);
/* 1334 */     paramUIDefaults.put("TextArea.inactiveForeground", color13);
/* 1335 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1336 */     paramUIDefaults.put("TextField.inactiveBackground", color13);
/* 1337 */     paramUIDefaults.put("FormattedTextField.inactiveBackground", color13);
/* 1338 */     paramUIDefaults.put("PasswordField.inactiveBackground", color13);
/* 1339 */     paramUIDefaults.put("TextArea.inactiveBackground", color13);
/* 1341 */     synthContext = new SynthContext(jTextField, Region.TEXT_FIELD, synthStyle, 512);
/* 1342 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1343 */     paramUIDefaults.put("TextField.selectionForeground", color13);
/* 1344 */     paramUIDefaults.put("FormattedTextField.selectionForeground", color13);
/* 1345 */     paramUIDefaults.put("PasswordField.selectionForeground", color13);
/* 1346 */     paramUIDefaults.put("TextArea.selectionForeground", color13);
/* 1347 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1348 */     paramUIDefaults.put("TextField.selectionBackground", color13);
/* 1349 */     paramUIDefaults.put("FormattedTextField.selectionBackground", color13);
/* 1350 */     paramUIDefaults.put("PasswordField.selectionBackground", color13);
/* 1351 */     paramUIDefaults.put("TextArea.selectionBackground", color13);
/* 1352 */     paramUIDefaults.put("textHighlight", color13);
/* 1355 */     JTextPane jTextPane = new JTextPane();
/* 1356 */     synthStyle = synthStyleFactory.getStyle(jTextField, Region.TEXT_PANE);
/* 1357 */     object = synthStyle.get(synthContext, "TextPane.focusInputMap");
/* 1358 */     paramUIDefaults.put("TextPane.focusInputMap", object);
/* 1359 */     paramUIDefaults.put("EditorPane.focusInputMap", object);
/* 1360 */     paramUIDefaults.put("TextArea.focusInputMap", object);
/* 1362 */     synthContext = new SynthContext(jTextPane, Region.TEXT_PANE, synthStyle, 0);
/* 1363 */     font = synthStyle.getFont(synthContext);
/* 1364 */     paramUIDefaults.put("TextPane.font", font);
/* 1365 */     paramUIDefaults.put("EditorPane.font", font);
/* 1366 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1367 */     paramUIDefaults.put("TextPane.foreground", color13);
/* 1368 */     paramUIDefaults.put("EditorPane.foreground", color13);
/* 1369 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1370 */     paramUIDefaults.put("TextPane.background", color13);
/* 1371 */     paramUIDefaults.put("EditorPane.background", color13);
/* 1373 */     synthContext = new SynthContext(jTextPane, Region.TEXT_PANE, synthStyle, 8);
/* 1374 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1375 */     paramUIDefaults.put("TextPane.inactiveForeground", color13);
/* 1376 */     paramUIDefaults.put("EditorPane.inactiveForeground", color13);
/* 1377 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1378 */     paramUIDefaults.put("TextPane.inactiveBackground", color13);
/* 1379 */     paramUIDefaults.put("EditorPane.inactiveBackground", color13);
/* 1381 */     synthContext = new SynthContext(jTextPane, Region.TEXT_PANE, synthStyle, 512);
/* 1382 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND);
/* 1383 */     paramUIDefaults.put("TextPane.selectionForeground", color13);
/* 1384 */     paramUIDefaults.put("EditorPane.selectionForeground", color13);
/* 1385 */     color13 = synthStyle.getColor(synthContext, ColorType.TEXT_BACKGROUND);
/* 1386 */     paramUIDefaults.put("TextPane.selectionBackground", color13);
/* 1387 */     paramUIDefaults.put("EditorPane.selectionBackground", color13);
/* 1390 */     JToolTip jToolTip = new JToolTip();
/* 1391 */     synthContext = new SynthContext(jToolTip, Region.TOOL_TIP, synthStyle, 0);
/* 1392 */     synthStyle = synthStyleFactory.getStyle(jToolTip, Region.TOOL_TIP);
/* 1393 */     paramUIDefaults.put("ToolTip.font", synthStyle.getFont(synthContext));
/* 1394 */     paramUIDefaults.put("ToolTip.foreground", synthStyle.getColor(synthContext, ColorType.TEXT_FOREGROUND));
/* 1396 */     Color color14 = synthStyle.getColor(synthContext, ColorType.BACKGROUND);
/* 1397 */     paramUIDefaults.put("ToolTip.background", (color14 == null) ? null : new Color(color14.getRGB()));
/*      */   }
/*      */   
/*      */   private void putIcons2Defaults(UIDefaults paramUIDefaults, String[] paramArrayOfString1, String[] paramArrayOfString2, SynthStyle paramSynthStyle, SynthContext paramSynthContext) {
/* 1402 */     for (byte b = 0; b < paramArrayOfString1.length; b++) {
/* 1404 */       Icon icon = paramSynthStyle.getIcon(paramSynthContext, paramArrayOfString1[b]);
/* 1405 */       paramUIDefaults.put(paramArrayOfString2[b], icon);
/*      */     } 
/*      */   }
/*      */   
/*      */   private Font getTitledBorderFont(Font paramFont) {
/* 1411 */     if (UIManager.get("Synthetica.titledBorder.title.fontName") != null)
/* 1412 */       paramFont = new FontUIResource(new Font(UIManager.getString("Synthetica.titledBorder.title.fontName"), paramFont.getStyle(), paramFont.getSize())); 
/* 1413 */     if (UIManager.get("Synthetica.titledBorder.title.fontSize") != null) {
/* 1415 */       float f = scaleFontSize(UIManager.getInt("Synthetica.titledBorder.title.fontSize"));
/* 1416 */       paramFont = new FontUIResource(paramFont.deriveFont(f));
/*      */     } 
/* 1418 */     if (UIManager.get("Synthetica.titledBorder.title.fontStyle") != null)
/* 1419 */       paramFont = new FontUIResource(paramFont.deriveFont(UIManager.getInt("Synthetica.titledBorder.title.fontStyle"))); 
/* 1420 */     return paramFont;
/*      */   }
/*      */   
/*      */   public void uninitialize() {
/* 1433 */     KeyboardFocusManager.getCurrentKeyboardFocusManager().removeKeyEventPostProcessor(this.extKeyEventProcessor);
/* 1436 */     ((StyleFactory)SynthLookAndFeel.getStyleFactory()).uninitialize();
/* 1439 */     UIDefaults uIDefaults = UIManager.getDefaults();
/* 1441 */     Object object1 = UIManager.get("Synthetica.license.info");
/* 1442 */     Object object2 = UIManager.get("Synthetica.license.key");
/* 1443 */     Object object3 = UIManager.get("SyntheticaAddons.license.info");
/* 1444 */     Object object4 = UIManager.get("SyntheticaAddons.license.key");
/* 1446 */     if (isSystemPropertySet("synthetica.clearPreDefinedDefaults")) {
/* 1447 */       uIDefaults.clear();
/*      */     } else {
/* 1450 */       UIDefaults uIDefaults1 = UIManager.getLookAndFeelDefaults();
/* 1451 */       UIDefaults uIDefaults2 = new UIDefaults();
/* 1452 */       for (Enumeration<Object> enumeration = this.orgDefaults.keys(); enumeration.hasMoreElements(); ) {
/* 1454 */         Object object = enumeration.nextElement();
/* 1455 */         if (!uIDefaults1.containsKey(object))
/* 1456 */           uIDefaults2.put(object, this.orgDefaults.get(object)); 
/*      */       } 
/* 1458 */       uIDefaults.clear();
/* 1459 */       uIDefaults.putAll(uIDefaults2);
/*      */     } 
/* 1462 */     if (object1 != null) {
/* 1464 */       UIManager.put("Synthetica.license.info", object1);
/* 1465 */       UIManager.put("Synthetica.license.key", object2);
/*      */     } 
/* 1467 */     if (object3 != null) {
/* 1469 */       uIDefaults.put("SyntheticaAddons.license.info", object3);
/* 1470 */       uIDefaults.put("SyntheticaAddons.license.key", object4);
/*      */     } 
/* 1472 */     UIManager.removePropertyChangeListener(this.lafChangeListener);
/* 1474 */     super.uninitialize();
/*      */   }
/*      */   
/*      */   protected boolean shouldUpdateStyleOnEvent(PropertyChangeEvent paramPropertyChangeEvent) {
/* 1481 */     String str = paramPropertyChangeEvent.getPropertyName();
/* 1482 */     if ("name".equals(str) || "componentOrientation".equals(str) || "Synthetica.style".equals(str) || "editable".equals(str))
/* 1483 */       return true; 
/* 1484 */     if ("ancestor".equals(str) && paramPropertyChangeEvent.getNewValue() != null)
/* 1485 */       return shouldUpdateStyleOnAncestorChanged(); 
/* 1486 */     return false;
/*      */   }
/*      */   
/*      */   private void blockLAFChange() {
/* 1494 */     UIManager.addPropertyChangeListener(new PropertyChangeListener() {
/*      */           public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 1498 */             Object object = param1PropertyChangeEvent.getNewValue();
/* 1499 */             if (!(object instanceof SyntheticaLookAndFeel))
/*      */               try {
/* 1503 */                 UIManager.setLookAndFeel(SyntheticaLookAndFeel.this);
/* 1505 */               } catch (Exception exception) {
/* 1507 */                 exception.printStackTrace();
/*      */               }  
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   public static SynthContext createContext(JComponent paramJComponent, Region paramRegion, int paramInt) {
/* 1516 */     SynthStyle synthStyle = getStyle(paramJComponent, paramRegion);
/* 1517 */     return new SynthContext(paramJComponent, paramRegion, synthStyle, paramInt);
/*      */   }
/*      */   
/*      */   public static void setFont(String paramString, int paramInt) {
/* 1528 */     setFont(new FontUIResource(paramString, 0, paramInt));
/*      */   }
/*      */   
/*      */   public static void setFont(Font paramFont) {
/* 1538 */     setFont(paramFont, true);
/*      */   }
/*      */   
/*      */   public static void setFont(Font paramFont, boolean paramBoolean) {
/* 1547 */     if (paramFont == null) {
/* 1549 */       defaultFont = null;
/*      */       return;
/*      */     } 
/* 1552 */     if (paramBoolean) {
/* 1554 */       float f = scaleFontSize(paramFont.getSize2D());
/* 1555 */       defaultFont = paramFont.deriveFont(f);
/*      */     } else {
/* 1558 */       defaultFont = paramFont;
/*      */     } 
/* 1561 */     LookAndFeel lookAndFeel = UIManager.getLookAndFeel();
/* 1562 */     if (defaultsCompatibilityMode && lookAndFeel instanceof SyntheticaLookAndFeel)
/* 1563 */       ((SyntheticaLookAndFeel)lookAndFeel).installCompatibilityDefaults(); 
/*      */   }
/*      */   
/*      */   public static Font getFont() {
/* 1572 */     return defaultFont;
/*      */   }
/*      */   
/*      */   public static String getFontName() {
/* 1580 */     return (defaultFont == null) ? null : defaultFont.getFontName();
/*      */   }
/*      */   
/*      */   public static int getFontSize() {
/* 1588 */     return (defaultFont == null) ? 0 : defaultFont.getSize();
/*      */   }
/*      */   
/*      */   public static boolean getAntiAliasEnabled() {
/* 1596 */     return antiAliasEnabled;
/*      */   }
/*      */   
/*      */   public static void setAntiAliasEnabled(boolean paramBoolean) {
/* 1608 */     antiAliasEnabled = paramBoolean;
/* 1610 */     System.setProperty("awt.useSystemAAFontSettings", "false");
/*      */   }
/*      */   
/*      */   public static void setWindowsDecorated(boolean paramBoolean) {
/* 1618 */     decorated = paramBoolean;
/*      */   }
/*      */   
/*      */   public static boolean getExtendedFileChooserEnabled() {
/* 1626 */     return extendedFileChooserEnabled;
/*      */   }
/*      */   
/*      */   public static void setExtendedFileChooserEnabled(boolean paramBoolean) {
/* 1634 */     extendedFileChooserEnabled = paramBoolean;
/* 1635 */     if (extendedFileChooserEnabled) {
/* 1637 */       UIDefaults uIDefaults = UIManager.getDefaults();
/* 1638 */       String str = null;
/* 1640 */       if (OS.getCurrentOS() == OS.Mac) {
/* 1642 */         String str1 = "ch.randelshofer.quaqua.panther.QuaquaPantherFileChooserUI";
/* 1643 */         str = (uIDefaults.get("Synthetica.fileChooserUI") == null) ? str1 : uIDefaults.getString("Synthetica.fileChooserUI");
/*      */         try {
/* 1647 */           Class.forName(str);
/* 1649 */           SwingUtilities.invokeLater(new Runnable() {
/*      */                 public void run() {
/* 1652 */                   SyntheticaLookAndFeel.initQuaquaFileChooser(SyntheticaLookAndFeel.uiDefaults);
/*      */                 }
/*      */               });
/* 1656 */         } catch (ClassNotFoundException classNotFoundException) {
/* 1659 */           str = null;
/*      */         } 
/*      */       } 
/* 1663 */       str = (str == null) ? "de.javasoft.plaf.synthetica.filechooser.SyntheticaFileChooserUI" : str;
/* 1664 */       uIDefaults.put("FileChooserUI", str);
/*      */     } else {
/* 1667 */       UIManager.getDefaults().put("FileChooserUI", "javax.swing.plaf.metal.MetalFileChooserUI");
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void initQuaquaFileChooser(UIDefaults paramUIDefaults) {
/* 1684 */     final Color labelForeground = paramUIDefaults.getColor("Label.foreground");
/* 1686 */     paramUIDefaults.addResourceBundle("ch.randelshofer.quaqua.Labels");
/* 1687 */     paramUIDefaults.put("Browser.expandedIcon", loadIcon("Synthetica.arrow.right"));
/* 1688 */     paramUIDefaults.put("Browser.sizeHandleIcon", new Icon() {
/*      */           public void paintIcon(Component param1Component, Graphics param1Graphics, int param1Int1, int param1Int2) {
/* 1692 */             param1Graphics.setColor(labelForeground);
/* 1693 */             param1Graphics.drawLine(5, 4, 5, 10);
/* 1694 */             param1Graphics.drawLine(8, 4, 8, 10);
/*      */           }
/*      */           
/*      */           public int getIconWidth() {
/* 1699 */             return 15;
/*      */           }
/*      */           
/*      */           public int getIconHeight() {
/* 1704 */             return 15;
/*      */           }
/*      */         });
/* 1708 */     paramUIDefaults.put("Browser.selectionBackground", new ColorUIResource(56, 117, 215));
/* 1709 */     paramUIDefaults.put("Browser.selectionForeground", new ColorUIResource(255, 255, 255));
/* 1710 */     paramUIDefaults.put("Browser.inactiveSelectionBackground", new ColorUIResource(208, 208, 208));
/* 1711 */     paramUIDefaults.put("Browser.inactiveSelectionForeground", new ColorUIResource(0, 0, 0));
/* 1713 */     paramUIDefaults.put("FileChooser.previewLabelForeground", color);
/* 1714 */     paramUIDefaults.put("FileChooser.previewValueForeground", color);
/* 1715 */     FontUIResource fontUIResource = new FontUIResource("Lucida Grande", 0, 11);
/* 1716 */     paramUIDefaults.put("FileChooser.previewLabelFont", fontUIResource);
/* 1717 */     paramUIDefaults.put("FileChooser.previewValueFont", fontUIResource);
/* 1719 */     paramUIDefaults.put("FileChooser.previewLabelInsets", new InsetsUIResource(0, 0, 0, 4));
/* 1720 */     paramUIDefaults.put("FileChooser.cellTipOrigin", new Point(18, 1));
/* 1721 */     paramUIDefaults.put("FileChooser.autovalidate", Boolean.TRUE);
/* 1723 */     paramUIDefaults.put("Sheet.showAsSheet", Boolean.TRUE);
/*      */   }
/*      */   
/*      */   public Icon getDisabledIcon(JComponent paramJComponent, Icon paramIcon) {
/* 1730 */     if (paramIcon == null || !getBoolean("Synthetica.translucency4DisabledIcons.enabled", paramJComponent))
/* 1731 */       return super.getDisabledIcon(paramJComponent, paramIcon); 
/* 1732 */     int i = getInt("Synthetica.translucency4DisabledIcons.alpha", paramJComponent, 50);
/* 1733 */     BufferedImage bufferedImage = new BufferedImage(paramIcon.getIconWidth(), paramIcon.getIconHeight(), 2);
/* 1734 */     Graphics2D graphics2D = (Graphics2D)bufferedImage.getGraphics();
/* 1735 */     AlphaComposite alphaComposite = AlphaComposite.getInstance(3, i / 100.0F);
/* 1736 */     graphics2D.setComposite(alphaComposite);
/* 1737 */     paramIcon.paintIcon(paramJComponent, graphics2D, 0, 0);
/* 1738 */     graphics2D.dispose();
/* 1739 */     Object object = bufferedImage.getProperty("comment", null);
/* 1740 */     return new ImageIconUIResource(bufferedImage, (object instanceof String) ? (String)object : "");
/*      */   }
/*      */   
/*      */   public static boolean getRememberFileChooserPreferences() {
/* 1748 */     if (rememberFileChooserPreferences != null)
/* 1749 */       return rememberFileChooserPreferences.booleanValue(); 
/* 1750 */     return getBoolean("Synthetica.extendedFileChooser.rememberPreferences", (Component)null, true);
/*      */   }
/*      */   
/*      */   public static void setRememberFileChooserPreferences(boolean paramBoolean) {
/* 1758 */     rememberFileChooserPreferences = Boolean.valueOf(paramBoolean);
/*      */   }
/*      */   
/*      */   public static boolean getUseSystemFileIcons() {
/* 1766 */     return useSystemFileIcons;
/*      */   }
/*      */   
/*      */   public static void setUseSystemFileIcons(boolean paramBoolean) {
/* 1774 */     useSystemFileIcons = paramBoolean;
/*      */   }
/*      */   
/*      */   public static void setDefaultsCompatibilityMode(boolean paramBoolean) {
/* 1782 */     defaultsCompatibilityMode = paramBoolean;
/*      */   }
/*      */   
/*      */   public static boolean getDefaultsCompatibilityMode() {
/* 1790 */     return defaultsCompatibilityMode;
/*      */   }
/*      */   
/*      */   public static void setToolbarSeparatorDimension(Dimension paramDimension) {
/* 1798 */     toolbarSeparatorDimension = paramDimension;
/*      */   }
/*      */   
/*      */   public static Dimension getToolbarSeparatorDimension() {
/* 1806 */     return toolbarSeparatorDimension;
/*      */   }
/*      */   
/*      */   private static ResourceBundle getResourceBundle(String paramString, Locale paramLocale) {
/* 1818 */     if (paramLocale == null)
/* 1819 */       paramLocale = Locale.getDefault(); 
/* 1820 */     String str = "de/javasoft/plaf/synthetica/resourceBundles/" + paramString;
/* 1821 */     if (JAVA6_OR_ABOVE)
/* 1822 */       return ResourceBundle.getBundle(str, paramLocale, ResourceBundle.Control.getControl(ResourceBundle.Control.FORMAT_PROPERTIES)); 
/* 1823 */     return ResourceBundle.getBundle(str, paramLocale);
/*      */   }
/*      */   
/*      */   public IVersion getSyntheticaVersion() {
/* 1833 */     return new Version();
/*      */   }
/*      */   
/*      */   public static String getStyleName(Component paramComponent) {
/* 1844 */     String str = paramComponent.getName();
/* 1845 */     SynthStyleFactory synthStyleFactory = getStyleFactory();
/* 1846 */     if (!(synthStyleFactory instanceof StyleFactory))
/* 1847 */       return str; 
/* 1849 */     StyleFactory styleFactory = (StyleFactory)synthStyleFactory;
/* 1850 */     if (styleFactory != null && styleFactory.isSyntheticaStyleNameSupportEnabled()) {
/* 1852 */       if (paramComponent instanceof Window)
/* 1854 */         if (paramComponent instanceof JFrame) {
/* 1855 */           paramComponent = ((JFrame)paramComponent).getRootPane();
/* 1856 */         } else if (paramComponent instanceof JDialog) {
/* 1857 */           paramComponent = ((JDialog)paramComponent).getRootPane();
/* 1858 */         } else if (paramComponent instanceof JWindow) {
/* 1859 */           paramComponent = ((JWindow)paramComponent).getRootPane();
/*      */         }  
/* 1862 */       if (paramComponent instanceof JComponent) {
/* 1864 */         Object object = ((JComponent)paramComponent).getClientProperty("Synthetica.style");
/* 1865 */         if (object != null)
/* 1866 */           str = (String)object; 
/*      */       } 
/*      */     } 
/* 1869 */     return str;
/*      */   }
/*      */   
/*      */   public static JVMCompatibilityMode getJVMCompatibilityMode() {
/* 1880 */     String str = UIManager.getString("Synthetica.JVMCompatibilityMode");
/* 1881 */     if (str == null)
/* 1882 */       return JVMCompatibilityMode.SUN; 
/* 1883 */     return JVMCompatibilityMode.valueOf(str);
/*      */   }
/*      */   
/*      */   public static <T> T getClientProperty(String paramString, JComponent paramJComponent, T paramT) {
/* 1898 */     Object object = paramJComponent.getClientProperty(paramString);
/* 1899 */     return (object != null) ? (T)object : paramT;
/*      */   }
/*      */   
/*      */   public static Icon loadIcon(String paramString) {
/* 1911 */     return loadIcon(paramString, (Component)null);
/*      */   }
/*      */   
/*      */   public static Icon loadIcon(String paramString, Component paramComponent) {
/* 1924 */     Icon icon = null;
/* 1925 */     String str = getString(paramString, paramComponent);
/* 1926 */     if (str != null) {
/* 1928 */       icon = iconCache.get(str);
/* 1929 */       if (icon != null)
/* 1930 */         return icon; 
/* 1932 */       String[] arrayOfString = str.split(",");
/* 1933 */       URL uRL = SyntheticaLookAndFeel.class.getResource(arrayOfString[arrayOfString.length - 1]);
/* 1934 */       if (uRL == null) {
/*      */         try {
/* 1938 */           icon = (Icon)Class.forName(str).newInstance();
/* 1940 */         } catch (Exception exception) {
/* 1942 */           throw new RuntimeException(exception);
/*      */         } 
/*      */       } else {
/* 1946 */         icon = new ImageIcon(uRL);
/*      */       } 
/* 1947 */       icon = new IconUIResource(icon);
/* 1948 */       iconCache.put(str, icon);
/*      */     } 
/* 1950 */     return icon;
/*      */   }
/*      */   
/*      */   public static Object get(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/* 1977 */     String str = paramString1;
/* 1978 */     byte b = 46;
/* 1979 */     int i = paramString1.length();
/* 1980 */     while (i > -1) {
/* 1982 */       StringBuilder stringBuilder = new StringBuilder("Synthetica.");
/* 1983 */       paramString1 = paramString1.substring(0, i);
/* 1984 */       stringBuilder.append(paramString1);
/* 1985 */       if (paramString2 != null) {
/* 1987 */         stringBuilder.append(b);
/* 1988 */         stringBuilder.append(paramString2);
/*      */       } 
/* 1990 */       if (paramString3 != null) {
/* 1992 */         stringBuilder.append(b);
/* 1993 */         stringBuilder.append(paramString3);
/*      */       } 
/* 1995 */       if (lookup(stringBuilder.toString()) != null || !paramBoolean)
/* 1996 */         return lookup(stringBuilder.toString()); 
/* 1997 */       i = paramString1.lastIndexOf(b);
/* 1999 */       if (i == -1 && paramString3 != null) {
/* 2001 */         paramString3 = null;
/* 2002 */         paramString1 = str;
/* 2003 */         i = paramString1.length();
/*      */       } 
/*      */     } 
/* 2006 */     return null;
/*      */   }
/*      */   
/*      */   public static String getString(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/* 2011 */     return (String)get(paramString1, paramString2, paramString3, paramBoolean);
/*      */   }
/*      */   
/*      */   public static Insets getInsets(String paramString1, String paramString2, String paramString3, boolean paramBoolean) {
/* 2016 */     return (Insets)get(paramString1, paramString2, paramString3, paramBoolean);
/*      */   }
/*      */   
/*      */   public static int getInt(String paramString1, String paramString2, String paramString3, boolean paramBoolean, int paramInt) {
/* 2021 */     Object object = get(paramString1, paramString2, paramString3, paramBoolean);
/* 2022 */     return (object != null) ? ((Integer)object).intValue() : paramInt;
/*      */   }
/*      */   
/*      */   public static Object get(String paramString, Component paramComponent) {
/* 2037 */     if (logger.isLoggable(Level.FINE))
/* 2038 */       logger.log(Level.FINE, "UI-propertyKey: " + paramString); 
/* 2040 */     if (paramComponent == null || paramComponent.getParent() instanceof javax.swing.CellRendererPane)
/* 2041 */       return lookup(paramString); 
/* 2042 */     return get(paramString, getStyleName(paramComponent));
/*      */   }
/*      */   
/*      */   public static Object get(String paramString1, String paramString2) {
/* 2058 */     if (paramString2 == null)
/* 2059 */       return lookup(paramString1); 
/* 2060 */     Object object = lookup(String.valueOf(paramString1) + "." + paramString2);
/* 2061 */     if (object != null)
/* 2062 */       return object; 
/* 2064 */     return lookup(paramString1);
/*      */   }
/*      */   
/*      */   private static Object lookup(String paramString) {
/* 2079 */     if (uiDefaults != null)
/* 2080 */       return uiDefaults.get(paramString); 
/* 2081 */     return UIManager.get(paramString);
/*      */   }
/*      */   
/*      */   public static boolean getBoolean(String paramString, Component paramComponent) {
/* 2092 */     return getBoolean(paramString, paramComponent, false);
/*      */   }
/*      */   
/*      */   public static boolean getBoolean(String paramString, Component paramComponent, boolean paramBoolean) {
/* 2107 */     Object object = get(paramString, paramComponent);
/* 2108 */     return (object != null) ? ((Boolean)object).booleanValue() : paramBoolean;
/*      */   }
/*      */   
/*      */   public static int getInt(String paramString, Component paramComponent) {
/* 2118 */     return getInt(paramString, paramComponent, 0);
/*      */   }
/*      */   
/*      */   public static int getInt(String paramString, Component paramComponent, int paramInt) {
/* 2132 */     Object object = get(paramString, paramComponent);
/* 2133 */     return (object != null) ? ((Integer)object).intValue() : paramInt;
/*      */   }
/*      */   
/*      */   public static Dimension getDim(String paramString, Component paramComponent) {
/* 2143 */     return getDim(paramString, paramComponent, (Dimension)null);
/*      */   }
/*      */   
/*      */   public static Dimension getDim(String paramString, Component paramComponent, Dimension paramDimension) {
/* 2157 */     Object object = get(paramString, paramComponent);
/* 2158 */     return (object != null) ? (Dimension)object : paramDimension;
/*      */   }
/*      */   
/*      */   public static Insets getInsets(String paramString, Component paramComponent) {
/* 2169 */     return getInsets(paramString, paramComponent, true);
/*      */   }
/*      */   
/*      */   public static Insets getInsets(String paramString, Component paramComponent, boolean paramBoolean) {
/* 2184 */     Object object = get(paramString, paramComponent);
/* 2185 */     return (object == null && !paramBoolean) ? new InsetsUIResource(0, 0, 0, 0) : (Insets)object;
/*      */   }
/*      */   
/*      */   public static Insets getInsets(String paramString, Component paramComponent, Insets paramInsets) {
/* 2198 */     Object object = get(paramString, paramComponent);
/* 2199 */     return (object != null) ? (Insets)object : paramInsets;
/*      */   }
/*      */   
/*      */   public static String getString(String paramString, Component paramComponent) {
/* 2210 */     return (String)get(paramString, paramComponent);
/*      */   }
/*      */   
/*      */   public static String getString(String paramString1, Component paramComponent, String paramString2) {
/* 2225 */     Object object = get(paramString1, paramComponent);
/* 2226 */     return (object != null) ? (String)object : paramString2;
/*      */   }
/*      */   
/*      */   public static Color getColor(String paramString, Component paramComponent) {
/* 2237 */     return (Color)get(paramString, paramComponent);
/*      */   }
/*      */   
/*      */   public static Color getColor(String paramString, Component paramComponent, Color paramColor) {
/* 2252 */     Object object = get(paramString, paramComponent);
/* 2253 */     return (object != null) ? (Color)object : paramColor;
/*      */   }
/*      */   
/*      */   public static Icon getIcon(String paramString, Component paramComponent) {
/* 2264 */     return (Icon)get(paramString, paramComponent);
/*      */   }
/*      */   
/*      */   public static boolean isToplevelPopupMenu(JPopupMenu paramJPopupMenu) {
/* 2277 */     Component component = paramJPopupMenu.getInvoker();
/* 2278 */     boolean bool1 = getBoolean("Synthetica.popupMenu.toplevel.enabled", paramJPopupMenu, false);
/* 2279 */     boolean bool2 = getBoolean("Synthetica.menu.toplevel.popupMenu.toplevel.enabled", paramJPopupMenu, bool1);
/* 2283 */     if (component instanceof JMenu && bool2)
/* 2284 */       return !(!((JMenu)component).isTopLevelMenu() && !((Boolean)getClientProperty("Synthetica.menu.toplevel", (JMenu)component, Boolean.valueOf(false))).booleanValue()); 
/* 2285 */     return (bool1 && ((Boolean)getClientProperty("Synthetica.popupMenu.toplevel", paramJPopupMenu, Boolean.valueOf(false))).booleanValue());
/*      */   }
/*      */   
/*      */   public static <T extends JComponent> T findOpaqueParentOfClass(Class<T> paramClass, Container paramContainer, boolean paramBoolean) {
/* 2302 */     if (paramContainer == null)
/* 2303 */       return null; 
/* 2304 */     if (paramContainer instanceof JComponent && paramClass.isInstance(paramContainer) && ((paramBoolean && paramContainer.isOpaque()) || isOpaque((JComponent)paramContainer)))
/* 2305 */       return (T)paramContainer; 
/* 2307 */     if (paramContainer.isOpaque())
/* 2308 */       return null; 
/* 2309 */     return findOpaqueParentOfClass(paramClass, paramContainer.getParent(), paramBoolean);
/*      */   }
/*      */   
/*      */   public static boolean isOpaque(JComponent paramJComponent) {
/* 2322 */     if (paramJComponent == null)
/* 2323 */       return true; 
/* 2325 */     boolean bool = !(paramJComponent.getBackground() != null && paramJComponent.getBackground().getAlpha() == 0);
/* 2326 */     bool = (paramJComponent.getClientProperty("Synthetica.opaque") == null) ? bool : ((Boolean)paramJComponent.getClientProperty("Synthetica.opaque")).booleanValue();
/* 2327 */     if (getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/* 2328 */       bool = paramJComponent.isOpaque(); 
/* 2329 */     return bool;
/*      */   }
/*      */   
/*      */   public static void setChildrenOpaque(Container paramContainer, boolean paramBoolean) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2340 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2340 */       Component component = arrayOfComponent[b];
/* 2342 */       if (component instanceof JComponent) {
/* 2344 */         JComponent jComponent = (JComponent)component;
/* 2345 */         jComponent.setOpaque(paramBoolean);
/* 2346 */         jComponent.putClientProperty("Synthetica.opaque", Boolean.valueOf(paramBoolean));
/* 2347 */         setChildrenOpaque(jComponent, paramBoolean);
/*      */       } 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Rectangle validateWindowBounds(Rectangle paramRectangle) {
/* 2362 */     Rectangle rectangle = new Rectangle(paramRectangle);
/* 2363 */     if (getBoolean("Synthetica.windowBoundsValidation.enabled", (Component)null, true)) {
/* 2365 */       Rectangle rectangle1 = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration().getBounds();
/* 2366 */       int i = rectangle1.x;
/* 2367 */       int j = rectangle1.x + rectangle1.width - rectangle.width;
/* 2368 */       int k = rectangle1.y;
/* 2369 */       int m = rectangle1.y + rectangle1.height - rectangle.height;
/* 2370 */       if (!isInScreen(rectangle.x, rectangle.y)) {
/* 2372 */         if (rectangle.x < i) {
/* 2373 */           rectangle.x = i;
/* 2374 */         } else if (rectangle.x > j) {
/* 2375 */           rectangle.x = j;
/*      */         } 
/* 2377 */         if (rectangle.y < k) {
/* 2378 */           rectangle.y = k;
/* 2379 */         } else if (rectangle.y > m) {
/* 2380 */           rectangle.y = m;
/*      */         } 
/*      */       } 
/*      */     } 
/* 2383 */     return rectangle;
/*      */   }
/*      */   
/*      */   private static boolean isInScreen(int paramInt1, int paramInt2) {
/*      */     byte b;
/*      */     int i;
/*      */     GraphicsDevice[] arrayOfGraphicsDevice;
/* 2388 */     for (i = (arrayOfGraphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices()).length, b = 0; b < i; ) {
/* 2388 */       GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/* 2390 */       Rectangle rectangle = graphicsDevice.getDefaultConfiguration().getBounds();
/* 2392 */       if (rectangle.contains(paramInt1, paramInt2))
/* 2393 */         return true; 
/*      */       b++;
/*      */     } 
/* 2395 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean isWindowOpacityEnabled(Window paramWindow) {
/* 2407 */     boolean bool = getBoolean("Synthetica.window.opaque", paramWindow, true) ? false : true;
/* 2408 */     return !((JAVA6U10_OR_ABOVE || OS.getCurrentOS() == OS.Mac) && bool);
/*      */   }
/*      */   
/*      */   public static void setWindowOpaque(Window paramWindow, boolean paramBoolean) {
/* 2419 */     if (paramWindow == null)
/*      */       return; 
/* 2422 */     if (JAVA7_OR_ABOVE) {
/* 2424 */       paramWindow.setBackground(paramBoolean ? null : new Color(0, 0, 0, 0));
/*      */       return;
/*      */     } 
/* 2428 */     if (OS.getCurrentOS() == OS.Mac && !paramBoolean) {
/* 2430 */       Boolean bool = Boolean.valueOf(getBoolean("Synthetica.window.forceRecognizeMacEvents", paramWindow));
/* 2431 */       paramWindow.setBackground(bool.booleanValue() ? new Color(192, 192, 192, 13) : new Color(0, 0, 0, 0));
/* 2432 */       if (paramWindow instanceof JFrame) {
/* 2434 */         ((JFrame)paramWindow).getRootPane().putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/* 2436 */         if (!isWindowOpacityEnabled(paramWindow))
/* 2437 */           ((JComponent)((JFrame)paramWindow).getContentPane()).setOpaque(false); 
/* 2439 */       } else if (paramWindow instanceof JDialog) {
/* 2441 */         ((JDialog)paramWindow).getRootPane().putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/* 2443 */         if (!isWindowOpacityEnabled(paramWindow))
/* 2444 */           ((JComponent)((JDialog)paramWindow).getContentPane()).setOpaque(false); 
/* 2446 */       } else if (paramWindow instanceof JWindow) {
/* 2448 */         ((JWindow)paramWindow).getRootPane().putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/* 2450 */         if (!isWindowOpacityEnabled(paramWindow))
/* 2451 */           ((JComponent)((JWindow)paramWindow).getContentPane()).setOpaque(false); 
/*      */       } 
/*      */       return;
/*      */     } 
/* 2456 */     if (getJVMCompatibilityMode() != JVMCompatibilityMode.SUN)
/*      */       return; 
/*      */     try {
/* 2461 */       Class<?> clazz = Class.forName("com.sun.awt.AWTUtilities");
/* 2462 */       Method method = clazz.getMethod("setWindowOpaque", new Class[] { Window.class, boolean.class });
/* 2464 */       if (!paramBoolean && "###overrideRedirect###".equals(paramWindow.getName()))
/* 2465 */         method.invoke(null, new Object[] { paramWindow, Boolean.valueOf(true) }); 
/* 2466 */       method.invoke(null, new Object[] { paramWindow, Boolean.valueOf(paramBoolean) });
/* 2470 */     } catch (Exception exception) {
/* 2472 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isWindowShapeEnabled(Window paramWindow) {
/* 2485 */     String str = getString("Synthetica.window.shape", paramWindow);
/* 2486 */     return (str != null && !str.equals("NONE"));
/*      */   }
/*      */   
/*      */   public static boolean isWindowShapeSupported(Window paramWindow) {
/*      */     int i;
/* 2497 */     boolean bool = JAVA6U10_OR_ABOVE;
/* 2498 */     if (OS.getCurrentOS() == OS.Mac)
/* 2499 */       i = bool & (JAVA7U8_OR_ABOVE ? getBoolean("Synthetica.window.shapeSupportOnMac", paramWindow, false) : 0); 
/* 2500 */     return i;
/*      */   }
/*      */   
/*      */   public static void updateWindowShape(Window paramWindow) {
/* 2510 */     if ((paramWindow instanceof JFrame && !((JFrame)paramWindow).isUndecorated()) || (
/* 2511 */       paramWindow instanceof JDialog && !((JDialog)paramWindow).isUndecorated()) || 
/* 2512 */       windowIsFullScreen(paramWindow) || 
/* 2513 */       getJVMCompatibilityMode() != JVMCompatibilityMode.SUN)
/*      */       return; 
/* 2519 */     if (OS.getCurrentOS() == OS.Mac && !isWindowShapeSupported(paramWindow)) {
/* 2521 */       setWindowOpaque(paramWindow, false);
/*      */       return;
/*      */     } 
/* 2525 */     boolean bool = (paramWindow instanceof Frame && (((Frame)paramWindow).getExtendedState() & 0x6) == 6) ? true : false;
/*      */     try {
/* 2528 */       Class<?> clazz = JAVA7_OR_ABOVE ? Window.class : Class.forName("com.sun.awt.AWTUtilities");
/* 2529 */       Method method = JAVA7_OR_ABOVE ? clazz.getMethod("setShape", new Class[] { Shape.class }) : clazz.getMethod("setWindowShape", new Class[] { Window.class, Shape.class });
/* 2530 */       String str = getString("Synthetica.window.shape", paramWindow);
/* 2531 */       Shape shape = null;
/* 2532 */       if (bool || !isWindowShapeEnabled(paramWindow)) {
/* 2533 */         shape = null;
/* 2534 */       } else if ("ROUND_RECT".equals(str)) {
/* 2536 */         int i = getInt("Synthetica.window.arcW", paramWindow, 18);
/* 2537 */         int j = getInt("Synthetica.window.arcH", paramWindow, 18);
/* 2538 */         shape = new RoundRectangle2D.Float(0.0F, 0.0F, paramWindow.getWidth(), paramWindow.getHeight(), i, j);
/*      */       } else {
/*      */         try {
/* 2545 */           shape = ((SyntheticaWindowShape)Class.forName(str).newInstance()).getShape(paramWindow.getWidth(), paramWindow.getHeight());
/* 2547 */         } catch (Exception exception) {
/* 2549 */           throw new RuntimeException(exception);
/*      */         } 
/*      */       } 
/* 2552 */       if (JAVA7_OR_ABOVE) {
/* 2553 */         method.invoke(paramWindow, new Object[] { shape });
/*      */       } else {
/* 2555 */         method.invoke(null, new Object[] { paramWindow, shape });
/*      */       } 
/* 2557 */     } catch (Exception exception) {
/* 2559 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean windowIsFullScreen(Window paramWindow) {
/* 2565 */     return (paramWindow.getGraphicsConfiguration().getDevice().getFullScreenWindow() == paramWindow);
/*      */   }
/*      */   
/*      */   private static void updateAllWindowShapes() {
/* 2570 */     if (JAVA6U10_OR_ABOVE) {
/*      */       byte b;
/*      */       int i;
/*      */       Window[] arrayOfWindow;
/* 2572 */       for (i = (arrayOfWindow = Window.getWindows()).length, b = 0; b < i; ) {
/* 2572 */         Window window = arrayOfWindow[b];
/* 2574 */         boolean bool = (!(window instanceof JWindow) && !(window instanceof JFrame) && !(window instanceof JDialog)) ? true : false;
/* 2575 */         if (!window.getClass().getName().contains("Popup$HeavyWeightWindow") && !bool)
/* 2576 */           updateWindowShape(window); 
/*      */         b++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isSystemPropertySet(String paramString) {
/* 2583 */     return isSystemPropertySet(paramString, false);
/*      */   }
/*      */   
/*      */   public static boolean isSystemPropertySet(String paramString, boolean paramBoolean) {
/* 2588 */     return isSystemPropertySet(paramString, Boolean.valueOf(paramBoolean)).booleanValue();
/*      */   }
/*      */   
/*      */   public static Boolean isSystemPropertySet(String paramString, Boolean paramBoolean) {
/*      */     try {
/* 2595 */       String str = System.getProperty(paramString);
/* 2596 */       if (str == null)
/* 2597 */         return paramBoolean; 
/* 2598 */       if (str.length() == 0)
/* 2599 */         return Boolean.valueOf(true); 
/* 2600 */       return Boolean.valueOf(Boolean.parseBoolean(str));
/* 2602 */     } catch (AccessControlException accessControlException) {
/* 2604 */       return Boolean.valueOf(false);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static boolean isSystemPropertySet(String paramString1, String paramString2) {
/*      */     try {
/* 2612 */       String str = System.getProperty(paramString1);
/* 2613 */       if (str == null)
/* 2614 */         return false; 
/* 2615 */       return str.equals(paramString2);
/* 2617 */     } catch (AccessControlException accessControlException) {
/* 2619 */       return false;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static float scaleFontSize(float paramFloat) {
/* 2632 */     float f = paramFloat;
/* 2633 */     if (getBoolean("Synthetica.font.respectSystemDPI", (Component)null, !isUIScalingEnabled())) {
/* 2635 */       Toolkit toolkit = Toolkit.getDefaultToolkit();
/* 2636 */       int j = 96;
/* 2637 */       if (OS.getCurrentOS() == OS.Windows) {
/* 2638 */         j = toolkit.getScreenResolution();
/* 2639 */       } else if (OS.getCurrentOS() == OS.Linux) {
/* 2641 */         Object object = toolkit.getDesktopProperty("gnome.Xft/DPI");
/* 2642 */         if (object instanceof Integer)
/* 2643 */           j = ((Integer)object).intValue() / 1024; 
/*      */       } 
/* 2645 */       f = j * paramFloat / 96.0F;
/*      */     } 
/* 2648 */     int i = getInt("Synthetica.font.scaleFactor", (Component)null, 100);
/* 2649 */     f = i * f / 100.0F;
/* 2651 */     return f;
/*      */   }
/*      */   
/*      */   static boolean isUIScalingEnabled() {
/* 2657 */     if (uiScaleEnabled != null)
/* 2658 */       return uiScaleEnabled.booleanValue(); 
/* 2660 */     GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
/* 2661 */     if (!GraphicsEnvironment.isHeadless()) {
/*      */       byte b;
/*      */       int i;
/*      */       GraphicsDevice[] arrayOfGraphicsDevice;
/* 2663 */       for (i = (arrayOfGraphicsDevice = graphicsEnvironment.getScreenDevices()).length, b = 0; b < i; ) {
/* 2663 */         GraphicsDevice graphicsDevice = arrayOfGraphicsDevice[b];
/* 2665 */         if (graphicsDevice.getDefaultConfiguration().getDefaultTransform().getScaleX() > 1.0D || graphicsDevice.getDefaultConfiguration().getDefaultTransform().getScaleY() > 1.0D)
/* 2666 */           return (uiScaleEnabled = Boolean.valueOf(true)).booleanValue(); 
/*      */         b++;
/*      */       } 
/*      */     } 
/* 2669 */     return (uiScaleEnabled = Boolean.valueOf(false)).booleanValue();
/*      */   }
/*      */   
/*      */   public static void setChildrenName(Container paramContainer, String paramString1, String paramString2) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2683 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2683 */       Component component = arrayOfComponent[b];
/* 2685 */       if (paramString1.equals(getStyleName(component)))
/* 2687 */         if (component instanceof JComponent && ((JComponent)component).getClientProperty("Synthetica.style") != null) {
/* 2688 */           ((JComponent)component).putClientProperty("Synthetica.style", paramString2);
/*      */         } else {
/* 2690 */           component.setName(paramString2);
/*      */         }  
/* 2692 */       if (component instanceof Container)
/* 2693 */         setChildrenName((Container)component, paramString1, paramString2); 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public static Component findComponent(String paramString, Container paramContainer) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2706 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2706 */       Component component = arrayOfComponent[b];
/* 2708 */       if (paramString.equals(getStyleName(component)))
/* 2709 */         return component; 
/* 2710 */       if (component instanceof Container) {
/* 2712 */         Component component1 = findComponent(paramString, (Container)component);
/* 2713 */         if (component1 != null)
/* 2713 */           return component1; 
/*      */       } 
/*      */       b++;
/*      */     } 
/* 2716 */     return null;
/*      */   }
/*      */   
/*      */   public static Component findComponent(Class<?> paramClass, Container paramContainer) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2728 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2728 */       Component component = arrayOfComponent[b];
/* 2730 */       if (paramClass.isInstance(component))
/* 2731 */         return component; 
/* 2732 */       if (component instanceof Container) {
/* 2734 */         Component component1 = findComponent(paramClass, (Container)component);
/* 2735 */         if (component1 != null)
/* 2735 */           return component1; 
/*      */       } 
/*      */       b++;
/*      */     } 
/* 2738 */     return null;
/*      */   }
/*      */   
/*      */   public static <T extends Component> List<T> findComponents(String paramString, Container paramContainer, List<T> paramList) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2751 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2751 */       Component component = arrayOfComponent[b];
/* 2753 */       if (paramString.equals(getStyleName(component)))
/* 2754 */         paramList.add((T)component); 
/* 2755 */       if (component instanceof Container)
/* 2756 */         findComponents(paramString, (Container)component, paramList); 
/*      */       b++;
/*      */     } 
/* 2758 */     return paramList;
/*      */   }
/*      */   
/*      */   public static <T extends Component> List<T> findComponents(Class<T> paramClass, Container paramContainer, List<T> paramList) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 2772 */     for (i = (arrayOfComponent = paramContainer.getComponents()).length, b = 0; b < i; ) {
/* 2772 */       Component component = arrayOfComponent[b];
/* 2774 */       if (paramClass.isInstance(component))
/* 2775 */         paramList.add((T)component); 
/* 2776 */       if (component instanceof Container)
/* 2777 */         findComponents(paramClass, (Container)component, paramList); 
/*      */       b++;
/*      */     } 
/* 2779 */     return paramList;
/*      */   }
/*      */   
/*      */   public static Border findDefaultBorder(Border paramBorder) {
/* 2791 */     if (paramBorder instanceof UIResource)
/* 2792 */       return paramBorder; 
/* 2793 */     if (paramBorder instanceof CompoundBorder) {
/* 2795 */       Border border1 = findDefaultBorder(((CompoundBorder)paramBorder).getOutsideBorder());
/* 2796 */       if (border1 != null)
/* 2797 */         return border1; 
/* 2798 */       Border border2 = findDefaultBorder(((CompoundBorder)paramBorder).getInsideBorder());
/* 2799 */       if (border2 != null)
/* 2800 */         return border2; 
/*      */     } 
/* 2802 */     return null;
/*      */   }
/*      */   
/*      */   public static boolean preservePopupIconSpace(JPopupMenu paramJPopupMenu) {
/* 2816 */     if (getBoolean("Synthetica.popupMenu.forceIconSpace", paramJPopupMenu, false))
/* 2817 */       return true; 
/* 2818 */     return popupHasIcons(paramJPopupMenu);
/*      */   }
/*      */   
/*      */   public static boolean popupHasIcons(JPopupMenu paramJPopupMenu) {
/* 2829 */     ArrayList<JMenuItem> arrayList = new ArrayList();
/* 2830 */     findComponents(JMenuItem.class, paramJPopupMenu, arrayList);
/* 2831 */     if (arrayList.size() == 0)
/* 2832 */       return false; 
/* 2833 */     for (JMenuItem jMenuItem : arrayList) {
/* 2835 */       if (jMenuItem.getIcon() != null)
/* 2836 */         return true; 
/*      */     } 
/* 2838 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean popupHasCheckRadio(JPopupMenu paramJPopupMenu) {
/* 2850 */     ArrayList<JMenuItem> arrayList = new ArrayList();
/* 2851 */     findComponents(JMenuItem.class, paramJPopupMenu, arrayList);
/* 2852 */     if (arrayList.size() == 0)
/* 2853 */       return false; 
/* 2854 */     for (JMenuItem jMenuItem : arrayList) {
/* 2856 */       if (jMenuItem instanceof javax.swing.JCheckBoxMenuItem || jMenuItem instanceof javax.swing.JRadioButtonMenuItem)
/* 2857 */         return true; 
/*      */     } 
/* 2859 */     return false;
/*      */   }
/*      */   
/*      */   public static boolean popupHasCheckRadioWithIcon(JPopupMenu paramJPopupMenu) {
/* 2871 */     ArrayList<JMenuItem> arrayList = new ArrayList();
/* 2872 */     findComponents(JMenuItem.class, paramJPopupMenu, arrayList);
/* 2873 */     for (JMenuItem jMenuItem : arrayList) {
/* 2874 */       if (jMenuItem instanceof javax.swing.JCheckBoxMenuItem || jMenuItem instanceof javax.swing.JRadioButtonMenuItem)
/* 2876 */         if (jMenuItem.getIcon() != null)
/* 2877 */           return true;  
/*      */     } 
/* 2879 */     return false;
/*      */   }
/*      */   
/*      */   public static Paint createLinearGradientPaint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float[] paramArrayOffloat, Color[] paramArrayOfColor) {
/* 2890 */     if (paramFloat1 == paramFloat3 && paramFloat2 == paramFloat4)
/* 2891 */       paramFloat4 += 1.0E-6F; 
/* 2893 */     if (JAVA5)
/* 2894 */       return (Paint)new LinearGradientPaint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramArrayOffloat, paramArrayOfColor); 
/* 2896 */     return new LinearGradientPaint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramArrayOffloat, paramArrayOfColor);
/*      */   }
/*      */   
/*      */   public static void setLookAndFeel(String paramString) {
/* 2910 */     setLookAndFeel(paramString, true, true);
/*      */   }
/*      */   
/*      */   public static void setLookAndFeel(String paramString, boolean paramBoolean1, boolean paramBoolean2) {
/*      */     try {
/* 2931 */       if (paramBoolean1)
/* 2933 */         if (OS.getCurrentOS() == OS.Mac) {
/* 2934 */           System.setProperty("apple.awt.textantialiasing", "on");
/*      */         } else {
/* 2936 */           System.setProperty("swing.aatext", (new StringBuilder(String.valueOf(paramBoolean1))).toString());
/*      */         }  
/* 2939 */       if (paramBoolean2 && OS.getCurrentOS() == OS.Mac && screenMenuBarSupportedByOSX() && getBoolean("Synthetica.screenMenuBarOnMacEnabled", (Component)null, true)) {
/* 2948 */         System.setProperty("apple.laf.useScreenMenuBar", (new StringBuilder(String.valueOf(paramBoolean2))).toString());
/* 2949 */         setLookAndFeelWorkaround(UIManager.getSystemLookAndFeelClassName());
/* 2951 */         String str = UIManager.getString("MenuBarUI");
/* 2957 */         Font font = UIManager.getFont("MenuItem.acceleratorFont");
/* 2958 */         Boolean bool1 = Boolean.valueOf(UIManager.getBoolean("Menu.borderPainted"));
/* 2959 */         Boolean bool2 = Boolean.valueOf(UIManager.getBoolean("MenuItem.borderPainted"));
/* 2960 */         Boolean bool3 = Boolean.valueOf(UIManager.getBoolean("RadioButtonMenuItem.borderPainted"));
/* 2961 */         Boolean bool4 = Boolean.valueOf(UIManager.getBoolean("CheckBoxButtonMenuItem.borderPainted"));
/* 2963 */         UIManager.put("Menu.borderPainted", bool1);
/* 2964 */         UIManager.put("MenuItem.acceleratorFont", font);
/* 2965 */         UIManager.put("MenuItem.borderPainted", bool2);
/* 2966 */         UIManager.put("RadioButtonMenuItem.borderPainted", bool3);
/* 2967 */         UIManager.put("CheckBoxMenuItem.borderPainted", bool4);
/* 2969 */         UIManager.put("MenuBarUI", str);
/*      */       } 
/* 2975 */       setLookAndFeelWorkaround(paramString);
/* 2977 */     } catch (Exception exception) {
/* 2979 */       throw new RuntimeException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean screenMenuBarSupportedByOSX() {
/* 2985 */     String str = OS.getVersion();
/* 2986 */     return !str.contains("10.4.");
/*      */   }
/*      */   
/*      */   private static void setLookAndFeelWorkaround(String paramString) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
/* 2992 */     Locale locale = Locale.getDefault();
/* 2993 */     boolean bool = "tr".equalsIgnoreCase(locale.getLanguage());
/* 2995 */     if (bool)
/* 2996 */       Locale.setDefault(Locale.US); 
/* 2998 */     UIManager.setLookAndFeel(paramString);
/* 3000 */     if (bool)
/* 3001 */       Locale.setDefault(locale); 
/*      */   }
/*      */   
/*      */   public abstract String getID();
/*      */   
/*      */   public abstract String getName();
/*      */   
/*      */   private static class Version implements IVersion {
/*      */     private int major;
/*      */     
/*      */     private int minor;
/*      */     
/*      */     private int revision;
/*      */     
/*      */     private int build;
/*      */     
/*      */     public Version() {
/* 3034 */       ResourceBundle resourceBundle = SyntheticaLookAndFeel.getResourceBundle("SyntheticaStandardLookAndFeelVersion", new Locale("", ""));
/* 3035 */       this.major = Integer.parseInt(resourceBundle.getString("major"));
/* 3036 */       this.minor = Integer.parseInt(resourceBundle.getString("minor"));
/* 3037 */       this.revision = Integer.parseInt(resourceBundle.getString("revision"));
/* 3038 */       this.build = Integer.parseInt(resourceBundle.getString("build"));
/*      */     }
/*      */     
/*      */     public int getMajor() {
/* 3046 */       return this.major;
/*      */     }
/*      */     
/*      */     public int getMinor() {
/* 3053 */       return this.minor;
/*      */     }
/*      */     
/*      */     public int getRevision() {
/* 3060 */       return this.revision;
/*      */     }
/*      */     
/*      */     public int getBuild() {
/* 3067 */       return this.build;
/*      */     }
/*      */     
/*      */     public String toString() {
/* 3074 */       return String.valueOf(this.major) + "." + this.minor + "." + this.revision + " Build " + this.build;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class ImageIconUIResource extends ImageIcon implements UIResource {
/*      */     public ImageIconUIResource(Image param1Image, String param1String) {
/* 3082 */       super(param1Image, param1String);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaLookAndFeel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */