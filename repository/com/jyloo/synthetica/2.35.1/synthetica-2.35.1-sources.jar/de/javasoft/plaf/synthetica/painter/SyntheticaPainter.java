/*      */ package de.javasoft.plaf.synthetica.painter;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*      */ import de.javasoft.plaf.synthetica.SyntheticaRootPaneUI;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.image.VolatileImage;
/*      */ import java.lang.reflect.Method;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.plaf.RootPaneUI;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthPainter;
/*      */ 
/*      */ public class SyntheticaPainter extends SynthPainter {
/*      */   private static SynthPainter instance;
/*      */   
/*      */   public SyntheticaPainter() {
/*   51 */     if (instance == null)
/*   51 */       instance = this; 
/*      */   }
/*      */   
/*      */   public static SynthPainter getInstance() {
/*   59 */     if (instance == null)
/*   59 */       instance = new SyntheticaPainter(); 
/*   60 */     return instance;
/*      */   }
/*      */   
/*      */   public static void clearCache() {
/*   68 */     SyntheticaSoftCache.getInstance().clear();
/*      */   }
/*      */   
/*      */   private boolean paintCachedImage(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, SyntheticaComponentPainter paramSyntheticaComponentPainter, String paramString, Class<?>... paramVarArgs) {
/*   73 */     int i = 0;
/*   74 */     Cacheable.ScaleType scaleType = paramSyntheticaComponentPainter.getCacheScaleType(paramString);
/*   75 */     if (!UIManager.getBoolean("Synthetica.cache.enabled") || (i = paramSyntheticaComponentPainter.getCacheHash(paramSynthContext, paramInt3, paramInt4, paramInt5, paramString)) == -1 || (
/*   76 */       scaleType != Cacheable.ScaleType.NINE_SQUARE && !SyntheticaSoftCache.getInstance().isCacheable(paramInt3, paramInt4)))
/*   77 */       return false; 
/*   79 */     Insets insets = null;
/*   80 */     int j = paramInt3;
/*   81 */     int k = paramInt4;
/*   82 */     if (scaleType == Cacheable.ScaleType.NINE_SQUARE) {
/*   84 */       insets = paramSyntheticaComponentPainter.getCacheScaleInsets(paramSynthContext, paramString);
/*   85 */       j = insets.left + insets.right + 24;
/*   86 */       k = insets.top + insets.bottom + 24;
/*      */     } 
/*   89 */     VolatileImage volatileImage = getCachedImage(i, paramSynthContext, paramGraphics, j, k, paramInt5, paramSyntheticaComponentPainter, paramString, paramVarArgs);
/*   90 */     if (volatileImage == null)
/*   91 */       return false; 
/*   93 */     if (scaleType == Cacheable.ScaleType.NONE)
/*   94 */       return paramGraphics.drawImage(volatileImage, paramInt1, paramInt2, null); 
/*   95 */     if (scaleType == Cacheable.ScaleType.NINE_SQUARE) {
/*   97 */       ImagePainter imagePainter = new ImagePainter(volatileImage, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, insets, insets);
/*   98 */       if (paramString.endsWith("Border")) {
/*   99 */         imagePainter.drawBorder();
/*      */       } else {
/*  101 */         imagePainter.draw();
/*      */       } 
/*  102 */       return true;
/*      */     } 
/*  104 */     return false;
/*      */   }
/*      */   
/*      */   private VolatileImage getCachedImage(int paramInt1, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt2, int paramInt3, int paramInt4, SyntheticaComponentPainter paramSyntheticaComponentPainter, String paramString, Class<?>... paramVarArgs) {
/*  109 */     GraphicsConfiguration graphicsConfiguration = ((Graphics2D)paramGraphics).getDeviceConfiguration();
/*  111 */     if (graphicsConfiguration.getDevice().getType() == 1)
/*  112 */       return null; 
/*  114 */     paramInt1 = 31 * paramInt1 + graphicsConfiguration.hashCode();
/*  116 */     SyntheticaSoftCache syntheticaSoftCache = SyntheticaSoftCache.getInstance();
/*  117 */     VolatileImage volatileImage = (VolatileImage)syntheticaSoftCache.getImage(paramInt1);
/*      */     while (true) {
/*  121 */       boolean bool = (volatileImage == null) ? true : volatileImage.validate(graphicsConfiguration);
/*  122 */       if (bool == 2 || bool == true) {
/*  124 */         if (bool == 2 || volatileImage.getWidth() != paramInt2 || volatileImage.getHeight() != paramInt3) {
/*  127 */           if (volatileImage != null) {
/*  129 */             volatileImage.flush();
/*  130 */             volatileImage = null;
/*      */           } 
/*  132 */           volatileImage = graphicsConfiguration.createCompatibleVolatileImage(paramInt2, paramInt3, 3);
/*  133 */           syntheticaSoftCache.setImage(volatileImage, paramInt1);
/*      */         } 
/*  135 */         Graphics2D graphics2D = volatileImage.createGraphics();
/*  136 */         graphics2D.setComposite(AlphaComposite.Clear);
/*  137 */         graphics2D.fillRect(0, 0, paramInt2, paramInt3);
/*  138 */         graphics2D.setComposite(AlphaComposite.SrcOver);
/*      */         try {
/*  142 */           Method method = paramSyntheticaComponentPainter.getClass().getMethod(paramString, paramVarArgs);
/*  143 */           if (paramInt4 == -1) {
/*  144 */             method.invoke(paramSyntheticaComponentPainter, new Object[] { paramSynthContext, graphics2D, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) });
/*      */           } else {
/*  146 */             method.invoke(paramSyntheticaComponentPainter, new Object[] { paramSynthContext, graphics2D, Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) });
/*      */           } 
/*  148 */         } catch (Exception exception) {
/*  150 */           throw new RuntimeException(exception);
/*      */         } finally {
/*  154 */           graphics2D.dispose();
/*      */         } 
/*      */       } 
/*  158 */       if (!volatileImage.contentsLost())
/*  159 */         return volatileImage; 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void paintArrowButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  168 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ArrowButtonPainter.getInstance(paramSynthContext), "paintArrowButtonBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  169 */       ArrowButtonPainter.getInstance(paramSynthContext).paintArrowButtonBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintArrowButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  175 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ArrowButtonPainter.getInstance(paramSynthContext), "paintArrowButtonBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  176 */       ArrowButtonPainter.getInstance(paramSynthContext).paintArrowButtonBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintArrowButtonForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  182 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, ArrowButtonPainter.getInstance(paramSynthContext), "paintArrowButtonForeground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  183 */       ArrowButtonPainter.getInstance(paramSynthContext).paintArrowButtonForeground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  192 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ButtonPainter.getInstance(paramSynthContext), "paintButtonBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  193 */       ButtonPainter.getInstance(paramSynthContext).paintButtonBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  199 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ButtonPainter.getInstance(paramSynthContext), "paintButtonBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  200 */       ButtonPainter.getInstance(paramSynthContext).paintButtonBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintCheckBoxBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  210 */     CheckBoxPainter.getInstance(paramSynthContext).paintCheckBoxBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintCheckBoxBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  217 */     CheckBoxPainter.getInstance(paramSynthContext).paintCheckBoxBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintComboBoxBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  226 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ComboBoxPainter.getInstance(paramSynthContext), "paintComboBoxBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  227 */       ComboBoxPainter.getInstance(paramSynthContext).paintComboBoxBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintComboBoxBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  233 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ComboBoxPainter.getInstance(paramSynthContext), "paintComboBoxBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  234 */       ComboBoxPainter.getInstance(paramSynthContext).paintComboBoxBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintDesktopPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  243 */     DesktopPanePainter.getInstance(paramSynthContext).paintDesktopPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintDesktopPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  249 */     DesktopPanePainter.getInstance(paramSynthContext).paintDesktopPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintEditorPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  258 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, EditorPanePainter.getInstance(paramSynthContext), "paintEditorPaneBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  259 */       EditorPanePainter.getInstance(paramSynthContext).paintEditorPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintEditorPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  267 */     EditorPanePainter.getInstance(paramSynthContext).paintEditorPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintFormattedTextFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  276 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, FormattedTextFieldPainter.getInstance(paramSynthContext), "paintFormattedTextFieldBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  277 */       FormattedTextFieldPainter.getInstance(paramSynthContext).paintFormattedTextFieldBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintFormattedTextFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  283 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, FormattedTextFieldPainter.getInstance(paramSynthContext), "paintFormattedTextFieldBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  284 */       FormattedTextFieldPainter.getInstance(paramSynthContext).paintFormattedTextFieldBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintInternalFrameBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  295 */     InternalFramePainter.getInstance(paramSynthContext).paintInternalFrameBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintInternalFrameBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  301 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, InternalFramePainter.getInstance(paramSynthContext), "paintInternalFrameBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  302 */       InternalFramePainter.getInstance(paramSynthContext).paintInternalFrameBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintInternalFrameTitlePaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  312 */     InternalFramePainter.getInstance(paramSynthContext).paintInternalFrameTitlePaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintInternalFrameTitlePaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  318 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, InternalFramePainter.getInstance(paramSynthContext), "paintInternalFrameTitlePaneBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  319 */       InternalFramePainter.getInstance(paramSynthContext).paintInternalFrameTitlePaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintLabelBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  330 */     LabelPainter.getInstance(paramSynthContext).paintLabelBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintLabelBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  338 */     LabelPainter.getInstance(paramSynthContext).paintLabelBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintListBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  349 */     ListPainter.getInstance(paramSynthContext).paintListBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintListBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  357 */     ListPainter.getInstance(paramSynthContext).paintListBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintMenuBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  366 */     MenuPainter.getInstance(paramSynthContext).paintMenuBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintMenuBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  372 */     MenuPainter.getInstance(paramSynthContext).paintMenuBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintMenuBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  381 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, MenuPainter.getInstance(paramSynthContext), "paintMenuBarBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  382 */       MenuPainter.getInstance(paramSynthContext).paintMenuBarBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintMenuBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  388 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, MenuPainter.getInstance(paramSynthContext), "paintMenuBarBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  389 */       MenuPainter.getInstance(paramSynthContext).paintMenuBarBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  399 */     MenuPainter.getInstance(paramSynthContext).paintMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  405 */     MenuPainter.getInstance(paramSynthContext).paintMenuItemBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintRadioButtonMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  415 */     MenuPainter.getInstance(paramSynthContext).paintRadioButtonMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintRadioButtonMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  421 */     MenuPainter.getInstance(paramSynthContext).paintRadioButtonMenuItemBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintCheckBoxMenuItemBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  431 */     MenuPainter.getInstance(paramSynthContext).paintCheckBoxMenuItemBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintCheckBoxMenuItemBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  437 */     MenuPainter.getInstance(paramSynthContext).paintCheckBoxMenuItemBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintOptionPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  446 */     OptionPanePainter.getInstance(paramSynthContext).paintOptionPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintOptionPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  452 */     OptionPanePainter.getInstance(paramSynthContext).paintOptionPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintPopupMenuBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  461 */     MenuPainter.getInstance(paramSynthContext).paintPopupMenuBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintPopupMenuBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  467 */     MenuPainter.getInstance(paramSynthContext).paintPopupMenuBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintPanelBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  478 */     PanelPainter.getInstance(paramSynthContext).paintPanelBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintPanelBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  485 */     PanelPainter.getInstance(paramSynthContext).paintPanelBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintPasswordFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  494 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, PasswordFieldPainter.getInstance(paramSynthContext), "paintPasswordFieldBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  495 */       PasswordFieldPainter.getInstance(paramSynthContext).paintPasswordFieldBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintPasswordFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  501 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, PasswordFieldPainter.getInstance(paramSynthContext), "paintPasswordFieldBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  502 */       PasswordFieldPainter.getInstance(paramSynthContext).paintPasswordFieldBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintProgressBarForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  513 */     ProgressBarPainter.getInstance(paramSynthContext).paintProgressBarForeground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */   
/*      */   public void paintProgressBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  519 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ProgressBarPainter.getInstance(paramSynthContext), "paintProgressBarBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  520 */       ProgressBarPainter.getInstance(paramSynthContext).paintProgressBarBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintProgressBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  526 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ProgressBarPainter.getInstance(paramSynthContext), "paintProgressBarBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  527 */       ProgressBarPainter.getInstance(paramSynthContext).paintProgressBarBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintRadioButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  537 */     RadioButtonPainter.getInstance(paramSynthContext).paintRadioButtonBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintRadioButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  544 */     RadioButtonPainter.getInstance(paramSynthContext).paintRadioButtonBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintRootPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*      */   
/*      */   public void paintRootPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  561 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, RootPanePainter.getInstance(paramSynthContext), "paintRootPaneBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  562 */       RootPanePainter.getInstance(paramSynthContext).paintRootPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintRootPaneTitlePaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  567 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, RootPanePainter.getInstance(paramSynthContext), "paintTitlePaneBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  568 */       RootPanePainter.getInstance(paramSynthContext).paintTitlePaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintRootPaneButtonAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  573 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, RootPanePainter.getInstance(paramSynthContext), "paintButtonAreaBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  574 */       RootPanePainter.getInstance(paramSynthContext).paintButtonAreaBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  583 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  584 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  590 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  591 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarThumbBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  599 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarThumbBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  600 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarThumbBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarThumbBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  606 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarThumbBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  607 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarThumbBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarTrackBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  615 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarTrackBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  616 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarTrackBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollBarTrackBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  622 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollBarPainter.getInstance(paramSynthContext), "paintScrollBarTrackBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  623 */       ScrollBarPainter.getInstance(paramSynthContext).paintScrollBarTrackBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  632 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollPanePainter.getInstance(paramSynthContext), "paintScrollPaneBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  633 */       ScrollPanePainter.getInstance(paramSynthContext).paintScrollPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintScrollPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  639 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ScrollPanePainter.getInstance(paramSynthContext), "paintScrollPaneBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  640 */       ScrollPanePainter.getInstance(paramSynthContext).paintScrollPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSeparatorBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  649 */     SeparatorPainter.getInstance(paramSynthContext).paintSeparatorBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintSeparatorBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  655 */     SeparatorPainter.getInstance(paramSynthContext).paintSeparatorBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintSeparatorForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  661 */     SeparatorPainter.getInstance(paramSynthContext).paintSeparatorForeground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */   
/*      */   public void paintSliderBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  672 */     SliderPainter.getInstance(paramSynthContext).paintSliderBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintSliderBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  678 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SliderPainter.getInstance(paramSynthContext), "paintSliderBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  679 */       SliderPainter.getInstance(paramSynthContext).paintSliderBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSliderTrackBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  685 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SliderPainter.getInstance(paramSynthContext), "paintSliderTrackBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  686 */       SliderPainter.getInstance(paramSynthContext).paintSliderTrackBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSliderTrackBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  692 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SliderPainter.getInstance(paramSynthContext), "paintSliderTrackBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  693 */       SliderPainter.getInstance(paramSynthContext).paintSliderTrackBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSliderThumbBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  699 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, SliderPainter.getInstance(paramSynthContext), "paintSliderThumbBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  700 */       SliderPainter.getInstance(paramSynthContext).paintSliderThumbBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintSliderThumbBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  706 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, SliderPainter.getInstance(paramSynthContext), "paintSliderThumbBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  707 */       SliderPainter.getInstance(paramSynthContext).paintSliderThumbBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintSpinnerBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  717 */     SyntheticaLookAndFeel.setChildrenOpaque(paramSynthContext.getComponent(), false);
/*  718 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SpinnerPainter.getInstance(paramSynthContext), "paintSpinnerBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  719 */       SpinnerPainter.getInstance(paramSynthContext).paintSpinnerBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSpinnerBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  725 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SpinnerPainter.getInstance(paramSynthContext), "paintSpinnerBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  726 */       SpinnerPainter.getInstance(paramSynthContext).paintSpinnerBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSplitPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  736 */     SplitPanePainter.getInstance(paramSynthContext).paintSplitPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintSplitPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  744 */     SplitPanePainter.getInstance(paramSynthContext).paintSplitPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintSplitPaneDividerForeground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  750 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, SplitPanePainter.getInstance(paramSynthContext), "paintSplitPaneDividerForeground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  751 */       SplitPanePainter.getInstance(paramSynthContext).paintSplitPaneDividerForeground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintSplitPaneDividerBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  757 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, SplitPanePainter.getInstance(paramSynthContext), "paintSplitPaneDividerBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  758 */       SplitPanePainter.getInstance(paramSynthContext).paintSplitPaneDividerBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintSplitPaneDragDivider(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  764 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, SplitPanePainter.getInstance(paramSynthContext), "paintSplitPaneDragDivider", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  765 */       SplitPanePainter.getInstance(paramSynthContext).paintSplitPaneDragDivider(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  776 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  784 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneContentBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  794 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneContentBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneContentBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  802 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneContentBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  810 */     Rectangle rectangle = tabAreaBoundsCorretion(paramSynthContext, paramInt1, paramInt2, paramInt3, paramInt4);
/*  811 */     paramInt1 = rectangle.x;
/*  812 */     paramInt2 = rectangle.y;
/*  813 */     paramInt3 = rectangle.width;
/*  814 */     paramInt4 = rectangle.height;
/*  817 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneTabAreaBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabAreaBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  823 */     Rectangle rectangle = tabAreaBoundsCorretion(paramSynthContext, paramInt1, paramInt2, paramInt3, paramInt4);
/*  824 */     paramInt1 = rectangle.x;
/*  825 */     paramInt2 = rectangle.y;
/*  826 */     paramInt3 = rectangle.width;
/*  827 */     paramInt4 = rectangle.height;
/*  830 */     TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneTabAreaBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   private Rectangle tabAreaBoundsCorretion(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  841 */     JTabbedPane jTabbedPane = (JTabbedPane)paramSynthContext.getComponent();
/*  842 */     if (jTabbedPane.getTabLayoutPolicy() == 1) {
/*  844 */       Insets insets1 = jTabbedPane.getInsets();
/*  845 */       Insets insets2 = paramSynthContext.getStyle().getInsets(paramSynthContext, null);
/*  846 */       int i = jTabbedPane.getTabCount();
/*  847 */       if (jTabbedPane.getTabPlacement() == 2 || jTabbedPane.getTabPlacement() == 4) {
/*  849 */         paramInt1 -= insets1.top;
/*  850 */         paramInt2 -= insets1.left;
/*  851 */         paramInt3 = ((i > 0) ? (jTabbedPane.getBoundsAt(0)).width : 0) + insets2.top + insets2.bottom;
/*  852 */         paramInt4 = insets2.left + insets2.right;
/*  853 */         for (byte b = 0; b < i; b++)
/*  854 */           paramInt4 += (jTabbedPane.getBoundsAt(b)).height; 
/*  855 */         paramInt4 = Math.max(paramInt4, jTabbedPane.getHeight());
/*      */       } else {
/*  859 */         paramInt1 -= insets1.left;
/*  860 */         paramInt2 -= insets1.top;
/*  861 */         paramInt3 = insets2.left + insets2.right;
/*  862 */         for (byte b = 0; b < i; b++)
/*  863 */           paramInt3 += (jTabbedPane.getBoundsAt(b)).width; 
/*  864 */         paramInt3 = Math.max(paramInt3, jTabbedPane.getWidth());
/*  865 */         paramInt4 = ((i > 0) ? (jTabbedPane.getBoundsAt(0)).height : 0) + insets2.top + insets2.bottom;
/*      */       } 
/*      */     } 
/*  868 */     return new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  876 */     paramSynthContext.getComponent().putClientProperty("Synthetica.tabbedPane.tabIndex", Integer.valueOf(paramInt5));
/*  877 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, TabbedPanePainter.getInstance(paramSynthContext), "paintTabbedPaneTabBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  878 */       TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneTabBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintTabbedPaneTabBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  884 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, TabbedPanePainter.getInstance(paramSynthContext), "paintTabbedPaneTabBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class, int.class }))
/*  885 */       TabbedPanePainter.getInstance(paramSynthContext).paintTabbedPaneTabBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5); 
/*      */   }
/*      */   
/*      */   public void paintTableBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  896 */     TablePainter.getInstance(paramSynthContext).paintTableBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTableBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  904 */     TablePainter.getInstance(paramSynthContext).paintTableBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTableHeaderBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  910 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, TablePainter.getInstance(paramSynthContext), "paintTableHeaderBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  911 */       TablePainter.getInstance(paramSynthContext).paintTableHeaderBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTableHeaderBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  917 */     TablePainter.getInstance(paramSynthContext).paintTableHeaderBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTextAreaBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  926 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, TextAreaPainter.getInstance(paramSynthContext), "paintTextAreaBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  927 */       TextAreaPainter.getInstance(paramSynthContext).paintTextAreaBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTextAreaBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  935 */     TextAreaPainter.getInstance(paramSynthContext).paintTextAreaBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTextFieldBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  944 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, TextFieldPainter.getInstance(paramSynthContext), "paintTextFieldBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  945 */       TextFieldPainter.getInstance(paramSynthContext).paintTextFieldBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTextFieldBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  951 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, TextFieldPainter.getInstance(paramSynthContext), "paintTextFieldBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  952 */       TextFieldPainter.getInstance(paramSynthContext).paintTextFieldBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTextPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  961 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, TextPanePainter.getInstance(paramSynthContext), "paintTextPaneBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  962 */       TextPanePainter.getInstance(paramSynthContext).paintTextPaneBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTextPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  970 */     TextPanePainter.getInstance(paramSynthContext).paintTextPaneBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintToggleButtonBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  979 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToggleButtonPainter.getInstance(paramSynthContext), "paintToggleButtonBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  980 */       ToggleButtonPainter.getInstance(paramSynthContext).paintToggleButtonBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToggleButtonBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  986 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToggleButtonPainter.getInstance(paramSynthContext), "paintToggleButtonBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/*  987 */       ToggleButtonPainter.getInstance(paramSynthContext).paintToggleButtonBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolBarBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  996 */     JComponent jComponent = paramSynthContext.getComponent();
/*  997 */     JRootPane jRootPane = jComponent.getRootPane();
/*  998 */     RootPaneUI rootPaneUI = jRootPane.getUI();
/*  999 */     if (rootPaneUI instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)rootPaneUI).isHeaderShadowEnabled()) {
/* 1001 */       Insets insets = jRootPane.getInsets();
/* 1002 */       boolean bool = ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.headerShadowSupport", jComponent, Boolean.valueOf(true))).booleanValue();
/* 1003 */       if (bool && paramInt3 == jRootPane.getWidth() - insets.left - insets.right && jComponent != ((SyntheticaRootPaneUI)rootPaneUI).getHeaderShadowComponent() && 
/* 1004 */         (jComponent.getLocationOnScreen()).y + jComponent.getHeight() < (jRootPane.getLocationOnScreen()).y + jRootPane.getHeight() - insets.bottom)
/* 1005 */         ((SyntheticaRootPaneUI)rootPaneUI).setHeaderShadowComponent(jComponent); 
/*      */     } 
/* 1008 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolBarPainter.getInstance(paramSynthContext), "paintToolBarBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1009 */       ToolBarPainter.getInstance(paramSynthContext).paintToolBarBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolBarBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1015 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolBarPainter.getInstance(paramSynthContext), "paintToolBarBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1016 */       ToolBarPainter.getInstance(paramSynthContext).paintToolBarBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolBarContentBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1022 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolBarPainter.getInstance(paramSynthContext), "paintToolBarContentBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1023 */       ToolBarPainter.getInstance(paramSynthContext).paintToolBarContentBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolBarContentBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1029 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolBarPainter.getInstance(paramSynthContext), "paintToolBarContentBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1030 */       ToolBarPainter.getInstance(paramSynthContext).paintToolBarContentBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolTipBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1039 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolTipPainter.getInstance(paramSynthContext), "paintToolTipBackground", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1040 */       ToolTipPainter.getInstance(paramSynthContext).paintToolTipBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintToolTipBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1046 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, -1, ToolTipPainter.getInstance(paramSynthContext), "paintToolTipBorder", new Class[] { SynthContext.class, Graphics.class, int.class, int.class, int.class, int.class }))
/* 1047 */       ToolTipPainter.getInstance(paramSynthContext).paintToolTipBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */   }
/*      */   
/*      */   public void paintTreeBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1058 */     TreePainter.getInstance(paramSynthContext).paintTreeBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTreeBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1066 */     TreePainter.getInstance(paramSynthContext).paintTreeBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTreeCellBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1075 */     TreePainter.getInstance(paramSynthContext).paintTreeCellBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTreeCellBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1081 */     TreePainter.getInstance(paramSynthContext).paintTreeCellBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintTreeCellFocus(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*      */   
/*      */   public void paintViewportBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1096 */     ViewportPainter.getInstance(paramSynthContext).paintViewportBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void paintViewportBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 1103 */     ViewportPainter.getInstance(paramSynthContext).paintViewportBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */