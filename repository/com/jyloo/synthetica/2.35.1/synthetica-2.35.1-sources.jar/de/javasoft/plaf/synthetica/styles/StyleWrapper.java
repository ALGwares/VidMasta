/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.SyntheticaPainter;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthGraphicsUtils;
/*     */ import javax.swing.plaf.synth.SynthPainter;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public abstract class StyleWrapper extends SynthStyle {
/*     */   protected SynthStyle synthStyle;
/*     */   
/*     */   public StyleWrapper() {}
/*     */   
/*     */   public StyleWrapper(SynthStyle paramSynthStyle) {
/*  41 */     this.synthStyle = paramSynthStyle;
/*     */   }
/*     */   
/*     */   void setStyle(SynthStyle paramSynthStyle) {
/*  46 */     this.synthStyle = paramSynthStyle;
/*     */   }
/*     */   
/*     */   public Object get(SynthContext paramSynthContext, Object paramObject) {
/*  51 */     return this.synthStyle.get(paramSynthContext, paramObject);
/*     */   }
/*     */   
/*     */   public boolean getBoolean(SynthContext paramSynthContext, Object paramObject, boolean paramBoolean) {
/*  56 */     return this.synthStyle.getBoolean(paramSynthContext, paramObject, paramBoolean);
/*     */   }
/*     */   
/*     */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/*  61 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*     */   }
/*     */   
/*     */   public Color getColorForState(SynthContext paramSynthContext, ColorType paramColorType) {
/*  66 */     return this.synthStyle.getColor(paramSynthContext, paramColorType);
/*     */   }
/*     */   
/*     */   public Font getFont(SynthContext paramSynthContext) {
/*  71 */     return this.synthStyle.getFont(paramSynthContext);
/*     */   }
/*     */   
/*     */   public Font getFontForState(SynthContext paramSynthContext) {
/*  76 */     return this.synthStyle.getFont(paramSynthContext);
/*     */   }
/*     */   
/*     */   public SynthGraphicsUtils getGraphicsUtils(SynthContext paramSynthContext) {
/*  81 */     return this.synthStyle.getGraphicsUtils(paramSynthContext);
/*     */   }
/*     */   
/*     */   public Icon getIcon(SynthContext paramSynthContext, Object paramObject) {
/*  86 */     return this.synthStyle.getIcon(paramSynthContext, paramObject);
/*     */   }
/*     */   
/*     */   public Insets getInsets(SynthContext paramSynthContext, Insets paramInsets) {
/*  91 */     return this.synthStyle.getInsets(paramSynthContext, paramInsets);
/*     */   }
/*     */   
/*     */   public int getInt(SynthContext paramSynthContext, Object paramObject, int paramInt) {
/*  96 */     return this.synthStyle.getInt(paramSynthContext, paramObject, paramInt);
/*     */   }
/*     */   
/*     */   public SynthPainter getPainter(SynthContext paramSynthContext) {
/* 102 */     return SyntheticaPainter.getInstance();
/*     */   }
/*     */   
/*     */   public String getString(SynthContext paramSynthContext, Object paramObject, String paramString) {
/* 107 */     return this.synthStyle.getString(paramSynthContext, paramObject, paramString);
/*     */   }
/*     */   
/*     */   public void installDefaults(SynthContext paramSynthContext) {
/* 112 */     this.synthStyle.installDefaults(paramSynthContext);
/*     */   }
/*     */   
/*     */   public boolean isOpaque(SynthContext paramSynthContext) {
/* 117 */     return this.synthStyle.isOpaque(paramSynthContext);
/*     */   }
/*     */   
/*     */   public void uninstallDefaults(SynthContext paramSynthContext) {
/* 122 */     this.synthStyle.uninstallDefaults(paramSynthContext);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\StyleWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */