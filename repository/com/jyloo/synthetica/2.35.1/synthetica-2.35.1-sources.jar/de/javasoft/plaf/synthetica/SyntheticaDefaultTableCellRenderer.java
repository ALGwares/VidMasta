/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Date;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ public class SyntheticaDefaultTableCellRenderer extends JLabel implements TableCellRenderer, Serializable, UIResource {
/*     */   private static final long serialVersionUID = 9059722839161202006L;
/*     */   
/*     */   private Border noFocusBorder;
/*     */   
/*     */   private Border focusBorder;
/*     */   
/*     */   private NumberFormat numberFormat;
/*     */   
/*     */   private DateFormat dateFormat;
/*     */   
/*     */   private Color alternateColor;
/*     */   
/*     */   private boolean colorCachingEnabled;
/*     */   
/*     */   private Color unselectedForeground;
/*     */   
/*     */   private Color unselectedBackground;
/*     */   
/*     */   public SyntheticaDefaultTableCellRenderer(TableCellRenderer paramTableCellRenderer) {
/*  64 */     setOpaque(true);
/*  66 */     Border border1 = (paramTableCellRenderer == null) ? new EmptyBorder(0, 0, 0, 0) : ((JComponent)paramTableCellRenderer).getBorder();
/*  67 */     Insets insets1 = (border1 == null) ? new Insets(0, 0, 0, 0) : border1.getBorderInsets(null);
/*  69 */     Border border2 = UIManager.getBorder("Table.focusCellHighlightBorder");
/*  70 */     Border border3 = (border2 == null) ? new EmptyBorder(0, 0, 0, 0) : border2;
/*  71 */     Insets insets2 = border3.getBorderInsets(null);
/*  73 */     Insets insets3 = new Insets(insets1.top - insets2.top, insets1.left - insets2.left, insets1.bottom - insets2.bottom, insets1.right - insets2.right);
/*  74 */     this.focusBorder = new CompoundBorder(border3, new EmptyBorder(insets3));
/*  75 */     this.noFocusBorder = new CompoundBorder(new EmptyBorder(insets2), new EmptyBorder(insets3));
/*  76 */     this.alternateColor = UIManager.getColor("Table.alternateRowColor");
/*  77 */     this.colorCachingEnabled = SyntheticaLookAndFeel.getBoolean("Synthetica.table.cellRenderer.colorCache.enabled", null, false);
/*     */   }
/*     */   
/*     */   public String getName() {
/*  83 */     String str = super.getName();
/*  84 */     if (str == null)
/*  85 */       str = "Table.cellRenderer"; 
/*  86 */     return str;
/*     */   }
/*     */   
/*     */   public void setForeground(Color paramColor) {
/*  92 */     super.setForeground(paramColor);
/*  93 */     if (this.colorCachingEnabled)
/*  94 */       this.unselectedForeground = paramColor; 
/*     */   }
/*     */   
/*     */   public void setBackground(Color paramColor) {
/* 100 */     super.setBackground(paramColor);
/* 101 */     if (this.colorCachingEnabled)
/* 102 */       this.unselectedBackground = paramColor; 
/*     */   }
/*     */   
/*     */   public void updateUI() {
/* 108 */     super.updateUI();
/* 109 */     setForeground((Color)null);
/* 110 */     setBackground((Color)null);
/*     */   }
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2) {
/* 127 */     Color color1 = null;
/* 128 */     Color color2 = null;
/* 130 */     if (!JavaVersion.JAVA5) {
/* 132 */       JTable.DropLocation dropLocation = paramJTable.getDropLocation();
/* 133 */       if (dropLocation != null && !dropLocation.isInsertRow() && !dropLocation.isInsertColumn() && dropLocation.getRow() == paramInt1 && dropLocation.getColumn() == paramInt2) {
/* 135 */         color1 = UIManager.getColor("Table.dropCellForeground");
/* 136 */         color2 = UIManager.getColor("Table.dropCellBackground");
/* 137 */         paramBoolean1 = true;
/*     */       } 
/*     */     } 
/* 141 */     if (paramBoolean1) {
/* 143 */       if (color1 == null)
/* 144 */         color1 = paramJTable.getSelectionForeground(); 
/* 145 */       if (color2 == null)
/* 146 */         color2 = paramJTable.getSelectionBackground(); 
/*     */     } else {
/* 150 */       color1 = (this.unselectedForeground == null) ? paramJTable.getForeground() : this.unselectedForeground;
/* 151 */       color2 = (this.unselectedBackground == null) ? paramJTable.getBackground() : this.unselectedBackground;
/* 152 */       if ((color2 == null || color2 instanceof UIResource) && this.alternateColor != null && paramInt1 % 2 == (JavaVersion.JAVA7_OR_ABOVE ? 1 : 0))
/* 153 */         color2 = this.alternateColor; 
/* 154 */       if (paramBoolean2 && paramJTable.isCellEditable(paramInt1, paramInt2)) {
/* 156 */         color1 = (UIManager.get("Table.focusCellForeground") == null) ? color1 : UIManager.getColor("Table.focusCellForeground");
/* 157 */         color2 = (UIManager.get("Table.focusCellBackground") == null) ? color2 : UIManager.getColor("Table.focusCellBackground");
/*     */       } 
/*     */     } 
/* 160 */     super.setForeground(color1);
/* 161 */     super.setBackground(color2);
/* 163 */     if (paramBoolean2) {
/* 164 */       setBorder(this.focusBorder);
/*     */     } else {
/* 166 */       setBorder(this.noFocusBorder);
/*     */     } 
/* 168 */     setFont(paramJTable.getFont());
/* 169 */     setValue(paramObject);
/* 170 */     setIcon((Icon)null);
/* 171 */     configureValue(paramObject, paramJTable.getColumnClass(paramInt2));
/* 172 */     return this;
/*     */   }
/*     */   
/*     */   protected void setValue(Object paramObject) {
/* 178 */     setText((paramObject == null) ? "" : paramObject.toString());
/*     */   }
/*     */   
/*     */   private void configureValue(Object paramObject, Class<?> paramClass) {
/* 183 */     if (paramClass == Object.class || paramClass == null) {
/* 184 */       setHorizontalAlignment(10);
/* 186 */     } else if (paramClass == Float.class || paramClass == Double.class) {
/* 188 */       if (this.numberFormat == null)
/* 189 */         this.numberFormat = NumberFormat.getInstance(); 
/* 190 */       setHorizontalAlignment(11);
/* 191 */       setText((paramObject == null) ? "" : this.numberFormat.format(paramObject));
/* 194 */     } else if (paramClass == Number.class) {
/* 195 */       setHorizontalAlignment(11);
/* 197 */     } else if (paramClass == Date.class) {
/* 199 */       if (this.dateFormat == null)
/* 200 */         this.dateFormat = DateFormat.getDateInstance(); 
/* 201 */       setHorizontalAlignment(10);
/* 202 */       setText((paramObject == null) ? "" : this.dateFormat.format(paramObject));
/* 205 */     } else if (paramClass == Icon.class || paramClass == ImageIcon.class) {
/* 207 */       setHorizontalAlignment(0);
/* 208 */       setIcon((paramObject instanceof Icon) ? (Icon)paramObject : null);
/* 209 */       setText("");
/*     */     } else {
/* 213 */       configureValue(paramObject, paramClass.getSuperclass());
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isOpaque() {
/* 220 */     Color color = getBackground();
/* 221 */     Container container = getParent();
/* 222 */     if (container != null)
/* 223 */       container = container.getParent(); 
/* 224 */     boolean bool = (color != null && container != null && color.equals(container.getBackground()) && container.isOpaque()) ? true : false;
/* 225 */     return (!bool && super.isOpaque());
/*     */   }
/*     */   
/*     */   public void invalidate() {}
/*     */   
/*     */   public void validate() {}
/*     */   
/*     */   public void revalidate() {}
/*     */   
/*     */   public void repaint(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void repaint(Rectangle paramRectangle) {}
/*     */   
/*     */   public void repaint() {}
/*     */   
/*     */   protected void firePropertyChange(String paramString, Object paramObject1, Object paramObject2) {
/* 242 */     if (paramString == "text" || paramString == "labelFor" || paramString == "displayedMnemonic" || ((paramString == "font" || paramString == "foreground") && 
/* 243 */       paramObject1 != paramObject2 && 
/* 244 */       getClientProperty("html") != null))
/* 246 */       super.firePropertyChange(paramString, paramObject1, paramObject2); 
/*     */   }
/*     */   
/*     */   public void firePropertyChange(String paramString, boolean paramBoolean1, boolean paramBoolean2) {}
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDefaultTableCellRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */