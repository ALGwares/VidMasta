/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.OS;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.UIDefaults;
/*     */ 
/*     */ class SyntheticaInputDefaults {
/*     */   public static Object[] getInputMapDefaults() {
/*  30 */     ArrayList<UIDefaults.LazyInputMap> arrayList = new ArrayList();
/*  31 */     Map<Object, Map<Object, Object>> map = getInputMap();
/*  32 */     for (Map.Entry<Object, Map<Object, Object>> entry : map.entrySet()) {
/*  34 */       arrayList.add(entry.getKey());
/*  36 */       Map map1 = (Map)entry.getValue();
/*  37 */       ArrayList arrayList1 = new ArrayList();
/*  38 */       for (Map.Entry entry1 : map1.entrySet()) {
/*  40 */         arrayList1.add(entry1.getKey());
/*  41 */         arrayList1.add(entry1.getValue());
/*     */       } 
/*  43 */       arrayList.add(new UIDefaults.LazyInputMap(arrayList1.toArray()));
/*     */     } 
/*  46 */     return arrayList.toArray();
/*     */   }
/*     */   
/*     */   private static Map<Object, Map<Object, Object>> getInputMap() {
/*  51 */     boolean bool1 = (OS.getCurrentOS() == OS.Mac) ? true : false;
/*  52 */     boolean bool2 = (OS.getCurrentOS() == OS.Linux) ? true : false;
/*  54 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*  56 */     Map<Object, Object> map = getBaseMap4JTable();
/*  57 */     if (bool1) {
/*  58 */       map.putAll(getMacMap4JTable());
/*  59 */     } else if (bool2) {
/*  60 */       map.putAll(getLinuxMap4JTable());
/*     */     } 
/*  61 */     hashMap.put("Table.ancestorInputMap", map);
/*  63 */     map = getBaseMap4JTableRTL();
/*  64 */     hashMap.put("Table.ancestorInputMap.RightToLeft", map);
/*  66 */     map = getBaseMap4JTree();
/*  67 */     if (bool1) {
/*  68 */       map.putAll(getMacMap4JTree());
/*  69 */     } else if (bool2) {
/*  70 */       map.putAll(getLinuxMap4JTree());
/*     */     } 
/*  71 */     hashMap.put("Tree.ancestorInputMap", map);
/*  73 */     map = getBaseMap4JComboBox();
/*  74 */     hashMap.put("ComboBox.ancestorInputMap", map);
/*  76 */     map = getBaseMap4JRootPane();
/*  77 */     hashMap.put("RootPane.ancestorInputMap", map);
/* 101 */     return (Map)hashMap;
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getBaseMap4JTable() {
/* 110 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 111 */     Object[] arrayOfObject = getBaseValues4JTable();
/* 112 */     for (byte b = 0; b < arrayOfObject.length; b += 2)
/* 113 */       hashMap.put(arrayOfObject[b], arrayOfObject[b + 1]); 
/* 114 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getMacMap4JTable() {
/* 119 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 120 */     hashMap.put("meta A", "selectAll");
/* 121 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getLinuxMap4JTable() {
/* 126 */     return new HashMap<Object, Object>();
/*     */   }
/*     */   
/*     */   private static Object[] getBaseValues4JTable() {
/* 132 */     return new Object[] { 
/* 133 */         "ctrl C", "copy", 
/* 134 */         "ctrl V", "paste", 
/* 135 */         "ctrl X", "cut", 
/* 136 */         "COPY", "copy", 
/* 137 */         "PASTE", "paste", 
/* 138 */         "CUT", "cut", 
/* 139 */         "RIGHT", "selectNextColumn", 
/* 140 */         "KP_RIGHT", "selectNextColumn", 
/* 141 */         "shift RIGHT", "selectNextColumnExtendSelection", 
/* 142 */         "shift KP_RIGHT", "selectNextColumnExtendSelection", 
/* 143 */         "ctrl shift RIGHT", "selectNextColumnExtendSelection", 
/* 144 */         "ctrl shift KP_RIGHT", "selectNextColumnExtendSelection", 
/* 145 */         "ctrl RIGHT", "selectNextColumnChangeLead", 
/* 146 */         "ctrl KP_RIGHT", "selectNextColumnChangeLead", 
/* 147 */         "LEFT", "selectPreviousColumn", 
/* 148 */         "KP_LEFT", "selectPreviousColumn", 
/* 149 */         "shift LEFT", "selectPreviousColumnExtendSelection", 
/* 150 */         "shift KP_LEFT", "selectPreviousColumnExtendSelection", 
/* 151 */         "ctrl shift LEFT", "selectPreviousColumnExtendSelection", 
/* 152 */         "ctrl shift KP_LEFT", "selectPreviousColumnExtendSelection", 
/* 153 */         "ctrl LEFT", "selectPreviousColumnChangeLead", 
/* 154 */         "ctrl KP_LEFT", "selectPreviousColumnChangeLead", 
/* 155 */         "DOWN", "selectNextRow", 
/* 156 */         "KP_DOWN", "selectNextRow", 
/* 157 */         "shift DOWN", "selectNextRowExtendSelection", 
/* 158 */         "shift KP_DOWN", "selectNextRowExtendSelection", 
/* 159 */         "ctrl shift DOWN", "selectNextRowExtendSelection", 
/* 160 */         "ctrl shift KP_DOWN", "selectNextRowExtendSelection", 
/* 161 */         "ctrl DOWN", "selectNextRowChangeLead", 
/* 162 */         "ctrl KP_DOWN", "selectNextRowChangeLead", 
/* 163 */         "UP", "selectPreviousRow", 
/* 164 */         "KP_UP", "selectPreviousRow", 
/* 165 */         "shift UP", "selectPreviousRowExtendSelection", 
/* 166 */         "shift KP_UP", "selectPreviousRowExtendSelection", 
/* 167 */         "ctrl shift UP", "selectPreviousRowExtendSelection", 
/* 168 */         "ctrl shift KP_UP", "selectPreviousRowExtendSelection", 
/* 169 */         "ctrl UP", "selectPreviousRowChangeLead", 
/* 170 */         "ctrl KP_UP", "selectPreviousRowChangeLead", 
/* 171 */         "HOME", "selectFirstColumn", 
/* 172 */         "shift HOME", "selectFirstColumnExtendSelection", 
/* 173 */         "ctrl shift HOME", "selectFirstRowExtendSelection", 
/* 174 */         "ctrl HOME", "selectFirstRow", 
/* 175 */         "END", "selectLastColumn", 
/* 176 */         "shift END", "selectLastColumnExtendSelection", 
/* 177 */         "ctrl shift END", "selectLastRowExtendSelection", 
/* 178 */         "ctrl END", "selectLastRow", 
/* 179 */         "PAGE_UP", "scrollUpChangeSelection", 
/* 180 */         "shift PAGE_UP", "scrollUpExtendSelection", 
/* 181 */         "ctrl shift PAGE_UP", "scrollLeftExtendSelection", 
/* 182 */         "ctrl PAGE_UP", "scrollLeftChangeSelection", 
/* 183 */         "PAGE_DOWN", "scrollDownChangeSelection", 
/* 184 */         "shift PAGE_DOWN", "scrollDownExtendSelection", 
/* 185 */         "ctrl shift PAGE_DOWN", "scrollRightExtendSelection", 
/* 186 */         "ctrl PAGE_DOWN", "scrollRightChangeSelection", 
/* 187 */         "TAB", "selectNextColumnCell", 
/* 188 */         "shift TAB", "selectPreviousColumnCell", 
/* 189 */         "ENTER", "selectNextRowCell", 
/* 190 */         "shift ENTER", "selectPreviousRowCell", 
/* 191 */         "ctrl A", "selectAll", 
/* 192 */         "ctrl SLASH", "selectAll", 
/* 193 */         "ctrl BACK_SLASH", "clearSelection", 
/* 194 */         "ESCAPE", "cancel", 
/* 195 */         "F2", "startEditing", 
/* 196 */         "SPACE", "addToSelection", 
/* 197 */         "ctrl SPACE", "toggleAndAnchor", 
/* 198 */         "shift SPACE", "extendTo", 
/* 199 */         "ctrl shift SPACE", "moveSelectionTo" };
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getBaseMap4JTableRTL() {
/* 205 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 206 */     Object[] arrayOfObject = getBaseValues4JTableRTL();
/* 207 */     for (byte b = 0; b < arrayOfObject.length; b += 2)
/* 208 */       hashMap.put(arrayOfObject[b], arrayOfObject[b + 1]); 
/* 209 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Object[] getBaseValues4JTableRTL() {
/* 214 */     return new Object[] { 
/* 215 */         "RIGHT", "selectPreviousColumn", 
/* 216 */         "KP_RIGHT", "selectPreviousColumn", 
/* 217 */         "shift RIGHT", "selectPreviousColumnExtendSelection", 
/* 218 */         "shift KP_RIGHT", "selectPreviousColumnExtendSelection", 
/* 219 */         "ctrl shift RIGHT", "selectPreviousColumnExtendSelection", 
/* 220 */         "ctrl shift KP_RIGHT", "selectPreviousColumnExtendSelection", 
/* 221 */         "shift RIGHT", "selectPreviousColumnChangeLead", 
/* 222 */         "shift KP_RIGHT", "selectPreviousColumnChangeLead", 
/* 223 */         "LEFT", "selectNextColumn", 
/* 224 */         "KP_LEFT", "selectNextColumn", 
/* 225 */         "shift LEFT", "selectNextColumnExtendSelection", 
/* 226 */         "shift KP_LEFT", "selectNextColumnExtendSelection", 
/* 227 */         "ctrl shift LEFT", "selectNextColumnExtendSelection", 
/* 228 */         "ctrl shift KP_LEFT", "selectNextColumnExtendSelection", 
/* 229 */         "ctrl LEFT", "selectNextColumnChangeLead", 
/* 230 */         "ctrl KP_LEFT", "selectNextColumnChangeLead", 
/* 231 */         "ctrl PAGE_UP", "scrollRightChangeSelection", 
/* 232 */         "ctrl PAGE_DOWN", "scrollLeftChangeSelection", 
/* 233 */         "ctrl shift PAGE_UP", "scrollRightExtendSelection", 
/* 234 */         "ctrl shift PAGE_DOWN", "scrollLeftExtendSelection" };
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getBaseMap4JTree() {
/* 244 */     return new HashMap<Object, Object>();
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getMacMap4JTree() {
/* 253 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 254 */     hashMap.put("meta A", "selectAll");
/* 255 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getLinuxMap4JTree() {
/* 260 */     return new HashMap<Object, Object>();
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getBaseMap4JComboBox() {
/* 270 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 271 */     Object[] arrayOfObject = getBaseValues4JComboBox();
/* 272 */     for (byte b = 0; b < arrayOfObject.length; b += 2)
/* 273 */       hashMap.put(arrayOfObject[b], arrayOfObject[b + 1]); 
/* 274 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Object[] getBaseValues4JComboBox() {
/* 280 */     return new Object[] { 
/* 281 */         "ESCAPE", "hidePopup", 
/* 282 */         "PAGE_UP", "pageUpPassThrough", 
/* 283 */         "PAGE_DOWN", "pageDownPassThrough", 
/* 284 */         "HOME", "homePassThrough", 
/* 285 */         "END", "endPassThrough", 
/* 286 */         "DOWN", "selectNext", 
/* 287 */         "KP_DOWN", "selectNext", 
/* 288 */         "alt DOWN", "togglePopup", 
/* 289 */         "alt KP_DOWN", "togglePopup", 
/* 290 */         "alt UP", "togglePopup", 
/* 291 */         "alt KP_UP", "togglePopup", 
/* 292 */         "SPACE", "spacePopup", 
/* 293 */         "ENTER", "enterPressed", 
/* 294 */         "UP", "selectPrevious", 
/* 295 */         "KP_UP", "selectPrevious" };
/*     */   }
/*     */   
/*     */   private static Map<Object, Object> getBaseMap4JRootPane() {
/* 305 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 306 */     Object[] arrayOfObject = getBaseValues4JRootPane();
/* 307 */     for (byte b = 0; b < arrayOfObject.length; b += 2)
/* 308 */       hashMap.put(arrayOfObject[b], arrayOfObject[b + 1]); 
/* 309 */     return hashMap;
/*     */   }
/*     */   
/*     */   private static Object[] getBaseValues4JRootPane() {
/* 315 */     return new Object[] { "shift F10", "postPopup", 
/* 317 */         "CONTEXT_MENU", "postPopup" };
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaInputDefaults.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */