/*      */ package de.javasoft.plaf.synthetica;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.styles.ButtonStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.CheckBoxStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ComboBoxStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.EditorPaneStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.FormattedTextFieldStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.LabelStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ListStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.MenuItemStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.MenuStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.PasswordFieldStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.PopupMenuStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.RadioButtonStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ScrollPaneStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.SpinnerStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TabbedPaneContentStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TabbedPaneStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TableStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TextAreaStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TextFieldStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.TextPaneStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ToggleButtonStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ToolBarButtonStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ToolBarSeparatorStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ToolBarStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ToolTipStyle;
/*      */ import de.javasoft.plaf.synthetica.styles.ViewportStyle;
/*      */ import de.javasoft.util.JavaVersion;
/*      */ import de.javasoft.util.OS;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ContainerAdapter;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.ContainerListener;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionAdapter;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Field;
/*      */ import java.security.AccessControlException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.EventListener;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import javax.swing.AbstractButton;
/*      */ import javax.swing.DefaultListCellRenderer;
/*      */ import javax.swing.DefaultRowSorter;
/*      */ import javax.swing.DesktopManager;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JDesktopPane;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.JScrollBar;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JSpinner;
/*      */ import javax.swing.JSplitPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JToolBar;
/*      */ import javax.swing.JTree;
/*      */ import javax.swing.JViewport;
/*      */ import javax.swing.ListCellRenderer;
/*      */ import javax.swing.LookAndFeel;
/*      */ import javax.swing.RowSorter;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.ToolTipManager;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.CompoundBorder;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.border.TitledBorder;
/*      */ import javax.swing.event.PopupMenuEvent;
/*      */ import javax.swing.event.PopupMenuListener;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.plaf.BorderUIResource;
/*      */ import javax.swing.plaf.FontUIResource;
/*      */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*      */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*      */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*      */ import javax.swing.plaf.synth.ColorType;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthStyle;
/*      */ import javax.swing.plaf.synth.SynthStyleFactory;
/*      */ import javax.swing.table.JTableHeader;
/*      */ import javax.swing.table.TableCellEditor;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import javax.swing.table.TableModel;
/*      */ import javax.swing.tree.TreeCellRenderer;
/*      */ import sun.swing.DefaultLookup;
/*      */ import sun.swing.plaf.synth.DefaultSynthStyle;
/*      */ 
/*      */ public class StyleFactory extends SynthStyleFactory {
/*      */   private SynthStyleFactory synthStyleFactory;
/*      */   
/*      */   private SyntheticaStyleFactory syntheticaStyleFactory;
/*      */   
/*      */   private PropertyChangeListener styleUpdater;
/*      */   
/*      */   private Boolean styleNameSupportEnabled;
/*      */   
/*      */   private ComponentPropertyStore componentPropertyStore;
/*      */   
/*      */   public class ComponentPropertyStore {
/*      */     private HashSet<StyleFactory.ComponentProperty> componentProperties;
/*      */     
/* 1924 */     private boolean enabled = SyntheticaLookAndFeel.getBoolean("Synthetica.propertyStore.enabled", null, StyleFactory.componentPropertyStoreEnabled);
/*      */     
/*      */     private Thread cleanerThread;
/*      */     
/*      */     ComponentPropertyStore() {
/* 1929 */       if (this.enabled)
/* 1930 */         reinit(); 
/*      */     }
/*      */     
/*      */     void reinit() {
/* 1937 */       stop();
/* 1939 */       this.componentProperties = new HashSet<StyleFactory.ComponentProperty>(500);
/* 1941 */       this.cleanerThread = new Thread() {
/*      */           public void run() {
/* 1946 */             while (!isInterrupted()) {
/* 1947 */               synchronized (StyleFactory.ComponentPropertyStore.this.componentProperties) {
/* 1949 */                 for (Iterator<StyleFactory.ComponentProperty> iterator = StyleFactory.ComponentPropertyStore.this.componentProperties.iterator(); iterator.hasNext(); ) {
/* 1951 */                   StyleFactory.ComponentProperty componentProperty = iterator.next();
/* 1952 */                   if (componentProperty.component.get() == null)
/* 1953 */                     iterator.remove(); 
/*      */                 } 
/*      */               } 
/* 1956 */               if (isInterrupted())
/*      */                 break; 
/*      */               try {
/* 1959 */                 sleep(StyleFactory.cleanerThreadDelay);
/*      */               } catch (InterruptedException interruptedException) {
/* 1959 */                 interrupt();
/*      */               } 
/*      */             } 
/* 1961 */             StyleFactory.ComponentPropertyStore.this.componentProperties.clear();
/*      */           }
/*      */         };
/* 1964 */       this.cleanerThread.setName("SyntheticaCleanerThread");
/* 1965 */       this.cleanerThread.setDaemon(true);
/* 1966 */       this.cleanerThread.start();
/*      */     }
/*      */     
/*      */     void stop() {
/* 1971 */       if (this.cleanerThread != null)
/* 1972 */         this.cleanerThread.interrupt(); 
/*      */     }
/*      */     
/*      */     boolean removeComponentProperty(Component param1Component, String param1String, Object param1Object) {
/* 1977 */       StyleFactory.ComponentProperty componentProperty = new StyleFactory.ComponentProperty(param1Component, param1String, param1Object);
/* 1978 */       return this.componentProperties.remove(componentProperty);
/*      */     }
/*      */     
/*      */     public void storeComponentProperty(Component param1Component, String param1String) {
/*      */       Integer integer;
/* 1984 */       if (!this.enabled)
/*      */         return; 
/* 1986 */       Boolean bool = null;
/* 1987 */       if (param1String.equals("SYCP_OPAQUE")) {
/* 1988 */         bool = Boolean.valueOf(param1Component.isOpaque());
/* 1989 */       } else if (param1String.equals("SYCP_INSETS")) {
/* 1990 */         Insets insets = ((JComponent)param1Component).getInsets();
/* 1991 */       } else if (param1String.equals("SYCP_BORDER")) {
/* 1992 */         Border border = ((JComponent)param1Component).getBorder();
/* 1993 */       } else if (param1String.equals("SYCP_BUTTON_MARGIN")) {
/* 1994 */         Insets insets = ((AbstractButton)param1Component).getMargin();
/* 1995 */       } else if (param1String.equals("SYCP_BUTTON_HALIGN")) {
/* 1996 */         integer = Integer.valueOf(((AbstractButton)param1Component).getHorizontalAlignment());
/* 1997 */       } else if (param1String.equals("SYCP_BUTTON_VALIGN")) {
/* 1998 */         integer = Integer.valueOf(((AbstractButton)param1Component).getVerticalAlignment());
/* 1999 */       } else if (param1String.equals("SYCP_TOOLBAR_SEPARATOR_SIZE")) {
/* 2000 */         Dimension dimension = ((JToolBar.Separator)param1Component).getSeparatorSize();
/* 2001 */       } else if (param1String.equals("SYCP_TREE_CELL_RENDERER")) {
/* 2002 */         TreeCellRenderer treeCellRenderer = ((JTree)param1Component).getCellRenderer();
/* 2003 */       } else if (param1String.equals("SYCP_LAYOUT_MANAGER")) {
/* 2004 */         LayoutManager layoutManager = ((JComponent)param1Component).getLayout();
/* 2005 */       } else if (param1String.equals("SYCP_DESKTOP_MANAGER")) {
/* 2006 */         DesktopManager desktopManager = ((JDesktopPane)param1Component).getDesktopManager();
/* 2007 */       } else if (param1String.equals("SYCP_TITLEDBORDER_TITLEPOSITION")) {
/* 2008 */         integer = Integer.valueOf(StyleFactory.this.getTitledBorder(((JComponent)param1Component).getBorder()).getTitlePosition());
/* 2009 */       } else if (param1String.equals("SYCP_TABLE_OBJECT_DEFAULT_RENDERER")) {
/* 2010 */         TableCellRenderer tableCellRenderer = ((JTable)param1Component).getDefaultRenderer(Object.class);
/* 2011 */       } else if (param1String.equals("SYCP_TABLE_BOOLEAN_DEFAULT_RENDERER")) {
/* 2012 */         TableCellRenderer tableCellRenderer = ((JTable)param1Component).getDefaultRenderer(Boolean.class);
/* 2013 */       } else if (param1String.equals("SYCP_TABLE_OBJECT_DEFAULT_EDITOR")) {
/* 2014 */         TableCellEditor tableCellEditor = ((JTable)param1Component).getDefaultEditor(Object.class);
/* 2015 */       } else if (param1String.equals("SYCP_TABLE_NUMBER_DEFAULT_EDITOR")) {
/* 2016 */         TableCellEditor tableCellEditor = ((JTable)param1Component).getDefaultEditor(Number.class);
/* 2017 */       } else if (param1String.equals("SYCP_TABLE_COLUMN_MARGIN")) {
/* 2018 */         integer = Integer.valueOf(((JTable)param1Component).getColumnModel().getColumnMargin());
/* 2019 */       } else if (param1String.equals("SYCP_TABLE_ROW_MARGIN")) {
/* 2020 */         integer = Integer.valueOf(((JTable)param1Component).getRowMargin());
/*      */       } 
/* 2022 */       StyleFactory.ComponentProperty componentProperty = new StyleFactory.ComponentProperty(param1Component, param1String, integer);
/* 2023 */       synchronized (this.componentProperties) {
/* 2025 */         if (!this.componentProperties.contains(componentProperty))
/* 2030 */           this.componentProperties.add(componentProperty); 
/*      */       } 
/*      */     }
/*      */     
/*      */     void restoreAllComponentProperties() {
/* 2037 */       synchronized (this.componentProperties) {
/* 2039 */         for (StyleFactory.ComponentProperty componentProperty : this.componentProperties)
/* 2040 */           restoreComponentProperty(componentProperty); 
/* 2041 */         this.componentProperties.clear();
/*      */       } 
/* 2043 */       StyleFactory.this.prepareMetalLAFSwitch = false;
/*      */     }
/*      */     
/*      */     private void restoreComponentProperty(StyleFactory.ComponentProperty param1ComponentProperty) {
/* 2048 */       Component component = param1ComponentProperty.component.get();
/* 2049 */       if (component == null)
/*      */         return; 
/* 2051 */       String str = param1ComponentProperty.propertyName;
/* 2052 */       Object object = null;
/* 2053 */       if (component instanceof JComponent) {
/* 2054 */         object = ((JComponent)component).getClientProperty(param1ComponentProperty.propertyName);
/*      */       } else {
/* 2056 */         object = param1ComponentProperty.value.get();
/*      */       } 
/* 2058 */       if (str.equals("SYCP_OPAQUE") && StyleFactory.this.prepareMetalLAFSwitch) {
/* 2063 */         StyleFactory.this.setOpaqueDefault4Metal((JComponent)component);
/* 2065 */       } else if (str.equals("SYCP_INSETS")) {
/* 2067 */         ((JComponent)component).setBorder(new EmptyBorder((Insets)object));
/* 2069 */       } else if (str.equals("SYCP_BUTTON_MARGIN")) {
/* 2071 */         ((AbstractButton)component).setMargin((Insets)object);
/* 2073 */       } else if (str.equals("SYCP_BUTTON_HALIGN")) {
/* 2075 */         ((AbstractButton)component).setHorizontalAlignment(((Integer)object).intValue());
/* 2077 */       } else if (str.equals("SYCP_BUTTON_VALIGN")) {
/* 2079 */         ((AbstractButton)component).setVerticalAlignment(((Integer)object).intValue());
/* 2081 */       } else if (str.equals("SYCP_TOOLBAR_SEPARATOR_SIZE")) {
/* 2083 */         Dimension dimension = (Dimension)object;
/* 2087 */         if (dimension == null)
/* 2088 */           dimension = new Dimension(10, 10); 
/* 2089 */         ((JToolBar.Separator)component).setSeparatorSize(dimension);
/* 2091 */       } else if (str.equals("SYCP_TREE_CELL_RENDERER")) {
/* 2093 */         TreeCellRenderer treeCellRenderer = (TreeCellRenderer)object;
/* 2094 */         ((JTree)component).setCellRenderer(treeCellRenderer);
/* 2096 */       } else if (str.equals("SYCP_PROPERTY_CHANGE_LISTENERS")) {
/* 2098 */         PropertyChangeListener[] arrayOfPropertyChangeListener = component.getPropertyChangeListeners();
/* 2099 */         for (byte b = 0; b < arrayOfPropertyChangeListener.length; b++) {
/* 2101 */           if (arrayOfPropertyChangeListener[b].getClass().getName().contains("synthetica"))
/* 2102 */             component.removePropertyChangeListener(arrayOfPropertyChangeListener[b]); 
/*      */         } 
/* 2106 */       } else if (str.equals("SYCP_COMPONENT_LISTENERS")) {
/* 2108 */         ComponentListener[] arrayOfComponentListener = component.getComponentListeners();
/* 2109 */         for (byte b = 0; b < arrayOfComponentListener.length; b++) {
/* 2111 */           if (arrayOfComponentListener[b].getClass().getName().contains("synthetica"))
/* 2112 */             component.removeComponentListener(arrayOfComponentListener[b]); 
/*      */         } 
/* 2115 */       } else if (str.equals("SYCP_CONTAINER_LISTENERS")) {
/* 2117 */         ContainerListener[] arrayOfContainerListener = ((JComponent)component).getContainerListeners();
/* 2118 */         for (byte b = 0; b < arrayOfContainerListener.length; b++) {
/* 2120 */           if (arrayOfContainerListener[b].getClass().getName().contains("synthetica"))
/* 2121 */             ((JComponent)component).removeContainerListener(arrayOfContainerListener[b]); 
/*      */         } 
/* 2125 */       } else if (str.equals("SYCP_MOUSE_LISTENERS")) {
/* 2127 */         MouseListener[] arrayOfMouseListener = component.getMouseListeners();
/* 2128 */         for (byte b = 0; b < arrayOfMouseListener.length; b++) {
/* 2130 */           if (arrayOfMouseListener[b].getClass().getName().contains("synthetica"))
/* 2132 */             component.removeMouseListener(arrayOfMouseListener[b]); 
/*      */         } 
/* 2136 */       } else if (str.equals("SYCP_MOUSE_MOTION_LISTENERS")) {
/* 2138 */         MouseMotionListener[] arrayOfMouseMotionListener = component.getMouseMotionListeners();
/* 2139 */         for (byte b = 0; b < arrayOfMouseMotionListener.length; b++) {
/* 2141 */           if (arrayOfMouseMotionListener[b].getClass().getName().contains("synthetica"))
/* 2143 */             component.removeMouseMotionListener(arrayOfMouseMotionListener[b]); 
/*      */         } 
/* 2147 */       } else if (str.equals("SYCP_FOCUS_LISTENERS")) {
/* 2149 */         FocusListener[] arrayOfFocusListener = component.getFocusListeners();
/* 2150 */         for (byte b = 0; b < arrayOfFocusListener.length; b++) {
/* 2152 */           if (arrayOfFocusListener[b].getClass().getName().contains("synthetica"))
/* 2154 */             component.removeFocusListener(arrayOfFocusListener[b]); 
/*      */         } 
/* 2158 */       } else if (str.equals("SYCP_POPUPMENU_LISTENERS")) {
/* 2160 */         PopupMenuListener[] arrayOfPopupMenuListener = ((JPopupMenu)component).getPopupMenuListeners();
/* 2161 */         for (byte b = 0; b < arrayOfPopupMenuListener.length; b++) {
/* 2163 */           if (arrayOfPopupMenuListener[b].getClass().getName().contains("synthetica"))
/* 2165 */             ((JPopupMenu)component).removePopupMenuListener(arrayOfPopupMenuListener[b]); 
/*      */         } 
/* 2169 */       } else if (str.equals("SYCP_COMBOBOX_POPUPMENU_LISTENERS")) {
/* 2171 */         PopupMenuListener[] arrayOfPopupMenuListener = ((JComboBox)component).getPopupMenuListeners();
/* 2172 */         for (byte b = 0; b < arrayOfPopupMenuListener.length; b++) {
/* 2174 */           if (arrayOfPopupMenuListener[b].getClass().getName().contains("synthetica"))
/* 2176 */             ((JComboBox)component).removePopupMenuListener(arrayOfPopupMenuListener[b]); 
/*      */         } 
/* 2180 */       } else if (str.equals("SYCP_LAYOUT_MANAGER")) {
/* 2182 */         LayoutManager layoutManager = (LayoutManager)object;
/* 2183 */         ((JComponent)component).setLayout(layoutManager);
/* 2185 */       } else if (str.equals("SYCP_DESKTOP_MANAGER")) {
/* 2187 */         DesktopManager desktopManager = (DesktopManager)object;
/* 2188 */         ((JDesktopPane)component).setDesktopManager(desktopManager);
/* 2190 */       } else if (str.equals("SYCP_TITLEDBORDER_TITLEPOSITION")) {
/* 2192 */         int i = ((Integer)object).intValue();
/* 2193 */         TitledBorder titledBorder = StyleFactory.this.getTitledBorder(((JComponent)component).getBorder());
/* 2194 */         if (titledBorder != null)
/* 2195 */           titledBorder.setTitlePosition(i); 
/* 2197 */       } else if (str.equals("SYCP_COMBOBOX_DEFAULT_RENDERER")) {
/* 2199 */         ListCellRenderer listCellRenderer = (ListCellRenderer)object;
/* 2200 */         ((JComboBox)component).setRenderer(listCellRenderer);
/* 2202 */       } else if (str.equals("SYCP_COMBOBOX_DEFAULT_LAYOUT")) {
/* 2204 */         LayoutManager layoutManager = (LayoutManager)object;
/* 2205 */         ((JComboBox)component).setLayout(layoutManager);
/* 2207 */       } else if (str.equals("SYCP_SPINNER_DEFAULT_LAYOUT")) {
/* 2209 */         LayoutManager layoutManager = (LayoutManager)object;
/* 2210 */         ((JSpinner)component).setLayout(layoutManager);
/* 2212 */       } else if (str.equals("SYCP_TABLE_OBJECT_DEFAULT_RENDERER")) {
/* 2214 */         TableCellRenderer tableCellRenderer = (TableCellRenderer)object;
/* 2215 */         ((JTable)component).setDefaultRenderer(Object.class, tableCellRenderer);
/* 2217 */       } else if (str.equals("SYCP_TABLE_BOOLEAN_DEFAULT_RENDERER")) {
/* 2219 */         TableCellRenderer tableCellRenderer = (TableCellRenderer)object;
/* 2220 */         ((JTable)component).setDefaultRenderer(Boolean.class, tableCellRenderer);
/* 2222 */       } else if (str.equals("SYCP_TABLE_OBJECT_DEFAULT_EDITOR")) {
/* 2224 */         TableCellEditor tableCellEditor = (TableCellEditor)object;
/* 2225 */         ((JTable)component).setDefaultEditor(Object.class, tableCellEditor);
/* 2227 */       } else if (str.equals("SYCP_TABLE_NUMBER_DEFAULT_EDITOR")) {
/* 2229 */         TableCellEditor tableCellEditor = (TableCellEditor)object;
/* 2230 */         ((JTable)component).setDefaultEditor(Number.class, tableCellEditor);
/* 2232 */       } else if (str.equals("SYCP_TABLE_COLUMN_MARGIN")) {
/* 2234 */         int i = ((Integer)object).intValue();
/* 2235 */         ((JTable)component).getColumnModel().setColumnMargin(i);
/* 2237 */       } else if (str.equals("SYCP_TABLE_ROW_MARGIN")) {
/* 2239 */         int i = ((Integer)object).intValue();
/* 2240 */         ((JTable)component).setRowMargin(i);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private boolean prepareMetalLAFSwitch = false;
/*      */   
/*      */   private CellRendererHoverListener cellRendererHoverListener;
/*      */   
/*      */   private static boolean menuToolTipEnabled;
/*      */   
/*      */   private static boolean menuItemToolTipEnabled;
/*      */   
/*      */   private static boolean componentPropertyStoreEnabled;
/*      */   
/*      */   private static int cleanerThreadDelay;
/*      */   
/*      */   static {
/*      */     try {
/*      */       String str = System.getProperty("synthetica.componentPropertyStoreEnabled");
/*      */       componentPropertyStoreEnabled = (str == null) ? true : Boolean.parseBoolean(str);
/*      */     } catch (AccessControlException accessControlException) {
/*      */       componentPropertyStoreEnabled = true;
/*      */     } 
/*      */     try {
/*      */       String str = System.getProperty("synthetica.cleanerThreadDelay");
/*      */       cleanerThreadDelay = (str == null) ? 30000 : Integer.parseInt(str);
/*      */     } catch (AccessControlException accessControlException) {
/*      */       cleanerThreadDelay = 30000;
/*      */     } 
/*      */   }
/*      */   
/*      */   public StyleFactory(SynthStyleFactory paramSynthStyleFactory) {
/*      */     this.synthStyleFactory = paramSynthStyleFactory;
/*      */     this.componentPropertyStore = new ComponentPropertyStore();
/*      */   }
/*      */   
/*      */   void uninitialize() {
/*      */     this.componentPropertyStore.enabled = false;
/*      */     restoreAllComponentProperties();
/*      */     this.componentPropertyStore.stop();
/*      */   }
/*      */   
/*      */   public ComponentPropertyStore getComponentPropertyStore() {
/*      */     return this.componentPropertyStore;
/*      */   }
/*      */   
/*      */   public SynthStyle getStyle(JComponent paramJComponent, Region paramRegion) {
/*      */     String str = SyntheticaLookAndFeel.getStyleName(paramJComponent);
/*      */     installStyleUpdater(paramJComponent);
/*      */     SynthStyle synthStyle = null;
/*      */     if (str != null && (paramRegion.equals(Region.TABBED_PANE_CONTENT) || paramRegion.equals(Region.TABBED_PANE_TAB) || paramRegion.equals(Region.TABBED_PANE_TAB_AREA) || paramRegion.equals(Region.INTERNAL_FRAME_TITLE_PANE))) {
/*      */       PropertyChangeListener[] arrayOfPropertyChangeListener1 = paramJComponent.getPropertyChangeListeners();
/*      */       byte b;
/*      */       int i;
/*      */       PropertyChangeListener[] arrayOfPropertyChangeListener2;
/*      */       for (i = (arrayOfPropertyChangeListener2 = arrayOfPropertyChangeListener1).length, b = 0; b < i; ) {
/*      */         PropertyChangeListener propertyChangeListener = arrayOfPropertyChangeListener2[b];
/*      */         paramJComponent.removePropertyChangeListener(propertyChangeListener);
/*      */         b++;
/*      */       } 
/*      */       paramJComponent.setName(String.valueOf(paramRegion.getName()) + "." + str);
/*      */       if (paramJComponent.getClientProperty("Synthetica.style") != null)
/*      */         paramJComponent.putClientProperty("Synthetica.style", String.valueOf(paramRegion.getName()) + "." + str); 
/*      */       synthStyle = getStyle(paramJComponent, paramRegion, getSynthStyle(paramJComponent, paramRegion), true);
/*      */       paramJComponent.setName(str);
/*      */       if (paramJComponent.getClientProperty("Synthetica.style") != null)
/*      */         paramJComponent.putClientProperty("Synthetica.style", str); 
/*      */       for (i = (arrayOfPropertyChangeListener2 = arrayOfPropertyChangeListener1).length, b = 0; b < i; ) {
/*      */         PropertyChangeListener propertyChangeListener = arrayOfPropertyChangeListener2[b];
/*      */         paramJComponent.addPropertyChangeListener(propertyChangeListener);
/*      */         b++;
/*      */       } 
/*      */     } else {
/*      */       synthStyle = getStyle(paramJComponent, paramRegion, getSynthStyle(paramJComponent, paramRegion), false);
/*      */     } 
/*      */     return synthStyle;
/*      */   }
/*      */   
/*      */   private void installStyleUpdater(JComponent paramJComponent) {
/*      */     if (isSyntheticaStyleNameSupportEnabled())
/*      */       if (JavaVersion.JAVA6 && !eventListenerExists(this.styleUpdater, (EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(this.styleUpdater);
/*      */       }  
/*      */   }
/*      */   
/*      */   private SynthStyle getSynthStyle(JComponent paramJComponent, Region paramRegion) {
/*      */     if (isSyntheticaStyleNameSupportEnabled()) {
/*      */       if (this.syntheticaStyleFactory == null)
/*      */         this.syntheticaStyleFactory = new SyntheticaStyleFactory(this.synthStyleFactory); 
/*      */       return this.syntheticaStyleFactory.getStyle(paramJComponent, paramRegion);
/*      */     } 
/*      */     return this.synthStyleFactory.getStyle(paramJComponent, paramRegion);
/*      */   }
/*      */   
/*      */   boolean isSyntheticaStyleNameSupportEnabled() {
/*      */     if (this.styleNameSupportEnabled == null) {
/*      */       this.styleNameSupportEnabled = Boolean.valueOf(false);
/*      */       if (JavaVersion.JAVA6U10_OR_ABOVE && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN) {
/*      */         this.styleNameSupportEnabled = Boolean.valueOf(SyntheticaLookAndFeel.getBoolean("Synthetica.styleNameSupportEnabled", null, true));
/*      */         if (JavaVersion.JAVA6)
/*      */           this.styleUpdater = new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if ("Synthetica.style".equals(param1PropertyChangeEvent.getPropertyName())) {
/*      */                   JComponent jComponent = (JComponent)param1PropertyChangeEvent.getSource();
/*      */                   jComponent.putClientProperty("Nimbus.Overrides", param1PropertyChangeEvent.getNewValue());
/*      */                 } 
/*      */               }
/*      */             }; 
/*      */       } 
/*      */     } 
/*      */     return this.styleNameSupportEnabled.booleanValue();
/*      */   }
/*      */   
/*      */   private SynthStyle getStyle(JComponent paramJComponent, Region paramRegion, SynthStyle paramSynthStyle, boolean paramBoolean) {
/*      */     String str = paramJComponent.getName();
/*      */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */       if (SyntheticaLookAndFeel.getFont() != null) {
/*      */         int i = (SyntheticaLookAndFeel.getBoolean("Synthetica.font.disabled", paramJComponent) ? 0 : 1) & SyntheticaLookAndFeel.getBoolean("Synthetica.font.enabled", paramJComponent, true);
/*      */         if (i != 0) {
/*      */           Font font1 = ((DefaultSynthStyle)paramSynthStyle).getStateInfo(0).getFont();
/*      */           Font font2 = SyntheticaLookAndFeel.getFont();
/*      */           font2 = new FontUIResource(font2.deriveFont((font1 == null) ? 0 : font1.getStyle()));
/*      */           ((DefaultSynthStyle)paramSynthStyle).getStateInfo(0).setFont(font2);
/*      */           if (paramJComponent.getBorder() instanceof TitledBorder)
/*      */             ((TitledBorder)paramJComponent.getBorder()).setTitleFont(font2); 
/*      */         } 
/*      */       } else if (SyntheticaLookAndFeel.getFont() == null) {
/*      */         Font font = ((DefaultSynthStyle)paramSynthStyle).getStateInfo(0).getFont();
/*      */         if (font == null) {
/*      */           font = new FontUIResource("Tahoma", 0, 11);
/*      */         } else {
/*      */           font = font.deriveFont(0);
/*      */         } 
/*      */         String str1 = UIManager.getString("Synthetica.font.resource");
/*      */         if (str1 != null)
/*      */           try {
/*      */             float f = font.getSize();
/*      */             font = Font.createFont(0, getClass().getResourceAsStream(str1));
/*      */             font = font.deriveFont(f);
/*      */           } catch (Exception exception) {
/*      */             throw new RuntimeException(exception);
/*      */           }  
/*      */         SyntheticaLookAndFeel.setFont(font, true);
/*      */       }  
/*      */     if (str != null && (str.startsWith("ComboBox.arrowButton") || str.startsWith("ComboBox.textField")) && SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */       paramJComponent.addMouseListener(new MouseAdapter() {
/*      */             public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */               Component component = (Component)param1MouseEvent.getSource();
/*      */               JComponent jComponent = (JComponent)component.getParent();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */               jComponent.dispatchEvent(param1MouseEvent);
/*      */             }
/*      */             
/*      */             public void mouseExited(MouseEvent param1MouseEvent) {
/*      */               Component component = (Component)param1MouseEvent.getSource();
/*      */               JComponent jComponent = (JComponent)component.getParent();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */               jComponent.dispatchEvent(param1MouseEvent);
/*      */             }
/*      */             
/*      */             public void mousePressed(MouseEvent param1MouseEvent) {
/*      */               Component component = (Component)param1MouseEvent.getSource();
/*      */               JComponent jComponent = (JComponent)component.getParent();
/*      */               if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", jComponent))
/*      */                 jComponent.repaint(); 
/*      */             }
/*      */             
/*      */             public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */               Component component = (Component)param1MouseEvent.getSource();
/*      */               JComponent jComponent = (JComponent)component.getParent();
/*      */               if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", jComponent))
/*      */                 jComponent.repaint(); 
/*      */             }
/*      */           });
/*      */     } 
/*      */     if (str != null && (str.startsWith("Spinner.nextButton") || str.startsWith("Spinner.previousButton") || str.startsWith("Spinner.formattedTextField")) && SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */       paramJComponent.addMouseListener(new MouseAdapter() {
/*      */             public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */               JSpinner jSpinner = getSpinner(param1MouseEvent);
/*      */               jSpinner.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */               jSpinner.dispatchEvent(param1MouseEvent);
/*      */             }
/*      */             
/*      */             public void mouseExited(MouseEvent param1MouseEvent) {
/*      */               JSpinner jSpinner = getSpinner(param1MouseEvent);
/*      */               jSpinner.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */               jSpinner.dispatchEvent(param1MouseEvent);
/*      */             }
/*      */             
/*      */             public void mousePressed(MouseEvent param1MouseEvent) {}
/*      */             
/*      */             public void mouseReleased(MouseEvent param1MouseEvent) {}
/*      */             
/*      */             private JSpinner getSpinner(MouseEvent param1MouseEvent) {
/*      */               Component component = (Component)param1MouseEvent.getSource();
/*      */               String str = component.getName();
/*      */               if (str != null && str.startsWith("Spinner.formattedTextField"))
/*      */                 return (JSpinner)component.getParent().getParent(); 
/*      */               return (JSpinner)component.getParent();
/*      */             }
/*      */           });
/*      */     } 
/*      */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.html.disable", paramJComponent, false) && paramJComponent.getClientProperty("html.disable") == null)
/*      */       paramJComponent.putClientProperty("html.disable", Boolean.TRUE); 
/*      */     if (paramRegion == Region.ARROW_BUTTON) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       if (paramJComponent.getClass().getName().endsWith("SynthScrollableTabButton")) {
/*      */         Dimension dimension = SyntheticaLookAndFeel.getDim("Synthetica.tabbedPane.arrowButton.size", paramJComponent);
/*      */         if (dimension != null)
/*      */           paramJComponent.setPreferredSize(dimension); 
/*      */       } 
/*      */       if (str != null && str.startsWith("Spinner.")) {
/*      */         int i = SyntheticaLookAndFeel.getInt("Synthetica.spinner.arrowButton.width", paramJComponent);
/*      */         if (i > 0 && paramJComponent.getPreferredSize() != null)
/*      */           paramJComponent.setPreferredSize(new Dimension(i, (paramJComponent.getPreferredSize()).height)); 
/*      */       } else if (str != null && str.startsWith("ScrollBar.button") && SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.hoverOnButtons.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 JButton jButton = (JButton)param1MouseEvent.getSource();
/*      */                 jButton.getParent().repaint();
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 JButton jButton = (JButton)param1MouseEvent.getSource();
/*      */                 jButton.getParent().repaint();
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.BUTTON) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_BUTTON_HALIGN");
/*      */       int i = SyntheticaLookAndFeel.getInt("Synthetica.button.horizontalAlignment", paramJComponent, -1);
/*      */       if (i >= 0)
/*      */         ((AbstractButton)paramJComponent).setHorizontalAlignment(i); 
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_BUTTON_VALIGN");
/*      */       int j = SyntheticaLookAndFeel.getInt("Synthetica.button.verticalAlignment", paramJComponent, -1);
/*      */       if (j >= 0)
/*      */         ((AbstractButton)paramJComponent).setVerticalAlignment(j); 
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_BUTTON_MARGIN");
/*      */       if (paramJComponent.getParent() instanceof JToolBar) {
/*      */         paramSynthStyle = ToolBarButtonStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       } else if (!SyntheticaLookAndFeel.getBoolean("Synthetica.button.useSynthStyle", paramJComponent, true)) {
/*      */         paramSynthStyle = ButtonStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       } 
/*      */       LookAndFeel.installProperty(paramJComponent, "iconTextGap", Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.button.iconTextGap", paramJComponent, 4)));
/*      */       if (str != null && str.startsWith("InternalFrameTitlePane.") && OS.getCurrentOS() == OS.Mac)
/*      */         paramJComponent.putClientProperty("Synthetica.popupType", Integer.valueOf(2)); 
/*      */     } else if (paramRegion == Region.INTERNAL_FRAME_TITLE_PANE) {
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners()) && !paramBoolean) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if ("ancestor".equals(param1PropertyChangeEvent.getPropertyName())) {
/*      */                   final JComponent c = (JComponent)param1PropertyChangeEvent.getSource();
/*      */                   if (JavaVersion.JAVA5 && jComponent instanceof BasicInternalFrameTitlePane) {
/*      */                     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrameTitlePane.java5LayoutManager.enabled", jComponent, true);
/*      */                     BasicInternalFrameTitlePane basicInternalFrameTitlePane = (BasicInternalFrameTitlePane)jComponent;
/*      */                     if (!(basicInternalFrameTitlePane.getLayout() instanceof SyntheticaInternalFrameTitlePaneLayout5) && bool)
/*      */                       basicInternalFrameTitlePane.setLayout(new SyntheticaInternalFrameTitlePaneLayout5(basicInternalFrameTitlePane)); 
/*      */                   } 
/*      */                   Component[] arrayOfComponent = jComponent.getComponents();
/*      */                   for (byte b = 0; b < arrayOfComponent.length; b++) {
/*      */                     Component component = arrayOfComponent[b];
/*      */                     if (component instanceof JButton) {
/*      */                       final String name = SyntheticaLookAndFeel.getStyleName(component);
/*      */                       boolean bool = true;
/*      */                       MouseListener[] arrayOfMouseListener = component.getMouseListeners();
/*      */                       for (byte b1 = 0; b1 < arrayOfMouseListener.length; b1++) {
/*      */                         if (arrayOfMouseListener[b1].getClass().getName().contains("synthetica")) {
/*      */                           bool = false;
/*      */                           break;
/*      */                         } 
/*      */                       } 
/*      */                       if (bool) {
/*      */                         StyleFactory.this.componentPropertyStore.storeComponentProperty(component, "SYCP_MOUSE_LISTENERS");
/*      */                         component.addMouseListener(new MouseAdapter() {
/*      */                               public void mouseEntered(MouseEvent param2MouseEvent) {
/*      */                                 c.putClientProperty("Synthetica.MOUSE_OVER", name);
/*      */                               }
/*      */                               
/*      */                               public void mouseExited(MouseEvent param2MouseEvent) {
/*      */                                 c.putClientProperty("Synthetica.MOUSE_OVER", (Object)null);
/*      */                               }
/*      */                               
/*      */                               public void mousePressed(MouseEvent param2MouseEvent) {
/*      */                                 c.putClientProperty("Synthetica.MOUSE_PRESSED", name);
/*      */                               }
/*      */                               
/*      */                               public void mouseReleased(final MouseEvent evt) {
/*      */                                 c.putClientProperty("Synthetica.MOUSE_PRESSED", (Object)null);
/*      */                                 if (c.getClientProperty("Synthetica.MOUSE_OVER") == null)
/*      */                                   return; 
/*      */                                 (new Thread() {
/*      */                                     public void run() {
/*      */                                       try {
/*      */                                         sleep(100L);
/*      */                                       } catch (InterruptedException interruptedException) {}
/*      */                                       EventQueue.invokeLater(new Runnable() {
/*      */                                             public void run() {
/*      */                                               JButton jButton = (JButton)evt.getSource();
/*      */                                               jButton.dispatchEvent(new MouseEvent(jButton, 505, evt.getWhen(), evt.getModifiers(), evt.getX(), evt.getY(), evt.getClickCount(), evt.isPopupTrigger()));
/*      */                                             }
/*      */                                           });
/*      */                                     }
/*      */                                   }).start();
/*      */                               }
/*      */                             });
/*      */                       } 
/*      */                     } 
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.CHECK_BOX) {
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         final JCheckBox cb = (JCheckBox)paramJComponent;
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 cb.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 cb.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */               }
/*      */             });
/*      */       } 
/*      */       LookAndFeel.installProperty(paramJComponent, "iconTextGap", Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.checkBox.iconTextGap", paramJComponent, 4)));
/*      */       paramSynthStyle = CheckBoxStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.COMBO_BOX) {
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         final JComboBox combo = (JComboBox)paramJComponent;
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 combo.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */                 combo.repaint();
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 combo.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */                 combo.repaint();
/*      */               }
/*      */               
/*      */               public void mousePressed(MouseEvent param1MouseEvent) {
/*      */                 combo.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(true));
/*      */                 combo.repaint();
/*      */               }
/*      */               
/*      */               public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */                 combo.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(false));
/*      */                 combo.repaint();
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.comboBox.openedStateSupport.enabled", paramJComponent) && !eventListenerExists((EventListener[])((JComboBox)paramJComponent).getPopupMenuListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_COMBOBOX_POPUPMENU_LISTENERS");
/*      */         final JComboBox combo = (JComboBox)paramJComponent;
/*      */         jComboBox.addPopupMenuListener(new PopupMenuListener() {
/*      */               public void popupMenuWillBecomeVisible(PopupMenuEvent param1PopupMenuEvent) {
/*      */                 combo.repaint();
/*      */               }
/*      */               
/*      */               public void popupMenuWillBecomeInvisible(PopupMenuEvent param1PopupMenuEvent) {
/*      */                 combo.repaint();
/*      */               }
/*      */               
/*      */               public void popupMenuCanceled(PopupMenuEvent param1PopupMenuEvent) {}
/*      */             });
/*      */       } 
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 JComboBox jComboBox = (JComboBox)param1PropertyChangeEvent.getSource();
/*      */                 String str = param1PropertyChangeEvent.getPropertyName();
/*      */                 if ("renderer".equals(str) || "name".equals(str)) {
/*      */                   String str1 = (String)SyntheticaLookAndFeel.get("Synthetica.comboBox.defaultRenderer.className", jComboBox);
/*      */                   if (StyleFactory.this.replaceDefaultComboRenderer(jComboBox.getRenderer(), str1)) {
/*      */                     StyleFactory.this.componentPropertyStore.storeComponentProperty(jComboBox, "SYCP_COMBOBOX_DEFAULT_RENDERER");
/*      */                     try {
/*      */                       jComboBox.setRenderer((DefaultListCellRenderer)Class.forName(str1).newInstance());
/*      */                     } catch (Exception exception) {
/*      */                       throw new RuntimeException(exception);
/*      */                     } 
/*      */                   } 
/*      */                 } else if ("UI".equals(str)) {
/*      */                   String str1 = SyntheticaLookAndFeel.getString("Synthetica.comboBox.layoutManager.className", jComboBox);
/*      */                   if (str1 != null) {
/*      */                     StyleFactory.this.componentPropertyStore.storeComponentProperty(jComboBox, "SYCP_COMBOBOX_DEFAULT_LAYOUT");
/*      */                     try {
/*      */                       jComboBox.setLayout((LayoutManager)Class.forName(str1).newInstance());
/*      */                     } catch (Exception exception) {
/*      */                       throw new RuntimeException(exception);
/*      */                     } 
/*      */                   } 
/*      */                 } else if ("editable".equals(str)) {
/*      */                   jComboBox.repaint();
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       paramSynthStyle = ComboBoxStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.EDITOR_PANE) {
/*      */       installFocusListener(paramJComponent);
/*      */       installTextComponentPropertyChangeListener(paramJComponent);
/*      */       paramSynthStyle = EditorPaneStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.editorPane.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.FORMATTED_TEXT_FIELD) {
/*      */       installFocusListener(paramJComponent);
/*      */       paramSynthStyle = FormattedTextFieldStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.formattedTextField.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.INTERNAL_FRAME) {
/*      */       SynthContext synthContext = new SynthContext(paramJComponent, Region.INTERNAL_FRAME, paramSynthStyle, 1);
/*      */       if (!paramSynthStyle.isOpaque(synthContext))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.internalFrame.opaque", paramJComponent) != null)
/*      */         setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.internalFrame.opaque", paramJComponent, true)); 
/*      */       if (JavaVersion.JAVA5 && !eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getPropertyName().equals("frameIcon")) {
/*      */                   JInternalFrame jInternalFrame = (JInternalFrame)param1PropertyChangeEvent.getSource();
/*      */                   if (SyntheticaLookAndFeel.findComponent("InternalFrame.northPane", jInternalFrame) != null)
/*      */                     ((JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.menuButton", jInternalFrame)).setIcon(jInternalFrame.getFrameIcon()); 
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.DESKTOP_ICON) {
/*      */       if (JavaVersion.JAVA5 && !eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getPropertyName().equals("ancestor")) {
/*      */                   JInternalFrame.JDesktopIcon jDesktopIcon = (JInternalFrame.JDesktopIcon)param1PropertyChangeEvent.getSource();
/*      */                   ((JButton)SyntheticaLookAndFeel.findComponent("InternalFrameTitlePane.menuButton", jDesktopIcon)).setIcon(jDesktopIcon.getInternalFrame().getFrameIcon());
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       Dimension dimension = SyntheticaLookAndFeel.getDim("Synthetica.internalFrame.desktopIcon.size", paramJComponent, null);
/*      */       if (dimension != null)
/*      */         paramJComponent.setPreferredSize(dimension); 
/*      */     } else if (paramRegion == Region.DESKTOP_PANE) {
/*      */       String str1 = SyntheticaLookAndFeel.getString("Synthetica.desktopPane.desktopManager.className", paramJComponent);
/*      */       if (str1 != null) {
/*      */         JDesktopPane jDesktopPane = (JDesktopPane)paramJComponent;
/*      */         this.componentPropertyStore.storeComponentProperty(jDesktopPane, "SYCP_DESKTOP_MANAGER");
/*      */         try {
/*      */           jDesktopPane.setDesktopManager((DesktopManager)Class.forName(str1).newInstance());
/*      */         } catch (Exception exception) {
/*      */           throw new RuntimeException(exception);
/*      */         } 
/*      */       } 
/*      */     } else if (paramRegion == Region.LABEL) {
/*      */       paramSynthStyle = LabelStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.LIST) {
/*      */       installFocusListener(paramJComponent);
/*      */       paramSynthStyle = ListStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.list.opaque", paramJComponent) != null)
/*      */         setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.list.opaque", paramJComponent, true)); 
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getSource() instanceof JList) {
/*      */                   JList jList = (JList)param1PropertyChangeEvent.getSource();
/*      */                   ListCellRenderer listCellRenderer = jList.getCellRenderer();
/*      */                   String str = SyntheticaLookAndFeel.getString("Synthetica.list.defaultCellRenderer.className", jList);
/*      */                   if (str != null && listCellRenderer != null && listCellRenderer.getClass().getName().startsWith("javax.swing.plaf.synth.SynthListUI"))
/*      */                     try {
/*      */                       ListCellRenderer listCellRenderer1 = (ListCellRenderer)Class.forName(str).newInstance();
/*      */                       jList.setCellRenderer(listCellRenderer1);
/*      */                     } catch (Exception exception) {
/*      */                       throw new RuntimeException(exception);
/*      */                     }  
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.hoverSupport.enabled", paramJComponent, false) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners()))
/*      */         installCellRendererHoverListener(paramJComponent); 
/*      */       if (OS.getCurrentOS() == OS.Mac && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners()) && SyntheticaLookAndFeel.getBoolean("Synthetica.metaKeySupportOnMacEnabled", paramJComponent, true) && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */         installMetaKeySupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.PASSWORD_FIELD) {
/*      */       installFocusListener(paramJComponent);
/*      */       paramSynthStyle = PasswordFieldStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.passwordField.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.ROOT_PANE) {
/*      */       Color color1 = UIManager.getColor("control");
/*      */       Color color2 = paramJComponent.getBackground();
/*      */       if (color2 instanceof java.awt.SystemColor && !color2.equals(color1) && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.replaceSystemColor", paramJComponent))
/*      */         paramJComponent.setBackground(color1); 
/*      */     } else if (paramRegion == Region.SPINNER) {
/*      */       paramSynthStyle = SpinnerStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       String str1 = SyntheticaLookAndFeel.getString("Synthetica.spinner.layoutManager.className", paramJComponent);
/*      */       LayoutManager layoutManager = paramJComponent.getLayout();
/*      */       if (str1 != null && layoutManager instanceof javax.swing.plaf.UIResource && !layoutManager.getClass().getName().equals(str1)) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_SPINNER_DEFAULT_LAYOUT");
/*      */         try {
/*      */           paramJComponent.setLayout((LayoutManager)Class.forName(str1).newInstance());
/*      */         } catch (Exception exception) {
/*      */           throw new RuntimeException(exception);
/*      */         } 
/*      */       } 
/*      */       if (JavaVersion.JAVA5 && !eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if ("ToolTipText".equals(param1PropertyChangeEvent.getPropertyName()))
/*      */                   StyleFactory.this.updateToolTipTextForChildren((JComponent)param1PropertyChangeEvent.getSource()); 
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.spinner.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         final JSpinner spinner = (JSpinner)paramJComponent;
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 spinner.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */                 spinner.repaint();
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 spinner.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */                 spinner.repaint();
/*      */               }
/*      */               
/*      */               public void mousePressed(MouseEvent param1MouseEvent) {
/*      */                 spinner.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(true));
/*      */                 spinner.repaint();
/*      */               }
/*      */               
/*      */               public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */                 spinner.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(false));
/*      */                 spinner.repaint();
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         final JComponent c_ = paramJComponent;
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getPropertyName().equals("model"))
/*      */                   EventQueue.invokeLater(new Runnable() {
/*      */                         public void run() {
/*      */                           c_.updateUI();
/*      */                         }
/*      */                       }); 
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.SCROLL_BAR) {
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.scrollBarTrack.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 JScrollBar jScrollBar = (JScrollBar)param1MouseEvent.getSource();
/*      */                 Boolean bool = (Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_OVER");
/*      */                 jScrollBar.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */                 if (bool == null || !bool.booleanValue())
/*      */                   jScrollBar.repaint(); 
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 boolean bool = ((param1MouseEvent.getModifiersEx() & 0x400) == 1024) ? true : false;
/*      */                 if (!bool) {
/*      */                   JScrollBar jScrollBar = (JScrollBar)param1MouseEvent.getSource();
/*      */                   Boolean bool1 = (Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_OVER");
/*      */                   jScrollBar.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */                   if (bool1 == null || bool1.booleanValue())
/*      */                     jScrollBar.repaint(); 
/*      */                 } 
/*      */               }
/*      */               
/*      */               public void mousePressed(MouseEvent param1MouseEvent) {
/*      */                 JScrollBar jScrollBar = (JScrollBar)param1MouseEvent.getSource();
/*      */                 Boolean bool = (Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_PRESSED");
/*      */                 jScrollBar.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(true));
/*      */                 if (bool == null || !bool.booleanValue())
/*      */                   jScrollBar.repaint(); 
/*      */               }
/*      */               
/*      */               public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */                 JScrollBar jScrollBar = (JScrollBar)param1MouseEvent.getSource();
/*      */                 Boolean bool = (Boolean)jScrollBar.getClientProperty("Synthetica.MOUSE_PRESSED");
/*      */                 jScrollBar.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(false));
/*      */                 boolean bool1 = jScrollBar.getBounds().contains(SwingUtilities.convertPoint(jScrollBar, param1MouseEvent.getPoint(), jScrollBar.getParent()));
/*      */                 if (!bool1)
/*      */                   jScrollBar.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false)); 
/*      */                 if (bool == null || bool.booleanValue())
/*      */                   jScrollBar.repaint(); 
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.SCROLL_PANE) {
/*      */       paramSynthStyle = ScrollPaneStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       JViewport jViewport = ((JScrollPane)paramJComponent).getViewport();
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent) && ((jViewport != null && jViewport.getView() instanceof javax.swing.text.JTextComponent) || SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.nonOpaque", paramJComponent)))
/*      */         setOpaque(paramJComponent, false); 
/*      */       applyTitledBorderStyle(paramJComponent);
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.cornerPainter.enabled", paramJComponent)) {
/*      */         JScrollPane jScrollPane = (JScrollPane)paramJComponent;
/*      */         installScrollPaneCorner(jScrollPane, "LOWER_RIGHT_CORNER");
/*      */         installScrollPaneCorner(jScrollPane, "LOWER_LEFT_CORNER");
/*      */         installScrollPaneCorner(jScrollPane, "UPPER_LEFT_CORNER");
/*      */         installScrollPaneCorner(jScrollPane, "UPPER_RIGHT_CORNER");
/*      */       } 
/*      */     } else if (paramRegion == Region.SLIDER && SyntheticaLookAndFeel.getBoolean("Synthetica.slider.hoverAndPressed.enabled", paramJComponent) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */       paramJComponent.addMouseListener(new MouseAdapter() {
/*      */             public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */               JComponent jComponent = (JComponent)param1MouseEvent.getSource();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */               jComponent.repaint();
/*      */             }
/*      */             
/*      */             public void mouseExited(MouseEvent param1MouseEvent) {
/*      */               JComponent jComponent = (JComponent)param1MouseEvent.getSource();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */               jComponent.repaint();
/*      */             }
/*      */             
/*      */             public void mousePressed(MouseEvent param1MouseEvent) {
/*      */               JComponent jComponent = (JComponent)param1MouseEvent.getSource();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(true));
/*      */               jComponent.repaint();
/*      */             }
/*      */             
/*      */             public void mouseReleased(MouseEvent param1MouseEvent) {
/*      */               JComponent jComponent = (JComponent)param1MouseEvent.getSource();
/*      */               jComponent.putClientProperty("Synthetica.MOUSE_PRESSED", Boolean.valueOf(false));
/*      */               jComponent.repaint();
/*      */             }
/*      */           });
/*      */     } else if (paramRegion == Region.SPLIT_PANE_DIVIDER) {
/*      */       if (SyntheticaLookAndFeel.getBoolean("Syntetica.splitPane.centerOneTouchButtons", paramJComponent)) {
/*      */         if (!eventListenerExists((EventListener[])paramJComponent.getComponentListeners())) {
/*      */           this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_COMPONENT_LISTENERS");
/*      */           paramJComponent.addComponentListener(new ComponentAdapter() {
/*      */                 public void componentResized(ComponentEvent param1ComponentEvent) {
/*      */                   if (param1ComponentEvent.getComponent() instanceof JSplitPane)
/*      */                     StyleFactory.this.updateSplitDivider((JSplitPane)param1ComponentEvent.getComponent()); 
/*      */                 }
/*      */               });
/*      */         } 
/*      */         if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */           this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */           paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */                 public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                   String str = param1PropertyChangeEvent.getPropertyName();
/*      */                   if (("orientation".equals(str) || "dividerSize".equals(str)) && param1PropertyChangeEvent.getSource() instanceof JSplitPane)
/*      */                     StyleFactory.this.updateSplitDivider((JSplitPane)param1PropertyChangeEvent.getSource()); 
/*      */                 }
/*      */               });
/*      */         } 
/*      */       } 
/*      */     } else if (paramRegion == Region.MENU) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       final JMenu menu = (JMenu)paramJComponent;
/*      */       if (!menuToolTipEnabled && paramJComponent.getToolTipText() != null)
/*      */         ToolTipManager.sharedInstance().unregisterComponent(paramJComponent); 
/*      */       MouseAdapter mouseAdapter = null;
/*      */       if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN) {
/*      */         final DefaultSynthStyle fStyle = (DefaultSynthStyle)paramSynthStyle;
/*      */         mouseAdapter = new MouseAdapter() {
/*      */             public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */               JMenu jMenu = (JMenu)param1MouseEvent.getSource();
/*      */               if (jMenu.isTopLevelMenu()) {
/*      */                 jMenu.putClientProperty("Synthetica.MOUSE_OVER", Boolean.TRUE);
/*      */                 Color color = fStyle.getColor(jMenu, Region.MENU, 512, ColorType.TEXT_FOREGROUND);
/*      */                 jMenu.setForeground(new Color(color.getRGB()));
/*      */                 jMenu.repaint();
/*      */               } 
/*      */             }
/*      */             
/*      */             public void mouseExited(MouseEvent param1MouseEvent) {
/*      */               JMenu jMenu = (JMenu)param1MouseEvent.getSource();
/*      */               if (jMenu.isTopLevelMenu()) {
/*      */                 jMenu.putClientProperty("Synthetica.MOUSE_OVER", Boolean.FALSE);
/*      */                 Color color = fStyle.getColor(jMenu, Region.MENU, 0, ColorType.TEXT_FOREGROUND);
/*      */                 jMenu.setForeground(color);
/*      */                 jMenu.repaint();
/*      */               } 
/*      */             }
/*      */           };
/*      */       } 
/*      */       if (jMenu.isEnabled() && !eventListenerExists((EventListener[])jMenu.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */           jMenu.addMouseListener(mouseAdapter); 
/*      */       } else if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         final MouseAdapter fListener = mouseAdapter;
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getPropertyName().equals("ancestor")) {
/*      */                   if (!menu.isEnabled() || !menu.isTopLevelMenu())
/*      */                     return; 
/*      */                   StyleFactory.this.componentPropertyStore.storeComponentProperty(menu, "SYCP_MOUSE_LISTENERS");
/*      */                   if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */                     menu.addMouseListener(fListener); 
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       paramSynthStyle = MenuStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.MENU_ITEM) {
/*      */       paramSynthStyle = MenuItemStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!menuItemToolTipEnabled && paramJComponent.getToolTipText() != null)
/*      */         ToolTipManager.sharedInstance().unregisterComponent(paramJComponent); 
/*      */     } else if (paramRegion == Region.RADIO_BUTTON_MENU_ITEM) {
/*      */       paramSynthStyle = MenuItemStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!menuItemToolTipEnabled && paramJComponent.getToolTipText() != null)
/*      */         ToolTipManager.sharedInstance().unregisterComponent(paramJComponent); 
/*      */     } else if (paramRegion == Region.CHECK_BOX_MENU_ITEM) {
/*      */       paramSynthStyle = MenuItemStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!menuItemToolTipEnabled && paramJComponent.getToolTipText() != null)
/*      */         ToolTipManager.sharedInstance().unregisterComponent(paramJComponent); 
/*      */     } else if (paramRegion == Region.TABLE) {
/*      */       installFocusListener(paramJComponent);
/*      */       final JTable table = (JTable)paramJComponent;
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.table.opaque", paramJComponent) != null)
/*      */         setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.table.opaque", paramJComponent, true)); 
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.table.columnMargin", jTable) != null) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_TABLE_COLUMN_MARGIN");
/*      */         int i = SyntheticaLookAndFeel.getInt("Synthetica.table.columnMargin", jTable);
/*      */         if (i != jTable.getColumnModel().getColumnMargin())
/*      */           jTable.getColumnModel().setColumnMargin(i); 
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.table.rowMargin", jTable) != null) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_TABLE_ROW_MARGIN");
/*      */         int i = SyntheticaLookAndFeel.getInt("Synthetica.table.rowMargin", jTable);
/*      */         if (i != jTable.getRowMargin())
/*      */           jTable.setRowMargin(i); 
/*      */       } 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.table.installCellRenderers", paramJComponent, true))
/*      */         installDefaultTableRenderers(jTable); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.table.installCellEditors", paramJComponent, true))
/*      */         installDefaultTableEditors(jTable); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.cellRenderer.hoverSupport.enabled", paramJComponent, false) && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners()))
/*      */         installCellRendererHoverListener(paramJComponent); 
/*      */       if (OS.getCurrentOS() == OS.Mac && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners()) && SyntheticaLookAndFeel.getBoolean("Synthetica.metaKeySupportOnMacEnabled", paramJComponent, true) && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */         installMetaKeySupport(paramJComponent); 
/*      */       if (jTable.getDefaultRenderer(Icon.class) == null)
/*      */         jTable.setDefaultRenderer(Icon.class, jTable.getDefaultRenderer(ImageIcon.class)); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.table.workaround6592461.enabled", paramJComponent, false) && !eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         final TableModelListener ml = new TableModelListener() {
/*      */             public void tableChanged(TableModelEvent param1TableModelEvent) {
/*      */               if (param1TableModelEvent.getType() == 0) {
/*      */                 RowSorter<? extends TableModel> rowSorter = table.getRowSorter();
/*      */                 if (rowSorter instanceof DefaultRowSorter && ((DefaultRowSorter)rowSorter).getSortsOnUpdates()) {
/*      */                   table.revalidate();
/*      */                   table.repaint();
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           };
/*      */         TableModel tableModel = jTable.getModel();
/*      */         if (tableModel != null)
/*      */           tableModel.addTableModelListener(tableModelListener); 
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if (param1PropertyChangeEvent.getPropertyName().equals("model")) {
/*      */                   TableModel tableModel = (TableModel)param1PropertyChangeEvent.getNewValue();
/*      */                   tableModel.addTableModelListener(ml);
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       paramSynthStyle = TableStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.TABLE_HEADER) {
/*      */       if (paramJComponent instanceof JTableHeader) {
/*      */         JTableHeader jTableHeader = (JTableHeader)paramJComponent;
/*      */         if (SyntheticaLookAndFeel.get("Synthetica.tableHeader.opaque", paramJComponent) != null)
/*      */           setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.tableHeader.opaque", paramJComponent, true)); 
/*      */         TableCellRenderer tableCellRenderer = jTableHeader.getDefaultRenderer();
/*      */         if (tableCellRenderer instanceof javax.swing.plaf.UIResource && !(tableCellRenderer instanceof SyntheticaHeaderRenderer5) && !tableCellRenderer.getClass().getName().equals("de.javasoft.plaf.synthetica.SyntheticaHeaderRenderer"))
/*      */           if (!tableCellRenderer.getClass().getName().equals("org.netbeans.modules.autoupdate.ui.SortColumnHeaderRenderer") && !SyntheticaLookAndFeel.getBoolean("Synthetica.table.useSynthHeaderRenderer", paramJComponent))
/*      */             if (JavaVersion.JAVA5) {
/*      */               jTableHeader.setDefaultRenderer(new SyntheticaHeaderRenderer5());
/*      */             } else if (SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN) {
/*      */               jTableHeader.setDefaultRenderer(new SyntheticaHeaderRenderer());
/*      */             }   
/*      */       } 
/*      */     } else if (paramRegion == Region.TABBED_PANE) {
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 if ("ancestor".equals(param1PropertyChangeEvent.getPropertyName()))
/*      */                   for (AbstractButton abstractButton : SyntheticaLookAndFeel.<AbstractButton>findComponents(AbstractButton.class, (JComponent)param1PropertyChangeEvent.getSource(), new ArrayList<AbstractButton>())) {
/*      */                     JTabbedPane jTabbedPane = (JTabbedPane)param1PropertyChangeEvent.getSource();
/*      */                     int i = jTabbedPane.getTabPlacement();
/*      */                     Dimension dimension = SyntheticaLookAndFeel.getDim("Synthetica.tabbedPane.arrowButton.size", jTabbedPane);
/*      */                     if (dimension != null)
/*      */                       abstractButton.setPreferredSize((i == 1 || i == 3) ? dimension : new Dimension(dimension.height, dimension.width)); 
/*      */                   }  
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.TABBED_PANE_TAB) {
/*      */       paramSynthStyle = TabbedPaneStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getMouseMotionListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_MOTION_LISTENERS");
/*      */         paramJComponent.addMouseMotionListener(new MouseMotionAdapter() {
/*      */               public void mouseMoved(MouseEvent param1MouseEvent) {
/*      */                 StyleFactory.this.tabHoverSupport(param1MouseEvent);
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */         paramJComponent.addMouseListener(new MouseAdapter() {
/*      */               public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                 StyleFactory.this.tabHoverSupport(param1MouseEvent);
/*      */               }
/*      */               
/*      */               public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                 JTabbedPane jTabbedPane = (JTabbedPane)param1MouseEvent.getSource();
/*      */                 Integer integer = (Integer)jTabbedPane.getClientProperty("Synthetica.MOUSE_OVER");
/*      */                 boolean bool = (integer == null) ? true : integer.intValue();
/*      */                 if (bool != -1) {
/*      */                   jTabbedPane.putClientProperty("Synthetica.MOUSE_OVER", Integer.valueOf(-1));
/*      */                   jTabbedPane.repaint();
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */       JTabbedPane jTabbedPane = (JTabbedPane)paramJComponent;
/*      */       if (!eventListenerExists((EventListener[])jTabbedPane.getContainerListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_CONTAINER_LISTENERS");
/*      */         storeContainerComponentProperties(jTabbedPane, "SYCP_OPAQUE");
/*      */         jTabbedPane.addContainerListener(new ContainerListener() {
/*      */               public void componentAdded(ContainerEvent param1ContainerEvent) {
/*      */                 StyleFactory.this.storeContainerComponentProperties(param1ContainerEvent.getContainer(), "SYCP_OPAQUE");
/*      */                 ((JTabbedPane)param1ContainerEvent.getContainer()).putClientProperty("Synthetica.childsAreTranslucent", Boolean.valueOf(false));
/*      */               }
/*      */               
/*      */               public void componentRemoved(ContainerEvent param1ContainerEvent) {}
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.TABBED_PANE_CONTENT) {
/*      */       paramSynthStyle = TabbedPaneContentStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.TEXT_AREA) {
/*      */       installFocusListener(paramJComponent);
/*      */       installTextComponentPropertyChangeListener(paramJComponent);
/*      */       paramSynthStyle = TextAreaStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.textArea.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.TEXT_FIELD) {
/*      */       installFocusListener(paramJComponent);
/*      */       paramSynthStyle = TextFieldStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.textField.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.TEXT_PANE) {
/*      */       installFocusListener(paramJComponent);
/*      */       installTextComponentPropertyChangeListener(paramJComponent);
/*      */       paramSynthStyle = TextPaneStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       if (!SyntheticaLookAndFeel.getBoolean("Synthetica.textComponents.useSwingOpaqueness", paramJComponent))
/*      */         setOpaque(paramJComponent, false); 
/*      */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.textPane.hoverSupport.enabled", paramJComponent))
/*      */         installTextComponentHoverSupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.TOGGLE_BUTTON) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_BUTTON_MARGIN");
/*      */       if (paramJComponent.getParent() != null && paramJComponent.getParent() instanceof JToolBar) {
/*      */         paramSynthStyle = ToolBarButtonStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       } else if (!SyntheticaLookAndFeel.getBoolean("Synthetica.toolgeButton.useSynthStyle", paramJComponent, true)) {
/*      */         paramSynthStyle = ToggleButtonStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       } 
/*      */       LookAndFeel.installProperty(paramJComponent, "iconTextGap", Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.toggleButton.iconTextGap", paramJComponent, 4)));
/*      */     } else if (paramRegion == Region.TOOL_BAR) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       paramSynthStyle = ToolBarStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.toolBar.opaque", paramJComponent, true));
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getContainerListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_CONTAINER_LISTENERS");
/*      */         paramJComponent.addContainerListener(new ContainerAdapter() {
/*      */               public void componentAdded(ContainerEvent param1ContainerEvent) {
/*      */                 Component component = param1ContainerEvent.getChild();
/*      */                 Font font = component.getFont();
/*      */                 if (component instanceof JButton && font instanceof javax.swing.plaf.UIResource && SyntheticaLookAndFeel.get("Synthetica.toolBar.button.font.style", component) != null) {
/*      */                   AbstractButton abstractButton = (AbstractButton)component;
/*      */                   String str = SyntheticaLookAndFeel.getStyleName(abstractButton);
/*      */                   if (abstractButton.getClientProperty("Synthetica.style") != null) {
/*      */                     abstractButton.putClientProperty("Synthetica.style", (Object)null);
/*      */                     abstractButton.putClientProperty("Synthetica.style", str);
/*      */                   } else {
/*      */                     component.setName(null);
/*      */                     component.setName(str);
/*      */                   } 
/*      */                 } else if (component instanceof javax.swing.JToggleButton && font instanceof javax.swing.plaf.UIResource && SyntheticaLookAndFeel.get("Synthetica.toolBar.toggleButton.font.style", component) != null) {
/*      */                   AbstractButton abstractButton = (AbstractButton)component;
/*      */                   String str = SyntheticaLookAndFeel.getStyleName(component);
/*      */                   if (abstractButton.getClientProperty("Synthetica.style") != null) {
/*      */                     abstractButton.putClientProperty("Synthetica.style", (Object)null);
/*      */                     abstractButton.putClientProperty("Synthetica.style", str);
/*      */                   } else {
/*      */                     component.setName(null);
/*      */                     component.setName(str);
/*      */                   } 
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion == Region.TOOL_BAR_SEPARATOR) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_TOOLBAR_SEPARATOR_SIZE");
/*      */       paramSynthStyle = ToolBarSeparatorStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.TOOL_TIP) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       paramSynthStyle = ToolTipStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */     } else if (paramRegion == Region.TREE) {
/*      */       installFocusListener(paramJComponent);
/*      */       if (SyntheticaLookAndFeel.get("Synthetica.tree.opaque", paramJComponent) != null)
/*      */         setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.tree.opaque", paramJComponent, true)); 
/*      */       if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */         paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */               public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */                 String str1 = param1PropertyChangeEvent.getPropertyName();
/*      */                 JTree jTree = (JTree)param1PropertyChangeEvent.getSource();
/*      */                 TreeCellRenderer treeCellRenderer = jTree.getCellRenderer();
/*      */                 boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.tree.defaultCellRenderer.enabled", jTree, true);
/*      */                 String str2 = SyntheticaLookAndFeel.getString("Synthetica.tree.defaultCellRenderer.className", jTree);
/*      */                 if (str2 == null)
/*      */                   str2 = SyntheticaDefaultTreeCellRenderer.class.getName(); 
/*      */                 if ((str1.equals("cellRenderer") || str1.equals("name")) && bool && treeCellRenderer != null && (treeCellRenderer.getClass().getName().startsWith("javax.swing.plaf.synth.SynthTreeUI") || treeCellRenderer instanceof SyntheticaDefaultTreeCellRenderer))
/*      */                   try {
/*      */                     if (!str2.equals(treeCellRenderer.getClass().getName())) {
/*      */                       TreeCellRenderer treeCellRenderer1 = (TreeCellRenderer)Class.forName(str2).newInstance();
/*      */                       jTree.setCellRenderer(treeCellRenderer1);
/*      */                     } 
/*      */                   } catch (Exception exception) {
/*      */                     throw new RuntimeException(exception);
/*      */                   }  
/*      */                 if (JavaVersion.JAVA5 && "componentOrientation".equals(str1) && !((ComponentOrientation)param1PropertyChangeEvent.getNewValue()).isLeftToRight())
/*      */                   ((JTree)param1PropertyChangeEvent.getSource()).updateUI(); 
/*      */               }
/*      */             });
/*      */       } 
/*      */       if (OS.getCurrentOS() == OS.Mac && !eventListenerExists((EventListener[])paramJComponent.getMouseListeners()) && SyntheticaLookAndFeel.getBoolean("Synthetica.metaKeySupportOnMacEnabled", paramJComponent, true) && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */         installMetaKeySupport(paramJComponent); 
/*      */     } else if (paramRegion == Region.PANEL) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       applyTitledBorderStyle(paramJComponent);
/*      */     } else if (paramRegion == Region.POPUP_MENU) {
/*      */       if ("ComboPopup.popup".equals(str) && UIManager.get("Synthetica.comboPopup.insets") != null && !(paramJComponent.getBorder() instanceof SyntheticaComboPopupBorder) && SyntheticaLookAndFeel.findComponent(JScrollPane.class, paramJComponent) != null) {
/*      */         paramJComponent.setBorder(new SyntheticaComboPopupBorder(null));
/*      */         JScrollPane jScrollPane = (JScrollPane)SyntheticaLookAndFeel.findComponent(JScrollPane.class, paramJComponent);
/*      */         Dimension dimension = jScrollPane.getPreferredSize();
/*      */         dimension.width -= (paramJComponent.getInsets()).left + (paramJComponent.getInsets()).right - 2;
/*      */         jScrollPane.setPreferredSize(dimension);
/*      */         jScrollPane.setMinimumSize(dimension);
/*      */         jScrollPane.setMaximumSize(dimension);
/*      */       } 
/*      */       final JComponent c_ = (JComponent)SyntheticaLookAndFeel.findComponent("ComboBox.scrollPane", paramJComponent);
/*      */       if (jComponent != null) {
/*      */         jComponent.setBorder(new EmptyBorder(0, 0, 0, 0));
/*      */         Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.comboPopup.list.insets", paramJComponent);
/*      */         JComponent jComponent1 = (JComponent)SyntheticaLookAndFeel.findComponent("ComboBox.list", paramJComponent);
/*      */         if (insets1 != null && jComponent1 != null)
/*      */           jComponent1.setBorder(new EmptyBorder(insets1)); 
/*      */       } 
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */       paramSynthStyle = PopupMenuStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.insets", paramJComponent);
/*      */       if (insets != null && !eventListenerExists((EventListener[])((JPopupMenu)paramJComponent).getPopupMenuListeners())) {
/*      */         this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_POPUPMENU_LISTENERS");
/*      */         ((JPopupMenu)paramJComponent).addPopupMenuListener(new PopupMenuListener() {
/*      */               public void popupMenuWillBecomeVisible(PopupMenuEvent param1PopupMenuEvent) {
/*      */                 JPopupMenu jPopupMenu = (JPopupMenu)param1PopupMenuEvent.getSource();
/*      */                 if (SyntheticaLookAndFeel.isToplevelPopupMenu(jPopupMenu)) {
/*      */                   StyleFactory.this.componentPropertyStore.storeComponentProperty(jPopupMenu, "SYCP_BORDER");
/*      */                   BorderUIResource borderUIResource = new BorderUIResource(new EmptyBorder(SyntheticaLookAndFeel.getInsets("Synthetica.popupMenu.toplevel.insets", jPopupMenu, false)));
/*      */                   jPopupMenu.setBorder(borderUIResource);
/*      */                 } 
/*      */               }
/*      */               
/*      */               public void popupMenuWillBecomeInvisible(PopupMenuEvent param1PopupMenuEvent) {}
/*      */               
/*      */               public void popupMenuCanceled(PopupMenuEvent param1PopupMenuEvent) {}
/*      */             });
/*      */       } 
/*      */     } else if (paramRegion != Region.POPUP_MENU_SEPARATOR) {
/*      */       if (paramRegion == Region.RADIO_BUTTON) {
/*      */         if (!eventListenerExists((EventListener[])paramJComponent.getMouseListeners())) {
/*      */           this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */           final JRadioButton rb = (JRadioButton)paramJComponent;
/*      */           paramJComponent.addMouseListener(new MouseAdapter() {
/*      */                 public void mouseEntered(MouseEvent param1MouseEvent) {
/*      */                   rb.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/*      */                 }
/*      */                 
/*      */                 public void mouseExited(MouseEvent param1MouseEvent) {
/*      */                   rb.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/*      */                 }
/*      */               });
/*      */         } 
/*      */         LookAndFeel.installProperty(paramJComponent, "iconTextGap", Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.radioButton.iconTextGap", paramJComponent, 4)));
/*      */         paramSynthStyle = RadioButtonStyle.getStyle(paramSynthStyle, paramJComponent, paramRegion);
/*      */       } else if (paramRegion == Region.VIEWPORT) {
/*      */         paramSynthStyle = ViewportStyle.getStyle(paramSynthStyle, paramJComponent, Region.VIEWPORT);
/*      */         if (SyntheticaLookAndFeel.get("Synthetica.viewport.opaque", paramJComponent) != null)
/*      */           setOpaque(paramJComponent, SyntheticaLookAndFeel.getBoolean("Synthetica.viewport.opaque", paramJComponent, true)); 
/*      */         if (!eventListenerExists((EventListener[])paramJComponent.getContainerListeners())) {
/*      */           this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_CONTAINER_LISTENERS");
/*      */           paramJComponent.addContainerListener(new ContainerAdapter() {
/*      */                 public void componentAdded(ContainerEvent param1ContainerEvent) {
/*      */                   Component component = param1ContainerEvent.getChild();
/*      */                   boolean bool = (component.getClass().getName().endsWith("JHEditorPane") && SyntheticaLookAndFeel.getBoolean("Synthetica.javaHelpEditorViewport.opaque", null, true)) ? true : false;
/*      */                   if (component instanceof javax.swing.text.JTextComponent && !bool)
/*      */                     StyleFactory.this.setOpaque((JViewport)param1ContainerEvent.getContainer(), false); 
/*      */                 }
/*      */               });
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     return paramSynthStyle;
/*      */   }
/*      */   
/*      */   private boolean replaceDefaultComboRenderer(ListCellRenderer paramListCellRenderer, String paramString) {
/*      */     String str = (paramListCellRenderer == null) ? "NULL" : paramListCellRenderer.getClass().getName();
/*      */     if (paramString != null && (paramListCellRenderer == null || paramListCellRenderer instanceof javax.swing.plaf.UIResource) && !str.equals(paramString))
/*      */       if (!str.startsWith("org.netbeans."))
/*      */         return true;  
/*      */     return false;
/*      */   }
/*      */   
/*      */   private void tabHoverSupport(MouseEvent paramMouseEvent) {
/*      */     JTabbedPane jTabbedPane = (JTabbedPane)paramMouseEvent.getSource();
/*      */     Integer integer = (Integer)jTabbedPane.getClientProperty("Synthetica.MOUSE_OVER");
/*      */     byte b1 = (integer == null) ? -1 : integer.intValue();
/*      */     byte b2 = -1;
/*      */     int i = jTabbedPane.getTabCount();
/*      */     for (byte b = 0; b < i; b++) {
/*      */       if (jTabbedPane.getBoundsAt(b).contains(paramMouseEvent.getPoint())) {
/*      */         b2 = b;
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     if (b1 != b2) {
/*      */       jTabbedPane.putClientProperty("Synthetica.MOUSE_OVER", Integer.valueOf(b2));
/*      */       if (b1 >= 0 && jTabbedPane.getTabCount() > b1)
/*      */         jTabbedPane.repaint(jTabbedPane.getBoundsAt(b1)); 
/*      */       if (b2 >= 0)
/*      */         jTabbedPane.repaint(jTabbedPane.getBoundsAt(b2)); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installScrollPaneCorner(JScrollPane paramJScrollPane, String paramString) {
/*      */     Component component = paramJScrollPane.getCorner(paramString);
/*      */     if ((component == null || component instanceof javax.swing.plaf.UIResource) && !(component instanceof SyntheticaScrollPaneCorner))
/*      */       paramJScrollPane.setCorner(paramString, new SyntheticaScrollPaneCorner.UIResource(paramString)); 
/*      */   }
/*      */   
/*      */   private void applyTitledBorderStyle(JComponent paramJComponent) {
/*      */     if (!eventListenerExists((EventListener[])paramJComponent.getPropertyChangeListeners())) {
/*      */       this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/*      */       paramJComponent.addPropertyChangeListener(new PropertyChangeListener() {
/*      */             public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */               if (!"border".equals(param1PropertyChangeEvent.getPropertyName()))
/*      */                 return; 
/*      */               JComponent jComponent = (JComponent)param1PropertyChangeEvent.getSource();
/*      */               TitledBorder titledBorder = StyleFactory.this.getTitledBorder(jComponent.getBorder());
/*      */               if (titledBorder != null && SyntheticaLookAndFeel.get("Synthetica.titledBorder.title.position", jComponent) != null)
/*      */                 StyleFactory.this.setTitledBorderTitlePosition(jComponent, titledBorder); 
/*      */             }
/*      */           });
/*      */     } 
/*      */     TitledBorder titledBorder = getTitledBorder(paramJComponent.getBorder());
/*      */     if (titledBorder != null && SyntheticaLookAndFeel.get("Synthetica.titledBorder.title.position", paramJComponent) != null)
/*      */       setTitledBorderTitlePosition(paramJComponent, titledBorder); 
/*      */   }
/*      */   
/*      */   private void setOpaque(JComponent paramJComponent, boolean paramBoolean) {
/*      */     this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_OPAQUE");
/*      */     paramJComponent.setOpaque(paramBoolean);
/*      */   }
/*      */   
/*      */   private boolean eventListenerExists(EventListener[] paramArrayOfEventListener) {
/*      */     byte b;
/*      */     int i;
/*      */     EventListener[] arrayOfEventListener;
/*      */     for (i = (arrayOfEventListener = paramArrayOfEventListener).length, b = 0; b < i; ) {
/*      */       EventListener eventListener = arrayOfEventListener[b];
/*      */       if (eventListener != this.styleUpdater && eventListener.getClass().getName().startsWith(getClass().getName()))
/*      */         return true; 
/*      */       b++;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private boolean eventListenerExists(EventListener paramEventListener, EventListener[] paramArrayOfEventListener) {
/*      */     byte b;
/*      */     int i;
/*      */     EventListener[] arrayOfEventListener;
/*      */     for (i = (arrayOfEventListener = paramArrayOfEventListener).length, b = 0; b < i; ) {
/*      */       EventListener eventListener = arrayOfEventListener[b];
/*      */       if (eventListener == paramEventListener)
/*      */         return true; 
/*      */       b++;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   private void updateToolTipTextForChildren(JComponent paramJComponent) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/*      */     for (i = (arrayOfComponent = paramJComponent.getComponents()).length, b = 0; b < i; ) {
/*      */       Component component = arrayOfComponent[b];
/*      */       ((JComponent)component).setToolTipText(paramJComponent.getToolTipText());
/*      */       if (component instanceof JComponent)
/*      */         updateToolTipTextForChildren((JComponent)component); 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   private TitledBorder getTitledBorder(Border paramBorder) {
/*      */     if (paramBorder instanceof TitledBorder)
/*      */       return (TitledBorder)paramBorder; 
/*      */     if (paramBorder instanceof CompoundBorder) {
/*      */       TitledBorder titledBorder1 = getTitledBorder(((CompoundBorder)paramBorder).getOutsideBorder());
/*      */       if (titledBorder1 != null)
/*      */         return titledBorder1; 
/*      */       TitledBorder titledBorder2 = getTitledBorder(((CompoundBorder)paramBorder).getInsideBorder());
/*      */       if (titledBorder2 != null)
/*      */         return titledBorder2; 
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   private void setTitledBorderTitlePosition(JComponent paramJComponent, TitledBorder paramTitledBorder) {
/*      */     this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_TITLEDBORDER_TITLEPOSITION");
/*      */     paramTitledBorder.setTitlePosition(SyntheticaLookAndFeel.getInt("Synthetica.titledBorder.title.position", paramJComponent));
/*      */   }
/*      */   
/*      */   private void installMetaKeySupport(JComponent paramJComponent) {
/*      */     this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/*      */     paramJComponent.addMouseListener(new MouseAdapter() {
/*      */           public void mousePressed(MouseEvent param1MouseEvent) {
/*      */             int i = JavaVersion.JAVA9_OR_ABOVE ? param1MouseEvent.getModifiersEx() : param1MouseEvent.getModifiers();
/*      */             try {
/*      */               int j = i;
/*      */               if (param1MouseEvent.isMetaDown()) {
/*      */                 if (JavaVersion.JAVA9_OR_ABOVE) {
/*      */                   j |= 0x80;
/*      */                 } else {
/*      */                   j |= 0x2;
/*      */                 } 
/*      */                 Class<?> clazz = Class.forName("java.awt.event.InputEvent");
/*      */                 Field field = clazz.getDeclaredField("modifiers");
/*      */                 field.setAccessible(true);
/*      */                 field.set(param1MouseEvent, Integer.valueOf(j));
/*      */               } 
/*      */             } catch (Exception exception) {
/*      */               throw new RuntimeException(exception);
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void storeContainerComponentProperties(Container paramContainer, String paramString) {
/*      */     if (paramContainer instanceof JComponent)
/*      */       this.componentPropertyStore.storeComponentProperty(paramContainer, paramString); 
/*      */     Component[] arrayOfComponent1 = paramContainer.getComponents();
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent2;
/*      */     for (i = (arrayOfComponent2 = arrayOfComponent1).length, b = 0; b < i; ) {
/*      */       Component component = arrayOfComponent2[b];
/*      */       if (component instanceof Container && !(component instanceof java.awt.Window) && !(component instanceof JRootPane))
/*      */         storeContainerComponentProperties((Container)component, paramString); 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   void restoreAllComponentProperties() {
/*      */     if (this.componentPropertyStore.cleanerThread != null) {
/*      */       this.componentPropertyStore.restoreAllComponentProperties();
/*      */       this.componentPropertyStore.cleanerThread.interrupt();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void prepareMetalLAFSwitch() {
/*      */     this.prepareMetalLAFSwitch = true;
/*      */   }
/*      */   
/*      */   static void reinitialize() {
/*      */     menuToolTipEnabled = UIManager.getBoolean("Synthetica.menu.toolTipEnabled");
/*      */     menuItemToolTipEnabled = UIManager.getBoolean("Synthetica.menuItem.toolTipEnabled");
/*      */   }
/*      */   
/*      */   private void setOpaqueDefault4Metal(JComponent paramJComponent) {
/* 2252 */     if (paramJComponent instanceof javax.swing.JLabel || paramJComponent instanceof JInternalFrame || paramJComponent instanceof JTabbedPane || 
/* 2253 */       paramJComponent instanceof javax.swing.JSeparator || paramJComponent instanceof JMenu || paramJComponent instanceof javax.swing.JSlider || (
/* 2254 */       paramJComponent instanceof JPanel && isGlassPane((JPanel)paramJComponent))) {
/* 2256 */       paramJComponent.setOpaque(false);
/*      */     } else {
/* 2259 */       if (paramJComponent instanceof JPanel)
/*      */         return; 
/* 2263 */       paramJComponent.setOpaque(true);
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isGlassPane(JPanel paramJPanel) {
/* 2269 */     if (paramJPanel.getParent() instanceof JRootPane && (
/* 2270 */       (JRootPane)paramJPanel.getParent()).getGlassPane() == paramJPanel)
/* 2271 */       return true; 
/* 2272 */     return false;
/*      */   }
/*      */   
/*      */   private void updateSplitDivider(JSplitPane paramJSplitPane) {
/* 2279 */     if (SyntheticaLookAndFeel.getJVMCompatibilityMode() != SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*      */       return; 
/* 2282 */     BasicSplitPaneUI basicSplitPaneUI = (BasicSplitPaneUI)paramJSplitPane.getUI();
/* 2283 */     BasicSplitPaneDivider basicSplitPaneDivider = basicSplitPaneUI.getDivider();
/* 2284 */     int i = DefaultLookup.getInt(paramJSplitPane, basicSplitPaneUI, "SplitPane.oneTouchButtonOffset", 2);
/*      */     try {
/* 2287 */       Class<?> clazz = Class.forName("javax.swing.plaf.basic.BasicSplitPaneDivider");
/* 2288 */       Field field = clazz.getDeclaredField("oneTouchOffset");
/* 2289 */       field.setAccessible(true);
/* 2290 */       if (basicSplitPaneDivider != null)
/* 2291 */         field.set(basicSplitPaneDivider, Integer.valueOf(i)); 
/* 2293 */     } catch (Exception exception) {
/* 2295 */       throw new RuntimeException(exception);
/*      */     } 
/* 2299 */     if (basicSplitPaneDivider != null)
/* 2300 */       basicSplitPaneDivider.getLayout().layoutContainer(basicSplitPaneDivider); 
/*      */   }
/*      */   
/*      */   private void installDefaultTableRenderers(JTable paramJTable) {
/* 2305 */     TableCellRenderer tableCellRenderer = paramJTable.getDefaultRenderer(Object.class);
/* 2307 */     String str = "Synthetica.table.defaultRenderer.className";
/* 2308 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultRenderer", paramJTable, true);
/* 2309 */     if (SyntheticaLookAndFeel.get(str, paramJTable) != null || bool)
/* 2311 */       if (tableCellRenderer == null || tableCellRenderer.getClass().getName().contains("$SynthTableCellRenderer")) {
/* 2313 */         this.componentPropertyStore.storeComponentProperty(paramJTable, "SYCP_TABLE_OBJECT_DEFAULT_RENDERER");
/* 2314 */         installDefaultTableCellRenderer(paramJTable, Object.class, str, tableCellRenderer);
/* 2315 */         tableCellRenderer = paramJTable.getDefaultRenderer(Object.class);
/*      */       }  
/* 2319 */     str = "Synthetica.table.defaultBooleanRenderer.className";
/* 2320 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultBooleanRenderer", paramJTable, true);
/* 2321 */     if (SyntheticaLookAndFeel.get(str, paramJTable) != null || bool) {
/* 2323 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Boolean.class);
/* 2324 */       if (tableCellRenderer1 == null || tableCellRenderer1.getClass().getName().contains("$SynthBooleanTableCellRenderer")) {
/* 2326 */         this.componentPropertyStore.storeComponentProperty(paramJTable, "SYCP_TABLE_BOOLEAN_DEFAULT_RENDERER");
/* 2327 */         installDefaultTableCellRenderer(paramJTable, Boolean.class, str, tableCellRenderer1);
/*      */       } 
/*      */     } 
/* 2331 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultFloatRenderer", paramJTable);
/* 2332 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultFloatRenderer.className", paramJTable) != null || bool) {
/* 2334 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Float.class);
/* 2335 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2336 */         installDefaultTableCellRenderer(paramJTable, Float.class, str, tableCellRenderer); 
/*      */     } 
/* 2339 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultDoubleRenderer", paramJTable);
/* 2340 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultDoubleRenderer.className", paramJTable) != null || bool) {
/* 2342 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Double.class);
/* 2343 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2344 */         installDefaultTableCellRenderer(paramJTable, Double.class, str, tableCellRenderer); 
/*      */     } 
/* 2347 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultNumberRenderer", paramJTable);
/* 2348 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultNumberRenderer.className", paramJTable) != null || bool) {
/* 2350 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Number.class);
/* 2351 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2352 */         installDefaultTableCellRenderer(paramJTable, Number.class, str, tableCellRenderer); 
/*      */     } 
/* 2355 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultDateRenderer", paramJTable);
/* 2356 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultDateRenderer.className", paramJTable) != null || bool) {
/* 2358 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Date.class);
/* 2359 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2360 */         installDefaultTableCellRenderer(paramJTable, Date.class, str, tableCellRenderer); 
/*      */     } 
/* 2363 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultIconRenderer", paramJTable);
/* 2364 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultIconRenderer.className", paramJTable) != null || bool) {
/* 2366 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(Icon.class);
/* 2367 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2368 */         installDefaultTableCellRenderer(paramJTable, Icon.class, str, tableCellRenderer); 
/*      */     } 
/* 2371 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultImageIconRenderer", paramJTable);
/* 2372 */     if (SyntheticaLookAndFeel.get("Synthetica.table.defaultImageIconRenderer.className", paramJTable) != null || bool) {
/* 2374 */       TableCellRenderer tableCellRenderer1 = paramJTable.getDefaultRenderer(ImageIcon.class);
/* 2375 */       if (tableCellRenderer1 == null || (tableCellRenderer1 instanceof javax.swing.plaf.UIResource && tableCellRenderer1 == tableCellRenderer))
/* 2376 */         installDefaultTableCellRenderer(paramJTable, ImageIcon.class, str, tableCellRenderer); 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installDefaultTableCellRenderer(JTable paramJTable, Class<?> paramClass, String paramString, TableCellRenderer paramTableCellRenderer) {
/*      */     try {
/* 2385 */       String str = (String)SyntheticaLookAndFeel.get(paramString, paramJTable);
/* 2386 */       if (str == null)
/* 2387 */         str = (paramClass == Boolean.class) ? SyntheticaDefaultBooleanTableCellRenderer.class.getName() : SyntheticaDefaultTableCellRenderer.class.getName(); 
/* 2388 */       TableCellRenderer tableCellRenderer = Class.forName(str).getConstructor(new Class[] { TableCellRenderer.class }).newInstance(new Object[] { paramTableCellRenderer });
/* 2389 */       paramJTable.setDefaultRenderer(paramClass, tableCellRenderer);
/* 2391 */     } catch (Exception exception) {
/* 2393 */       throw new RuntimeException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installDefaultTableEditors(JTable paramJTable) {
/* 2399 */     String str = "Synthetica.table.defaultEditor.className";
/* 2400 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultEditor", paramJTable, true);
/* 2401 */     if (SyntheticaLookAndFeel.get(str, paramJTable) != null || bool) {
/* 2403 */       TableCellEditor tableCellEditor = paramJTable.getDefaultEditor(Object.class);
/* 2404 */       if (tableCellEditor == null || tableCellEditor.getClass().getName().contains(".JTable") || tableCellEditor.getClass().getName().contains(".swingx.JXTable")) {
/* 2406 */         this.componentPropertyStore.storeComponentProperty(paramJTable, "SYCP_TABLE_OBJECT_DEFAULT_EDITOR");
/* 2407 */         installDefaultTableCellEditor(paramJTable, Object.class, str, tableCellEditor);
/*      */       } 
/*      */     } 
/* 2412 */     str = "Synthetica.table.defaultEditor.className";
/* 2413 */     bool = SyntheticaLookAndFeel.getBoolean("Synthetica.table.installDefaultNumberEditor", paramJTable, true);
/* 2414 */     if (SyntheticaLookAndFeel.get(str, paramJTable) != null || bool) {
/* 2416 */       TableCellEditor tableCellEditor = paramJTable.getDefaultEditor(Number.class);
/* 2417 */       if (tableCellEditor == null || tableCellEditor.getClass().getName().contains(".JTable") || tableCellEditor.getClass().getName().contains(".swingx.table.NumberEditorExt")) {
/* 2419 */         this.componentPropertyStore.storeComponentProperty(paramJTable, "SYCP_TABLE_NUMBER_DEFAULT_EDITOR");
/* 2420 */         installDefaultTableCellEditor(paramJTable, Number.class, str, tableCellEditor);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installDefaultTableCellEditor(JTable paramJTable, Class<?> paramClass, String paramString, TableCellEditor paramTableCellEditor) {
/*      */     try {
/* 2430 */       String str = (String)SyntheticaLookAndFeel.get(paramString, paramJTable);
/* 2431 */       if (str == null)
/* 2432 */         str = SyntheticaDefaultTableCellEditor.class.getName(); 
/* 2433 */       if (paramClass == Number.class)
/* 2434 */         str = String.valueOf(str) + "$NumberEditor"; 
/* 2435 */       paramJTable.setDefaultEditor(paramClass, (TableCellEditor)Class.forName(str).newInstance());
/* 2437 */     } catch (Exception exception) {
/* 2439 */       throw new RuntimeException(exception);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installCellRendererHoverListener(JComponent paramJComponent) {
/* 2446 */     this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_LISTENERS");
/* 2447 */     this.componentPropertyStore.storeComponentProperty(paramJComponent, "SYCP_MOUSE_MOTION_LISTENERS");
/* 2448 */     if (this.cellRendererHoverListener == null)
/* 2449 */       this.cellRendererHoverListener = new CellRendererHoverListener(null); 
/* 2450 */     paramJComponent.addMouseListener(this.cellRendererHoverListener);
/* 2451 */     paramJComponent.addMouseMotionListener(this.cellRendererHoverListener);
/*      */   }
/*      */   
/*      */   private class ComponentProperty {
/*      */     static final String OPAQUE = "SYCP_OPAQUE";
/*      */     
/*      */     static final String INSETS = "SYCP_INSETS";
/*      */     
/*      */     static final String BORDER = "SYCP_BORDER";
/*      */     
/*      */     static final String BUTTON_MARGIN = "SYCP_BUTTON_MARGIN";
/*      */     
/*      */     static final String BUTTON_HALIGN = "SYCP_BUTTON_HALIGN";
/*      */     
/*      */     static final String BUTTON_VALIGN = "SYCP_BUTTON_VALIGN";
/*      */     
/*      */     static final String TOOLBAR_SEPARATOR_SIZE = "SYCP_TOOLBAR_SEPARATOR_SIZE";
/*      */     
/*      */     static final String PROPERTY_CHANGE_LISTENERS = "SYCP_PROPERTY_CHANGE_LISTENERS";
/*      */     
/*      */     static final String COMPONENT_LISTENERS = "SYCP_COMPONENT_LISTENERS";
/*      */     
/*      */     static final String MOUSE_LISTENERS = "SYCP_MOUSE_LISTENERS";
/*      */     
/*      */     static final String MOUSE_MOTION_LISTENERS = "SYCP_MOUSE_MOTION_LISTENERS";
/*      */     
/*      */     static final String CONTAINER_LISTENERS = "SYCP_CONTAINER_LISTENERS";
/*      */     
/*      */     static final String POPUPMENU_LISTENERS = "SYCP_POPUPMENU_LISTENERS";
/*      */     
/*      */     static final String COMBOBOX_POPUPMENU_LISTENERS = "SYCP_COMBOBOX_POPUPMENU_LISTENERS";
/*      */     
/*      */     static final String TREE_CELL_RENDERER = "SYCP_TREE_CELL_RENDERER";
/*      */     
/*      */     static final String FOCUS_LISTENERS = "SYCP_FOCUS_LISTENERS";
/*      */     
/*      */     static final String LAYOUT_MANAGER = "SYCP_LAYOUT_MANAGER";
/*      */     
/*      */     static final String DESKTOP_MANAGER = "SYCP_DESKTOP_MANAGER";
/*      */     
/*      */     static final String TITLEDBORDER_TITLEPOSITION = "SYCP_TITLEDBORDER_TITLEPOSITION";
/*      */     
/*      */     static final String COMBOBOX_DEFAULT_RENDERER = "SYCP_COMBOBOX_DEFAULT_RENDERER";
/*      */     
/*      */     static final String COMBOBOX_DEFAULT_LAYOUT = "SYCP_COMBOBOX_DEFAULT_LAYOUT";
/*      */     
/*      */     static final String SPINNER_DEFAULT_LAYOUT = "SYCP_SPINNER_DEFAULT_LAYOUT";
/*      */     
/*      */     static final String TABLE_OBJECT_DEFAULT_RENDERER = "SYCP_TABLE_OBJECT_DEFAULT_RENDERER";
/*      */     
/*      */     static final String TABLE_BOOLEAN_DEFAULT_RENDERER = "SYCP_TABLE_BOOLEAN_DEFAULT_RENDERER";
/*      */     
/*      */     static final String TABLE_OBJECT_DEFAULT_EDITOR = "SYCP_TABLE_OBJECT_DEFAULT_EDITOR";
/*      */     
/*      */     static final String TABLE_NUMBER_DEFAULT_EDITOR = "SYCP_TABLE_NUMBER_DEFAULT_EDITOR";
/*      */     
/*      */     static final String TABLE_COLUMN_MARGIN = "SYCP_TABLE_COLUMN_MARGIN";
/*      */     
/*      */     static final String TABLE_ROW_MARGIN = "SYCP_TABLE_ROW_MARGIN";
/*      */     
/*      */     private WeakReference<Component> component;
/*      */     
/*      */     private String propertyName;
/*      */     
/*      */     private WeakReference<Object> value;
/*      */     
/*      */     private int componentHashCode;
/*      */     
/*      */     ComponentProperty(Component param1Component, String param1String, Object param1Object) {
/* 2495 */       this.component = new WeakReference<Component>(param1Component);
/* 2496 */       this.propertyName = param1String;
/* 2499 */       if (param1Component instanceof JComponent) {
/* 2500 */         ((JComponent)param1Component).putClientProperty(param1String, param1Object);
/*      */       } else {
/* 2502 */         this.value = new WeakReference(param1Object);
/*      */       } 
/* 2503 */       int i = 0;
/*      */       try {
/* 2507 */         i = param1Component.hashCode();
/* 2509 */       } catch (RuntimeException runtimeException) {}
/* 2512 */       this.componentHashCode = (String.valueOf(i) + param1String).hashCode();
/*      */     }
/*      */     
/*      */     public boolean equals(Object param1Object) {
/* 2518 */       return (this.componentHashCode == param1Object.hashCode());
/*      */     }
/*      */     
/*      */     public int hashCode() {
/* 2523 */       return this.componentHashCode;
/*      */     }
/*      */   }
/*      */   
/*      */   private void installFocusListener(Component paramComponent) {
/* 2535 */     if (!paramComponent.isEnabled())
/*      */       return; 
/*      */     byte b;
/*      */     int i;
/*      */     FocusListener[] arrayOfFocusListener;
/* 2536 */     for (i = (arrayOfFocusListener = paramComponent.getFocusListeners()).length, b = 0; b < i; ) {
/* 2536 */       FocusListener focusListener = arrayOfFocusListener[b];
/* 2538 */       if (focusListener instanceof RepaintFocusListener)
/*      */         return; 
/*      */       b++;
/*      */     } 
/* 2541 */     getComponentPropertyStore().storeComponentProperty(paramComponent, "SYCP_FOCUS_LISTENERS");
/* 2542 */     paramComponent.addFocusListener(new RepaintFocusListener(null));
/*      */   }
/*      */   
/*      */   private void installTextComponentHoverSupport(final JComponent tc) {
/* 2550 */     if (!eventListenerExists((EventListener[])tc.getMouseListeners())) {
/* 2552 */       this.componentPropertyStore.storeComponentProperty(tc, "SYCP_MOUSE_LISTENERS");
/* 2553 */       tc.addMouseListener(new MouseAdapter() {
/*      */             public void mouseEntered(MouseEvent param1MouseEvent) {
/* 2558 */               tc.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(true));
/* 2559 */               tc.repaint();
/*      */             }
/*      */             
/*      */             public void mouseExited(MouseEvent param1MouseEvent) {
/* 2565 */               tc.putClientProperty("Synthetica.MOUSE_OVER", Boolean.valueOf(false));
/* 2566 */               tc.repaint();
/*      */             }
/*      */           });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void installTextComponentPropertyChangeListener(Component paramComponent) {
/* 2578 */     if (!eventListenerExists((EventListener[])paramComponent.getPropertyChangeListeners())) {
/* 2580 */       this.componentPropertyStore.storeComponentProperty(paramComponent, "SYCP_PROPERTY_CHANGE_LISTENERS");
/* 2581 */       paramComponent.addPropertyChangeListener(new RepaintTextComponentPropertyChangeListener(null));
/*      */     } 
/*      */   }
/*      */   
/*      */   private static class RepaintTextComponentPropertyChangeListener implements PropertyChangeListener {
/*      */     private RepaintTextComponentPropertyChangeListener() {}
/*      */     
/*      */     public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 2595 */       JComponent jComponent = (JComponent)param1PropertyChangeEvent.getSource();
/* 2596 */       String str = param1PropertyChangeEvent.getPropertyName();
/* 2597 */       if (jComponent.getParent() != null && jComponent.getParent() instanceof JViewport && (
/* 2598 */         "enabled".equals(str) || "background".equals(str) || "Synthetica.MOUSE_OVER".equals(str)))
/* 2600 */         jComponent.getParent().getParent().repaint(); 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class RepaintFocusListener implements FocusListener {
/*      */     private RepaintFocusListener() {}
/*      */     
/*      */     public void focusGained(FocusEvent param1FocusEvent) {
/* 2615 */       repaintComponent(param1FocusEvent.getComponent());
/*      */     }
/*      */     
/*      */     public void focusLost(FocusEvent param1FocusEvent) {
/* 2620 */       repaintComponent(param1FocusEvent.getComponent());
/*      */     }
/*      */     
/*      */     private void repaintComponent(Component param1Component) {
/* 2625 */       String str = param1Component.getName();
/* 2626 */       if ("ComboBox.textField".equals(str) && param1Component.getParent() != null) {
/* 2628 */         param1Component.getParent().repaint();
/* 2630 */       } else if ("Spinner.formattedTextField".equals(str) && 
/* 2631 */         param1Component.getParent() != null && param1Component.getParent().getParent() != null) {
/* 2633 */         param1Component.getParent().getParent().repaint();
/* 2635 */       } else if (param1Component.getParent() != null && param1Component.getParent().getParent() != null && 
/* 2636 */         param1Component.getParent().getParent() instanceof JScrollPane) {
/* 2638 */         JScrollPane jScrollPane = (JScrollPane)param1Component.getParent().getParent();
/* 2639 */         jScrollPane.repaint();
/*      */       } else {
/* 2642 */         param1Component.repaint();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class SyntheticaComboPopupBorder implements Border {
/*      */     private SyntheticaComboPopupBorder() {}
/*      */     
/*      */     public Insets getBorderInsets(Component param1Component) {
/* 2655 */       return UIManager.getInsets("Synthetica.comboPopup.insets");
/*      */     }
/*      */     
/*      */     public boolean isBorderOpaque() {
/* 2660 */       return false;
/*      */     }
/*      */     
/*      */     public void paintBorder(Component param1Component, Graphics param1Graphics, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 2665 */       Color color = UIManager.getColor("Synthetica.comboPopup.border.color");
/* 2666 */       if (color != null && getBorderInsets(param1Component).equals(new Insets(1, 1, 1, 1))) {
/* 2668 */         param1Graphics.setColor(color);
/* 2669 */         param1Graphics.drawRect(param1Int1, param1Int2, param1Int3 - 1, param1Int4 - 1);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class CellRendererHoverListener extends MouseAdapter {
/*      */     private final String HOVER = "Synthetica.hoverIndex";
/*      */     
/*      */     private CellRendererHoverListener() {
/* 2683 */       this.HOVER = "Synthetica.hoverIndex";
/*      */     }
/*      */     
/*      */     public void mouseExited(MouseEvent param1MouseEvent) {
/* 2687 */       JComponent jComponent = (JComponent)param1MouseEvent.getSource();
/* 2688 */       jComponent.putClientProperty("Synthetica.hoverIndex", Integer.valueOf(-1));
/* 2689 */       jComponent.repaint();
/*      */     }
/*      */     
/*      */     public void mouseMoved(MouseEvent param1MouseEvent) {
/* 2695 */       doHover(param1MouseEvent);
/*      */     }
/*      */     
/*      */     private void doHover(MouseEvent param1MouseEvent) {
/* 2700 */       Object object = param1MouseEvent.getSource();
/* 2701 */       if (object instanceof JList) {
/* 2703 */         JList jList = (JList)param1MouseEvent.getSource();
/* 2704 */         int i = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.hoverIndex", jList, Integer.valueOf(-1))).intValue();
/* 2705 */         if (i >= 0 && i < jList.getModel().getSize()) {
/* 2707 */           Rectangle rectangle1 = jList.getCellBounds(i, i);
/* 2708 */           jList.repaint(rectangle1);
/*      */         } 
/* 2711 */         int j = jList.locationToIndex(param1MouseEvent.getPoint());
/* 2712 */         jList.putClientProperty("Synthetica.hoverIndex", Integer.valueOf(j));
/* 2713 */         Rectangle rectangle = jList.getCellBounds(j, j);
/* 2715 */         if (rectangle != null)
/* 2716 */           jList.repaint(rectangle); 
/* 2718 */       } else if (object instanceof JTable) {
/* 2720 */         JTable jTable = (JTable)param1MouseEvent.getSource();
/* 2721 */         if (jTable.getColumnCount() <= 0)
/*      */           return; 
/* 2724 */         int i = ((Integer)SyntheticaLookAndFeel.<Integer>getClientProperty("Synthetica.hoverIndex", jTable, Integer.valueOf(-1))).intValue();
/* 2725 */         if (i >= 0 && i < jTable.getRowCount()) {
/* 2727 */           Rectangle rectangle3 = jTable.getCellRect(i, 0, true);
/* 2728 */           Rectangle rectangle4 = jTable.getCellRect(i, jTable.getColumnCount() - 1, true);
/* 2729 */           if (rectangle3 != null && rectangle4 != null) {
/* 2731 */             rectangle3.width = rectangle4.x + rectangle4.width - rectangle3.x;
/* 2732 */             jTable.repaint(rectangle3);
/*      */           } 
/*      */         } 
/* 2736 */         int j = jTable.rowAtPoint(param1MouseEvent.getPoint());
/* 2737 */         jTable.putClientProperty("Synthetica.hoverIndex", Integer.valueOf(j));
/* 2738 */         Rectangle rectangle1 = jTable.getCellRect(j, 0, true);
/* 2739 */         Rectangle rectangle2 = jTable.getCellRect(j, jTable.getColumnCount() - 1, true);
/* 2740 */         if (rectangle1 != null && rectangle2 != null) {
/* 2742 */           rectangle1.width = rectangle2.x + rectangle2.width - rectangle1.x;
/* 2743 */           jTable.repaint(rectangle1);
/*      */         } 
/*      */       } else {
/* 2746 */         object instanceof JTree;
/*      */       } 
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\StyleFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */