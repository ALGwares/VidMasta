/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.MenuPainter;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthConstants;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class SyntheticaMenuUI extends BasicMenuUI implements PropertyChangeListener, SynthConstants {
/*     */   private String acceleratorDelimiter;
/*     */   
/*     */   public static ComponentUI createUI(JComponent paramJComponent) {
/*  45 */     return new SyntheticaMenuUI();
/*     */   }
/*     */   
/*     */   protected void installDefaults() {
/*  51 */     updateStyle(this.menuItem);
/*     */   }
/*     */   
/*     */   protected void installListeners() {
/*  57 */     super.installListeners();
/*  58 */     this.menuItem.addPropertyChangeListener(this);
/*     */   }
/*     */   
/*     */   private void updateStyle(JMenuItem paramJMenuItem) {
/*  63 */     String str = getPropertyPrefix();
/*  64 */     SynthContext synthContext = SyntheticaMenuItemUI.getContext(paramJMenuItem, 1);
/*  65 */     SynthStyle synthStyle = SyntheticaMenuItemUI.getStyle(paramJMenuItem);
/*  67 */     synthStyle.installDefaults(synthContext);
/*  69 */     this.defaultTextIconGap = synthStyle.getInt(synthContext, String.valueOf(str) + ".textIconGap", 4);
/*  70 */     if (this.menuItem.getMargin() == null || this.menuItem.getMargin() instanceof javax.swing.plaf.UIResource) {
/*  72 */       Insets insets = (Insets)synthStyle.get(synthContext, String.valueOf(str) + ".margin");
/*  73 */       if (insets == null)
/*  74 */         insets = new InsetsUIResource(0, 0, 0, 0); 
/*  75 */       this.menuItem.setMargin(insets);
/*     */     } 
/*  78 */     this.acceleratorDelimiter = synthStyle.getString(synthContext, String.valueOf(str) + ".acceleratorDelimiter", "+");
/*  79 */     this.arrowIcon = synthStyle.getIcon(synthContext, String.valueOf(str) + ".arrowIcon");
/*  80 */     this.checkIcon = synthStyle.getIcon(synthContext, String.valueOf(str) + ".checkIcon");
/*  81 */     ((JMenu)this.menuItem).setDelay(synthStyle.getInt(synthContext, String.valueOf(str) + ".delay", 200));
/*     */   }
/*     */   
/*     */   protected void uninstallDefaults() {
/*  87 */     super.uninstallDefaults();
/*     */   }
/*     */   
/*     */   protected void uninstallListeners() {
/*  93 */     super.uninstallListeners();
/*  94 */     this.menuItem.removePropertyChangeListener(this);
/*     */   }
/*     */   
/*     */   protected Dimension getPreferredMenuItemSize(JComponent paramJComponent, Icon paramIcon1, Icon paramIcon2, int paramInt) {
/* 100 */     SynthContext synthContext1 = SyntheticaMenuItemUI.getMenuItemContext(paramJComponent);
/* 101 */     SynthContext synthContext2 = SyntheticaMenuItemUI.getContext(paramJComponent, Region.MENU_ITEM_ACCELERATOR);
/* 102 */     return SyntheticaMenuItemUI.getPreferredMenuItemSize(synthContext1, synthContext2, isTopLevelMenu(), paramJComponent, paramIcon1, paramIcon2, paramInt, this.acceleratorDelimiter);
/*     */   }
/*     */   
/*     */   public void update(Graphics paramGraphics, JComponent paramJComponent) {
/* 109 */     SynthContext synthContext = SyntheticaMenuItemUI.getContext(paramJComponent);
/* 110 */     paintBackground(synthContext, paramGraphics, 0, 0, paramJComponent.getWidth(), paramJComponent.getHeight());
/* 111 */     paint(synthContext, paramGraphics);
/* 112 */     paintBorder(synthContext, paramGraphics, 0, 0, paramJComponent.getWidth(), paramJComponent.getHeight());
/*     */   }
/*     */   
/*     */   private void paintBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 117 */     MenuPainter.getInstance(paramSynthContext).paintMenuBackground(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   private void paintBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 122 */     MenuPainter.getInstance(paramSynthContext).paintMenuBorder(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics, JComponent paramJComponent) {
/* 128 */     paint(SyntheticaMenuItemUI.getContext(paramJComponent), paramGraphics);
/*     */   }
/*     */   
/*     */   private void paint(SynthContext paramSynthContext, Graphics paramGraphics) {
/* 133 */     SynthStyle synthStyle = paramSynthContext.getStyle();
/* 134 */     String str = getPropertyPrefix();
/* 135 */     Icon icon1 = synthStyle.getIcon(paramSynthContext, String.valueOf(str) + ".arrowIcon");
/* 136 */     Icon icon2 = synthStyle.getIcon(paramSynthContext, String.valueOf(str) + ".checkIcon");
/* 137 */     SynthContext synthContext = SyntheticaMenuItemUI.getContext(this.menuItem, Region.MENU_ITEM_ACCELERATOR);
/* 138 */     paramSynthContext = SyntheticaMenuItemUI.getMenuItemContext(paramSynthContext.getComponent());
/* 139 */     SyntheticaMenuItemUI.paint(paramSynthContext, synthContext, paramGraphics, icon2, icon1, isTopLevelMenu(), this.acceleratorDelimiter, this.defaultTextIconGap);
/*     */   }
/*     */   
/*     */   private boolean isTopLevelMenu() {
/* 144 */     return ((JMenu)this.menuItem).isTopLevelMenu();
/*     */   }
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent) {
/* 152 */     if (SyntheticaLookAndFeel.shouldUpdateStyle(paramPropertyChangeEvent))
/* 153 */       updateStyle((JMenu)paramPropertyChangeEvent.getSource()); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaMenuUI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */