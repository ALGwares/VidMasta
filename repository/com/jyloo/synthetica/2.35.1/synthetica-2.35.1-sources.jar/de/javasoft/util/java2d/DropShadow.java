/*     */ package de.javasoft.util.java2d;
/*     */ 
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.awt.image.DataBufferInt;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.ImagingOpException;
/*     */ 
/*     */ public class DropShadow {
/*     */   private boolean highQuality = true;
/*     */   
/*  31 */   private BufferedImage shadow = null;
/*     */   
/*  32 */   private BufferedImage originalImage = null;
/*     */   
/*  33 */   private float angle = 45.0F;
/*     */   
/*  34 */   private int distance = -5;
/*     */   
/*  35 */   private int shadowSize = 5;
/*     */   
/*  36 */   private float shadowOpacity = 0.8F;
/*     */   
/*  37 */   private Color shadowColor = new Color(0);
/*     */   
/*  40 */   private int distance_x = 0;
/*     */   
/*  41 */   private int distance_y = 0;
/*     */   
/*     */   protected DropShadow() {
/*  48 */     computeShadowPosition();
/*     */   }
/*     */   
/*     */   public DropShadow(BufferedImage paramBufferedImage) {
/*  56 */     this();
/*  57 */     setImage(paramBufferedImage);
/*     */   }
/*     */   
/*     */   public void setImage(BufferedImage paramBufferedImage) {
/*  65 */     this.originalImage = paramBufferedImage;
/*  66 */     refreshShadow();
/*     */   }
/*     */   
/*     */   public BufferedImage getImage() {
/*  71 */     return this.originalImage;
/*     */   }
/*     */   
/*     */   public boolean getHighQuality() {
/*  79 */     return this.highQuality;
/*     */   }
/*     */   
/*     */   public void setQuality(boolean paramBoolean) {
/*  84 */     this.highQuality = paramBoolean;
/*  85 */     refreshShadow();
/*     */   }
/*     */   
/*     */   public float getAngle() {
/*  93 */     return this.angle;
/*     */   }
/*     */   
/*     */   public void setAngle(float paramFloat) {
/*  98 */     this.angle = paramFloat;
/*  99 */     computeShadowPosition();
/*     */   }
/*     */   
/*     */   public int getDistance() {
/* 107 */     return this.distance;
/*     */   }
/*     */   
/*     */   public void setDistance(int paramInt) {
/* 112 */     this.distance = paramInt;
/* 113 */     computeShadowPosition();
/*     */   }
/*     */   
/*     */   public Color getShadowColor() {
/* 121 */     return this.shadowColor;
/*     */   }
/*     */   
/*     */   public void setShadowColor(Color paramColor) {
/* 126 */     this.shadowColor = paramColor;
/* 127 */     refreshShadow();
/*     */   }
/*     */   
/*     */   public float getShadowOpacity() {
/* 135 */     return this.shadowOpacity;
/*     */   }
/*     */   
/*     */   public void setShadowOpacity(float paramFloat) {
/* 140 */     this.shadowOpacity = paramFloat;
/* 141 */     refreshShadow();
/*     */   }
/*     */   
/*     */   public int getShadowSize() {
/* 149 */     return this.shadowSize;
/*     */   }
/*     */   
/*     */   public void setShadowSize(int paramInt) {
/* 154 */     this.shadowSize = paramInt;
/* 155 */     refreshShadow();
/*     */   }
/*     */   
/*     */   private void refreshShadow() {
/* 162 */     if (this.originalImage != null)
/* 163 */       this.shadow = createDropShadow(this.originalImage); 
/*     */   }
/*     */   
/*     */   private void computeShadowPosition() {
/* 170 */     double d = Math.toRadians(this.angle);
/* 171 */     this.distance_x = (int)(Math.cos(d) * this.distance);
/* 172 */     this.distance_y = (int)(Math.sin(d) * this.distance);
/*     */   }
/*     */   
/*     */   private BufferedImage createDropShadow(BufferedImage paramBufferedImage) {
/* 179 */     BufferedImage bufferedImage = new BufferedImage(paramBufferedImage.getWidth() + this.shadowSize * 2, paramBufferedImage.getHeight() + this.shadowSize * 2, 2);
/* 180 */     Graphics2D graphics2D = bufferedImage.createGraphics();
/* 181 */     graphics2D.drawImage(paramBufferedImage, (BufferedImageOp)null, this.shadowSize, this.shadowSize);
/* 182 */     graphics2D.dispose();
/* 184 */     if (this.highQuality) {
/* 186 */       BufferedImage bufferedImage1 = createShadowMask(bufferedImage);
/*     */       try {
/* 189 */         Synthetica2DUtils.createBlurOp(this.shadowSize).filter(bufferedImage1, bufferedImage);
/* 191 */       } catch (ImagingOpException imagingOpException) {
/* 194 */         if (!JavaVersion.JAVA7)
/* 195 */           throw new RuntimeException(imagingOpException); 
/*     */       } 
/*     */     } else {
/* 199 */       applyShadow(bufferedImage);
/*     */     } 
/* 201 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   private void applyShadow(BufferedImage paramBufferedImage) {
/* 208 */     int i = paramBufferedImage.getWidth();
/* 209 */     int j = paramBufferedImage.getHeight();
/* 211 */     int k = this.shadowSize - 1 >> 1;
/* 212 */     int m = this.shadowSize - k;
/* 213 */     int n = k;
/* 214 */     int i1 = i - m;
/* 215 */     int i2 = k;
/* 216 */     int i3 = j - m;
/* 218 */     int i4 = this.shadowColor.getRGB() & 0xFFFFFF;
/* 220 */     int[] arrayOfInt1 = new int[this.shadowSize];
/* 221 */     int i5 = 0;
/* 225 */     int[] arrayOfInt2 = ((DataBufferInt)paramBufferedImage.getRaster().getDataBuffer()).getData();
/* 226 */     int i6 = m * i;
/* 227 */     float f = this.shadowOpacity / this.shadowSize;
/*     */     byte b;
/*     */     int i7;
/* 230 */     for (b = 0, i7 = 0; b < j; i7 = ++b * i) {
/* 232 */       int i8 = 0;
/* 233 */       i5 = 0;
/*     */       int i9;
/* 234 */       for (i9 = 0; i9 < this.shadowSize; i9++, i7++) {
/* 236 */         int i10 = arrayOfInt2[i7] >>> 24;
/* 237 */         arrayOfInt1[i9] = i10;
/* 238 */         i8 += i10;
/*     */       } 
/* 241 */       i7 -= m;
/* 243 */       for (i9 = n; i9 < i1; i9++, i7++) {
/* 245 */         int i10 = (int)(i8 * f);
/* 246 */         arrayOfInt2[i7] = i10 << 24 | i4;
/* 249 */         i8 -= arrayOfInt1[i5];
/* 252 */         i10 = arrayOfInt2[i7 + m] >>> 24;
/* 253 */         arrayOfInt1[i5] = i10;
/* 254 */         i8 += i10;
/* 256 */         if (++i5 >= this.shadowSize)
/* 257 */           i5 -= this.shadowSize; 
/*     */       } 
/*     */     } 
/* 262 */     for (b = 0, i7 = 0; b < i; i7 = ++b) {
/* 264 */       int i8 = 0;
/* 265 */       i5 = 0;
/*     */       int i9;
/* 266 */       for (i9 = 0; i9 < this.shadowSize; i9++, i7 += i) {
/* 268 */         int i10 = arrayOfInt2[i7] >>> 24;
/* 269 */         arrayOfInt1[i9] = i10;
/* 270 */         i8 += i10;
/*     */       } 
/* 273 */       i7 -= i6;
/* 275 */       for (i9 = i2; i9 < i3; i9++, i7 += i) {
/* 277 */         int i10 = (int)(i8 * f);
/* 278 */         arrayOfInt2[i7] = i10 << 24 | i4;
/* 281 */         i8 -= arrayOfInt1[i5];
/* 284 */         i10 = arrayOfInt2[i7 + i6] >>> 24;
/* 285 */         arrayOfInt1[i5] = i10;
/* 286 */         i8 += i10;
/* 288 */         if (++i5 >= this.shadowSize)
/* 289 */           i5 -= this.shadowSize; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private BufferedImage createShadowMask(BufferedImage paramBufferedImage) {
/* 298 */     BufferedImage bufferedImage = new BufferedImage(paramBufferedImage.getWidth(), paramBufferedImage.getHeight(), 2);
/* 300 */     Graphics2D graphics2D = bufferedImage.createGraphics();
/* 301 */     graphics2D.drawImage(paramBufferedImage, 0, 0, (ImageObserver)null);
/* 302 */     graphics2D.setComposite(AlphaComposite.getInstance(5, this.shadowOpacity));
/* 303 */     graphics2D.setColor(this.shadowColor);
/* 304 */     graphics2D.fillRect(0, 0, paramBufferedImage.getWidth(), paramBufferedImage.getHeight());
/* 305 */     graphics2D.dispose();
/* 307 */     return bufferedImage;
/*     */   }
/*     */   
/*     */   public void paintShadow(Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 315 */     if (this.shadow != null)
/* 316 */       paramGraphics.drawImage(this.shadow, paramInt1 + this.distance_x, paramInt2 + this.distance_y, null); 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 324 */     paint(paramGraphics, paramInt1, paramInt2, true);
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 332 */     if (paramBoolean)
/* 333 */       paintShadow(paramGraphics, paramInt1, paramInt2); 
/* 334 */     if (this.originalImage != null)
/* 335 */       paramGraphics.drawImage(this.originalImage, paramInt1, paramInt2, null); 
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasof\\util\java2d\DropShadow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */