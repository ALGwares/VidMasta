/*    */ package de.javasoft.plaf.synthetica.styles;
/*    */ 
/*    */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JViewport;
/*    */ import javax.swing.plaf.synth.ColorType;
/*    */ import javax.swing.plaf.synth.Region;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthStyle;
/*    */ 
/*    */ public class ViewportStyle extends StyleWrapper {
/* 34 */   private static ViewportStyle instance = new ViewportStyle();
/*    */   
/*    */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/* 42 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/* 44 */       instance.setStyle(paramSynthStyle);
/* 45 */       return instance;
/*    */     } 
/* 47 */     ViewportStyle viewportStyle = new ViewportStyle();
/* 48 */     viewportStyle.setStyle(paramSynthStyle);
/* 49 */     return viewportStyle;
/*    */   }
/*    */   
/*    */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/* 55 */     if (paramColorType == ColorType.BACKGROUND) {
/* 57 */       JViewport jViewport = (JViewport)paramSynthContext.getComponent();
/* 58 */       Component component = jViewport.getView();
/* 60 */       if (component != null && component.getClass().getName().endsWith("JHEditorPane") && SyntheticaLookAndFeel.get("Synthetica.javaHelpEditorViewport.background", jViewport) != null)
/* 61 */         return SyntheticaLookAndFeel.getColor("Synthetica.javaHelpEditorViewport.background", jViewport); 
/* 63 */       boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.viewport.dynamicBackgroundColorEnabled", jViewport);
/* 64 */       if (component != null && component instanceof JComponent && ((JComponent)component).isOpaque() && bool)
/* 65 */         return component.getBackground(); 
/*    */     } 
/* 67 */     return super.getColor(paramSynthContext, paramColorType);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ViewportStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */