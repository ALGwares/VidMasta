/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Component;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.Popup;
/*     */ import javax.swing.PopupFactory;
/*     */ 
/*     */ public class PopupFactory extends PopupFactory {
/*  25 */   private static PopupFactory popupFactory = new PopupFactory();
/*     */   
/*     */   private static PopupFactory storedPopupFactory;
/*     */   
/*     */   public static void install() {
/*  41 */     if (storedPopupFactory == null) {
/*  44 */       storedPopupFactory = getSharedInstance();
/*  45 */       setSharedInstance(popupFactory);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void uninstall() {
/*  54 */     if (storedPopupFactory == null)
/*     */       return; 
/*  58 */     setSharedInstance(storedPopupFactory);
/*  59 */     storedPopupFactory = null;
/*     */   }
/*     */   
/*     */   public Popup getPopup(Component paramComponent1, Component paramComponent2, int paramInt1, int paramInt2) {
/*  73 */     if (paramComponent1 instanceof JComponent) {
/*  75 */       JComponent jComponent = (JComponent)paramComponent1;
/*  76 */       Integer integer = (Integer)jComponent.getClientProperty("Synthetica.popupType");
/*  77 */       if (integer == null)
/*  78 */         integer = (SyntheticaLookAndFeel.get("Synthetica.popupType", jComponent) == null) ? null : Integer.valueOf(SyntheticaLookAndFeel.getInt("Synthetica.popupType", jComponent)); 
/*  81 */       if (integer == null && OS.getCurrentOS() == OS.Mac && SyntheticaLookAndFeel.getBoolean("Synthetica.forceHeavyWeightPopupOnOSX.enabled", null, true) && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*     */         try {
/*  86 */           Method method = PopupFactory.class.getDeclaredMethod("getPopupType", null);
/*  87 */           method.setAccessible(true);
/*  88 */           if (((Integer)method.invoke(this, new Object[0])).intValue() == 1)
/*  89 */             integer = Integer.valueOf(2); 
/*  91 */         } catch (Exception exception) {} 
/*  97 */       if (integer != null && SyntheticaLookAndFeel.getJVMCompatibilityMode() == SyntheticaLookAndFeel.JVMCompatibilityMode.SUN)
/*     */         try {
/* 101 */           Method method = PopupFactory.class.getDeclaredMethod("setPopupType", new Class[] { int.class });
/* 102 */           method.setAccessible(true);
/* 103 */           method.invoke(this, new Object[] { integer });
/* 105 */         } catch (Exception exception) {} 
/*     */     } 
/* 111 */     Popup popup = super.getPopup(paramComponent1, paramComponent2, paramInt1, paramInt2);
/* 112 */     return new Popup(paramComponent1, paramComponent2, paramInt1, paramInt2, popup);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\PopupFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */