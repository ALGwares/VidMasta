/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Window;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ 
/*     */ public class OptionPanePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.OptionPanePainter";
/*     */   
/*     */   public static OptionPanePainter getInstance() {
/*  59 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static OptionPanePainter getInstance(SynthContext paramSynthContext) {
/*  68 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, OptionPanePainter.class, "Synthetica.OptionPanePainter"));
/*  69 */     if (syntheticaComponentPainter == null)
/*  70 */       syntheticaComponentPainter = getInstance(paramSynthContext, OptionPanePainter.class, "Synthetica.OptionPanePainter"); 
/*  71 */     return (OptionPanePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintOptionPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintOptionPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  83 */     paintPanelBackground(paramSynthContext.getComponent(), new SyntheticaState(), paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintPanelBackground(JComponent paramJComponent, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  88 */     Color color = paramJComponent.getBackground();
/*  89 */     if (paramJComponent.isOpaque() || SyntheticaLookAndFeel.getBoolean("Synthetica.optionPane.background.opaque", paramJComponent, false)) {
/*  91 */       String str1 = SyntheticaLookAndFeel.getString("Synthetica.optionPane.inactive.background.image", paramJComponent);
/*  92 */       boolean bool1 = false;
/*  93 */       if (str1 != null) {
/*  95 */         Window window = SwingUtilities.getWindowAncestor(paramJComponent);
/*  96 */         bool1 = (window != null && !window.isActive()) ? true : false;
/*     */       } 
/*  98 */       String str2 = bool1 ? str1 : SyntheticaLookAndFeel.getString("Synthetica.optionPane.background.image", paramJComponent);
/*  99 */       boolean bool2 = (SyntheticaLookAndFeel.getBoolean("Synthetica.optionPane.background.image.enabled", paramJComponent, true) && !(paramJComponent.getParent() instanceof javax.swing.CellRendererPane)) ? true : false;
/* 100 */       if ((!bool2 || str2 == null) && color != null && !(color instanceof javax.swing.plaf.ColorUIResource)) {
/* 102 */         paramGraphics.setColor(color);
/* 103 */         paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 105 */       } else if (bool2 && str2 != null && (color == null || (color != null && color instanceof javax.swing.plaf.ColorUIResource))) {
/* 107 */         boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica.optionPane.background.horizontalTiled", paramJComponent, false) ? true : false;
/* 108 */         boolean bool4 = SyntheticaLookAndFeel.getBoolean("Synthetica.optionPane.background.verticalTiled", paramJComponent, false) ? true : false;
/* 109 */         Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.optionPane.background.image.insets", paramJComponent, false);
/* 110 */         Insets insets2 = insets1;
/* 111 */         String str = SyntheticaLookAndFeel.getString("Synthetica.optionPane.background.image.origin", paramJComponent);
/* 112 */         if (str != null && str.equals("PANEL")) {
/* 114 */           ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets1, insets2, bool3, bool4);
/* 115 */           imagePainter.draw();
/*     */         } else {
/* 119 */           Container container = (str != null && str.equals("CONTENT_PANE")) ? paramJComponent.getRootPane().getContentPane() : paramJComponent.getRootPane();
/* 120 */           if (container == null)
/*     */             return; 
/* 122 */           Rectangle rectangle1 = container.getBounds();
/* 123 */           rectangle1.width = Math.max(rectangle1.width, SyntheticaLookAndFeel.getInt("Synthetica.optionPane.minimumBackgroundWidth", paramJComponent, rectangle1.width));
/* 124 */           rectangle1.height = Math.max(rectangle1.height, SyntheticaLookAndFeel.getInt("Synthetica.optionPane.minimumBackgroundHeight", paramJComponent, rectangle1.height));
/* 126 */           Rectangle rectangle2 = SwingUtilities.convertRectangle(paramJComponent, new Rectangle(paramInt1, paramInt2, paramInt3, paramInt4), container);
/* 127 */           ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1 - rectangle2.x, paramInt2 - rectangle2.y, rectangle1.width, rectangle1.height, str2, insets1, insets2, bool3, bool4);
/* 128 */           imagePainter.draw();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 137 */     return Cacheable.ScaleType.NINE_SQUARE;
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 143 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\OptionPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */