/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ public class ScrollPanePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.ScrollPanePainter";
/*     */   
/*     */   public static ScrollPanePainter getInstance() {
/*  70 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static ScrollPanePainter getInstance(SynthContext paramSynthContext) {
/*  79 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ScrollPanePainter.class, "Synthetica.ScrollPanePainter"));
/*  80 */     if (syntheticaComponentPainter == null)
/*  81 */       syntheticaComponentPainter = getInstance(paramSynthContext, ScrollPanePainter.class, "Synthetica.ScrollPanePainter"); 
/*  82 */     return (ScrollPanePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintScrollPaneBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  90 */     JScrollPane jScrollPane = (JScrollPane)paramSynthContext.getComponent();
/*  91 */     if (jScrollPane.getViewport() == null || jScrollPane.getViewport().getView() == null || !SyntheticaLookAndFeel.isOpaque(jScrollPane))
/*     */       return; 
/*  94 */     Component component = jScrollPane.getViewport().getView();
/*  95 */     Border border1 = jScrollPane.getBorder();
/*  96 */     Border border2 = SyntheticaLookAndFeel.findDefaultBorder(border1);
/*  97 */     boolean bool1 = (border2 == null) ? false : border2.getClass().getName().equals("javax.swing.plaf.synth.SynthBorder");
/*  98 */     boolean bool2 = component instanceof JTextComponent;
/* 117 */     if (bool2 && !SyntheticaLookAndFeel.isOpaque((JTextComponent)component))
/*     */       return; 
/* 120 */     if (!bool2 && !bool1) {
/* 122 */       if (component.isOpaque())
/* 123 */         fillBackground(jScrollPane, border1, border2, bool1, component, paramGraphics, component.getBackground(), paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */       return;
/*     */     } 
/* 127 */     boolean bool3 = (border1 instanceof CompoundBorder && ((CompoundBorder)border1).getInsideBorder() == border2) ? true : false;
/* 128 */     if (bool3) {
/* 130 */       Insets insets4 = border1.getBorderInsets(jScrollPane);
/* 131 */       Insets insets5 = border2.getBorderInsets(jScrollPane);
/* 132 */       paramInt1 += insets4.left - insets5.left;
/* 133 */       paramInt2 += insets4.top - insets5.top;
/* 134 */       paramInt3 -= insets4.left - insets5.left + insets4.right - insets5.right;
/* 135 */       paramInt4 -= insets4.top - insets5.top + insets4.bottom - insets5.bottom;
/*     */     } 
/* 138 */     if (!bool2) {
/* 140 */       Color color1 = jScrollPane.getBackground();
/* 141 */       if (color1 instanceof javax.swing.plaf.UIResource)
/* 142 */         color1 = component.getBackground(); 
/* 144 */       Color color2 = paramGraphics.getColor();
/* 146 */       if (color2 == null || (color2 != null && !color2.equals(color1))) {
/* 148 */         boolean bool10 = ((component instanceof javax.swing.JTable && !SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.table.fillBackground", component, true)) || (
/* 149 */           component instanceof javax.swing.JList && !SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.list.fillBackground", component, true)) || (
/* 150 */           component instanceof javax.swing.JTree && !SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.tree.fillBackground", component, true)) || (
/* 151 */           component instanceof javax.swing.JPanel && !SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.panel.fillBackground", component, true))) ? false : true;
/* 154 */         if (bool1) {
/* 156 */           if (bool10)
/* 157 */             fillBackground(jScrollPane, border1, border2, bool1, component, paramGraphics, color1, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */         } else {
/* 162 */           if (bool10)
/* 163 */             fillBackground(jScrollPane, (Border)null, border2, bool1, component, paramGraphics, color1, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */           return;
/*     */         } 
/*     */       } 
/* 168 */       String str = null;
/* 169 */       if (component.isEnabled()) {
/* 170 */         str = SyntheticaLookAndFeel.getString("Synthetica.scrollPane.border", jScrollPane);
/*     */       } else {
/* 172 */         str = SyntheticaLookAndFeel.getString("Synthetica.scrollPane.border.disabled", jScrollPane);
/*     */       } 
/* 176 */       Insets insets4 = SyntheticaLookAndFeel.getInsets("Synthetica.scrollPane.border.insets", jScrollPane);
/* 177 */       Insets insets5 = insets4;
/* 178 */       ImagePainter imagePainter1 = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets4, insets5, 0, 0);
/* 179 */       imagePainter1.drawBorder();
/*     */       return;
/*     */     } 
/* 185 */     JTextComponent jTextComponent = (JTextComponent)component;
/* 186 */     Color color = jTextComponent.getBackground();
/* 187 */     boolean bool4 = (color != null && !(color instanceof javax.swing.plaf.ColorUIResource)) ? false : true;
/* 188 */     boolean bool5 = SyntheticaLookAndFeel.getBoolean("Synthetica.scrollPane.keepLockedBorderIfColored", jTextComponent);
/* 189 */     boolean bool6 = jTextComponent.isEnabled();
/* 190 */     boolean bool7 = jTextComponent.isEditable() ? false : true;
/* 192 */     String str1 = "textField";
/* 193 */     if (jTextComponent instanceof javax.swing.JTextArea) {
/* 194 */       str1 = "textArea";
/* 195 */     } else if (jTextComponent instanceof javax.swing.JEditorPane) {
/* 196 */       str1 = "editorPane";
/* 197 */     } else if (jTextComponent instanceof javax.swing.JTextPane) {
/* 198 */       str1 = "textPane";
/*     */     } 
/* 200 */     int i = bool7 ? SyntheticaState.State.LOCKED.toInt() : 0;
/* 201 */     i |= !bool6 ? SyntheticaState.State.DISABLED.toInt() : 0;
/* 203 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext, i, false);
/* 206 */     if (!bool4 && !bool5)
/* 207 */       syntheticaPainterState.resetState(SyntheticaState.State.LOCKED); 
/* 209 */     UIKey uIKey = new UIKey(String.valueOf(str1) + ".border", syntheticaPainterState);
/* 211 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get(uIKey.get("fillBackground"), jTextComponent);
/* 212 */     if (bool == null || bool.booleanValue())
/* 213 */       fillBackground(jScrollPane, border1, border2, bool1, jTextComponent, paramGraphics, color, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 216 */     boolean bool8 = (SyntheticaLookAndFeel.get(uIKey.get(), jTextComponent) != null) ? true : false;
/* 217 */     if (bool7 && !bool8) {
/* 219 */       syntheticaPainterState.resetState(SyntheticaState.State.LOCKED);
/* 220 */       uIKey = new UIKey(String.valueOf(str1) + ".border", syntheticaPainterState);
/*     */     } 
/* 224 */     bool8 = (SyntheticaLookAndFeel.get(uIKey.get(), jTextComponent) != null) ? true : false;
/* 225 */     if (!bool8)
/* 226 */       uIKey = new UIKey("scrollPane.border", syntheticaPainterState); 
/* 232 */     boolean bool9 = SyntheticaLookAndFeel.getBoolean(uIKey.get("solid"), jTextComponent);
/* 233 */     String str2 = SyntheticaLookAndFeel.getString(uIKey.get(), jTextComponent);
/* 237 */     Insets insets1 = SyntheticaLookAndFeel.getInsets(uIKey.get("insets"), jTextComponent);
/* 239 */     Insets insets2 = (insets1 == null) ? SyntheticaLookAndFeel.getInsets("Synthetica.scrollPane.border.insets", jTextComponent) : insets1;
/* 240 */     Insets insets3 = insets2;
/* 242 */     if (!bool1) {
/* 244 */       Insets insets = jScrollPane.getInsets();
/* 245 */       paramInt1 += insets.left;
/* 246 */       paramInt2 += insets.top;
/* 247 */       paramInt3 += -insets.left - insets.right;
/* 248 */       paramInt4 += -insets.top - insets.bottom;
/* 249 */       insets3 = new Insets(0, 0, 0, 0);
/*     */     } 
/* 253 */     ImagePainter imagePainter = new ImagePainter(jTextComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str2, insets2, insets3, 0, 0);
/* 254 */     if (bool9) {
/* 255 */       imagePainter.draw();
/*     */     } else {
/* 257 */       imagePainter.drawBorder();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintScrollPaneBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 274 */     JComponent jComponent = paramSynthContext.getComponent();
/* 275 */     if (!(jComponent instanceof JScrollPane))
/*     */       return; 
/* 277 */     JScrollPane jScrollPane = (JScrollPane)jComponent;
/* 279 */     if (jScrollPane.getViewport() == null || jScrollPane.getViewport().getView() == null)
/*     */       return; 
/* 281 */     Component component = jScrollPane.getViewport().getView();
/* 283 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.focus.textComponents.enabled", component, true);
/* 284 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica.focus.scrollPane.enabled", component, true);
/* 285 */     if (component.hasFocus() && ((
/* 286 */       !(component instanceof JTextComponent) && bool2) || (
/* 287 */       component instanceof JTextComponent && bool1)))
/* 289 */       FocusPainter.paintFocus("focus.scrollPane", paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   private void fillBackground(JScrollPane paramJScrollPane, Border paramBorder1, Border paramBorder2, boolean paramBoolean, Component paramComponent, Graphics paramGraphics, Color paramColor, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 299 */     if (paramColor instanceof javax.swing.plaf.ColorUIResource && paramComponent instanceof JTextComponent) {
/* 301 */       JTextComponent jTextComponent = (JTextComponent)paramComponent;
/* 302 */       if (jTextComponent.isEnabled() && ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.MOUSE_OVER", jTextComponent, Boolean.valueOf(false))).booleanValue()) {
/* 304 */         Region region = (jTextComponent instanceof javax.swing.JTextArea) ? Region.TEXT_AREA : ((jTextComponent instanceof javax.swing.JTextPane) ? Region.TEXT_PANE : Region.EDITOR_PANE);
/* 305 */         SynthStyle synthStyle = SynthLookAndFeel.getStyle(jTextComponent, region);
/* 306 */         SynthContext synthContext = new SynthContext(jTextComponent, region, synthStyle, 2);
/* 307 */         paramColor = synthContext.getStyle().getColor(synthContext, ColorType.BACKGROUND);
/* 309 */       } else if (!jTextComponent.isEditable() || !jTextComponent.isEnabled()) {
/* 311 */         if (!jTextComponent.isEditable()) {
/* 313 */           Color color1 = null;
/* 314 */           if (jTextComponent instanceof javax.swing.JTextArea) {
/* 315 */             color1 = SyntheticaLookAndFeel.getColor("Synthetica.textArea.lockedColor", jTextComponent);
/* 316 */           } else if (jTextComponent instanceof javax.swing.JTextPane) {
/* 317 */             color1 = SyntheticaLookAndFeel.getColor("Synthetica.textPane.lockedColor", jTextComponent);
/* 318 */           } else if (jTextComponent instanceof javax.swing.JEditorPane) {
/* 319 */             color1 = SyntheticaLookAndFeel.getColor("Synthetica.editorPane.lockedColor", jTextComponent);
/*     */           } 
/* 321 */           if (color1 == null && !jTextComponent.isEnabled())
/* 322 */             color1 = getDisabledBackgroundColor(jTextComponent); 
/* 324 */           if (color1 != null)
/* 325 */             paramColor = color1; 
/* 327 */         } else if (!jTextComponent.isEnabled()) {
/* 328 */           paramColor = getDisabledBackgroundColor(jTextComponent);
/*     */         } 
/*     */       } 
/*     */     } 
/* 331 */     Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 332 */     Color color = graphics2D.getColor();
/* 333 */     graphics2D.setColor(paramColor);
/* 334 */     Insets insets = paramJScrollPane.getInsets();
/* 336 */     if (paramBorder1 == null || insets.equals(new Insets(0, 0, 0, 0))) {
/* 337 */       graphics2D.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 338 */     } else if (!paramBoolean) {
/* 339 */       paramGraphics.fillRect(paramInt1 + insets.left, paramInt2 + insets.top, paramInt3 - insets.left - insets.right, paramInt4 - insets.top - insets.bottom);
/*     */     } else {
/* 342 */       RenderingHints renderingHints = graphics2D.getRenderingHints();
/* 343 */       graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 344 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.scrollPane.border.fillInsets", paramJScrollPane, false);
/* 345 */       int i = SyntheticaLookAndFeel.getInt("Synthetica.scrollPane.border.arcWidth", paramJScrollPane, 8);
/* 346 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.scrollPane.border.arcHeight", paramJScrollPane, 8);
/* 347 */       graphics2D.fillRoundRect(paramInt1 + insets1.left, paramInt2 + insets1.top, paramInt3 - insets1.left - insets1.right, paramInt4 - insets1.top - insets1.bottom, i, j);
/* 348 */       graphics2D.setRenderingHints(renderingHints);
/*     */     } 
/* 351 */     graphics2D.setColor(color);
/*     */   }
/*     */   
/*     */   private Color getDisabledBackgroundColor(JTextComponent paramJTextComponent) {
/* 356 */     Color color = null;
/* 357 */     if (paramJTextComponent instanceof javax.swing.JTextArea) {
/* 358 */       color = SyntheticaLookAndFeel.getColor("Synthetica.textArea.disabledColor", paramJTextComponent);
/* 359 */     } else if (paramJTextComponent instanceof javax.swing.JTextPane) {
/* 360 */       color = SyntheticaLookAndFeel.getColor("Synthetica.textPane.disabledColor", paramJTextComponent);
/* 361 */     } else if (paramJTextComponent instanceof javax.swing.JEditorPane) {
/* 362 */       color = SyntheticaLookAndFeel.getColor("Synthetica.editorPane.disabledColor", paramJTextComponent);
/*     */     } 
/* 363 */     return color;
/*     */   }
/*     */   
/*     */   public void paintScrollPaneCorner(JScrollPane paramJScrollPane, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) {}
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 373 */     return Cacheable.ScaleType.NINE_SQUARE;
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 379 */     JScrollPane jScrollPane = (JScrollPane)paramSynthContext.getComponent();
/* 380 */     JComponent jComponent = (JComponent)jScrollPane.getViewport().getView();
/* 382 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 384 */     if (jComponent != null) {
/* 386 */       boolean bool1 = jComponent.isEnabled();
/* 387 */       boolean bool2 = jComponent.hasFocus();
/* 388 */       boolean bool = (jComponent instanceof JTextComponent) ? (((JTextComponent)jComponent).isEditable() ? false : true) : false;
/* 390 */       Color color = jComponent.getBackground();
/* 391 */       Boolean bool3 = (Boolean)jComponent.getClientProperty("Synthetica.opaque");
/* 393 */       i = 31 * i + jComponent.getClass().hashCode();
/* 394 */       i = (color == null) ? i : (31 * i + color.getRGB());
/* 395 */       i = (bool3 == null) ? i : (31 * i + (bool3.booleanValue() ? 0 : 1));
/* 396 */       i = 31 * i + (bool1 ? 0 : 1);
/* 397 */       i = 31 * i + (bool2 ? 0 : 1);
/* 398 */       i = 31 * i + (bool ? 0 : 1);
/*     */     } 
/* 400 */     return i;
/*     */   }
/*     */   
/*     */   public Insets getCacheScaleInsets(SynthContext paramSynthContext, String paramString) {
/* 406 */     if (paramString.equals("paintScrollPaneBorder")) {
/* 408 */       Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.scrollPane.border.insets", paramSynthContext.getComponent());
/* 409 */       if (insets != null)
/* 410 */         return insets; 
/*     */     } 
/* 412 */     return super.getCacheScaleInsets(paramSynthContext, paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ScrollPanePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */