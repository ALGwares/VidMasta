package de.javasoft.io;

import java.util.EventListener;

public interface FileOperationListener extends EventListener {
  boolean processFileOperationEvent(FileOperationEvent paramFileOperationEvent);
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\io\FileOperationListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */