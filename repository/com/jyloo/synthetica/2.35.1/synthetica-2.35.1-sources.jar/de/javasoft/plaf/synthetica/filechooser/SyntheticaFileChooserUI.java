/*      */ package de.javasoft.plaf.synthetica.filechooser;
/*      */ 
/*      */ import de.javasoft.io.FileProperties;
/*      */ import de.javasoft.io.FileUtils;
/*      */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*      */ import de.javasoft.util.JavaVersion;
/*      */ import de.javasoft.util.OS;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Cursor;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.ContainerListener;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.FilteredImageSource;
/*      */ import java.awt.image.RGBImageFilter;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.security.AccessControlException;
/*      */ import java.text.Collator;
/*      */ import java.text.DateFormat;
/*      */ import java.text.MessageFormat;
/*      */ import java.text.NumberFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.EventObject;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.prefs.Preferences;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.AbstractListModel;
/*      */ import javax.swing.Box;
/*      */ import javax.swing.ButtonGroup;
/*      */ import javax.swing.ComboBoxModel;
/*      */ import javax.swing.DefaultCellEditor;
/*      */ import javax.swing.DefaultListCellRenderer;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRadioButtonMenuItem;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.JToggleButton;
/*      */ import javax.swing.JTree;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.ListCellRenderer;
/*      */ import javax.swing.ListModel;
/*      */ import javax.swing.ListSelectionModel;
/*      */ import javax.swing.Spring;
/*      */ import javax.swing.SpringLayout;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.CompoundBorder;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.event.CellEditorListener;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import javax.swing.event.ListDataEvent;
/*      */ import javax.swing.event.ListDataListener;
/*      */ import javax.swing.event.ListSelectionEvent;
/*      */ import javax.swing.event.ListSelectionListener;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.event.TreeSelectionEvent;
/*      */ import javax.swing.event.TreeSelectionListener;
/*      */ import javax.swing.filechooser.FileFilter;
/*      */ import javax.swing.filechooser.FileSystemView;
/*      */ import javax.swing.plaf.ComponentUI;
/*      */ import javax.swing.plaf.basic.BasicDirectoryModel;
/*      */ import javax.swing.plaf.basic.BasicFileChooserUI;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*      */ import javax.swing.plaf.synth.SynthStyle;
/*      */ import javax.swing.table.AbstractTableModel;
/*      */ import javax.swing.table.DefaultTableCellRenderer;
/*      */ import javax.swing.table.JTableHeader;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import javax.swing.table.TableColumn;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import javax.swing.text.Position;
/*      */ import javax.swing.tree.DefaultMutableTreeNode;
/*      */ import javax.swing.tree.DefaultTreeCellEditor;
/*      */ import javax.swing.tree.DefaultTreeCellRenderer;
/*      */ import javax.swing.tree.DefaultTreeModel;
/*      */ import javax.swing.tree.TreeNode;
/*      */ import javax.swing.tree.TreePath;
/*      */ import sun.awt.shell.ShellFolder;
/*      */ import sun.swing.plaf.synth.DefaultSynthStyle;
/*      */ 
/*      */ public class SyntheticaFileChooserUI extends BasicFileChooserUI implements ActionListener {
/*      */   private static final int LIST_VIEW = 0;
/*      */   
/*      */   private static final int TABLE_VIEW = 1;
/*      */   
/*      */   private static final int TREE_VIEW = 2;
/*      */   
/*      */   private JButton newFolderButton;
/*      */   
/*      */   private JButton upFolderButton;
/*      */   
/*      */   private JComboBox directoryComboBox;
/*      */   
/*      */   private JLabel lookInLabel;
/*      */   
/*      */   private JButton approveButton;
/*      */   
/*      */   private JButton cancelButton;
/*      */   
/*      */   private JPanel controlButtonPanel;
/*      */   
/*      */   private JTextField fileNameTextField;
/*      */   
/*      */   private Color comboListBackground;
/*      */   
/*      */   private FilePane filePane;
/*      */   
/*      */   private boolean readOnly;
/*      */   
/*      */   public class FilePane extends JPanel implements PropertyChangeListener {
/*      */     private static final int LIST_WIDTH = 600;
/*      */     
/*      */     private static final int LIST_HEIGHT = 205;
/*      */     
/*      */     private static final int COLUMN_FILE = 0;
/*      */     
/*      */     private static final int COLUMN_FILESIZE = 1;
/*      */     
/*      */     private static final int COLUMN_FILETYPE = 2;
/*      */     
/*      */     private static final int COLUMN_FILEDATE = 3;
/*      */     
/*      */     private static final int COLUMN_FILEATTR = 4;
/*      */     
/*      */     private static final int COLUMN_COLCOUNT = 5;
/*      */     
/*      */     private class DetailsTableModel extends AbstractTableModel {
/*      */       JFileChooser fileChooser;
/*      */       
/*      */       File newAddedEntry;
/*      */       
/*      */       ListModel listModel;
/*      */       
/*      */       DetailsTableModel(JFileChooser param2JFileChooser) {
/* 2842 */         this.fileChooser = param2JFileChooser;
/* 2843 */         this.listModel = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getModel();
/* 2845 */         this.listModel.addListDataListener(new ListDataListener() {
/*      */               public void contentsChanged(ListDataEvent param3ListDataEvent) {
/* 2850 */                 SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/* 2851 */                 SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.doFileSelection();
/*      */               }
/*      */               
/*      */               public void intervalAdded(ListDataEvent param3ListDataEvent) {
/* 2856 */                 SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.newAddedEntry = SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.listModel.getElementAt(param3ListDataEvent.getIndex0());
/* 2857 */                 final boolean newDir = SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.this$1.newCreatedFile;
/* 2858 */                 SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/* 2860 */                 if (!(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.this$1)).treePanelEnabled)
/* 2863 */                   EventQueue.invokeLater(new Runnable() {
/*      */                         public void run() {
/* 2868 */                           SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this).doFileSelection();
/* 2869 */                           if (newDir) {
/* 2871 */                             int i = SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1).getModel().indexOf((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).newAddedEntry);
/* 2872 */                             (SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1)).filePane.editIndex = i;
/* 2873 */                             (SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1)).filePane.editFileName();
/*      */                           } 
/*      */                         }
/*      */                       }); 
/*      */               }
/*      */               
/*      */               public void intervalRemoved(ListDataEvent param3ListDataEvent) {
/* 2883 */                 SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/*      */               }
/*      */             });
/*      */       }
/*      */       
/*      */       public int getRowCount() {
/* 2890 */         return this.listModel.getSize();
/*      */       }
/*      */       
/*      */       public int getColumnCount() {
/* 2895 */         return 5;
/*      */       }
/*      */       
/*      */       public String getColumnName(int param2Int) {
/* 2900 */         return SyntheticaFileChooserUI.FilePane.this.columnNames[param2Int];
/*      */       }
/*      */       
/*      */       public Class<?> getColumnClass(int param2Int) {
/* 2905 */         switch (param2Int) {
/*      */           case 0:
/* 2908 */             return File.class;
/*      */           case 3:
/* 2910 */             return Date.class;
/*      */           case 1:
/* 2912 */             return Long.class;
/*      */         } 
/* 2914 */         return super.getColumnClass(param2Int);
/*      */       }
/*      */       
/*      */       public Object getValueAt(int param2Int1, int param2Int2) {
/*      */         long l;
/*      */         String str;
/* 2927 */         File file = this.listModel.getElementAt(param2Int1);
/* 2928 */         switch (param2Int2) {
/*      */           case 0:
/* 2931 */             return file;
/*      */           case 1:
/* 2934 */             if (!file.exists() || file.isDirectory() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/* 2935 */               return new Long(-1L); 
/* 2937 */             return new Long(file.length());
/*      */           case 2:
/* 2940 */             if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/* 2941 */               return null; 
/* 2942 */             return this.fileChooser.getFileSystemView().getSystemTypeDescription(file);
/*      */           case 3:
/* 2945 */             if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/* 2946 */               return null; 
/* 2947 */             l = file.lastModified();
/* 2948 */             return (l == 0L) ? null : new Date(l);
/*      */           case 4:
/* 2951 */             if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/* 2952 */               return null; 
/* 2953 */             str = "";
/*      */             try {
/* 2956 */               if (!file.canWrite())
/* 2956 */                 str = String.valueOf(str) + "R"; 
/* 2958 */             } catch (AccessControlException accessControlException) {}
/* 2962 */             if (file.isHidden())
/* 2962 */               str = String.valueOf(str) + "H"; 
/* 2963 */             return str;
/*      */         } 
/* 2965 */         return null;
/*      */       }
/*      */       
/*      */       public void setValueAt(Object param2Object, int param2Int1, int param2Int2) {}
/*      */       
/*      */       public boolean isCellEditable(int param2Int1, int param2Int2) {
/* 2975 */         return (param2Int2 == 0 && SyntheticaFileChooserUI.FilePane.this.editFile != null);
/*      */       }
/*      */       
/*      */       public void doFileSelection() {
/* 2981 */         File file = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).isDirectorySelected() ? SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getDirectory() : this.fileChooser.getSelectedFile();
/* 2982 */         int i = ((BasicDirectoryModel)this.listModel).indexOf(file);
/* 2983 */         if (file != null && i >= 0) {
/* 2986 */           SyntheticaFileChooserUI.FilePane.this.list.setSelectedValue(file, true);
/*      */         } else {
/* 2988 */           SyntheticaFileChooserUI.FilePane.this.list.clearSelection();
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     private class FileNode extends DefaultMutableTreeNode {
/*      */       boolean refresh = false;
/*      */       
/*      */       boolean updateAllowed = true;
/*      */       
/*      */       FileNode(File param2File) {
/* 3004 */         super(param2File);
/*      */       }
/*      */       
/*      */       public File getFile() {
/* 3009 */         return (File)this.userObject;
/*      */       }
/*      */       
/*      */       public int getChildCount() {
/* 3014 */         updateChildren();
/* 3015 */         return super.getChildCount();
/*      */       }
/*      */       
/*      */       public Enumeration<?> children() {
/* 3020 */         updateChildren();
/* 3021 */         return super.children();
/*      */       }
/*      */       
/*      */       public boolean isLeaf() {
/* 3026 */         return !((File)this.userObject).isDirectory();
/*      */       }
/*      */       
/*      */       private void prepareForUpdateChildren() {
/* 3032 */         this.refresh = true;
/*      */       }
/*      */       
/*      */       private void updateChildren() {
/* 3037 */         if (this.refresh) {
/* 3039 */           this.refresh = false;
/* 3040 */           removeAllChildren();
/* 3041 */           this.children = null;
/*      */         } 
/* 3044 */         if (this.children == null && this.updateAllowed) {
/* 3046 */           final FileSystemView fsv = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSystemView();
/* 3047 */           File[] arrayOfFile1 = fileSystemView.getFiles(getFile(), true);
/* 3048 */           Arrays.sort(arrayOfFile1, new Comparator() {
/*      */                 public int compare(Object param3Object1, Object param3Object2) {
/* 3052 */                   File file1 = (File)param3Object1;
/* 3053 */                   File file2 = (File)param3Object2;
/* 3054 */                   if (file1 == null || file2 == null)
/* 3055 */                     return 0; 
/* 3058 */                   if (fsv.isFileSystemRoot(file1) || fsv.isFileSystemRoot(file2))
/* 3059 */                     return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/* 3061 */                   if (file1.isDirectory() && file2.isFile())
/* 3062 */                     return -1 * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/* 3063 */                   if (file1.isFile() && file2.isDirectory())
/* 3064 */                     return 1 * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/* 3066 */                   if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 0) {
/* 3070 */                     Collator collator = SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.getFilenameCollator();
/* 3071 */                     int i = collator.compare(file1.getName(), file2.getName());
/* 3072 */                     return i * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                   } 
/* 3074 */                   if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 3) {
/* 3076 */                     long l = file1.lastModified() - file2.lastModified();
/* 3077 */                     return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                   } 
/* 3079 */                   if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 1) {
/* 3081 */                     long l = file1.length() - file2.length();
/* 3082 */                     return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                   } 
/* 3085 */                   return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                 }
/*      */               });
/* 3088 */           boolean bool = (SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSelectionMode() == 1) ? true : false;
/*      */           byte b;
/*      */           int i;
/*      */           File[] arrayOfFile2;
/* 3089 */           for (i = (arrayOfFile2 = arrayOfFile1).length, b = 0; b < i; ) {
/* 3089 */             File file = arrayOfFile2[b];
/* 3091 */             if (!bool || (bool && file.isDirectory()))
/* 3092 */               insert(new FileNode(file), (this.children == null) ? 0 : this.children.size()); 
/*      */             b++;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/*      */       public String toString() {
/* 3099 */         return SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSystemView().getSystemDisplayName(getFile());
/*      */       }
/*      */     }
/*      */     
/*      */     private class FilePaneMouseListener implements MouseListener {
/*      */       private MouseListener doubleClickListener;
/*      */       
/*      */       private boolean singleClick;
/*      */       
/* 3117 */       private final int EDIT_DELAY = 250;
/*      */       
/*      */       public FilePaneMouseListener(JList param2JList) {
/* 3121 */         this.doubleClickListener = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).createDoubleClickListener(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser(), param2JList);
/*      */       }
/*      */       
/*      */       public FilePaneMouseListener(JTable param2JTable) {
/* 3126 */         this.doubleClickListener = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).createDoubleClickListener(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser(), SyntheticaFileChooserUI.FilePane.this.list);
/*      */       }
/*      */       
/*      */       public void mouseClicked(MouseEvent param2MouseEvent) {
/*      */         int i;
/* 3132 */         JComponent jComponent = (JComponent)param2MouseEvent.getSource();
/* 3135 */         if (jComponent instanceof JList) {
/* 3136 */           i = loc2IndexFileList((JList)jComponent, param2MouseEvent.getPoint());
/* 3137 */         } else if (jComponent instanceof JTable) {
/* 3138 */           i = ((JTable)jComponent).rowAtPoint(param2MouseEvent.getPoint());
/*      */         } else {
/* 3139 */           if (jComponent instanceof JTableHeader) {
/* 3141 */             int j = ((JTableHeader)jComponent).columnAtPoint(param2MouseEvent.getPoint());
/* 3142 */             j = SyntheticaFileChooserUI.FilePane.this.table.convertColumnIndexToModel(j);
/* 3143 */             if (j == SyntheticaFileChooserUI.FilePane.this.sortColumn) {
/* 3145 */               if (SyntheticaFileChooserUI.FilePane.this.sortOrder == 1) {
/* 3146 */                 SyntheticaFileChooserUI.FilePane.this.sortOrder = -1;
/*      */               } else {
/* 3148 */                 SyntheticaFileChooserUI.FilePane.this.sortOrder = 1;
/*      */               } 
/*      */             } else {
/* 3153 */               SyntheticaFileChooserUI.FilePane.this.sortOrder = (j == 1 || j == 3) ? -1 : 1;
/* 3154 */               SyntheticaFileChooserUI.FilePane.this.sortColumn = j;
/*      */             } 
/* 3156 */             SyntheticaFileChooserUI.FilePane.this.detailsTableSortModel.sort();
/* 3157 */             SyntheticaFileChooserUI.FilePane.this.viewPanel.repaint();
/*      */             return;
/*      */           } 
/*      */           return;
/*      */         } 
/* 3165 */         if (i >= 0 && SyntheticaFileChooserUI.FilePane.this.list.getSelectionModel().isSelectedIndex(i) && jComponent instanceof JTable) {
/* 3167 */           Rectangle rectangle = SyntheticaFileChooserUI.FilePane.this.list.getCellBounds(i, i);
/* 3168 */           param2MouseEvent = new MouseEvent(SyntheticaFileChooserUI.FilePane.this.list, param2MouseEvent.getID(), param2MouseEvent.getWhen(), param2MouseEvent
/* 3169 */               .getModifiers(), rectangle.x, rectangle.y, param2MouseEvent.getClickCount(), param2MouseEvent
/* 3170 */               .isPopupTrigger(), param2MouseEvent.getButton());
/*      */         } 
/* 3173 */         if (i >= 0 && SwingUtilities.isLeftMouseButton(param2MouseEvent))
/* 3176 */           if (param2MouseEvent.getClickCount() == 1) {
/* 3178 */             this.singleClick = true;
/* 3179 */             if (SyntheticaFileChooserUI.FilePane.this.editIndex == i && SyntheticaFileChooserUI.FilePane.this.editFile == null) {
/* 3185 */               (new Thread() {
/*      */                   public void run() {
/*      */                     try {
/* 3191 */                       sleep(250L);
/* 3193 */                     } catch (InterruptedException interruptedException) {}
/* 3196 */                     if (SyntheticaFileChooserUI.FilePane.FilePaneMouseListener.this.singleClick)
/* 3196 */                       SwingUtilities.invokeLater(new Runnable() {
/*      */                             public void run() {
/* 3200 */                               SyntheticaFileChooserUI.FilePane.FilePaneMouseListener.access$1(SyntheticaFileChooserUI.FilePane.FilePaneMouseListener.null.access$0(SyntheticaFileChooserUI.FilePane.FilePaneMouseListener.null.this)).editFileName();
/*      */                             }
/*      */                           }); 
/*      */                   }
/* 3204 */                 }).start();
/* 3206 */             } else if (SyntheticaFileChooserUI.FilePane.this.editFile == null) {
/* 3208 */               SyntheticaFileChooserUI.FilePane.this.editIndex = i;
/*      */             } 
/* 3221 */           } else if (param2MouseEvent.getClickCount() != 1) {
/* 3223 */             this.singleClick = false;
/* 3224 */             SyntheticaFileChooserUI.FilePane.this.cancelEditFileName();
/*      */           }  
/* 3228 */         if (i >= 0)
/* 3229 */           this.doubleClickListener.mouseClicked(param2MouseEvent); 
/*      */       }
/*      */       
/*      */       public void mouseEntered(MouseEvent param2MouseEvent) {
/* 3234 */         this.doubleClickListener.mouseEntered(param2MouseEvent);
/*      */       }
/*      */       
/*      */       public void mouseExited(MouseEvent param2MouseEvent) {
/* 3239 */         if (param2MouseEvent.getSource() instanceof JList)
/* 3240 */           this.doubleClickListener.mouseExited(param2MouseEvent); 
/*      */       }
/*      */       
/*      */       public void mousePressed(MouseEvent param2MouseEvent) {
/* 3245 */         if (param2MouseEvent.getSource() instanceof JList)
/* 3246 */           this.doubleClickListener.mousePressed(param2MouseEvent); 
/*      */       }
/*      */       
/*      */       public void mouseReleased(MouseEvent param2MouseEvent) {
/* 3251 */         if (param2MouseEvent.getSource() instanceof JList)
/* 3252 */           this.doubleClickListener.mouseReleased(param2MouseEvent); 
/*      */       }
/*      */       
/*      */       private int loc2IndexFileList(JList param2JList, Point param2Point) {
/* 3257 */         int i = param2JList.locationToIndex(param2Point);
/* 3258 */         if (i != -1 && !pointIsInActualBounds(param2JList, i, param2Point))
/* 3259 */           i = -1; 
/* 3260 */         return i;
/*      */       }
/*      */       
/*      */       private boolean pointIsInActualBounds(JList param2JList, int param2Int, Point param2Point) {
/* 3269 */         ListCellRenderer listCellRenderer = param2JList.getCellRenderer();
/* 3270 */         ListModel<Object> listModel = param2JList.getModel();
/* 3271 */         Object object = listModel.getElementAt(param2Int);
/* 3272 */         Component component = listCellRenderer.getListCellRendererComponent(param2JList, object, param2Int, false, false);
/* 3273 */         Dimension dimension = component.getPreferredSize();
/* 3274 */         Rectangle rectangle = param2JList.getCellBounds(param2Int, param2Int);
/* 3275 */         if (!component.getComponentOrientation().isLeftToRight())
/* 3276 */           rectangle.x += rectangle.width - dimension.width; 
/* 3277 */         rectangle.width = dimension.width;
/* 3278 */         rectangle.height = dimension.height;
/* 3279 */         return rectangle.contains(param2Point);
/*      */       }
/*      */     }
/*      */     
/*      */     private class IconBorder extends CompoundBorder {
/*      */       public IconBorder(Border param2Border, Icon param2Icon) {
/*      */         super(param2Border, new Border(SyntheticaFileChooserUI.FilePane.this, param2Icon) {
/*      */               public void paintBorder(Component param3Component, Graphics param3Graphics, int param3Int1, int param3Int2, int param3Int3, int param3Int4) {
/*      */                 icon.paintIcon(param3Component, param3Graphics, param3Int1 + param3Int3 - icon.getIconWidth(), param3Int2 + (param3Int4 - icon.getIconHeight()) / 2);
/*      */               }
/*      */               
/*      */               public Insets getBorderInsets(Component param3Component) {
/*      */                 return new Insets(0, 0, 0, icon.getIconWidth());
/*      */               }
/*      */               
/*      */               public boolean isBorderOpaque() {
/*      */                 return false;
/*      */               }
/*      */             });
/*      */       }
/*      */     }
/*      */     
/*      */     private class PaddingBorder extends CompoundBorder {
/*      */       public PaddingBorder(Border param2Border) {
/*      */         super(param2Border, new Border(SyntheticaFileChooserUI.FilePane.this) {
/*      */               public void paintBorder(Component param3Component, Graphics param3Graphics, int param3Int1, int param3Int2, int param3Int3, int param3Int4) {}
/*      */               
/*      */               public Insets getBorderInsets(Component param3Component) {
/*      */                 return new Insets(1, 4, 1, 4);
/*      */               }
/*      */               
/*      */               public boolean isBorderOpaque() {
/*      */                 return false;
/*      */               }
/*      */             });
/*      */       }
/*      */     }
/*      */     
/*      */     private int[] COLUMN_WIDTHS = new int[] { 175, 60, 100, 100, 30 };
/*      */     
/*      */     private static final int ASCENDING = 1;
/*      */     
/*      */     private static final int DESCENDING = -1;
/*      */     
/*      */     private int sortColumn = 0;
/*      */     
/*      */     private int sortOrder = 1;
/*      */     
/*      */     private int view = -1;
/*      */     
/*      */     private JPanel viewPanel;
/*      */     
/*      */     private JPanel listPanel;
/*      */     
/*      */     private JPanel tablePanel;
/*      */     
/*      */     private JPanel treePanel;
/*      */     
/*      */     private JPopupMenu fileContextMenu;
/*      */     
/*      */     private JList list;
/*      */     
/*      */     private JTable table;
/*      */     
/*      */     private JTree tree;
/*      */     
/*      */     private DetailsTableSortModel detailsTableSortModel;
/*      */     
/*      */     private String fileSizeHeaderText;
/*      */     
/*      */     private File editFile;
/*      */     
/*      */     private JTextField editTextField;
/*      */     
/*      */     private boolean newCreatedFile;
/*      */     
/*      */     private int editX = 20;
/*      */     
/*      */     private int editIndex = -1;
/*      */     
/*      */     String[] columnNames;
/*      */     
/*      */     public FilePane() {
/*      */       super(new BorderLayout());
/*      */       setName("JFileChooser.FilePanel");
/*      */       this.editTextField = new JTextField();
/*      */       this.editTextField.addFocusListener(new FocusListener() {
/*      */             public void focusGained(FocusEvent param2FocusEvent) {}
/*      */             
/*      */             public void focusLost(FocusEvent param2FocusEvent) {
/*      */               SyntheticaFileChooserUI.FilePane.this.applyEditFileName();
/*      */             }
/*      */           });
/*      */       this.editTextField.addKeyListener(new KeyListener() {
/*      */             public void keyTyped(KeyEvent param2KeyEvent) {
/*      */               if (param2KeyEvent.getKeyChar() == '\033') {
/*      */                 SyntheticaFileChooserUI.FilePane.this.cancelEditFileName();
/*      */               } else if (param2KeyEvent.getKeyChar() == '\n') {
/*      */                 SyntheticaFileChooserUI.FilePane.this.applyEditFileName();
/*      */               } 
/*      */             }
/*      */             
/*      */             public void keyPressed(KeyEvent param2KeyEvent) {}
/*      */             
/*      */             public void keyReleased(KeyEvent param2KeyEvent) {}
/*      */           });
/*      */       this.listPanel = createListPanel();
/*      */       this.tablePanel = createTablePanel();
/*      */       if (SyntheticaFileChooserUI.this.treePanelEnabled)
/*      */         this.treePanel = createTreePanel(); 
/*      */       this.viewPanel = new JPanel(new BorderLayout());
/*      */       this.viewPanel.setName("JFileChooser.ViewPanel");
/*      */       add(this.viewPanel);
/*      */       SyntheticaFileChooserUI.this.getFileChooser().registerKeyboardAction(SyntheticaFileChooserUI.this, "deleteAction", KeyStroke.getKeyStroke(127, 0), 1);
/*      */       this.viewPanel.registerKeyboardAction(SyntheticaFileChooserUI.this, "renameAction", KeyStroke.getKeyStroke(113, 0), 2);
/*      */       this.table.registerKeyboardAction(SyntheticaFileChooserUI.this, "renameAction", KeyStroke.getKeyStroke(113, 0), 1);
/*      */     }
/*      */     
/*      */     private void setView(int param1Int) {
/*      */       if (this.view == param1Int)
/*      */         return; 
/*      */       firePropertyChange("SET_VIEW", this.view, param1Int);
/*      */       this.view = param1Int;
/*      */       this.viewPanel.removeAll();
/*      */       if (this.view == 0) {
/*      */         this.viewPanel.add(this.listPanel);
/*      */       } else if (this.view == 1) {
/*      */         this.viewPanel.add(this.tablePanel);
/*      */       } else if (this.view == 2) {
/*      */         this.viewPanel.add(this.treePanel);
/*      */       } 
/*      */       setInheritPopupMenu(this.viewPanel, true);
/*      */       SyntheticaFileChooserUI.this.actionPerformed(new ActionEvent(this, 0, "orderBy.nameAction"));
/*      */       revalidate();
/*      */       this.viewPanel.repaint();
/*      */     }
/*      */     
/*      */     private int getView() {
/*      */       return this.view;
/*      */     }
/*      */     
/*      */     private void setInheritPopupMenu(Container param1Container, boolean param1Boolean) {
/*      */       int i = param1Container.getComponentCount();
/*      */       if (param1Container instanceof JComponent)
/*      */         ((JComponent)param1Container).setInheritsPopupMenu(param1Boolean); 
/*      */       for (byte b = 0; b < i; b++)
/*      */         setInheritPopupMenu((Container)param1Container.getComponent(b), param1Boolean); 
/*      */     }
/*      */     
/*      */     protected JPanel createListPanel() {
/*      */       JPanel jPanel = new JPanel(new BorderLayout());
/*      */       JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/*      */       this.list = new JList();
/*      */       this.list.setName("JFileChooser.List");
/*      */       this.list.putClientProperty("List.isFileList", Boolean.TRUE);
/*      */       this.list.setCellRenderer(new ListRenderer(this.list.getCellRenderer()));
/*      */       this.list.setLayoutOrientation(1);
/*      */       this.list.setVisibleRowCount(-1);
/*      */       this.list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
/*      */             public void valueChanged(ListSelectionEvent param2ListSelectionEvent) {
/*      */               File file = SyntheticaFileChooserUI.FilePane.this.list.getSelectedValue();
/*      */               if ((SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).treePanelEnabled && file != null) {
/*      */                 TreePath treePath = SyntheticaFileChooserUI.FilePane.this.getPath(file);
/*      */                 SyntheticaFileChooserUI.FilePane.this.tree.setSelectionPath(treePath);
/*      */                 SyntheticaFileChooserUI.FilePane.this.tree.scrollPathToVisible(treePath);
/*      */               } 
/*      */               if (((ListSelectionModel)param2ListSelectionEvent.getSource()).isSelectionEmpty())
/*      */                 SyntheticaFileChooserUI.FilePane.this.editIndex = -1; 
/*      */             }
/*      */           });
/*      */       this.list.setModel(new ListModel() {
/*      */             public int getSize() {
/*      */               return SyntheticaFileChooserUI.FilePane.this.detailsTableSortModel.getRowCount();
/*      */             }
/*      */             
/*      */             public Object getElementAt(int param2Int) {
/*      */               return SyntheticaFileChooserUI.FilePane.this.detailsTableSortModel.getValueAt(param2Int, 0);
/*      */             }
/*      */             
/*      */             public void addListDataListener(ListDataListener param2ListDataListener) {
/*      */               SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getModel().addListDataListener(param2ListDataListener);
/*      */             }
/*      */             
/*      */             public void removeListDataListener(ListDataListener param2ListDataListener) {
/*      */               SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getModel().removeListDataListener(param2ListDataListener);
/*      */             }
/*      */           });
/*      */       this.list.addMouseListener(new FilePaneMouseListener(this.list));
/*      */       this.list.addListSelectionListener(SyntheticaFileChooserUI.this.createListSelectionListener(jFileChooser));
/*      */       this.list.setSelectionMode(0);
/*      */       byte b;
/*      */       int i;
/*      */       KeyListener[] arrayOfKeyListener;
/*      */       for (i = (arrayOfKeyListener = this.list.getKeyListeners()).length, b = 0; b < i; ) {
/*      */         KeyListener keyListener = arrayOfKeyListener[b];
/*      */         this.list.removeKeyListener(keyListener);
/*      */         b++;
/*      */       } 
/*      */       this.list.addKeyListener(new SyntheticaFileChooserUI.FileSelectHandler());
/*      */       JScrollPane jScrollPane = new JScrollPane(this.list);
/*      */       jPanel.setPreferredSize(new Dimension(600, 205));
/*      */       jPanel.add(jScrollPane, "Center");
/*      */       return jPanel;
/*      */     }
/*      */     
/*      */     protected JPanel createTablePanel() {
/*      */       JPanel jPanel = new JPanel(new BorderLayout());
/*      */       JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/*      */       Locale locale = jFileChooser.getLocale();
/*      */       String str1 = UIManager.getString("FileChooser.fileNameHeaderText", locale);
/*      */       this.fileSizeHeaderText = UIManager.getString("FileChooser.fileSizeHeaderText", locale);
/*      */       String str2 = UIManager.getString("FileChooser.fileTypeHeaderText", locale);
/*      */       String str3 = UIManager.getString("FileChooser.fileDateHeaderText", locale);
/*      */       String str4 = UIManager.getString("FileChooser.fileAttrHeaderText", locale);
/*      */       this.columnNames = new String[] { str1, this.fileSizeHeaderText, str2, str3, str4 };
/*      */       this.table = new JTable() {
/*      */           public boolean editCellAt(int param2Int1, int param2Int2, EventObject param2EventObject) {
/*      */             if (!JavaVersion.JAVA5 && isEditing())
/*      */               return true; 
/*      */             return super.editCellAt(param2Int1, param2Int2, param2EventObject);
/*      */           }
/*      */         };
/*      */       this.table.setName("JFileChooser.Table");
/*      */       this.table.putClientProperty("Table.isFileList", Boolean.TRUE);
/*      */       this.detailsTableSortModel = new DetailsTableSortModel(new DetailsTableModel(jFileChooser));
/*      */       this.table.setSelectionModel(this.list.getSelectionModel());
/*      */       this.table.setModel(this.detailsTableSortModel);
/*      */       this.table.setShowGrid(false);
/*      */       this.table.setIntercellSpacing(new Dimension(0, 0));
/*      */       int i = this.table.getRowHeight();
/*      */       Icon icon = null;
/*      */       FileSystemView fileSystemView = jFileChooser.getFileSystemView();
/*      */       try {
/*      */         icon = fileSystemView.getSystemIcon(fileSystemView.getHomeDirectory());
/*      */       } catch (Exception exception) {
/*      */         try {
/*      */           icon = fileSystemView.getSystemIcon(fileSystemView.getDefaultDirectory());
/*      */         } catch (Exception exception1) {
/*      */           icon = SyntheticaFileChooserUI.this.homeFolderIcon;
/*      */         } 
/*      */       } 
/*      */       if (icon == null)
/*      */         icon = SyntheticaFileChooserUI.this.homeFolderIcon; 
/*      */       if (i <= icon.getIconHeight())
/*      */         this.table.setRowHeight(icon.getIconHeight() + 1); 
/*      */       this.table.getTableHeader().setDefaultRenderer(new TableHeaderRenderer(this.table));
/*      */       this.table.getTableHeader().addMouseListener(new FilePaneMouseListener(this.table));
/*      */       TableColumnModel tableColumnModel = this.table.getColumnModel();
/*      */       TableColumn[] arrayOfTableColumn = new TableColumn[5];
/*      */       for (byte b = 0; b < 5; b++) {
/*      */         arrayOfTableColumn[b] = tableColumnModel.getColumn(b);
/*      */         arrayOfTableColumn[b].setPreferredWidth(this.COLUMN_WIDTHS[b]);
/*      */       } 
/*      */       OS oS = OS.getCurrentOS();
/*      */       if (oS == OS.Unknown || oS != OS.Windows) {
/*      */         tableColumnModel.removeColumn(arrayOfTableColumn[2]);
/*      */         tableColumnModel.removeColumn(arrayOfTableColumn[4]);
/*      */       } 
/*      */       DetailsTableCellRenderer detailsTableCellRenderer = new DetailsTableCellRenderer(jFileChooser);
/*      */       this.table.setDefaultRenderer(File.class, detailsTableCellRenderer);
/*      */       this.table.setDefaultRenderer(Long.class, detailsTableCellRenderer);
/*      */       this.table.setDefaultRenderer(Date.class, detailsTableCellRenderer);
/*      */       this.table.setDefaultRenderer(Object.class, detailsTableCellRenderer);
/*      */       arrayOfTableColumn[0].setCellEditor(new DefaultCellEditor(this.editTextField));
/*      */       this.table.addMouseListener(new FilePaneMouseListener(this.table));
/*      */       this.table.addKeyListener(new SyntheticaFileChooserUI.FileSelectHandler());
/*      */       JScrollPane jScrollPane = new JScrollPane(this.table);
/*      */       jScrollPane.getViewport().setBackground(this.table.getBackground());
/*      */       if (UIManager.get("Table.scrollPaneCornerComponent") == null)
/*      */         jScrollPane.setCorner("UPPER_TRAILING_CORNER", new SyntheticaFileChooserUI.TableHeaderCorner(this.table)); 
/*      */       jPanel.add(jScrollPane, "Center");
/*      */       return jPanel;
/*      */     }
/*      */     
/*      */     protected JPanel createTreePanel() {
/*      */       JPanel jPanel = new JPanel(new BorderLayout());
/*      */       final JFileChooser fc = SyntheticaFileChooserUI.this.getFileChooser();
/*      */       this.tree = new JTree();
/*      */       this.tree.setName("JFileChooser.Tree");
/*      */       this.tree.setEditable(true);
/*      */       FileNode fileNode = new FileNode(jFileChooser.getFileSystemView().getRoots()[0]);
/*      */       this.tree.setModel(new DefaultTreeModel(fileNode));
/*      */       this.tree.setCellRenderer(new TreeRenderer(null));
/*      */       this.tree.setCellEditor(new DefaultTreeCellEditor(this.tree, (DefaultTreeCellRenderer)this.tree.getCellRenderer(), new FileCellEditor(new JTextField())));
/*      */       this.tree.getCellEditor().addCellEditorListener(new CellEditorListener() {
/*      */             public void editingStopped(ChangeEvent param2ChangeEvent) {
/*      */               SyntheticaFileChooserUI.FilePane.FileCellEditor fileCellEditor = (SyntheticaFileChooserUI.FilePane.FileCellEditor)param2ChangeEvent.getSource();
/*      */               String str = fileCellEditor.getDelegateValue();
/*      */               SyntheticaFileChooserUI.FilePane.this.editTextField.setText(str);
/*      */               SyntheticaFileChooserUI.FilePane.this.editFile = ((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile();
/*      */               File file = SyntheticaFileChooserUI.FilePane.this.applyEditFileName();
/*      */               TreePath treePath = (SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).filePane.getPath(file);
/*      */               ((SyntheticaFileChooserUI.FilePane.FileNode)treePath.getLastPathComponent()).prepareForUpdateChildren();
/*      */               ((DefaultTreeModel)(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).filePane.tree.getModel()).nodeStructureChanged((TreeNode)treePath.getLastPathComponent());
/*      */             }
/*      */             
/*      */             public void editingCanceled(ChangeEvent param2ChangeEvent) {}
/*      */           });
/*      */       this.tree.setVisibleRowCount(-1);
/*      */       this.tree.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
/*      */             public void valueChanged(TreeSelectionEvent param2TreeSelectionEvent) {
/*      */               if (SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath() == null || SyntheticaFileChooserUI.FilePane.this.view != 2)
/*      */                 return; 
/*      */               final File file = ((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile().getAbsoluteFile();
/*      */               File file2 = fc.getCurrentDirectory();
/*      */               File file3 = (file1.isDirectory() && SyntheticaFileChooserUI.FilePane.this.view == 2) ? file1 : file1.getParentFile();
/*      */               if (!file2.equals(file3))
/*      */                 fc.setCurrentDirectory(file3); 
/*      */               if (!file1.equals(fc.getSelectedFile())) {
/*      */                 fc.setSelectedFile(file1);
/*      */                 if (!file2.equals(fc.getCurrentDirectory())) {
/*      */                   SyntheticaFileChooserUI.FilePane.this.detailsTableSortModel.addTableModelListener(new TableModelListener() {
/*      */                         public void tableChanged(TableModelEvent param3TableModelEvent) {
/*      */                           (SyntheticaFileChooserUI.FilePane.null.access$0(SyntheticaFileChooserUI.FilePane.null.this)).detailsTableSortModel.removeTableModelListener(this);
/*      */                           SwingUtilities.invokeLater(new Runnable() {
/*      */                                 public void run() {
/*      */                                   (SyntheticaFileChooserUI.FilePane.null.access$0(SyntheticaFileChooserUI.FilePane.null.null.access$0(SyntheticaFileChooserUI.FilePane.null.null.this))).list.setSelectedValue(file, true);
/*      */                                 }
/*      */                               });
/*      */                         }
/*      */                       });
/*      */                 } else {
/*      */                   SyntheticaFileChooserUI.FilePane.this.list.setSelectedValue(file1, true);
/*      */                 } 
/*      */               } 
/*      */             }
/*      */           });
/*      */       this.tree.addMouseListener(new FilePaneMouseListener(this.list));
/*      */       this.tree.getSelectionModel().setSelectionMode(1);
/*      */       this.tree.addKeyListener(new SyntheticaFileChooserUI.FileSelectHandler());
/*      */       JScrollPane jScrollPane = new JScrollPane(this.tree);
/*      */       jPanel.setPreferredSize(new Dimension(600, 205));
/*      */       jPanel.add(jScrollPane, "Center");
/*      */       return jPanel;
/*      */     }
/*      */     
/*      */     private TreePath getPath(File param1File) {
/*      */       FileNode fileNode1 = (FileNode)this.tree.getModel().getRoot();
/*      */       if (fileNode1.getFile().equals(param1File) || param1File == null)
/*      */         return new TreePath(fileNode1); 
/*      */       TreePath treePath = getPath(SyntheticaFileChooserUI.this.getFileChooser().getFileSystemView().getParentDirectory(param1File));
/*      */       FileNode fileNode2 = (FileNode)treePath.getLastPathComponent();
/*      */       Enumeration<?> enumeration = fileNode2.children();
/*      */       while (enumeration.hasMoreElements()) {
/*      */         FileNode fileNode = (FileNode)enumeration.nextElement();
/*      */         if (fileNode.getFile().exists() && fileNode.getFile().equals(param1File))
/*      */           return treePath.pathByAddingChild(fileNode); 
/*      */       } 
/*      */       return treePath;
/*      */     }
/*      */     
/*      */     public boolean isSelectionEmpty() {
/*      */       if (this.view == 2)
/*      */         return this.tree.getSelectionModel().isSelectionEmpty(); 
/*      */       return this.list.getSelectionModel().isSelectionEmpty();
/*      */     }
/*      */     
/*      */     public void clearSelection() {
/*      */       if (SyntheticaFileChooserUI.this.treePanelEnabled)
/*      */         this.tree.getSelectionModel().clearSelection(); 
/*      */       this.list.getSelectionModel().clearSelection();
/*      */     }
/*      */     
/*      */     public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */       String str = param1PropertyChangeEvent.getPropertyName();
/*      */       if (str.equals("MultiSelectionEnabledChangedProperty"))
/*      */         if (SyntheticaFileChooserUI.this.getFileChooser().isMultiSelectionEnabled()) {
/*      */           this.list.setSelectionMode(2);
/*      */           this.table.setSelectionMode(2);
/*      */         } else {
/*      */           this.list.setSelectionMode(0);
/*      */           this.table.setSelectionMode(0);
/*      */         }  
/*      */     }
/*      */     
/*      */     private void editFileName() {
/*      */       this.editIndex = this.list.getSelectedIndex();
/*      */       if (this.editIndex < 0 || SyntheticaFileChooserUI.this.directoryChooser)
/*      */         return; 
/*      */       this.editFile = (File)this.detailsTableSortModel.getValueAt(this.editIndex, 0);
/*      */       File file = SyntheticaFileChooserUI.this.getFileChooser().getCurrentDirectory();
/*      */       if (!file.canWrite() || !this.editFile.canWrite() || SyntheticaFileChooserUI.this.readOnly || SyntheticaFileChooserUI.this.getFileChooser().getFileSystemView().isFileSystemRoot(this.editFile)) {
/*      */         cancelEditFileName();
/*      */         return;
/*      */       } 
/*      */       Rectangle rectangle = null;
/*      */       if (this.view == 0) {
/*      */         rectangle = this.list.getCellBounds(this.editIndex, this.editIndex);
/*      */         this.list.add(this.editTextField);
/*      */       } 
/*      */       ComponentOrientation componentOrientation = this.list.getComponentOrientation();
/*      */       this.editTextField.setComponentOrientation(componentOrientation);
/*      */       if (this.view == 0) {
/*      */         if (componentOrientation.isLeftToRight()) {
/*      */           this.editTextField.setBounds(this.editX + rectangle.x, rectangle.y, rectangle.width - this.editX, rectangle.height);
/*      */         } else {
/*      */           this.editTextField.setBounds(rectangle.x, rectangle.y, rectangle.width - this.editX, rectangle.height);
/*      */         } 
/*      */       } else if (this.view == 1) {
/*      */         this.table.editCellAt(this.editIndex, this.table.convertColumnIndexToView(0));
/*      */       } 
/*      */       this.editTextField.setText(this.editFile.getName());
/*      */       this.editTextField.requestFocus();
/*      */       this.editTextField.selectAll();
/*      */       SyntheticaFileChooserUI.this.getFileChooser().getInputMap(1).put(KeyStroke.getKeyStroke(27, 0), "NO_ACTION");
/*      */       this.table.getActionMap().put("NO_ACTION_KEY", new AbstractAction() {
/*      */             public void actionPerformed(ActionEvent param2ActionEvent) {}
/*      */           });
/*      */       this.table.getInputMap(1).put(KeyStroke.getKeyStroke(27, 0), "NO_ACTION_KEY");
/*      */     }
/*      */     
/*      */     private File applyEditFileName() {
/*      */       if (this.editFile == null)
/*      */         return null; 
/*      */       JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/*      */       String str1 = jFileChooser.getName(this.editFile);
/*      */       String str2 = this.editFile.getName();
/*      */       String str3 = this.editTextField.getText().trim();
/*      */       String str4 = str3;
/*      */       File file = this.editFile;
/*      */       if (!str3.equals(str1)) {
/*      */         int i = str2.length();
/*      */         int j = str1.length();
/*      */         if (i > j && str2.charAt(j) == '.')
/*      */           str4 = String.valueOf(str3) + str2.substring(j); 
/*      */         FileSystemView fileSystemView = jFileChooser.getFileSystemView();
/*      */         file = fileSystemView.createFileObject(this.editFile.getParentFile(), str4);
/*      */         TreePath treePath = null;
/*      */         if (SyntheticaFileChooserUI.this.treePanelEnabled)
/*      */           treePath = getPath(this.editFile); 
/*      */         if (file.exists()) {
/*      */           String str5 = UIManager.getString("FileRenameErrorDialog.title");
/*      */           String str6 = String.format(UIManager.getString("FileRenameErrorDialog.message"), new Object[] { file.getName() });
/*      */           JOptionPane.showMessageDialog(jFileChooser, str6, str5, 0);
/*      */         } else if (!file.exists() && this.editFile.renameTo(file)) {
/*      */           final Object selected;
/*      */           if (this.editFile.equals(this.list.getSelectedValue())) {
/*      */             object = file;
/*      */           } else {
/*      */             object = this.list.getSelectedValue();
/*      */           } 
/*      */           SyntheticaFileChooserUI.this.getModel().validateFileCache();
/*      */           if (SyntheticaFileChooserUI.this.treePanelEnabled)
/*      */             this.tree.getModel().valueForPathChanged(treePath, file); 
/*      */           (new Thread() {
/*      */               public void run() {
/*      */                 try {
/*      */                   Thread.sleep(350L);
/*      */                 } catch (InterruptedException interruptedException) {}
/*      */                 SwingUtilities.invokeLater(new Runnable() {
/*      */                       public void run() {
/*      */                         (SyntheticaFileChooserUI.FilePane.null.access$0(SyntheticaFileChooserUI.FilePane.null.this)).list.setSelectedValue(selected, true);
/*      */                       }
/*      */                     });
/*      */               }
/*      */             }).start();
/*      */         } 
/*      */       } 
/*      */       cancelEditFileName();
/*      */       return file;
/*      */     }
/*      */     
/*      */     private void cancelEditFileName() {
/*      */       this.editIndex = -1;
/*      */       if (this.editFile == null)
/*      */         return; 
/*      */       this.editFile = null;
/*      */       if (this.view == 0) {
/*      */         this.list.remove(this.editTextField);
/*      */       } else {
/*      */         this.table.editingCanceled(new ChangeEvent(this.table));
/*      */       } 
/*      */       repaint();
/*      */       SyntheticaFileChooserUI.this.getFileChooser().getInputMap(1).put(KeyStroke.getKeyStroke(27, 0), "cancelSelection");
/*      */       this.table.getActionMap().remove("NO_ACTION_KEY");
/*      */     }
/*      */     
/*      */     public JPopupMenu getComponentPopupMenu() {
/*      */       JPopupMenu jPopupMenu = SyntheticaFileChooserUI.this.getFileChooser().getComponentPopupMenu();
/*      */       if (jPopupMenu != null)
/*      */         return jPopupMenu; 
/*      */       if (this.fileContextMenu != null && this.fileContextMenu.isVisible())
/*      */         return this.fileContextMenu; 
/*      */       Locale locale = SyntheticaFileChooserUI.this.getFileChooser().getLocale();
/*      */       JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/*      */       File file = jFileChooser.getCurrentDirectory();
/*      */       String str = "";
/*      */       if (jFileChooser.getDialogType() == 0) {
/*      */         str = UIManager.getString("FileChooser.contextMenu.open", locale);
/*      */       } else if (jFileChooser.getDialogType() == 1) {
/*      */         str = UIManager.getString("FileChooser.contextMenu.save", locale);
/*      */       } 
/*      */       JMenuItem jMenuItem1 = new JMenuItem("<html><b>" + str + "</b>");
/*      */       jMenuItem1.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem1.setActionCommand("approveAction");
/*      */       if (jFileChooser.getSelectedFile() == null && !SyntheticaFileChooserUI.this.isDirectorySelected()) {
/*      */         jMenuItem1.setEnabled(false);
/*      */       } else if (jFileChooser.getDialogType() != 0 && SyntheticaFileChooserUI.this.isDirectorySelected()) {
/*      */         jMenuItem1.setEnabled(false);
/*      */       } 
/*      */       JRadioButtonMenuItem jRadioButtonMenuItem1 = new JRadioButtonMenuItem(UIManager.getString("FileChooser.contextMenu.listView", locale));
/*      */       if (this.view == 0)
/*      */         jRadioButtonMenuItem1.setSelected(true); 
/*      */       jRadioButtonMenuItem1.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jRadioButtonMenuItem1.setActionCommand("view.listAction");
/*      */       JRadioButtonMenuItem jRadioButtonMenuItem2 = new JRadioButtonMenuItem(UIManager.getString("FileChooser.contextMenu.detailsView", locale));
/*      */       if (this.view == 1)
/*      */         jRadioButtonMenuItem2.setSelected(true); 
/*      */       jRadioButtonMenuItem2.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jRadioButtonMenuItem2.setActionCommand("view.detailsAction");
/*      */       JMenu jMenu1 = new JMenu(UIManager.getString("FileChooser.contextMenu.view", locale));
/*      */       jMenu1.add(jRadioButtonMenuItem1);
/*      */       jMenu1.add(jRadioButtonMenuItem2);
/*      */       JRadioButtonMenuItem jRadioButtonMenuItem3 = new JRadioButtonMenuItem(UIManager.getString("FileChooser.contextMenu.orderByName", locale));
/*      */       jRadioButtonMenuItem3.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jRadioButtonMenuItem3.setActionCommand("orderBy.nameAction");
/*      */       if (this.sortColumn == 0)
/*      */         jRadioButtonMenuItem3.setSelected(true); 
/*      */       JRadioButtonMenuItem jRadioButtonMenuItem4 = new JRadioButtonMenuItem(UIManager.getString("FileChooser.contextMenu.orderBySize", locale));
/*      */       jRadioButtonMenuItem4.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jRadioButtonMenuItem4.setActionCommand("orderBy.sizeAction");
/*      */       if (this.sortColumn == 1)
/*      */         jRadioButtonMenuItem4.setSelected(true); 
/*      */       JRadioButtonMenuItem jRadioButtonMenuItem5 = new JRadioButtonMenuItem(UIManager.getString("FileChooser.contextMenu.orderByDate", locale));
/*      */       jRadioButtonMenuItem5.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jRadioButtonMenuItem5.setActionCommand("orderBy.dateAction");
/*      */       if (this.sortColumn == 3)
/*      */         jRadioButtonMenuItem5.setSelected(true); 
/*      */       JMenu jMenu2 = new JMenu(UIManager.getString("FileChooser.contextMenu.orderBy", locale));
/*      */       jMenu2.add(jRadioButtonMenuItem3);
/*      */       jMenu2.add(jRadioButtonMenuItem4);
/*      */       jMenu2.add(jRadioButtonMenuItem5);
/*      */       JMenuItem jMenuItem2 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.refresh", locale));
/*      */       jMenuItem2.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem2.setActionCommand("refreshAction");
/*      */       JMenuItem jMenuItem3 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.newFolder", locale));
/*      */       jMenuItem3.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem3.setActionCommand("newFolderAction");
/*      */       if (!file.canWrite())
/*      */         jMenuItem3.setEnabled(false); 
/*      */       JMenuItem jMenuItem4 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.cut", locale));
/*      */       jMenuItem4.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem4.setActionCommand("cutAction");
/*      */       if (isSelectionEmpty())
/*      */         jMenuItem4.setEnabled(false); 
/*      */       JMenuItem jMenuItem5 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.copy", locale));
/*      */       jMenuItem5.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem5.setActionCommand("copyAction");
/*      */       if (isSelectionEmpty())
/*      */         jMenuItem5.setEnabled(false); 
/*      */       JMenuItem jMenuItem6 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.paste", locale));
/*      */       jMenuItem6.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem6.setActionCommand("pasteAction");
/*      */       if ((SyntheticaFileChooserUI.this.cutBuffer.isEmpty() && SyntheticaFileChooserUI.this.copyBuffer.isEmpty()) || !file.canWrite())
/*      */         jMenuItem6.setEnabled(false); 
/*      */       JMenuItem jMenuItem7 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.delete", locale));
/*      */       jMenuItem7.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem7.setActionCommand("deleteAction");
/*      */       if (isSelectionEmpty() || !file.canWrite())
/*      */         jMenuItem7.setEnabled(false); 
/*      */       JMenuItem jMenuItem8 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.rename", locale));
/*      */       jMenuItem8.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem8.setActionCommand("renameAction");
/*      */       if (isSelectionEmpty() || (jFileChooser.getSelectedFile() == null && !SyntheticaFileChooserUI.this.isDirectorySelected()) || !file.canWrite())
/*      */         jMenuItem8.setEnabled(false); 
/*      */       JMenuItem jMenuItem9 = new JMenuItem(UIManager.getString("FileChooser.contextMenu.properties", locale));
/*      */       jMenuItem9.addActionListener(SyntheticaFileChooserUI.this);
/*      */       jMenuItem9.setActionCommand("propertiesAction");
/*      */       if (isSelectionEmpty())
/*      */         jMenuItem9.setEnabled(false); 
/*      */       this.fileContextMenu = new JPopupMenu();
/*      */       this.fileContextMenu.setName("JFileChooser.FileContextMenu");
/*      */       if (jFileChooser.getDialogType() != 2) {
/*      */         this.fileContextMenu.add(jMenuItem1);
/*      */         this.fileContextMenu.addSeparator();
/*      */       } 
/*      */       if (!SyntheticaFileChooserUI.this.directoryChooser) {
/*      */         this.fileContextMenu.add(jMenu1);
/*      */         this.fileContextMenu.addSeparator();
/*      */       } 
/*      */       if (!SyntheticaFileChooserUI.this.directoryChooser && SyntheticaFileChooserUI.this.sortEnabled)
/*      */         this.fileContextMenu.add(jMenu2); 
/*      */       this.fileContextMenu.add(jMenuItem2);
/*      */       this.fileContextMenu.addSeparator();
/*      */       if (!SyntheticaFileChooserUI.this.readOnly) {
/*      */         this.fileContextMenu.add(jMenuItem3);
/*      */         this.fileContextMenu.addSeparator();
/*      */         this.fileContextMenu.add(jMenuItem4);
/*      */         this.fileContextMenu.add(jMenuItem5);
/*      */         this.fileContextMenu.add(jMenuItem6);
/*      */         this.fileContextMenu.addSeparator();
/*      */         this.fileContextMenu.add(jMenuItem7);
/*      */         this.fileContextMenu.add(jMenuItem8);
/*      */         this.fileContextMenu.addSeparator();
/*      */       } 
/*      */       this.fileContextMenu.add(jMenuItem9);
/*      */       this.fileContextMenu.applyComponentOrientation(jFileChooser.getComponentOrientation());
/*      */       ContainerEvent containerEvent = new ContainerEvent(SyntheticaFileChooserUI.this.filePane, 300, this.fileContextMenu);
/*      */       byte b;
/*      */       int i;
/*      */       ContainerListener[] arrayOfContainerListener;
/*      */       for (i = (arrayOfContainerListener = SyntheticaFileChooserUI.this.filePane.getContainerListeners()).length, b = 0; b < i; ) {
/*      */         ContainerListener containerListener = arrayOfContainerListener[b];
/*      */         containerListener.componentAdded(containerEvent);
/*      */         b++;
/*      */       } 
/*      */       return this.fileContextMenu;
/*      */     }
/*      */     
/*      */     private Collator getFilenameCollator() {
/*      */       Locale locale = SyntheticaFileChooserUI.this.getFileChooser().getLocale();
/*      */       if (locale.getLanguage().equals(Locale.GERMAN.getLanguage()))
/*      */         return GermanCollator.getInstance(); 
/*      */       return Collator.getInstance(locale);
/*      */     }
/*      */     
/*      */     private class FileCellEditor extends DefaultCellEditor {
/*      */       public FileCellEditor(JTextField param2JTextField) {
/*      */         super(param2JTextField);
/*      */       }
/*      */       
/*      */       public Object getCellEditorValue() {
/*      */         return ((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile();
/*      */       }
/*      */       
/*      */       public String getDelegateValue() {
/*      */         return (String)this.delegate.getCellEditorValue();
/*      */       }
/*      */     }
/*      */     
/*      */     private class ListRenderer implements ListCellRenderer {
/*      */       private FileSystemView fsv = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSystemView();
/*      */       
/*      */       ListCellRenderer delegate;
/*      */       
/*      */       public ListRenderer(ListCellRenderer param2ListCellRenderer) {
/*      */         this.delegate = param2ListCellRenderer;
/*      */       }
/*      */       
/*      */       public Component getListCellRendererComponent(JList<?> param2JList, Object param2Object, int param2Int, boolean param2Boolean1, boolean param2Boolean2) {
/*      */         JLabel jLabel = (JLabel)this.delegate.getListCellRendererComponent(param2JList, param2Object, param2Int, param2Boolean1, param2Boolean2);
/*      */         File file = (File)param2Object;
/*      */         String str = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getName(file);
/*      */         jLabel.setText(str);
/*      */         jLabel.setIcon(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getIcon(file, this.fsv));
/*      */         return jLabel;
/*      */       }
/*      */     }
/*      */     
/*      */     private class DetailsTableCellRenderer extends DefaultTableCellRenderer {
/*      */       private DateFormat dateFormat;
/*      */       
/*      */       private Color sortColor = UIManager.getColor("Synthetica.fileChooser.tableView.sortColumnColor");
/*      */       
/*      */       private Color alternateBackground = UIManager.getColor("Table.alternateRowColor");
/*      */       
/*      */       private FileSystemView fsv = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSystemView();
/*      */       
/*      */       private SyntheticaFileChooserUI ui = (SyntheticaFileChooserUI)SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getUI();
/*      */       
/*      */       DetailsTableCellRenderer(JFileChooser param2JFileChooser) {
/*      */         this.dateFormat = DateFormat.getDateTimeInstance(3, 3, param2JFileChooser.getLocale());
/*      */       }
/*      */       
/*      */       public Component getTableCellRendererComponent(JTable param2JTable, Object param2Object, boolean param2Boolean1, boolean param2Boolean2, int param2Int1, int param2Int2) {
/*      */         JComponent jComponent = (JComponent)super.getTableCellRendererComponent(param2JTable, param2Object, param2Boolean1, param2Boolean2, param2Int1, param2Int2);
/*      */         if (!param2Boolean1) {
/*      */           Color color = (param2Int1 % 2 == 0 && this.alternateBackground != null) ? this.alternateBackground : param2JTable.getBackground();
/*      */           if (param2Int2 == param2JTable.convertColumnIndexToView(SyntheticaFileChooserUI.FilePane.this.sortColumn) && this.sortColor != null) {
/*      */             float f = this.sortColor.getAlpha() / 255.0F;
/*      */             int i = (int)(this.sortColor.getRed() * f) + (int)(color.getRed() * (1.0F - f));
/*      */             int j = (int)(this.sortColor.getGreen() * f) + (int)(color.getGreen() * (1.0F - f));
/*      */             int k = (int)(this.sortColor.getBlue() * f) + (int)(color.getBlue() * (1.0F - f));
/*      */             jComponent.setBackground(new Color(i, j, k));
/*      */           } else {
/*      */             jComponent.setBackground(color);
/*      */           } 
/*      */         } 
/*      */         Border border = (jComponent.getBorder() instanceof SyntheticaFileChooserUI.FilePane.PaddingBorder) ? ((SyntheticaFileChooserUI.FilePane.PaddingBorder)getBorder()).getOutsideBorder() : jComponent.getBorder();
/*      */         if ((border.getBorderInsets(jComponent)).left + (border.getBorderInsets(jComponent)).right <= 4)
/*      */           border = new SyntheticaFileChooserUI.FilePane.PaddingBorder(border); 
/*      */         jComponent.setBorder(border);
/*      */         return jComponent;
/*      */       }
/*      */       
/*      */       public void setValue(Object param2Object) {
/*      */         setIcon((Icon)null);
/*      */         setHorizontalAlignment(2);
/*      */         if (param2Object instanceof File) {
/*      */           File file = (File)param2Object;
/*      */           String str = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getName(file);
/*      */           setText(str);
/*      */           setIcon(this.ui.getIcon(file, this.fsv));
/*      */         } else if (param2Object instanceof Date) {
/*      */           setText((param2Object == null) ? "" : this.dateFormat.format((Date)param2Object));
/*      */         } else if (param2Object instanceof Long) {
/*      */           long l = ((Long)param2Object).longValue();
/*      */           if (l == -1L) {
/*      */             setText("");
/*      */             return;
/*      */           } 
/*      */           l /= 1024L;
/*      */           String str = "0";
/*      */           if (l < 1024L) {
/*      */             if (l == 0L)
/*      */               l = 1L; 
/*      */             NumberFormat numberFormat = NumberFormat.getInstance(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getLocale());
/*      */             str = String.valueOf(numberFormat.format(l)) + " KB";
/*      */           } else {
/*      */             l /= 1024L;
/*      */             NumberFormat numberFormat = NumberFormat.getInstance(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getLocale());
/*      */             str = String.valueOf(numberFormat.format(l)) + " MB";
/*      */           } 
/*      */           setHorizontalAlignment(4);
/*      */           setText(str);
/*      */         } else {
/*      */           super.setValue(param2Object);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     private class TreeRenderer extends DefaultTreeCellRenderer {
/*      */       private FileSystemView fsv = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getFileSystemView();
/*      */       
/*      */       private SyntheticaFileChooserUI ui = (SyntheticaFileChooserUI)SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().getUI();
/*      */       
/*      */       public Component getTreeCellRendererComponent(JTree param2JTree, Object param2Object, boolean param2Boolean1, boolean param2Boolean2, boolean param2Boolean3, int param2Int, boolean param2Boolean4) {
/*      */         super.getTreeCellRendererComponent(param2JTree, param2Object, param2Boolean1, param2Boolean2, param2Boolean3, param2Int, param2Boolean4);
/*      */         File file = ((SyntheticaFileChooserUI.FilePane.FileNode)param2Object).getFile();
/*      */         setText(this.fsv.getSystemDisplayName(file));
/*      */         setIcon(getIcon(file));
/*      */         return this;
/*      */       }
/*      */       
/*      */       public Icon getLeafIcon() {
/*      */         if (SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath() == null)
/*      */           return super.getLeafIcon(); 
/*      */         return getIcon(((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile());
/*      */       }
/*      */       
/*      */       public Icon getOpenIcon() {
/*      */         if (SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath() == null)
/*      */           return super.getOpenIcon(); 
/*      */         return getIcon(((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile());
/*      */       }
/*      */       
/*      */       public Icon getClosedIcon() {
/*      */         if (SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath() == null)
/*      */           return super.getClosedIcon(); 
/*      */         return getIcon(((SyntheticaFileChooserUI.FilePane.FileNode)SyntheticaFileChooserUI.FilePane.this.tree.getSelectionPath().getLastPathComponent()).getFile());
/*      */       }
/*      */       
/*      */       private Icon getIcon(File param2File) {
/*      */         return this.ui.getIcon(param2File, this.fsv);
/*      */       }
/*      */       
/*      */       private TreeRenderer() {}
/*      */     }
/*      */     
/*      */     public class TableHeaderRenderer implements TableCellRenderer {
/*      */       private TableCellRenderer renderer;
/*      */       
/*      */       public TableHeaderRenderer(JTable param2JTable) {
/*      */         this.renderer = param2JTable.getTableHeader().getDefaultRenderer();
/*      */       }
/*      */       
/*      */       public Component getTableCellRendererComponent(JTable param2JTable, Object param2Object, boolean param2Boolean1, boolean param2Boolean2, int param2Int1, int param2Int2) {
/*      */         JLabel jLabel = (JLabel)this.renderer.getTableCellRendererComponent(param2JTable, param2Object, param2Boolean1, param2Boolean2, param2Int1, param2Int2);
/*      */         Border border = (jLabel.getBorder() instanceof SyntheticaFileChooserUI.FilePane.IconBorder) ? ((SyntheticaFileChooserUI.FilePane.IconBorder)SyntheticaFileChooserUI.FilePane.this.getBorder()).getOutsideBorder() : jLabel.getBorder();
/*      */         if ((border.getBorderInsets(jLabel)).left + (border.getBorderInsets(jLabel)).right <= 4)
/*      */           border = new EmptyBorder(2, 4, 2, 4); 
/*      */         if ((SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).sortEnabled && param2Int2 == param2JTable.convertColumnIndexToView(SyntheticaFileChooserUI.FilePane.this.sortColumn)) {
/*      */           Icon icon = SyntheticaLookAndFeel.loadIcon((SyntheticaFileChooserUI.FilePane.this.sortOrder == 1) ? "Synthetica.fileChooser.tableView.arrowUp" : "Synthetica.fileChooser.tableView.arrowDown");
/*      */           jLabel.setBorder(new SyntheticaFileChooserUI.FilePane.IconBorder(border, icon));
/*      */         } else {
/*      */           jLabel.setBorder(border);
/*      */         } 
/*      */         return jLabel;
/*      */       }
/*      */     }
/*      */     
/*      */     private class DetailsTableSortModel extends AbstractTableModel implements TableModelListener {
/*      */       TableModel model;
/*      */       
/*      */       Row[] rows;
/*      */       
/*      */       DetailsTableSortModel(TableModel param2TableModel) {
/*      */         this.model = param2TableModel;
/*      */         param2TableModel.addTableModelListener(this);
/*      */         reinit();
/*      */       }
/*      */       
/*      */       public void reinit() {
/*      */         this.rows = new Row[this.model.getRowCount()];
/*      */         for (byte b = 0; b < this.rows.length; b++) {
/*      */           this.rows[b] = new Row(null);
/*      */           (this.rows[b]).index = b;
/*      */         } 
/*      */         sort();
/*      */       }
/*      */       
/*      */       public void tableChanged(TableModelEvent param2TableModelEvent) {
/*      */         reinit();
/*      */         File file = ((SyntheticaFileChooserUI.FilePane.DetailsTableModel)this.model).newAddedEntry;
/*      */         if (file != null && SyntheticaFileChooserUI.FilePane.this.newCreatedFile) {
/*      */           for (byte b = 0; b < getRowCount(); b++) {
/*      */             if (file.equals(getValueAt(b, 0))) {
/*      */               (SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).filePane.editIndex = b;
/*      */               (SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this)).filePane.editFileName();
/*      */               break;
/*      */             } 
/*      */           } 
/*      */           ((SyntheticaFileChooserUI.FilePane.DetailsTableModel)this.model).newAddedEntry = null;
/*      */           SyntheticaFileChooserUI.FilePane.this.newCreatedFile = false;
/*      */         } 
/*      */       }
/*      */       
/*      */       public void sort() {
/*      */         Cursor cursor = SyntheticaFileChooserUI.FilePane.this.table.getTableHeader().getCursor();
/*      */         SyntheticaFileChooserUI.FilePane.this.table.getTableHeader().setCursor(null);
/*      */         SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().setCursor(Cursor.getPredefinedCursor(3));
/*      */         Arrays.sort((Object[])this.rows);
/*      */         fireTableDataChanged();
/*      */         SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.this).getFileChooser().setCursor(Cursor.getPredefinedCursor(0));
/*      */         SyntheticaFileChooserUI.FilePane.this.table.getTableHeader().setCursor(cursor);
/*      */       }
/*      */       
/*      */       public int getRowCount() {
/*      */         return this.model.getRowCount();
/*      */       }
/*      */       
/*      */       public int getColumnCount() {
/*      */         return this.model.getColumnCount();
/*      */       }
/*      */       
/*      */       public String getColumnName(int param2Int) {
/*      */         return this.model.getColumnName(param2Int);
/*      */       }
/*      */       
/*      */       public Class<?> getColumnClass(int param2Int) {
/*      */         return this.model.getColumnClass(param2Int);
/*      */       }
/*      */       
/*      */       public Object getValueAt(int param2Int1, int param2Int2) {
/*      */         if (this.rows.length == 0)
/*      */           return null; 
/*      */         return this.model.getValueAt((this.rows[param2Int1]).index, param2Int2);
/*      */       }
/*      */       
/*      */       public void setValueAt(Object param2Object, int param2Int1, int param2Int2) {
/*      */         this.model.setValueAt(param2Object, param2Int1, param2Int2);
/*      */       }
/*      */       
/*      */       public boolean isCellEditable(int param2Int1, int param2Int2) {
/*      */         return this.model.isCellEditable(param2Int1, param2Int2);
/*      */       }
/*      */       
/*      */       private class Row implements Comparable<Object> {
/*      */         public int index;
/*      */         
/*      */         private Row() {}
/*      */         
/*      */         public int compareTo(Object param3Object) {
/*      */           if (!(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1)).sortEnabled)
/*      */             return 0; 
/*      */           File file1 = (File)SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.model.getValueAt(this.index, 0);
/*      */           File file2 = (File)SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.model.getValueAt(((Row)param3Object).index, 0);
/*      */           if (file1 == null || file2 == null)
/*      */             return 0; 
/*      */           FileSystemView fileSystemView = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1).getFileChooser().getFileSystemView();
/*      */           if (fileSystemView.isFileSystemRoot(file1) || fileSystemView.isFileSystemRoot(file2))
/*      */             return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */           if (file1.isDirectory() && file2.isFile())
/*      */             return -1 * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */           if (file1.isFile() && file2.isDirectory())
/*      */             return 1 * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */           if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 0) {
/*      */             Collator collator = SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.getFilenameCollator();
/*      */             int i = collator.compare(file1.getName(), file2.getName());
/*      */             return i * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */           } 
/*      */           if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 3) {
/*      */             long l = file1.lastModified() - file2.lastModified();
/*      */             return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * -SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */           } 
/*      */           if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 1) {
/*      */             long l = file1.length() - file2.length();
/*      */             return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * -SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */           } 
/*      */           if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 2) {
/*      */             String str1 = fileSystemView.getSystemTypeDescription(file1);
/*      */             String str2 = fileSystemView.getSystemTypeDescription(file2);
/*      */             return str1.compareTo(str2) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */           } 
/*      */           if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 4) {
/*      */             String str1 = "";
/*      */             try {
/*      */               if (!file1.canWrite())
/*      */                 str1 = String.valueOf(str1) + "R"; 
/*      */             } catch (AccessControlException accessControlException) {}
/*      */             if (file1.isHidden())
/*      */               str1 = String.valueOf(str1) + "H"; 
/*      */             String str2 = "";
/*      */             try {
/*      */               if (!file2.canWrite())
/*      */                 str2 = String.valueOf(str2) + "R"; 
/*      */             } catch (AccessControlException accessControlException) {}
/*      */             if (file2.isHidden())
/*      */               str2 = String.valueOf(str2) + "H"; 
/*      */             return str1.compareTo(str2) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */           } 
/*      */           return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class DetailsTableModel extends AbstractTableModel {
/*      */     JFileChooser fileChooser;
/*      */     
/*      */     File newAddedEntry;
/*      */     
/*      */     ListModel listModel;
/*      */     
/*      */     DetailsTableModel(JFileChooser param1JFileChooser) {
/*      */       this.fileChooser = param1JFileChooser;
/*      */       this.listModel = SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane)SyntheticaFileChooserUI.this).getModel();
/*      */       this.listModel.addListDataListener(new ListDataListener() {
/*      */             public void contentsChanged(ListDataEvent param3ListDataEvent) {
/*      */               SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/*      */               SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.doFileSelection();
/*      */             }
/*      */             
/*      */             public void intervalAdded(ListDataEvent param3ListDataEvent) {
/*      */               SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.newAddedEntry = SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.listModel.getElementAt(param3ListDataEvent.getIndex0());
/*      */               final boolean newDir = SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.this$1.newCreatedFile;
/*      */               SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/*      */               if (!(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.this$1)).treePanelEnabled)
/*      */                 EventQueue.invokeLater(new Runnable() {
/*      */                       public void run() {
/*      */                         SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this).doFileSelection();
/*      */                         if (newDir) {
/*      */                           int i = SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1).getModel().indexOf((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).newAddedEntry);
/*      */                           (SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1)).filePane.editIndex = i;
/*      */                           (SyntheticaFileChooserUI.FilePane.access$26((SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.access$0(SyntheticaFileChooserUI.FilePane.DetailsTableModel.null.this)).this$1)).filePane.editFileName();
/*      */                         } 
/*      */                       }
/*      */                     }); 
/*      */             }
/*      */             
/*      */             public void intervalRemoved(ListDataEvent param3ListDataEvent) {
/*      */               SyntheticaFileChooserUI.FilePane.DetailsTableModel.this.fireTableDataChanged();
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     public int getRowCount() {
/*      */       return this.listModel.getSize();
/*      */     }
/*      */     
/*      */     public int getColumnCount() {
/*      */       return 5;
/*      */     }
/*      */     
/*      */     public String getColumnName(int param1Int) {
/*      */       return this.this$1.columnNames[param1Int];
/*      */     }
/*      */     
/*      */     public Class<?> getColumnClass(int param1Int) {
/*      */       switch (param1Int) {
/*      */         case 0:
/*      */           return File.class;
/*      */         case 3:
/*      */           return Date.class;
/*      */         case 1:
/*      */           return Long.class;
/*      */       } 
/*      */       return super.getColumnClass(param1Int);
/*      */     }
/*      */     
/*      */     public Object getValueAt(int param1Int1, int param1Int2) {
/*      */       long l;
/*      */       String str;
/*      */       File file = this.listModel.getElementAt(param1Int1);
/*      */       switch (param1Int2) {
/*      */         case 0:
/*      */           return file;
/*      */         case 1:
/*      */           if (!file.exists() || file.isDirectory() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/*      */             return new Long(-1L); 
/*      */           return new Long(file.length());
/*      */         case 2:
/*      */           if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/*      */             return null; 
/*      */           return this.fileChooser.getFileSystemView().getSystemTypeDescription(file);
/*      */         case 3:
/*      */           if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/*      */             return null; 
/*      */           l = file.lastModified();
/*      */           return (l == 0L) ? null : new Date(l);
/*      */         case 4:
/*      */           if (!file.exists() || this.fileChooser.getFileSystemView().isFileSystemRoot(file))
/*      */             return null; 
/*      */           str = "";
/*      */           try {
/*      */             if (!file.canWrite())
/*      */               str = String.valueOf(str) + "R"; 
/*      */           } catch (AccessControlException accessControlException) {}
/*      */           if (file.isHidden())
/*      */             str = String.valueOf(str) + "H"; 
/*      */           return str;
/*      */       } 
/*      */       return null;
/*      */     }
/*      */     
/*      */     public void setValueAt(Object param1Object, int param1Int1, int param1Int2) {}
/*      */     
/*      */     public boolean isCellEditable(int param1Int1, int param1Int2) {
/*      */       return (param1Int2 == 0 && this.this$1.editFile != null);
/*      */     }
/*      */     
/*      */     public void doFileSelection() {
/*      */       File file = SyntheticaFileChooserUI.FilePane.access$26(this.this$1).isDirectorySelected() ? SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getDirectory() : this.fileChooser.getSelectedFile();
/*      */       int i = ((BasicDirectoryModel)this.listModel).indexOf(file);
/*      */       if (file != null && i >= 0) {
/*      */         this.this$1.list.setSelectedValue(file, true);
/*      */       } else {
/*      */         this.this$1.list.clearSelection();
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private class FileNode extends DefaultMutableTreeNode {
/*      */     boolean refresh = false;
/*      */     
/*      */     boolean updateAllowed = true;
/*      */     
/*      */     FileNode(File param1File) {
/*      */       super(param1File);
/*      */     }
/*      */     
/*      */     public File getFile() {
/*      */       return (File)this.userObject;
/*      */     }
/*      */     
/*      */     public int getChildCount() {
/*      */       updateChildren();
/*      */       return super.getChildCount();
/*      */     }
/*      */     
/*      */     public Enumeration<?> children() {
/*      */       updateChildren();
/*      */       return super.children();
/*      */     }
/*      */     
/*      */     public boolean isLeaf() {
/*      */       return !((File)this.userObject).isDirectory();
/*      */     }
/*      */     
/*      */     private void prepareForUpdateChildren() {
/*      */       this.refresh = true;
/*      */     }
/*      */     
/*      */     private void updateChildren() {
/*      */       if (this.refresh) {
/*      */         this.refresh = false;
/*      */         removeAllChildren();
/*      */         this.children = null;
/*      */       } 
/*      */       if (this.children == null && this.updateAllowed) {
/*      */         final FileSystemView fsv = SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getFileChooser().getFileSystemView();
/*      */         File[] arrayOfFile1 = fileSystemView.getFiles(getFile(), true);
/*      */         Arrays.sort(arrayOfFile1, new Comparator() {
/*      */               public int compare(Object param3Object1, Object param3Object2) {
/*      */                 File file1 = (File)param3Object1;
/*      */                 File file2 = (File)param3Object2;
/*      */                 if (file1 == null || file2 == null)
/*      */                   return 0; 
/*      */                 if (fsv.isFileSystemRoot(file1) || fsv.isFileSystemRoot(file2))
/*      */                   return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/*      */                 if (file1.isDirectory() && file2.isFile())
/*      */                   return -1 * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/*      */                 if (file1.isFile() && file2.isDirectory())
/*      */                   return 1 * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder; 
/*      */                 if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 0) {
/*      */                   Collator collator = SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.getFilenameCollator();
/*      */                   int i = collator.compare(file1.getName(), file2.getName());
/*      */                   return i * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                 } 
/*      */                 if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 3) {
/*      */                   long l = file1.lastModified() - file2.lastModified();
/*      */                   return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                 } 
/*      */                 if (SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortColumn == 1) {
/*      */                   long l = file1.length() - file2.length();
/*      */                   return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */                 } 
/*      */                 return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.FileNode.this.this$1.sortOrder;
/*      */               }
/*      */             });
/*      */         boolean bool = (SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getFileChooser().getFileSelectionMode() == 1) ? true : false;
/*      */         byte b;
/*      */         int i;
/*      */         File[] arrayOfFile2;
/*      */         for (i = (arrayOfFile2 = arrayOfFile1).length, b = 0; b < i; ) {
/*      */           File file = arrayOfFile2[b];
/*      */           if (!bool || (bool && file.isDirectory()))
/*      */             insert(new FileNode(file), (this.children == null) ? 0 : this.children.size()); 
/*      */           b++;
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*      */     public String toString() {
/*      */       return SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getFileChooser().getFileSystemView().getSystemDisplayName(getFile());
/*      */     }
/*      */   }
/*      */   
/*      */   private HashSet<File> cutBuffer = new HashSet<File>();
/*      */   
/*      */   private HashSet<File> copyBuffer = new HashSet<File>();
/*      */   
/*      */   private boolean useSystemFileIcons = SyntheticaLookAndFeel.getUseSystemFileIcons();
/*      */   
/*      */   private boolean directoryChooser = false;
/*      */   
/*      */   private boolean treePanelEnabled = false;
/*      */   
/*      */   private boolean sortEnabled = true;
/*      */   
/*      */   private int xGap = 10;
/*      */   
/*      */   private int yGap = 10;
/*      */   
/*      */   public SyntheticaFileChooserUI(JFileChooser paramJFileChooser) {
/*      */     super(paramJFileChooser);
/*      */   }
/*      */   
/*      */   protected SyntheticaFileChooserUI(JFileChooser paramJFileChooser, boolean paramBoolean) {
/*      */     super(paramJFileChooser);
/*      */     this.directoryChooser = paramBoolean;
/*      */     this.treePanelEnabled = paramBoolean;
/*      */     if (paramBoolean)
/*      */       paramJFileChooser.setFileSelectionMode(1); 
/*      */   }
/*      */   
/*      */   public static ComponentUI createUI(JComponent paramJComponent) {
/*      */     return new SyntheticaFileChooserUI((JFileChooser)paramJComponent);
/*      */   }
/*      */   
/*      */   public void installUI(JComponent paramJComponent) {
/*      */     super.installUI(paramJComponent);
/*      */     this.comboListBackground = SyntheticaLookAndFeel.getColor("Synthetica.fileChooser.comboListBackground", paramJComponent);
/*      */     String str = "Synthetica.extendedFileChooser.sortEnabled";
/*      */     this.sortEnabled = SyntheticaLookAndFeel.getBoolean(str, paramJComponent, true);
/*      */     if (SyntheticaLookAndFeel.getRememberFileChooserPreferences() && !this.directoryChooser) {
/*      */       final JFileChooser fc = getFileChooser();
/*      */       Thread thread = new Thread() {
/*      */           public void run() {
/*      */             Window window = null;
/*      */             char c = 'È';
/*      */             while (((window = SyntheticaFileChooserUI.this.getWindow()) == null || !window.isShowing()) && c > '\000') {
/*      */               try {
/*      */                 sleep(10L);
/*      */               } catch (InterruptedException interruptedException) {}
/*      */               c--;
/*      */             } 
/*      */             if (window == null)
/*      */               return; 
/*      */             String str1 = "";
/*      */             byte b2;
/*      */             Frame[] arrayOfFrame;
/*      */             for (int i = (arrayOfFrame = Frame.getFrames()).length; b2 < i; ) {
/*      */               Frame frame = arrayOfFrame[b2];
/*      */               if (frame instanceof javax.swing.JFrame && frame.getTitle() != null) {
/*      */                 str1 = frame.getTitle();
/*      */                 break;
/*      */               } 
/*      */               b2++;
/*      */             } 
/*      */             byte b1 = 50;
/*      */             b2 = 7;
/*      */             String str2 = (fc.getClientProperty("Synthetica.fileChooser.id") == null) ? "" : ("." + (String)fc.getClientProperty("Synthetica.fileChooser.id"));
/*      */             str2 = (str2.length() <= b2) ? str2 : str2.substring(0, b2 + 1);
/*      */             String str3 = ".SyntheticaFileChooser";
/*      */             str1 = (str1.length() <= b1) ? str1 : str1.substring(0, b1);
/*      */             str1 = str1.replace("//", "/");
/*      */             final Preferences sysPrefs = Preferences.userRoot().node(String.valueOf(str1) + str2 + str3);
/*      */             int j = preferences.getInt("xPos", (window.getLocation()).x);
/*      */             int k = preferences.getInt("yPos", (window.getLocation()).y);
/*      */             int m = preferences.getInt("width", (window.getSize()).width);
/*      */             int n = preferences.getInt("height", (window.getSize()).height);
/*      */             Rectangle rectangle = SyntheticaLookAndFeel.validateWindowBounds(new Rectangle(j, k, m, n));
/*      */             window.setBounds(rectangle);
/*      */             final File dir = new File(preferences.get("directory" + fc.getDialogType(), fc.getCurrentDirectory().getAbsolutePath()));
/*      */             String str4 = "Synthetica.extendedFileChooser.rememberLastDirectory";
/*      */             boolean bool = fc.getFileSystemView().getDefaultDirectory().equals(fc.getCurrentDirectory());
/*      */             final boolean rememberDirEnabeld = (SyntheticaLookAndFeel.getBoolean(str4, fc, true) && bool) ? true : false;
/*      */             if (bool1 && file != null && file.exists())
/*      */               EventQueue.invokeLater(new Runnable() {
/*      */                     public void run() {
/*      */                       fc.setCurrentDirectory(dir);
/*      */                     }
/*      */                   }); 
/*      */             EventQueue.invokeLater(new Runnable() {
/*      */                   public void run() {
/*      */                     (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.setView(sysPrefs.getInt("view", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.getView()));
/*      */                     (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortColumn = sysPrefs.getInt("sortColumn", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortColumn);
/*      */                     (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortOrder = sysPrefs.getInt("sortOrder", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortOrder);
/*      */                   }
/*      */                 });
/*      */             window.addWindowListener(new WindowAdapter() {
/*      */                   public void windowClosed(WindowEvent param2WindowEvent) {
/*      */                     Dialog dialog = (Dialog)param2WindowEvent.getWindow();
/*      */                     int i = (dialog.getLocation()).x;
/*      */                     int j = (dialog.getLocation()).y;
/*      */                     int k = (dialog.getSize()).width;
/*      */                     int m = (dialog.getSize()).height;
/*      */                     sysPrefs.putInt("xPos", i);
/*      */                     sysPrefs.putInt("yPos", j);
/*      */                     sysPrefs.putInt("width", k);
/*      */                     sysPrefs.putInt("height", m);
/*      */                     sysPrefs.putInt("view", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.getView());
/*      */                     sysPrefs.putInt("sortColumn", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortColumn);
/*      */                     sysPrefs.putInt("sortOrder", (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.sortOrder);
/*      */                     if (rememberDirEnabeld)
/*      */                       sysPrefs.put("directory" + fc.getDialogType(), fc.getCurrentDirectory().getAbsolutePath()); 
/*      */                   }
/*      */                 });
/*      */           }
/*      */         };
/*      */       thread.setDaemon(true);
/*      */       thread.setPriority(10);
/*      */       thread.start();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void installComponents(final JFileChooser fc) {
/*      */     if (this.directoryChooser)
/*      */       fc.setDialogTitle(UIManager.getString("DirectoryChooser.title")); 
/*      */     Locale locale = fc.getLocale();
/*      */     fc.setLayout(new BorderLayout(0, this.yGap));
/*      */     fc.setBorder(new EmptyBorder(this.yGap, this.xGap, this.yGap, this.xGap));
/*      */     JPanel jPanel1 = new JPanel(new GridBagLayout());
/*      */     jPanel1.setName("JFileChooser.NorthPanel");
/*      */     GridBagConstraints gridBagConstraints1 = new GridBagConstraints();
/*      */     this.lookInLabel = new JLabel(UIManager.getString("FileChooser.lookInLabelText", locale));
/*      */     this.lookInLabel.setDisplayedMnemonic(UIManager.getInt("FileChooser.lookInLabelMnemonic"));
/*      */     gridBagConstraints1.weightx = 0.0D;
/*      */     gridBagConstraints1.insets = new Insets(0, 0, 0, this.xGap);
/*      */     jPanel1.add(this.lookInLabel, gridBagConstraints1);
/*      */     this.directoryComboBox = new JComboBox();
/*      */     this.directoryComboBox.setName("JFileChooser.DirectoryComboBox");
/*      */     final DirectoryComboBoxModel directoryComboBoxModel = new DirectoryComboBoxModel();
/*      */     this.directoryComboBox.setModel(directoryComboBoxModel);
/*      */     final ListCellRenderer renderer = this.directoryComboBox.getRenderer();
/*      */     this.directoryComboBox.setRenderer(new DefaultListCellRenderer() {
/*      */           SyntheticaFileChooserUI.IndentIcon ii = new SyntheticaFileChooserUI.IndentIcon(null);
/*      */           
/*      */           public Component getListCellRendererComponent(JList<?> param1JList, Object param1Object, int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
/*      */             if (SyntheticaFileChooserUI.this.comboListBackground != null && (param1JList.getBorder() == null || param1JList.getBorder().getClass().getName().contains("SynthBorder")))
/*      */               param1JList.setBackground(SyntheticaFileChooserUI.this.comboListBackground); 
/*      */             JLabel jLabel = (JLabel)renderer.getListCellRendererComponent(param1JList, param1Object, param1Int, param1Boolean1, param1Boolean2);
/*      */             if (param1Object == null) {
/*      */               jLabel.setText("");
/*      */               return this;
/*      */             } 
/*      */             File file = (File)param1Object;
/*      */             jLabel.setText(fc.getName(file));
/*      */             if (SyntheticaFileChooserUI.this.useSystemFileIcons) {
/*      */               FileSystemView fileSystemView = fc.getFileSystemView();
/*      */               try {
/*      */                 this.ii.icon = fileSystemView.getSystemIcon(file);
/*      */               } catch (NullPointerException nullPointerException) {}
/*      */             } 
/*      */             if (this.ii.icon == null || !SyntheticaFileChooserUI.this.useSystemFileIcons)
/*      */               this.ii.icon = SyntheticaFileChooserUI.this.getFileChooser().getIcon(file); 
/*      */             this.ii.depth = directoryComboBoxModel.getDepth(param1Int);
/*      */             jLabel.setIcon(this.ii);
/*      */             jLabel.setOpaque(param1Boolean1);
/*      */             return jLabel;
/*      */           }
/*      */         });
/*      */     this.directoryComboBox.addActionListener(this);
/*      */     this.directoryComboBox.setActionCommand("directoryComboBox.select");
/*      */     this.directoryComboBox.setMaximumRowCount(15);
/*      */     this.directoryComboBox.putClientProperty("JComboBox.isTableCellEditor", Boolean.TRUE);
/*      */     gridBagConstraints1.gridx = 2;
/*      */     gridBagConstraints1.fill = 2;
/*      */     gridBagConstraints1.weightx = 1.0D;
/*      */     jPanel1.add(this.directoryComboBox, gridBagConstraints1);
/*      */     Box box = new Box(2);
/*      */     box.add(Box.createHorizontalStrut(this.xGap));
/*      */     boolean bool = UIManager.getBoolean("Synthetica.extendedFileChooser.actionButtons.paintBorder");
/*      */     this.upFolderButton = new JButton(this.upFolderIcon);
/*      */     if (SyntheticaLookAndFeel.get("FileChooser.upFolderIcon.disabled", fc) != null) {
/*      */       this.upFolderButton.setDisabledIcon(SyntheticaLookAndFeel.getIcon("FileChooser.upFolderIcon.disabled", fc));
/*      */     } else {
/*      */       this.upFolderButton.setDisabledIcon(createBrightIcon(this.upFolderIcon));
/*      */     } 
/*      */     this.upFolderButton.setPressedIcon(SyntheticaLookAndFeel.getIcon("FileChooser.upFolderIcon.pressed", fc));
/*      */     this.upFolderButton.setToolTipText(UIManager.getString("FileChooser.upFolderToolTipText", locale));
/*      */     if (UIManager.getLookAndFeel() instanceof SyntheticaLookAndFeel) {
/*      */       this.upFolderButton.setMargin(new Insets(0, 0, 0, 0));
/*      */       if (!bool)
/*      */         this.upFolderButton.setBorderPainted(false); 
/*      */     } else {
/*      */       this.upFolderButton.setMargin(new Insets(2, 2, 2, 2));
/*      */     } 
/*      */     this.upFolderButton.addActionListener(this);
/*      */     this.upFolderButton.setActionCommand("upFolderAction");
/*      */     box.add(this.upFolderButton);
/*      */     JButton jButton = new JButton(this.homeFolderIcon);
/*      */     jButton.setDisabledIcon(SyntheticaLookAndFeel.getIcon("FileChooser.homeFolderIcon.disabled", fc));
/*      */     jButton.setPressedIcon(SyntheticaLookAndFeel.getIcon("FileChooser.homeFolderIcon.pressed", fc));
/*      */     jButton.setToolTipText(UIManager.getString("FileChooser.homeFolderToolTipText", locale));
/*      */     if (UIManager.getLookAndFeel() instanceof SyntheticaLookAndFeel) {
/*      */       jButton.setMargin(new Insets(0, 0, 0, 0));
/*      */       if (!bool)
/*      */         jButton.setBorderPainted(false); 
/*      */     } else {
/*      */       jButton.setMargin(new Insets(2, 2, 2, 2));
/*      */     } 
/*      */     jButton.addActionListener(this);
/*      */     jButton.setActionCommand("goHomeAction");
/*      */     box.add(jButton);
/*      */     this.readOnly = UIManager.getBoolean("FileChooser.readOnly");
/*      */     if (!this.readOnly) {
/*      */       this.newFolderButton = new JButton(this.newFolderIcon);
/*      */       if (SyntheticaLookAndFeel.get("FileChooser.newFolderIcon.disabled", fc) != null) {
/*      */         this.newFolderButton.setDisabledIcon(SyntheticaLookAndFeel.getIcon("FileChooser.newFolderIcon.disabled", fc));
/*      */       } else {
/*      */         this.newFolderButton.setDisabledIcon(createBrightIcon(this.newFolderIcon));
/*      */       } 
/*      */       this.newFolderButton.setPressedIcon(SyntheticaLookAndFeel.getIcon("FileChooser.newFolderIcon.pressed", fc));
/*      */       this.newFolderButton.setToolTipText(UIManager.getString("FileChooser.newFolderToolTipText", locale));
/*      */       if (UIManager.getLookAndFeel() instanceof SyntheticaLookAndFeel) {
/*      */         this.newFolderButton.setMargin(new Insets(0, 0, 0, 0));
/*      */         if (!bool)
/*      */           this.newFolderButton.setBorderPainted(false); 
/*      */       } else {
/*      */         this.newFolderButton.setMargin(new Insets(2, 2, 2, 2));
/*      */       } 
/*      */       this.newFolderButton.addActionListener(this);
/*      */       this.newFolderButton.setActionCommand("newFolderAction");
/*      */       box.add(this.newFolderButton);
/*      */     } 
/*      */     if (!this.directoryChooser)
/*      */       box.add(Box.createHorizontalStrut(this.xGap * 2)); 
/*      */     ButtonGroup buttonGroup = new ButtonGroup();
/*      */     final JToggleButton listViewButton = new JToggleButton(this.listViewIcon);
/*      */     jToggleButton1.setToolTipText(UIManager.getString("FileChooser.listViewButtonToolTipText", locale));
/*      */     if (UIManager.getLookAndFeel() instanceof SyntheticaLookAndFeel) {
/*      */       jToggleButton1.setMargin(new Insets(0, 0, 0, 0));
/*      */       if (!bool)
/*      */         jToggleButton1.setBorderPainted(false); 
/*      */     } else {
/*      */       jToggleButton1.setMargin(new Insets(2, 2, 2, 2));
/*      */     } 
/*      */     jToggleButton1.addActionListener(this);
/*      */     jToggleButton1.setActionCommand("view.listAction");
/*      */     buttonGroup.add(jToggleButton1);
/*      */     if (!this.directoryChooser)
/*      */       box.add(jToggleButton1); 
/*      */     final JToggleButton detailsViewButton = new JToggleButton(this.detailsViewIcon);
/*      */     jToggleButton2.setToolTipText(UIManager.getString("FileChooser.detailsViewButtonToolTipText", locale));
/*      */     if (UIManager.getLookAndFeel() instanceof SyntheticaLookAndFeel) {
/*      */       jToggleButton2.setMargin(new Insets(0, 0, 0, 0));
/*      */       if (!bool)
/*      */         jToggleButton2.setBorderPainted(false); 
/*      */     } else {
/*      */       jToggleButton2.setMargin(new Insets(2, 2, 2, 2));
/*      */     } 
/*      */     jToggleButton2.addActionListener(this);
/*      */     jToggleButton2.setActionCommand("view.detailsAction");
/*      */     buttonGroup.add(jToggleButton2);
/*      */     if (!this.directoryChooser)
/*      */       box.add(jToggleButton2); 
/*      */     gridBagConstraints1.gridx = 3;
/*      */     gridBagConstraints1.fill = 0;
/*      */     gridBagConstraints1.weightx = 0.0D;
/*      */     gridBagConstraints1.insets = new Insets(0, 0, 0, 0);
/*      */     jPanel1.add(box, gridBagConstraints1);
/*      */     fc.add(jPanel1, "North");
/*      */     this.filePane = createFilePane();
/*      */     this.filePane.addPropertyChangeListener(new PropertyChangeListener() {
/*      */           public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */             if (param1PropertyChangeEvent.getPropertyName().equals("SET_VIEW")) {
/*      */               int i = ((Integer)param1PropertyChangeEvent.getNewValue()).intValue();
/*      */               if (i == 0) {
/*      */                 listViewButton.setSelected(true);
/*      */               } else if (i == 1) {
/*      */                 detailsViewButton.setSelected(true);
/*      */               } 
/*      */             } 
/*      */           }
/*      */         });
/*      */     if (this.directoryChooser) {
/*      */       this.filePane.setView(2);
/*      */     } else {
/*      */       this.filePane.setView(0);
/*      */     } 
/*      */     fc.addPropertyChangeListener(this.filePane);
/*      */     fc.add(this.filePane, "Center");
/*      */     JComponent jComponent = fc.getAccessory();
/*      */     if (jComponent != null)
/*      */       getAccessoryPanel().add(jComponent); 
/*      */     fc.add(getAccessoryPanel(), "After");
/*      */     JPanel jPanel2 = new JPanel(new GridBagLayout());
/*      */     jPanel2.setName("JFileChooser.SouthPanel");
/*      */     GridBagConstraints gridBagConstraints2 = new GridBagConstraints();
/*      */     gridBagConstraints2.anchor = SyntheticaLookAndFeel.getBoolean("Synthetica.extendedFileChooser.rightLabelAlignment", fc) ? 13 : 17;
/*      */     gridBagConstraints2.weighty = 0.0D;
/*      */     gridBagConstraints2.gridwidth = 1;
/*      */     gridBagConstraints2.gridheight = 1;
/*      */     gridBagConstraints2.insets = new Insets(0, 0, this.yGap / 2, this.xGap);
/*      */     gridBagConstraints2.gridx = 0;
/*      */     gridBagConstraints2.gridy = 0;
/*      */     gridBagConstraints2.weightx = 0.0D;
/*      */     gridBagConstraints2.fill = 0;
/*      */     JLabel jLabel = new JLabel(UIManager.getString("FileChooser.fileNameLabelText", locale));
/*      */     if (this.directoryChooser)
/*      */       jLabel.setText(UIManager.getString("DirectoryChooser.directoryNameLabelText", locale)); 
/*      */     jPanel2.add(jLabel, gridBagConstraints2);
/*      */     gridBagConstraints2.gridx = 1;
/*      */     gridBagConstraints2.weightx = 1.0D;
/*      */     gridBagConstraints2.fill = 2;
/*      */     gridBagConstraints2.insets = new Insets(0, 0, this.yGap / 2, 0);
/*      */     this.fileNameTextField = new JTextField();
/*      */     this.fileNameTextField.setName("JFileChooser.FileNameTextField");
/*      */     jPanel2.add(this.fileNameTextField, gridBagConstraints2);
/*      */     if (!this.directoryChooser) {
/*      */       gridBagConstraints2.insets = new Insets(0, 0, 0, this.xGap);
/*      */       gridBagConstraints2.gridx = 0;
/*      */       gridBagConstraints2.gridy = 1;
/*      */       gridBagConstraints2.weightx = 0.0D;
/*      */       gridBagConstraints2.fill = 0;
/*      */       JLabel jLabel1 = new JLabel(UIManager.getString("FileChooser.filesOfTypeLabelText", locale));
/*      */       jPanel2.add(jLabel1, gridBagConstraints2);
/*      */       gridBagConstraints2.gridx = 1;
/*      */       gridBagConstraints2.weightx = 1.0D;
/*      */       gridBagConstraints2.fill = 2;
/*      */       gridBagConstraints2.insets = new Insets(0, 0, 0, 0);
/*      */       JComboBox jComboBox = new JComboBox();
/*      */       jComboBox.setName("JFileChooser.FilterComboBox");
/*      */       jComboBox.setRenderer(new DefaultListCellRenderer() {
/*      */             public Component getListCellRendererComponent(JList<?> param1JList, Object param1Object, int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
/*      */               super.getListCellRendererComponent(param1JList, param1Object, param1Int, param1Boolean1, param1Boolean2);
/*      */               if (param1JList.getFixedCellHeight() != -1)
/*      */                 param1JList.setFixedCellHeight(-1); 
/*      */               if (SyntheticaFileChooserUI.this.comboListBackground != null && (param1JList.getBorder() == null || param1JList.getBorder().getClass().getName().contains("SynthBorder")))
/*      */                 param1JList.setBackground(SyntheticaFileChooserUI.this.comboListBackground); 
/*      */               if (param1Object != null && param1Object instanceof FileFilter)
/*      */                 setText(((FileFilter)param1Object).getDescription()); 
/*      */               setOpaque(param1Boolean1);
/*      */               return this;
/*      */             }
/*      */             
/*      */             public String getName() {
/*      */               return "ComboBox.listRenderer";
/*      */             }
/*      */           });
/*      */       FilterComboBoxModel filterComboBoxModel = new FilterComboBoxModel();
/*      */       jComboBox.setModel(filterComboBoxModel);
/*      */       fc.addPropertyChangeListener(filterComboBoxModel);
/*      */       jPanel2.add(jComboBox, gridBagConstraints2);
/*      */     } 
/*      */     gridBagConstraints2.insets = new Insets(this.yGap * 2, 0, 0, 0);
/*      */     gridBagConstraints2.gridx = 0;
/*      */     gridBagConstraints2.gridy = 2;
/*      */     gridBagConstraints2.gridwidth = 2;
/*      */     gridBagConstraints2.weightx = 1.0D;
/*      */     gridBagConstraints2.fill = 2;
/*      */     this.approveButton = this.directoryChooser ? new JButton(UIManager.getString("DirectoryChooser.approveButtonText")) : new JButton(getApproveButtonText(fc));
/*      */     this.approveButton.setName("JFileChooser.ApproveButton");
/*      */     this.cancelButton = new JButton(this.cancelButtonText);
/*      */     this.cancelButton.setName("JFileChooser.CancelButton");
/*      */     this.approveButton.setToolTipText(getApproveButtonToolTipText(fc));
/*      */     this.approveButton.addActionListener(getApproveSelectionAction());
/*      */     this.cancelButton.setToolTipText(this.cancelButtonToolTipText);
/*      */     this.cancelButton.addActionListener(getCancelSelectionAction());
/*      */     SpringLayout springLayout = new SpringLayout();
/*      */     this.controlButtonPanel = new JPanel(springLayout);
/*      */     this.controlButtonPanel.add(this.approveButton);
/*      */     this.controlButtonPanel.add(this.cancelButton);
/*      */     springLayout.putConstraint("East", this.cancelButton, 0, "East", this.controlButtonPanel);
/*      */     springLayout.putConstraint("East", this.approveButton, -this.xGap, "West", this.cancelButton);
/*      */     Spring spring = Spring.constant(0);
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/*      */     for (i = (arrayOfComponent = this.controlButtonPanel.getComponents()).length, b = 0; b < i; ) {
/*      */       Component component = arrayOfComponent[b];
/*      */       spring = Spring.max(spring, springLayout.getConstraints(component).getWidth());
/*      */       b++;
/*      */     } 
/*      */     for (i = (arrayOfComponent = this.controlButtonPanel.getComponents()).length, b = 0; b < i; ) {
/*      */       Component component = arrayOfComponent[b];
/*      */       SpringLayout.Constraints constraints = springLayout.getConstraints(component);
/*      */       constraints.setWidth(spring);
/*      */       b++;
/*      */     } 
/*      */     this.controlButtonPanel.setPreferredSize(this.cancelButton.getPreferredSize());
/*      */     this.controlButtonPanel.setMinimumSize(this.cancelButton.getPreferredSize());
/*      */     jPanel2.add(this.controlButtonPanel, gridBagConstraints2);
/*      */     fc.add(jPanel2, "South");
/*      */   }
/*      */   
/*      */   protected FilePane createFilePane() {
/*      */     return new FilePane();
/*      */   }
/*      */   
/*      */   public void actionPerformed(ActionEvent paramActionEvent) {
/*      */     String str = paramActionEvent.getActionCommand();
/*      */     if (str.startsWith("directoryComboBox.select")) {
/*      */       this.directoryComboBox.hidePopup();
/*      */       getFileChooser().setCurrentDirectory((File)this.directoryComboBox.getSelectedItem());
/*      */     } else if (str.startsWith("upFolderAction")) {
/*      */       getChangeToParentDirectoryAction().actionPerformed(paramActionEvent);
/*      */     } else if (str.startsWith("goHomeAction")) {
/*      */       getGoHomeAction().actionPerformed(paramActionEvent);
/*      */     } else if (str.startsWith("newFolderAction")) {
/*      */       this.filePane.newCreatedFile = true;
/*      */       getNewFolderAction().actionPerformed(paramActionEvent);
/*      */     } else if (str.startsWith("view.")) {
/*      */       if (str.endsWith("listAction")) {
/*      */         this.filePane.setView(0);
/*      */       } else if (str.endsWith("detailsAction")) {
/*      */         this.filePane.setView(1);
/*      */       } else if (str.endsWith("treeAction")) {
/*      */         this.filePane.setView(2);
/*      */       } 
/*      */     } else if (str.startsWith("approveAction")) {
/*      */       getApproveSelectionAction().actionPerformed(new ActionEvent(this, 0, ""));
/*      */     } else if (str.startsWith("orderBy.")) {
/*      */       if (this.filePane == null)
/*      */         return; 
/*      */       if (str.endsWith("nameAction")) {
/*      */         if (this.filePane.sortColumn == 0 && this.filePane.sortOrder == 1)
/*      */           return; 
/*      */         this.filePane.sortColumn = 0;
/*      */       } else if (str.endsWith("sizeAction")) {
/*      */         if (this.filePane.sortColumn == 1 && this.filePane.sortOrder == 1)
/*      */           return; 
/*      */         this.filePane.sortColumn = 1;
/*      */       } else if (str.endsWith("dateAction")) {
/*      */         if (this.filePane.sortColumn == 3 && this.filePane.sortOrder == 1)
/*      */           return; 
/*      */         this.filePane.sortColumn = 3;
/*      */       } 
/*      */       this.filePane.sortOrder = 1;
/*      */       this.filePane.detailsTableSortModel.sort();
/*      */       this.filePane.viewPanel.repaint();
/*      */       if (this.filePane.view == 2)
/*      */         rescanCurrentDirectory(getFileChooser()); 
/*      */     } else if (str.startsWith("refreshAction")) {
/*      */       rescanCurrentDirectory(getFileChooser());
/*      */     } else if (str.startsWith("cutAction")) {
/*      */       fillFileBuffer(this.cutBuffer);
/*      */       this.copyBuffer.clear();
/*      */       this.filePane.clearSelection();
/*      */       this.filePane.repaint();
/*      */     } else if (str.startsWith("copyAction")) {
/*      */       fillFileBuffer(this.copyBuffer);
/*      */       if (!this.cutBuffer.isEmpty()) {
/*      */         this.cutBuffer.clear();
/*      */         this.filePane.repaint();
/*      */       } 
/*      */     } else if (str.startsWith("pasteAction")) {
/*      */       final HashSet buffer;
/*      */       byte b = 0;
/*      */       if (!this.cutBuffer.isEmpty()) {
/*      */         hashSet = (HashSet)this.cutBuffer.clone();
/*      */         b = 2;
/*      */       } else {
/*      */         hashSet = (HashSet)this.copyBuffer.clone();
/*      */         b = 1;
/*      */       } 
/*      */       final File currentDirectory = getFileChooser().getCurrentDirectory();
/*      */       Window window = getWindow();
/*      */       final FileOperationDialog dialog = (window instanceof Dialog) ? new FileOperationDialog((Dialog)window, b) : new FileOperationDialog((Frame)window, b);
/*      */       fileOperationDialog.applyComponentOrientation(getFileChooser().getComponentOrientation());
/*      */       final boolean moveOperation = (b == 2) ? true : false;
/*      */       fileOperationDialog.setVisible(true);
/*      */       (new Thread() {
/*      */           public void run() {
/*      */             for (Iterator<File> iterator = fileBuffer.iterator(); iterator.hasNext(); ) {
/*      */               File file1 = iterator.next();
/*      */               File file2 = new File(currentDirectory, file1.getName());
/*      */               if (!file1.exists()) {
/*      */                 iterator.remove();
/*      */                 continue;
/*      */               } 
/*      */               if (!SyntheticaFileChooserUI.this.cutBuffer.isEmpty() && file1.equals(file2)) {
/*      */                 iterator.remove();
/*      */                 continue;
/*      */               } 
/*      */               if (file1.equals(file2)) {
/*      */                 byte b = 0;
/*      */                 while (file2.exists()) {
/*      */                   b++;
/*      */                   String str1 = (b == 1) ? "" : ("(" + b + ") ");
/*      */                   String str2 = UIManager.getString("FileChooser.copyAction.copyFilename", SyntheticaFileChooserUI.this.getFileChooser().getLocale());
/*      */                   String str3 = MessageFormat.format(str2, new Object[] { str1, file1.getName() });
/*      */                   file2 = new File(file2.getParentFile(), str3);
/*      */                 } 
/*      */               } 
/*      */               try {
/*      */                 boolean bool = FileUtils.copy(file1, file2, true, true, SyntheticaFileChooserUI.this.copyBuffer.isEmpty(), dialog) ? false : true;
/*      */                 if (bool)
/*      */                   break; 
/*      */               } catch (IOException iOException) {
/*      */                 iOException.printStackTrace();
/*      */               } 
/*      */             } 
/*      */             dialog.dispose();
/*      */             SwingUtilities.invokeLater(new Runnable() {
/*      */                   public void run() {
/*      */                     if ((SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.view == 2 && moveOperation) {
/*      */                       HashSet<File> hashSet = new HashSet();
/*      */                       for (File file : fileBuffer)
/*      */                         hashSet.add(file.getParentFile()); 
/*      */                       for (File file : hashSet) {
/*      */                         TreePath treePath = (SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.getPath(file);
/*      */                         ((SyntheticaFileChooserUI.FilePane.FileNode)treePath.getLastPathComponent()).prepareForUpdateChildren();
/*      */                         ((DefaultTreeModel)(SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.tree.getModel()).nodeStructureChanged((TreeNode)treePath.getLastPathComponent());
/*      */                       } 
/*      */                     } 
/*      */                     SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).rescanCurrentDirectory(SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser());
/*      */                   }
/*      */                 });
/*      */           }
/*      */         }).start();
/*      */       if (!this.cutBuffer.isEmpty())
/*      */         this.cutBuffer.clear(); 
/*      */     } else if (str.startsWith("deleteAction")) {
/*      */       if (this.readOnly || this.filePane.isSelectionEmpty())
/*      */         return; 
/*      */       String str1 = UIManager.getString("FileChooser.deleteAction.confirmMessage");
/*      */       String str2 = UIManager.getString("FileChooser.deleteAction.confirmDialogTitle");
/*      */       JOptionPane jOptionPane = new JOptionPane();
/*      */       SynthStyle synthStyle = SynthLookAndFeel.getStyleFactory().getStyle(jOptionPane, Region.OPTION_PANE);
/*      */       SynthContext synthContext = new SynthContext(jOptionPane, Region.OPTION_PANE, synthStyle, 0);
/*      */       Icon icon = ((DefaultSynthStyle)synthStyle).getIcon(synthContext, "OptionPane.stopIcon");
/*      */       int i = JOptionPane.showConfirmDialog(getFileChooser(), str1, str2, 2, 3, icon);
/*      */       if (i != 0)
/*      */         return; 
/*      */       final HashSet<File> buffer = new HashSet();
/*      */       fillFileBuffer(hashSet);
/*      */       Window window = getWindow();
/*      */       final FileOperationDialog dialog = (window instanceof Dialog) ? new FileOperationDialog((Dialog)window, 3) : new FileOperationDialog((Frame)window, 3);
/*      */       fileOperationDialog.applyComponentOrientation(getFileChooser().getComponentOrientation());
/*      */       fileOperationDialog.setVisible(true);
/*      */       (new Thread() {
/*      */           public void run() {
/*      */             for (Iterator<File> iterator = deleteBuffer.iterator(); iterator.hasNext(); ) {
/*      */               File file = iterator.next();
/*      */               boolean bool = FileUtils.delete(file, true, dialog) ? false : true;
/*      */               if (bool)
/*      */                 break; 
/*      */               iterator.remove();
/*      */             } 
/*      */             dialog.dispose();
/*      */             SwingUtilities.invokeLater(new Runnable() {
/*      */                   public void run() {
/*      */                     if ((SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this)).filePane.view == 2 && !SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser().getCurrentDirectory().exists()) {
/*      */                       File file = SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser().getCurrentDirectory().getParentFile();
/*      */                       SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser().setSelectedFile(file);
/*      */                       SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser().setCurrentDirectory(file);
/*      */                     } 
/*      */                     SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).rescanCurrentDirectory(SyntheticaFileChooserUI.null.access$0(SyntheticaFileChooserUI.null.this).getFileChooser());
/*      */                   }
/*      */                 });
/*      */           }
/*      */         }).start();
/*      */     } else if (str.startsWith("propertiesAction")) {
/*      */       if (this.filePane.isSelectionEmpty())
/*      */         return; 
/*      */       final HashSet<File> buffer = new HashSet();
/*      */       fillFileBuffer(hashSet);
/*      */       Window window = getWindow();
/*      */       final FilePropertiesDialog dialog = (window instanceof Dialog) ? new FilePropertiesDialog((Dialog)window) : new FilePropertiesDialog((Frame)window);
/*      */       final FileProperties props = new FileProperties();
/*      */       filePropertiesDialog.applyComponentOrientation(getFileChooser().getComponentOrientation());
/*      */       filePropertiesDialog.setVisible(true);
/*      */       (new Thread() {
/*      */           public void run() {
/*      */             for (File file : buffer) {
/*      */               boolean bool = false;
/*      */               try {
/*      */                 bool = FileUtils.determineProperties(props, file, true, dialog) ? false : true;
/*      */               } catch (IOException iOException) {
/*      */                 iOException.printStackTrace();
/*      */               } 
/*      */               if (bool)
/*      */                 break; 
/*      */             } 
/*      */             dialog.refresh();
/*      */           }
/*      */         }).start();
/*      */     } else if (str.startsWith("renameAction")) {
/*      */       if (this.filePane.view == 2)
/*      */         this.filePane.tree.startEditingAtPath(this.filePane.tree.getSelectionModel().getSelectionPath()); 
/*      */       this.filePane.editFileName();
/*      */     } 
/*      */   }
/*      */   
/*      */   private Window getWindow() {
/*      */     Container container = getFileChooser().getParent();
/*      */     while (container != null) {
/*      */       if (container instanceof Window)
/*      */         return (Window)container; 
/*      */       container = container.getParent();
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   private synchronized void fillFileBuffer(Collection<File> paramCollection) {
/*      */     paramCollection.clear();
/*      */     if (this.filePane.view == 2) {
/*      */       byte b;
/*      */       int i;
/*      */       TreePath[] arrayOfTreePath;
/*      */       for (i = (arrayOfTreePath = this.filePane.tree.getSelectionModel().getSelectionPaths()).length, b = 0; b < i; ) {
/*      */         TreePath treePath = arrayOfTreePath[b];
/*      */         FilePane.FileNode fileNode = (FilePane.FileNode)treePath.getLastPathComponent();
/*      */         paramCollection.add(fileNode.getFile());
/*      */         b++;
/*      */       } 
/*      */     } else {
/*      */       ListSelectionModel listSelectionModel = this.filePane.list.getSelectionModel();
/*      */       FilePane.DetailsTableSortModel detailsTableSortModel = this.filePane.detailsTableSortModel;
/*      */       for (byte b = 0; b < detailsTableSortModel.getRowCount(); b++) {
/*      */         File file = (File)detailsTableSortModel.getValueAt(b, 0);
/*      */         if (listSelectionModel.isSelectedIndex(b))
/*      */           paramCollection.add(file); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setFileName(String paramString) {
/*      */     this.fileNameTextField.setText(paramString);
/*      */   }
/*      */   
/*      */   public String getFileName() {
/*      */     return this.fileNameTextField.getText();
/*      */   }
/*      */   
/*      */   public PropertyChangeListener createPropertyChangeListener(JFileChooser paramJFileChooser) {
/*      */     return new PropertyChangeListener() {
/*      */         public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*      */           String str = param1PropertyChangeEvent.getPropertyName();
/*      */           if (str.equals("SelectedFileChangedProperty")) {
/*      */             SyntheticaFileChooserUI.this.doSelectedFileChanged(param1PropertyChangeEvent);
/*      */           } else if (str.equals("SelectedFilesChangedProperty")) {
/*      */             SyntheticaFileChooserUI.this.doSelectedFilesChanged(param1PropertyChangeEvent);
/*      */           } else if (str.equals("directoryChanged")) {
/*      */             SyntheticaFileChooserUI.this.doDirectoryChanged(param1PropertyChangeEvent);
/*      */           } else if (!str.equals("fileFilterChanged")) {
/*      */             if (str.equals("fileSelectionChanged")) {
/*      */               SyntheticaFileChooserUI.this.doFileSelectionModeChanged(param1PropertyChangeEvent);
/*      */             } else if (str.equals("AccessoryChangedProperty")) {
/*      */               SyntheticaFileChooserUI.this.doAccessoryChanged(param1PropertyChangeEvent);
/*      */             } else if (str.equals("ApproveButtonTextChangedProperty") || str.equals("ApproveButtonToolTipTextChangedProperty")) {
/*      */               SyntheticaFileChooserUI.this.doApproveButtonTextChanged(param1PropertyChangeEvent);
/*      */             } else if (str.equals("DialogTypeChangedProperty")) {
/*      */               SyntheticaFileChooserUI.this.doDialogTypeChanged(param1PropertyChangeEvent);
/*      */             } else if (!str.equals("ApproveButtonMnemonicChangedProperty")) {
/*      */               if (str.equals("ControlButtonsAreShownChangedProperty")) {
/*      */                 if (SyntheticaFileChooserUI.this.getFileChooser().getControlButtonsAreShown()) {
/*      */                   SyntheticaFileChooserUI.this.controlButtonPanel.setVisible(true);
/*      */                 } else {
/*      */                   SyntheticaFileChooserUI.this.controlButtonPanel.setVisible(false);
/*      */                 } 
/*      */               } else if (str.equals("componentOrientation")) {
/*      */                 ComponentOrientation componentOrientation = (ComponentOrientation)param1PropertyChangeEvent.getNewValue();
/*      */                 JFileChooser jFileChooser = (JFileChooser)param1PropertyChangeEvent.getSource();
/*      */                 if (componentOrientation != (ComponentOrientation)param1PropertyChangeEvent.getOldValue()) {
/*      */                   jFileChooser.applyComponentOrientation(componentOrientation);
/*      */                   SyntheticaFileChooserUI.this.filePane.listPanel.applyComponentOrientation(componentOrientation);
/*      */                   SyntheticaFileChooserUI.this.filePane.tablePanel.applyComponentOrientation(componentOrientation);
/*      */                   SyntheticaFileChooserUI.this.filePane.table.setIntercellSpacing(new Dimension(0, 0));
/*      */                   SpringLayout springLayout = new SpringLayout();
/*      */                   if (jFileChooser.getComponentOrientation() == ComponentOrientation.LEFT_TO_RIGHT) {
/*      */                     springLayout.putConstraint("East", SyntheticaFileChooserUI.this.cancelButton, 0, "East", SyntheticaFileChooserUI.this.controlButtonPanel);
/*      */                     springLayout.putConstraint("East", SyntheticaFileChooserUI.this.approveButton, -SyntheticaFileChooserUI.this.xGap, "West", SyntheticaFileChooserUI.this.cancelButton);
/*      */                   } else {
/*      */                     springLayout.putConstraint("West", SyntheticaFileChooserUI.this.cancelButton, 0, "West", SyntheticaFileChooserUI.this.controlButtonPanel);
/*      */                     springLayout.putConstraint("West", SyntheticaFileChooserUI.this.approveButton, SyntheticaFileChooserUI.this.xGap, "East", SyntheticaFileChooserUI.this.cancelButton);
/*      */                   } 
/*      */                   SyntheticaFileChooserUI.this.controlButtonPanel.setLayout(springLayout);
/*      */                 } 
/*      */               } else if (str != "FileChooser.useShellFolder") {
/*      */                 if (str.equals("ancestor"))
/*      */                   if (param1PropertyChangeEvent.getOldValue() == null)
/*      */                     param1PropertyChangeEvent.getNewValue();  
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   private void doSelectedFileChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     File file = (File)paramPropertyChangeEvent.getNewValue();
/*      */     if (file != null) {
/*      */       ((FilePane.DetailsTableModel)this.filePane.detailsTableSortModel.model).doFileSelection();
/*      */       JFileChooser jFileChooser = getFileChooser();
/*      */       if (this.directoryChooser || jFileChooser.getFileSelectionMode() == 1) {
/*      */         if (jFileChooser.getFileSystemView().isFileSystem(file))
/*      */           setFileName(file.getPath()); 
/*      */       } else if (jFileChooser.isDirectorySelectionEnabled() || !file.isDirectory()) {
/*      */         setFileName(file.getName());
/*      */       } 
/*      */     } else if (this.filePane.list.getSelectedIndex() > 0 && this.filePane.list.getSelectedValue() instanceof File && !((File)this.filePane.list.getSelectedValue()).isDirectory()) {
/*      */       this.filePane.clearSelection();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void doSelectedFilesChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     File[] arrayOfFile = (File[])paramPropertyChangeEvent.getNewValue();
/*      */     if (arrayOfFile != null && arrayOfFile.length > 1) {
/*      */       StringBuilder stringBuilder = new StringBuilder();
/*      */       for (byte b = 0; b < arrayOfFile.length; b++) {
/*      */         stringBuilder.append("\"");
/*      */         stringBuilder.append(arrayOfFile[b].getName());
/*      */         stringBuilder.append("\" ");
/*      */       } 
/*      */       setFileName(stringBuilder.toString().trim());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void doDirectoryChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     JFileChooser jFileChooser = getFileChooser();
/*      */     File file = jFileChooser.getCurrentDirectory();
/*      */     if (file == null) {
/*      */       this.newFolderButton.setEnabled(false);
/*      */       return;
/*      */     } 
/*      */     if (!this.readOnly)
/*      */       if (!file.exists() || !file.canWrite()) {
/*      */         this.newFolderButton.setEnabled(false);
/*      */       } else {
/*      */         this.newFolderButton.setEnabled(true);
/*      */       }  
/*      */     ((DirectoryComboBoxModel)this.directoryComboBox.getModel()).addItem(file);
/*      */     boolean bool = false;
/*      */     byte b;
/*      */     int i;
/*      */     StackTraceElement[] arrayOfStackTraceElement;
/*      */     for (i = (arrayOfStackTraceElement = (new Throwable()).getStackTrace()).length, b = 0; b < i; ) {
/*      */       StackTraceElement stackTraceElement = arrayOfStackTraceElement[b];
/*      */       if (stackTraceElement.toString().contains("setSelectedFile")) {
/*      */         bool = true;
/*      */         break;
/*      */       } 
/*      */       b++;
/*      */     } 
/*      */     if (this.treePanelEnabled) {
/*      */       TreePath treePath = this.filePane.getPath(file);
/*      */       if (this.filePane.tree.getSelectionPath() == null || (treePath != null && !treePath.equals(this.filePane.tree.getSelectionPath()) && !bool)) {
/*      */         this.filePane.tree.setSelectionPath(treePath);
/*      */         this.filePane.tree.scrollPathToVisible(treePath);
/*      */       } 
/*      */     } 
/*      */     if ((this.directoryChooser || jFileChooser.getFileSelectionMode() == 1) && file != null && jFileChooser.getFileSystemView().isFileSystem(file))
/*      */       setFileName(file.getPath()); 
/*      */     this.upFolderButton.setEnabled(!jFileChooser.getFileSystemView().isRoot(file));
/*      */   }
/*      */   
/*      */   private void doFileSelectionModeChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     JFileChooser jFileChooser = getFileChooser();
/*      */     File file = jFileChooser.getCurrentDirectory();
/*      */     if (file != null && ((Integer)paramPropertyChangeEvent.getNewValue()).intValue() == 1 && jFileChooser.getFileSystemView().isFileSystem(file)) {
/*      */       setFileName(file.getPath());
/*      */     } else {
/*      */       setFileName((String)null);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void doAccessoryChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     if (getAccessoryPanel() == null)
/*      */       return; 
/*      */     JComponent jComponent = (JComponent)paramPropertyChangeEvent.getOldValue();
/*      */     if (jComponent != null)
/*      */       getAccessoryPanel().remove(jComponent); 
/*      */     jComponent = (JComponent)paramPropertyChangeEvent.getNewValue();
/*      */     if (jComponent != null)
/*      */       getAccessoryPanel().add(jComponent, "Center"); 
/*      */   }
/*      */   
/*      */   private void doApproveButtonTextChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     JFileChooser jFileChooser = getFileChooser();
/*      */     this.approveButton.setText(getApproveButtonText(jFileChooser));
/*      */     this.approveButton.setToolTipText(getApproveButtonToolTipText(jFileChooser));
/*      */   }
/*      */   
/*      */   private void doDialogTypeChanged(PropertyChangeEvent paramPropertyChangeEvent) {
/*      */     JFileChooser jFileChooser = getFileChooser();
/*      */     doApproveButtonTextChanged(paramPropertyChangeEvent);
/*      */     if (jFileChooser.getDialogType() == 0) {
/*      */       this.lookInLabel.setText(UIManager.getString("FileChooser.lookInLabelText", jFileChooser.getLocale()));
/*      */     } else if (jFileChooser.getDialogType() == 1) {
/*      */       this.lookInLabel.setText(UIManager.getString("FileChooser.saveInLabelText", jFileChooser.getLocale()));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void rescanCurrentDirectory(JFileChooser paramJFileChooser) {
/*      */     getModel().validateFileCache();
/*      */     if (this.treePanelEnabled) {
/*      */       File file = getFileChooser().getCurrentDirectory();
/*      */       TreePath treePath = this.filePane.getPath(file);
/*      */       ((FilePane.FileNode)treePath.getLastPathComponent()).prepareForUpdateChildren();
/*      */       ((DefaultTreeModel)this.filePane.tree.getModel()).nodeStructureChanged((TreeNode)treePath.getLastPathComponent());
/*      */     } 
/*      */   }
/*      */   
/*      */   private ImageIcon createBrightIcon(Icon paramIcon) {
/*      */     BufferedImage bufferedImage = new BufferedImage(paramIcon.getIconWidth(), paramIcon.getIconHeight(), 2);
/*      */     paramIcon.paintIcon(null, bufferedImage.getGraphics(), 0, 0);
/*      */     ImageIcon imageIcon = new ImageIcon(bufferedImage);
/*      */     imageIcon = new ImageIcon((new JPanel()).createImage(new FilteredImageSource(bufferedImage.getSource(), new RGBImageFilter() {
/*      */               public int filterRGB(int param1Int1, int param1Int2, int param1Int3) {
/*      */                 return 0x60FFFFFF & param1Int3;
/*      */               }
/*      */             })));
/*      */     bufferedImage.getGraphics().dispose();
/*      */     return imageIcon;
/*      */   }
/*      */   
/*      */   private Icon getIcon(File paramFile, FileSystemView paramFileSystemView) {
/*      */     Icon icon = null;
/*      */     if (this.useSystemFileIcons) {
/*      */       try {
/*      */         icon = paramFileSystemView.getSystemIcon(paramFile);
/*      */       } catch (NullPointerException nullPointerException) {
/*      */         icon = getFileChooser().getIcon(paramFile);
/*      */       } 
/*      */     } else {
/*      */       icon = getFileChooser().getIcon(paramFile);
/*      */     } 
/*      */     if (this.cutBuffer.contains(paramFile))
/*      */       icon = createBrightIcon(icon); 
/*      */     return icon;
/*      */   }
/*      */   
/*      */   private class IndentIcon implements Icon {
/*      */     private Icon icon = null;
/*      */     
/*      */     private int depth = 0;
/*      */     
/*      */     private int indent = 10;
/*      */     
/*      */     public void paintIcon(Component param1Component, Graphics param1Graphics, int param1Int1, int param1Int2) {
/*      */       if (param1Component.getComponentOrientation().isLeftToRight()) {
/*      */         this.icon.paintIcon(param1Component, param1Graphics, param1Int1 + this.depth * this.indent, param1Int2);
/*      */       } else {
/*      */         this.icon.paintIcon(param1Component, param1Graphics, param1Int1, param1Int2);
/*      */       } 
/*      */     }
/*      */     
/*      */     public int getIconWidth() {
/*      */       return this.icon.getIconWidth() + this.depth * this.indent;
/*      */     }
/*      */     
/*      */     public int getIconHeight() {
/*      */       return this.icon.getIconHeight();
/*      */     }
/*      */     
/*      */     private IndentIcon() {}
/*      */   }
/*      */   
/*      */   private class DirectoryComboBoxModel extends AbstractListModel implements ComboBoxModel {
/*      */     private ArrayList<File> directories = new ArrayList<File>();
/*      */     
/*      */     private ArrayList<Integer> depths = new ArrayList<Integer>();
/*      */     
/*      */     private File selectedDirectory = null;
/*      */     
/*      */     private void addItem(File param1File) {
/*      */       if (param1File == null)
/*      */         return; 
/*      */       this.directories.clear();
/*      */       this.depths.clear();
/*      */       boolean bool = SyntheticaFileChooserUI.this.getFileChooser().getFileSystemView().equals(FileSystemView.getFileSystemView());
/*      */       Boolean bool1 = (Boolean)SyntheticaFileChooserUI.this.getFileChooser().getClientProperty("FileChooser.useShellFolder");
/*      */       if (bool1 != null)
/*      */         bool = bool1.booleanValue(); 
/*      */       File[] arrayOfFile = bool ? (File[])ShellFolder.get("fileChooserComboBoxFolders") : SyntheticaFileChooserUI.this.getFileChooser().getFileSystemView().getRoots();
/*      */       this.directories.addAll(Arrays.asList(arrayOfFile));
/*      */       try {
/*      */         param1File = param1File.getCanonicalFile();
/*      */       } catch (IOException iOException) {}
/*      */       try {
/*      */         param1File = ShellFolder.getShellFolder(param1File);
/*      */       } catch (IOException iOException) {}
/*      */       File file = param1File;
/*      */       ArrayList<File> arrayList1 = new ArrayList();
/*      */       do {
/*      */         arrayList1.add(file);
/*      */       } while ((file = file.getParentFile()) != null);
/*      */       ArrayList<File> arrayList2 = new ArrayList();
/*      */       for (byte b = 0; b < arrayList1.size(); b++) {
/*      */         file = arrayList1.get(b);
/*      */         if (this.directories.contains(file)) {
/*      */           Iterator<File> iterator = this.directories.iterator();
/*      */           while (iterator.hasNext()) {
/*      */             File file1 = iterator.next();
/*      */             if (file1.equals(file) && !this.directories.contains(param1File)) {
/*      */               for (byte b2 = b; b2 >= 0; b2--) {
/*      */                 arrayList2.add(arrayList1.get(b2));
/*      */                 this.depths.add(new Integer(arrayList1.size() - 1 - b2));
/*      */               } 
/*      */               continue;
/*      */             } 
/*      */             arrayList2.add(file1);
/*      */             File file2 = file1;
/*      */             byte b1 = 0;
/*      */             while ((file2 = file2.getParentFile()) != null && arrayList2.contains(file2))
/*      */               b1++; 
/*      */             this.depths.add(new Integer(b1));
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } 
/*      */       this.directories = arrayList2;
/*      */       setSelectedItem(param1File);
/*      */     }
/*      */     
/*      */     public int getDepth(int param1Int) {
/*      */       return (param1Int >= 0 && param1Int < this.depths.size()) ? ((Integer)this.depths.get(param1Int)).intValue() : 0;
/*      */     }
/*      */     
/*      */     public void setSelectedItem(Object param1Object) {
/*      */       this.selectedDirectory = (File)param1Object;
/*      */       fireContentsChanged(this, -1, -1);
/*      */     }
/*      */     
/*      */     public Object getSelectedItem() {
/*      */       return this.selectedDirectory;
/*      */     }
/*      */     
/*      */     public int getSize() {
/*      */       return this.directories.size();
/*      */     }
/*      */     
/*      */     public Object getElementAt(int param1Int) {
/*      */       return this.directories.get(param1Int);
/*      */     }
/*      */     
/*      */     public DirectoryComboBoxModel() {
/*      */       File file = SyntheticaFileChooserUI.this.getFileChooser().getCurrentDirectory();
/*      */       if (file != null)
/*      */         addItem(file); 
/*      */     }
/*      */   }
/*      */   
/*      */   private class DetailsTableSortModel extends AbstractTableModel implements TableModelListener {
/*      */     TableModel model;
/*      */     
/*      */     Row[] rows;
/*      */     
/*      */     DetailsTableSortModel(TableModel param1TableModel) {
/*      */       this.model = param1TableModel;
/*      */       param1TableModel.addTableModelListener(this);
/*      */       reinit();
/*      */     }
/*      */     
/*      */     public void reinit() {
/*      */       this.rows = new Row[this.model.getRowCount()];
/*      */       for (byte b = 0; b < this.rows.length; b++) {
/*      */         this.rows[b] = new Row(null);
/*      */         (this.rows[b]).index = b;
/*      */       } 
/*      */       sort();
/*      */     }
/*      */     
/*      */     public void tableChanged(TableModelEvent param1TableModelEvent) {
/*      */       reinit();
/*      */       File file = ((SyntheticaFileChooserUI.FilePane.DetailsTableModel)this.model).newAddedEntry;
/*      */       if (file != null && this.this$1.newCreatedFile) {
/*      */         for (byte b = 0; b < getRowCount(); b++) {
/*      */           if (file.equals(getValueAt(b, 0))) {
/*      */             (SyntheticaFileChooserUI.FilePane.access$26(this.this$1)).filePane.editIndex = b;
/*      */             (SyntheticaFileChooserUI.FilePane.access$26(this.this$1)).filePane.editFileName();
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         ((SyntheticaFileChooserUI.FilePane.DetailsTableModel)this.model).newAddedEntry = null;
/*      */         this.this$1.newCreatedFile = false;
/*      */       } 
/*      */     }
/*      */     
/*      */     public void sort() {
/*      */       Cursor cursor = this.this$1.table.getTableHeader().getCursor();
/*      */       this.this$1.table.getTableHeader().setCursor(null);
/*      */       SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getFileChooser().setCursor(Cursor.getPredefinedCursor(3));
/*      */       Arrays.sort((Object[])this.rows);
/*      */       fireTableDataChanged();
/*      */       SyntheticaFileChooserUI.FilePane.access$26(this.this$1).getFileChooser().setCursor(Cursor.getPredefinedCursor(0));
/*      */       this.this$1.table.getTableHeader().setCursor(cursor);
/*      */     }
/*      */     
/*      */     public int getRowCount() {
/*      */       return this.model.getRowCount();
/*      */     }
/*      */     
/*      */     public int getColumnCount() {
/*      */       return this.model.getColumnCount();
/*      */     }
/*      */     
/*      */     public String getColumnName(int param1Int) {
/*      */       return this.model.getColumnName(param1Int);
/*      */     }
/*      */     
/*      */     public Class<?> getColumnClass(int param1Int) {
/*      */       return this.model.getColumnClass(param1Int);
/*      */     }
/*      */     
/*      */     public Object getValueAt(int param1Int1, int param1Int2) {
/*      */       if (this.rows.length == 0)
/*      */         return null; 
/*      */       return this.model.getValueAt((this.rows[param1Int1]).index, param1Int2);
/*      */     }
/*      */     
/*      */     public void setValueAt(Object param1Object, int param1Int1, int param1Int2) {
/*      */       this.model.setValueAt(param1Object, param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     public boolean isCellEditable(int param1Int1, int param1Int2) {
/*      */       return this.model.isCellEditable(param1Int1, param1Int2);
/*      */     }
/*      */     
/*      */     private class Row implements Comparable<Object> {
/*      */       public int index;
/*      */       
/*      */       private Row() {}
/*      */       
/*      */       public int compareTo(Object param3Object) {
/*      */         if (!(SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1)).sortEnabled)
/*      */           return 0; 
/*      */         File file1 = (File)SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.model.getValueAt(this.index, 0);
/*      */         File file2 = (File)SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.model.getValueAt(((Row)param3Object).index, 0);
/*      */         if (file1 == null || file2 == null)
/*      */           return 0; 
/*      */         FileSystemView fileSystemView = SyntheticaFileChooserUI.FilePane.access$26(SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1).getFileChooser().getFileSystemView();
/*      */         if (fileSystemView.isFileSystemRoot(file1) || fileSystemView.isFileSystemRoot(file2))
/*      */           return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */         if (file1.isDirectory() && file2.isFile())
/*      */           return -1 * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */         if (file1.isFile() && file2.isDirectory())
/*      */           return 1 * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder; 
/*      */         if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 0) {
/*      */           Collator collator = SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.getFilenameCollator();
/*      */           int i = collator.compare(file1.getName(), file2.getName());
/*      */           return i * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         } 
/*      */         if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 3) {
/*      */           long l = file1.lastModified() - file2.lastModified();
/*      */           return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * -SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         } 
/*      */         if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 1) {
/*      */           long l = file1.length() - file2.length();
/*      */           return ((l < 0L) ? 1 : ((l > 0L) ? -1 : 0)) * -SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         } 
/*      */         if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 2) {
/*      */           String str1 = fileSystemView.getSystemTypeDescription(file1);
/*      */           String str2 = fileSystemView.getSystemTypeDescription(file2);
/*      */           return str1.compareTo(str2) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         } 
/*      */         if (SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortColumn == 4) {
/*      */           String str1 = "";
/*      */           try {
/*      */             if (!file1.canWrite())
/*      */               str1 = String.valueOf(str1) + "R"; 
/*      */           } catch (AccessControlException accessControlException) {}
/*      */           if (file1.isHidden())
/*      */             str1 = String.valueOf(str1) + "H"; 
/*      */           String str2 = "";
/*      */           try {
/*      */             if (!file2.canWrite())
/*      */               str2 = String.valueOf(str2) + "R"; 
/*      */           } catch (AccessControlException accessControlException) {}
/*      */           if (file2.isHidden())
/*      */             str2 = String.valueOf(str2) + "H"; 
/*      */           return str1.compareTo(str2) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */         } 
/*      */         return file1.toString().compareTo(file2.toString()) * SyntheticaFileChooserUI.FilePane.DetailsTableSortModel.this.this$1.sortOrder;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected class FilterComboBoxModel extends AbstractListModel implements ComboBoxModel, PropertyChangeListener {
/* 3302 */     protected FileFilter[] filters = SyntheticaFileChooserUI.this.getFileChooser().getChoosableFileFilters();
/*      */     
/*      */     public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 3310 */       String str = param1PropertyChangeEvent.getPropertyName();
/* 3311 */       if (str.equals("ChoosableFileFilterChangedProperty")) {
/* 3313 */         this.filters = (FileFilter[])param1PropertyChangeEvent.getNewValue();
/* 3314 */         fireContentsChanged(this, -1, -1);
/* 3316 */       } else if (str.equals("fileFilterChanged")) {
/* 3317 */         fireContentsChanged(this, -1, -1);
/*      */       } 
/*      */     }
/*      */     
/*      */     public void setSelectedItem(Object param1Object) {
/* 3325 */       if (param1Object != null) {
/* 3327 */         JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/* 3328 */         jFileChooser.setFileFilter((FileFilter)param1Object);
/* 3329 */         if (jFileChooser.getDialogType() != 1)
/* 3330 */           SyntheticaFileChooserUI.this.setFileName((String)null); 
/* 3331 */         fireContentsChanged(this, -1, -1);
/*      */       } 
/*      */     }
/*      */     
/*      */     public Object getSelectedItem() {
/* 3340 */       JFileChooser jFileChooser = SyntheticaFileChooserUI.this.getFileChooser();
/* 3341 */       FileFilter fileFilter = jFileChooser.getFileFilter();
/* 3342 */       if (fileFilter != null && !Arrays.<FileFilter>asList(this.filters).contains(fileFilter))
/* 3343 */         jFileChooser.addChoosableFileFilter(fileFilter); 
/* 3344 */       return jFileChooser.getFileFilter();
/*      */     }
/*      */     
/*      */     public int getSize() {
/* 3352 */       return this.filters.length;
/*      */     }
/*      */     
/*      */     public Object getElementAt(int param1Int) {
/* 3360 */       if (this.filters.length > 0)
/* 3361 */         return this.filters[param1Int]; 
/* 3363 */       return null;
/*      */     }
/*      */   }
/*      */   
/*      */   protected class FileSelectHandler implements KeyListener {
/*      */     private String prefix;
/*      */     
/*      */     private long lastTime;
/*      */     
/*      */     public void keyTyped(KeyEvent param1KeyEvent) {
/* 3379 */       if (param1KeyEvent.isAltDown() || param1KeyEvent.isControlDown() || param1KeyEvent.isMetaDown())
/*      */         return; 
/* 3381 */       char c = param1KeyEvent.getKeyChar();
/* 3382 */       JComponent jComponent = (JComponent)param1KeyEvent.getSource();
/* 3384 */       int i = -1;
/* 3385 */       if (jComponent instanceof JList) {
/* 3386 */         i = ((JList)jComponent).getLeadSelectionIndex();
/* 3387 */       } else if (jComponent instanceof JTable) {
/* 3388 */         i = ((JTable)jComponent).getSelectedRow();
/*      */       } 
/* 3390 */       long l = param1KeyEvent.getWhen();
/* 3391 */       if (l - this.lastTime > 1000L) {
/* 3393 */         i++;
/* 3394 */         this.prefix = (new StringBuilder(String.valueOf(c))).toString();
/* 3399 */       } else if (this.prefix.length() == 1 && c == this.prefix.charAt(0)) {
/* 3400 */         i++;
/*      */       } else {
/* 3402 */         this.prefix = String.valueOf(this.prefix) + c;
/*      */       } 
/* 3405 */       this.lastTime = l;
/* 3407 */       int j = getNextFileIndex(jComponent, this.prefix, i, Position.Bias.Forward);
/* 3408 */       if (j < 0)
/* 3409 */         j = getNextFileIndex(jComponent, this.prefix, 0, Position.Bias.Forward); 
/* 3411 */       if (j >= 0)
/* 3413 */         if (jComponent instanceof JList) {
/* 3415 */           ((JList)jComponent).setSelectedIndex(j);
/* 3416 */           ((JList)jComponent).ensureIndexIsVisible(j);
/* 3418 */         } else if (jComponent instanceof JTable) {
/* 3420 */           ((JTable)jComponent).setRowSelectionInterval(j, j);
/* 3421 */           ((JTable)jComponent).scrollRectToVisible(((JTable)jComponent).getCellRect(j, 0, true));
/*      */         }  
/*      */     }
/*      */     
/*      */     public void keyPressed(KeyEvent param1KeyEvent) {}
/*      */     
/*      */     public void keyReleased(KeyEvent param1KeyEvent) {}
/*      */     
/*      */     private int getNextFileIndex(JComponent param1JComponent, String param1String, int param1Int, Position.Bias param1Bias) {
/* 3436 */       int i = -1;
/* 3437 */       if (param1JComponent instanceof JList) {
/* 3438 */         i = ((JList)param1JComponent).getModel().getSize();
/* 3439 */       } else if (param1JComponent instanceof JTable) {
/* 3440 */         i = ((JTable)param1JComponent).getModel().getRowCount();
/*      */       } 
/* 3442 */       if (param1Int < 0 || param1Int >= i)
/* 3443 */         return -1; 
/* 3445 */       boolean bool = (param1Bias == Position.Bias.Backward) ? true : false;
/* 3446 */       for (int j = param1Int; bool ? (j < 0) : (j >= i); j += bool ? -1 : 1) {
/* 3448 */         String str = null;
/* 3449 */         if (param1JComponent instanceof JList) {
/* 3451 */           ListModel<File> listModel = ((JList)param1JComponent).getModel();
/* 3452 */           str = SyntheticaFileChooserUI.this.getFileChooser().getName(listModel.getElementAt(j));
/* 3454 */         } else if (param1JComponent instanceof JTable) {
/* 3456 */           TableModel tableModel = ((JTable)param1JComponent).getModel();
/* 3457 */           str = SyntheticaFileChooserUI.this.getFileChooser().getName((File)tableModel.getValueAt(j, 0));
/*      */         } 
/* 3459 */         if (str.regionMatches(true, 0, param1String, 0, param1String.length()))
/* 3460 */           return j; 
/*      */       } 
/* 3462 */       return -1;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class TableHeaderCorner extends JTableHeader {
/*      */     public TableHeaderCorner(JTable param1JTable) {
/* 3471 */       setTable(param1JTable);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\filechooser\SyntheticaFileChooserUI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */