/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Paint;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.Window;
/*     */ import java.awt.geom.AffineTransform;
/*     */ import java.awt.geom.Area;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.VolatileImage;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class SyntheticaBasicIconPainter extends SyntheticaIconPainter implements Cacheable {
/*     */   private SynthContext sc;
/*     */   
/*     */   private int width;
/*     */   
/*     */   private int height;
/*     */   
/*  55 */   private static final boolean OS_X_QUARTZ_ENABLED = SyntheticaLookAndFeel.isSystemPropertySet("apple.awt.graphics.UseQuartz");
/*     */   
/*     */   public SyntheticaBasicIconPainter() {
/*  62 */     this(null, 16, 16);
/*     */   }
/*     */   
/*     */   public SyntheticaBasicIconPainter(SynthContext paramSynthContext, int paramInt1, int paramInt2) {
/*  73 */     this.sc = paramSynthContext;
/*  74 */     this.width = paramInt1;
/*  75 */     this.height = paramInt2;
/*     */   }
/*     */   
/*     */   protected float getScale() {
/*  83 */     return 1.0F;
/*     */   }
/*     */   
/*     */   protected BasicStroke createStroke(SynthContext paramSynthContext) {
/*  91 */     return new BasicStroke(1.0F);
/*     */   }
/*     */   
/*     */   public int getIconHeight() {
/* 100 */     return (int)(this.height * getScale());
/*     */   }
/*     */   
/*     */   public int getIconWidth() {
/* 109 */     return (int)(this.width * getScale());
/*     */   }
/*     */   
/*     */   public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 118 */     SynthContext synthContext = this.sc;
/* 120 */     if (synthContext == null && paramComponent instanceof AbstractButton && UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel) {
/* 122 */       AbstractButton abstractButton = (AbstractButton)paramComponent;
/* 123 */       SynthStyle synthStyle = SyntheticaLookAndFeel.getStyle(abstractButton, Region.BUTTON);
/* 124 */       int i = 0;
/* 125 */       i |= abstractButton.getModel().isPressed() ? 4 : 0;
/* 126 */       i |= abstractButton.getModel().isSelected() ? 512 : 0;
/* 127 */       i |= !abstractButton.getModel().isEnabled() ? 8 : 0;
/* 128 */       i |= abstractButton.getModel().isRollover() ? 2 : 0;
/* 129 */       synthContext = new SynthContext(abstractButton, Region.BUTTON, synthStyle, i);
/*     */     } 
/* 131 */     paintIcon(synthContext, paramGraphics, paramInt1, paramInt2, getIconWidth(), getIconHeight());
/*     */   }
/*     */   
/*     */   public void paintIcon(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 142 */     if (!paintCachedImage(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4))
/* 143 */       paintIcon_(paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   private void paintIcon_(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 148 */     Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 150 */     Object object1 = graphics2D.getRenderingHint(RenderingHints.KEY_ANTIALIASING);
/* 151 */     Object object2 = graphics2D.getRenderingHint(RenderingHints.KEY_STROKE_CONTROL);
/* 152 */     AffineTransform affineTransform1 = graphics2D.getTransform();
/* 153 */     Paint paint = graphics2D.getPaint();
/* 154 */     Stroke stroke = graphics2D.getStroke();
/* 156 */     graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 157 */     graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
/* 159 */     BasicStroke basicStroke = createStroke(paramSynthContext);
/* 160 */     graphics2D.setStroke(basicStroke);
/* 162 */     AffineTransform affineTransform2 = new AffineTransform();
/* 164 */     if (OS.getCurrentOS() == OS.Mac && OS_X_QUARTZ_ENABLED) {
/* 165 */       affineTransform2.translate((paramInt1 + Math.round((getScale() / 2.0F) - 0.5D)), (paramInt2 + Math.round((getScale() / 2.0F) - 0.5D)));
/*     */     } else {
/* 167 */       affineTransform2.translate((paramInt1 + getScale() / 2.0F), (paramInt2 + getScale() / 2.0F));
/*     */     } 
/* 168 */     affineTransform2.scale(getScale(), getScale());
/* 169 */     graphics2D.transform(affineTransform2);
/* 173 */     paint2D(paramSynthContext, (Graphics2D)paramGraphics, paramInt1, paramInt2, (this.width - 1), (this.height - 1));
/* 175 */     graphics2D.setStroke(stroke);
/* 176 */     graphics2D.setPaint(paint);
/* 177 */     graphics2D.setTransform(affineTransform1);
/* 178 */     graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, object1);
/* 179 */     graphics2D.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, object2);
/*     */   }
/*     */   
/*     */   private boolean paintCachedImage(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 187 */     int i = 0;
/* 188 */     if (paramSynthContext == null || !UIManager.getBoolean("Synthetica.cache.enabled") || (i = getCacheHash(paramSynthContext, paramInt3, paramInt4, 0, "")) == -1 || 
/* 189 */       !SyntheticaSoftCache.getInstance().isCacheable(paramInt3, paramInt4))
/* 190 */       return false; 
/* 191 */     VolatileImage volatileImage = getCachedImage(i, paramSynthContext, paramGraphics, paramInt3, paramInt4);
/* 192 */     return (volatileImage == null) ? false : paramGraphics.drawImage(volatileImage, paramInt1, paramInt2, null);
/*     */   }
/*     */   
/*     */   private VolatileImage getCachedImage(int paramInt1, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt2, int paramInt3) {
/* 198 */     GraphicsConfiguration graphicsConfiguration = ((Graphics2D)paramGraphics).getDeviceConfiguration();
/* 199 */     SyntheticaSoftCache syntheticaSoftCache = SyntheticaSoftCache.getInstance();
/* 200 */     VolatileImage volatileImage = (VolatileImage)syntheticaSoftCache.getImage(paramInt1);
/*     */     while (true) {
/* 204 */       boolean bool = (volatileImage == null) ? true : volatileImage.validate(graphicsConfiguration);
/* 205 */       if (bool == 2 || bool == true) {
/* 207 */         if (bool == 2 || volatileImage.getWidth() != paramInt2 || volatileImage.getHeight() != paramInt3) {
/* 210 */           if (volatileImage != null) {
/* 212 */             volatileImage.flush();
/* 213 */             volatileImage = null;
/*     */           } 
/* 215 */           volatileImage = graphicsConfiguration.createCompatibleVolatileImage(paramInt2, paramInt3, 3);
/* 216 */           syntheticaSoftCache.setImage(volatileImage, paramInt1);
/*     */         } 
/* 218 */         Graphics2D graphics2D = volatileImage.createGraphics();
/* 219 */         graphics2D.setComposite(AlphaComposite.Clear);
/* 220 */         graphics2D.fillRect(0, 0, paramInt2, paramInt3);
/* 221 */         graphics2D.setComposite(AlphaComposite.SrcOver);
/* 223 */         paintIcon_(paramSynthContext, graphics2D, 0, 0, paramInt2, paramInt3);
/* 224 */         graphics2D.dispose();
/*     */       } 
/* 227 */       if (!volatileImage.contentsLost())
/* 228 */         return volatileImage; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint2D(SynthContext paramSynthContext, Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {}
/*     */   
/*     */   protected Rectangle2D.Float calc2DBounds(Graphics2D paramGraphics2D, float paramFloat1, float paramFloat2) {
/* 261 */     float f1 = ((BasicStroke)paramGraphics2D.getStroke()).getLineWidth();
/* 262 */     float f2 = f1 / 2.0F - 0.5F;
/* 263 */     return new Rectangle2D.Float(f2, f2, paramFloat1 - f1 + 1.0F, paramFloat2 - f1 + 1.0F);
/*     */   }
/*     */   
/*     */   protected static Shape subtractStroke(Graphics2D paramGraphics2D, Shape paramShape) {
/* 275 */     if (!SyntheticaLookAndFeel.getBoolean("Synthetica.2D.subtractStrokeEnabled", null))
/* 276 */       return paramShape; 
/* 277 */     Area area1 = new Area(((BasicStroke)paramGraphics2D.getStroke()).createStrokedShape(paramShape));
/* 278 */     Area area2 = new Area(paramShape);
/* 279 */     area2.subtract(area1);
/* 280 */     return area2;
/*     */   }
/*     */   
/*     */   protected Color getSyntheticaBackgroundColor(JComponent paramJComponent) {
/* 294 */     Color color = (Color)paramJComponent.getClientProperty("Synthetica.background");
/* 295 */     if (color != null) {
/* 297 */       float f = (paramJComponent.getClientProperty("Synthetica.background.alpha") == null) ? 0.1F : ((Float)paramJComponent.getClientProperty("Synthetica.background.alpha")).floatValue();
/* 298 */       int i = color.getRGB() & ((int)(f * 255.0F) << 24 | 0xFFFFFF);
/* 299 */       color = new Color(i, true);
/*     */     } 
/* 301 */     return color;
/*     */   }
/*     */   
/*     */   protected Paint createLinearGradientPaint(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float[] paramArrayOffloat, Color[] paramArrayOfColor) {
/* 310 */     return SyntheticaLookAndFeel.createLinearGradientPaint(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramArrayOffloat, paramArrayOfColor);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 316 */     int i = paramString.hashCode();
/* 317 */     i = 31 * i + paramInt1;
/* 318 */     i = 31 * i + paramInt2;
/* 319 */     i = 31 * i + paramInt3;
/* 320 */     i = 31 * i + (int)getScale() * 100;
/* 321 */     i = 31 * i + getClass().hashCode();
/* 323 */     if (paramSynthContext != null) {
/* 325 */       JComponent jComponent = paramSynthContext.getComponent();
/* 326 */       String str = SyntheticaLookAndFeel.getStyleName(jComponent);
/* 327 */       Color color = (Color)jComponent.getClientProperty("Synthetica.background");
/* 328 */       Float float_ = (Float)jComponent.getClientProperty("Synthetica.background.alpha");
/* 329 */       Window window = SwingUtilities.getWindowAncestor(jComponent);
/* 331 */       i = 31 * i + jComponent.getClass().hashCode();
/* 332 */       i = 31 * i + paramSynthContext.getComponentState();
/* 333 */       i = (str == null) ? i : (31 * i + str.hashCode());
/* 334 */       i = (color == null) ? i : (i * 31 + color.getRGB());
/* 335 */       i = (float_ == null) ? i : (i * 31 + (int)(float_.floatValue() * 100.0F));
/* 336 */       i = 31 * i + ((window == null || window.isActive()) ? 0 : 1);
/*     */     } 
/* 338 */     return i;
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 343 */     return Cacheable.ScaleType.NONE;
/*     */   }
/*     */   
/*     */   public Insets getCacheScaleInsets(SynthContext paramSynthContext, String paramString) {
/* 349 */     int i = (int)(getScale() * 10.0F);
/* 350 */     return new Insets(i, i, i, i);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\SyntheticaBasicIconPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */