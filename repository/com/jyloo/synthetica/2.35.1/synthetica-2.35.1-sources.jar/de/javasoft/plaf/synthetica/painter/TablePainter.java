/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.table.JTableHeader;
/*     */ 
/*     */ public class TablePainter extends SyntheticaComponentPainter {
/*     */   public static final String UI_KEY = "Synthetica.TablePainter";
/*     */   
/*     */   public static TablePainter getInstance() {
/*  52 */     return getInstance((SynthContext)null);
/*     */   }
/*     */   
/*     */   public static TablePainter getInstance(SynthContext paramSynthContext) {
/*  61 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, TablePainter.class, "Synthetica.TablePainter"));
/*  62 */     if (syntheticaComponentPainter == null)
/*  63 */       syntheticaComponentPainter = getInstance(paramSynthContext, TablePainter.class, "Synthetica.TablePainter"); 
/*  64 */     return (TablePainter)syntheticaComponentPainter;
/*     */   }
/*     */   
/*     */   public void paintTableBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintTableBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintTableHeaderBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  83 */     JComponent jComponent = paramSynthContext.getComponent();
/*  84 */     String str = SyntheticaLookAndFeel.getString("Synthetica.tableHeader.background.image", jComponent);
/*  85 */     if (str != null && SyntheticaLookAndFeel.isOpaque(jComponent)) {
/*  87 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica.tableHeader.background.image.insets", jComponent, true);
/*  88 */       Insets insets2 = insets1;
/*  89 */       ImagePainter imagePainter = new ImagePainter(paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/*  90 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintTableHeaderBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public void paintTableHeaderBackground(JTable paramJTable, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 112 */     JTableHeader jTableHeader = paramJTable.getTableHeader();
/* 113 */     SynthStyle synthStyle = SynthLookAndFeel.getStyleFactory().getStyle(jTableHeader, Region.TABLE_HEADER);
/* 114 */     SynthContext synthContext = new SynthContext(jTableHeader, Region.TABLE_HEADER, synthStyle, paramSyntheticaState.getState());
/* 115 */     synthStyle.getPainter(synthContext).paintTableHeaderBackground(synthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public void paintTableHeaderCellBackground(JTable paramJTable, SyntheticaState paramSyntheticaState, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 133 */     JTableHeader jTableHeader = paramJTable.getTableHeader();
/* 134 */     String str = null;
/* 135 */     Insets insets = null;
/* 137 */     if (paramInt5 == 1) {
/* 139 */       str = SyntheticaLookAndFeel.getString("Synthetica.tableHeader.ascendingSort.background.image", jTableHeader);
/* 140 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.tableHeader.ascendingSort.background.image.insets", jTableHeader, true);
/* 142 */     } else if (paramInt5 == 2) {
/* 144 */       str = SyntheticaLookAndFeel.getString("Synthetica.tableHeader.descendingSort.background.image", jTableHeader);
/* 145 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.tableHeader.descendingSort.background.image.insets", jTableHeader, true);
/*     */     } else {
/* 149 */       str = SyntheticaLookAndFeel.getString("Synthetica.tableHeader.cell.background.image", jTableHeader);
/* 150 */       insets = SyntheticaLookAndFeel.getInsets("Synthetica.tableHeader.cell.background.image.insets", jTableHeader, true);
/*     */     } 
/* 153 */     if (str != null && SyntheticaLookAndFeel.isOpaque(jTableHeader)) {
/* 155 */       ImagePainter imagePainter = new ImagePainter(jTableHeader, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets, insets, 0, 0);
/* 156 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 163 */     if (!paramString.equals("paintTableHeaderBackground"))
/* 164 */       return Cacheable.ScaleType.NINE_SQUARE; 
/* 165 */     return super.getCacheScaleType(paramString);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 171 */     if (!paramString.equals("paintTableHeaderBackground"))
/* 172 */       return -1; 
/* 173 */     return super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TablePainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */