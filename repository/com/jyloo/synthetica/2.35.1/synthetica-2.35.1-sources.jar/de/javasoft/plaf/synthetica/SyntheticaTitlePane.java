/*      */ package de.javasoft.plaf.synthetica;
/*      */ 
/*      */ import de.javasoft.plaf.synthetica.painter.SyntheticaPainter;
/*      */ import de.javasoft.util.JavaVersion;
/*      */ import de.javasoft.util.OS;
/*      */ import de.javasoft.util.java2d.DropShadow;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.ComponentOrientation;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.EventQueue;
/*      */ import java.awt.Font;
/*      */ import java.awt.FontMetrics;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GridBagConstraints;
/*      */ import java.awt.GridBagLayout;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.ContainerListener;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.event.WindowListener;
/*      */ import java.awt.event.WindowStateListener;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JDialog;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JLayeredPane;
/*      */ import javax.swing.JMenuBar;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import javax.swing.event.MouseInputListener;
/*      */ import javax.swing.plaf.basic.BasicRootPaneUI;
/*      */ import javax.swing.plaf.synth.ColorType;
/*      */ import javax.swing.plaf.synth.Region;
/*      */ import javax.swing.plaf.synth.SynthContext;
/*      */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*      */ import javax.swing.plaf.synth.SynthStyle;
/*      */ 
/*      */ public class SyntheticaTitlePane extends JPanel {
/*      */   private static final long serialVersionUID = -6164225719742333375L;
/*      */   
/*      */   private static final String BUTTON_ID = "Synthetica.buttonID";
/*      */   
/*      */   private JRootPane rootPane;
/*      */   
/*      */   private SyntheticaRootPaneUI rootPaneUI;
/*      */   
/*      */   private Window window;
/*      */   
/*      */   private Frame frame;
/*      */   
/*      */   private Dialog dialog;
/*      */   
/*      */   private JButton menuButton;
/*      */   
/*      */   private JLabel titleLabel;
/*      */   
/*      */   private JLabel menuBarLabel;
/*      */   
/*      */   private Container userComponentContainer;
/*      */   
/*      */   private JButton toggleButton;
/*      */   
/*      */   private JButton iconifyButton;
/*      */   
/*      */   private JButton closeButton;
/*      */   
/*      */   private JPopupMenu systemMenu;
/*      */   
/*      */   private Action closeAction;
/*      */   
/*      */   private Action iconifyAction;
/*      */   
/*      */   private Action restoreAction;
/*      */   
/*      */   private Action maximizeAction;
/*      */   
/*      */   private WindowListener windowListener;
/*      */   
/*      */   private PropertyChangeListener propertyChangeListener;
/*      */   
/*      */   private PropertyChangeListener rootPanePropertyChangeListener;
/*      */   
/*      */   private ContainerListener layeredPaneContainerListener;
/*      */   
/*      */   private ActionListener menuActionListener;
/*      */   
/*      */   public enum LayoutStyle {
/*  114 */     REGULAR, INLINEMENU, INLINEMENU_LEADING, SECONDARYMENU;
/*      */   }
/*      */   
/*      */   private boolean selected = true;
/*      */   
/*      */   private boolean useMACStyle = false;
/*      */   
/*  152 */   private JInternalFrame iFrameDelegate = new JInternalFrame();
/*      */   
/*      */   public SyntheticaTitlePane(JRootPane paramJRootPane, BasicRootPaneUI paramBasicRootPaneUI) {
/*  160 */     this.rootPane = paramJRootPane;
/*  161 */     this.rootPaneUI = (SyntheticaRootPaneUI)paramBasicRootPaneUI;
/*  163 */     Container container = this.rootPane.getParent();
/*  164 */     this.window = (container instanceof Window) ? (Window)container : SwingUtilities.getWindowAncestor(container);
/*  165 */     if (this.window instanceof Frame) {
/*  166 */       this.frame = (Frame)this.window;
/*  167 */     } else if (this.window instanceof Dialog) {
/*  168 */       this.dialog = (Dialog)this.window;
/*      */     } 
/*  170 */     this.useMACStyle = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.useMACStyleOnMAC", this.window, true);
/*  171 */     setOpaque(SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.opaque", this.window, true));
/*  174 */     if (!isOpaque() && !SyntheticaLookAndFeel.isWindowOpacityEnabled(this.window))
/*  175 */       setDoubleBuffered(false); 
/*  177 */     setLayout(new GridBagLayout());
/*  178 */     setName("RootPane.titlePane");
/*  180 */     this.closeAction = new AbstractAction() {
/*      */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  184 */           SyntheticaTitlePane.this.close();
/*      */         }
/*      */       };
/*  188 */     int i = this.rootPane.getWindowDecorationStyle();
/*  189 */     boolean bool1 = SyntheticaLookAndFeel.getBoolean("Synthetica.dialog.icon.enabled", this.window);
/*  190 */     if (i == 1 || i == 3 || i == 7 || 
/*  191 */       i == 8 || i == 2 || bool1) {
/*  193 */       this.iconifyAction = new AbstractAction() {
/*      */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*  196 */             SyntheticaTitlePane.this.iconify();
/*      */           }
/*      */         };
/*  199 */       this.restoreAction = new AbstractAction() {
/*      */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*  202 */             SyntheticaTitlePane.this.restore();
/*      */           }
/*      */         };
/*  205 */       this.maximizeAction = new AbstractAction() {
/*      */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*  208 */             SyntheticaTitlePane.this.maximize();
/*      */           }
/*      */         };
/*  212 */       this.menuButton = createTitlePaneButton("RootPane.titlePane.menuButton");
/*  213 */       this.menuButton.putClientProperty("doNotCancelPopup", (new JComboBox()).getClientProperty("doNotCancelPopup"));
/*  214 */       this.menuButton.setIcon(getIcon(this.rootPane));
/*  215 */       this.menuButton.addMouseListener(new MouseAdapter() {
/*      */             public void mouseClicked(MouseEvent param1MouseEvent) {
/*  220 */               String str = System.getProperty("os.name").toLowerCase();
/*  221 */               if (param1MouseEvent.getClickCount() == 2 && str.contains("windows"))
/*  222 */                 SyntheticaTitlePane.this.closeAction.actionPerformed(new ActionEvent(param1MouseEvent.getSource(), param1MouseEvent.getID(), "doubleClick")); 
/*      */             }
/*      */           });
/*  226 */       this.systemMenu = new JPopupMenu();
/*  227 */       this.systemMenu.putClientProperty("Synthetica.popupMenu.toplevel", Boolean.valueOf(false));
/*  228 */       addMenuItems(this.systemMenu);
/*      */     } 
/*  231 */     this.titleLabel = new JLabel(" ");
/*  232 */     this.titleLabel.setName("RootPane.title");
/*  234 */     this.titleLabel.setBorder(new EmptyBorder(0, 0, 0, 0));
/*  235 */     this.titleLabel.setFont(this.titleLabel.getFont().deriveFont(1));
/*  237 */     this.menuBarLabel = new JLabel(" ");
/*  238 */     this.menuBarLabel.setName("RootPane.menuBar");
/*  240 */     this.menuBarLabel.setBorder(new EmptyBorder(0, 0, 0, 0));
/*  241 */     boolean bool2 = showMenuBarInTitlePane();
/*  242 */     this.menuBarLabel.setVisible(bool2);
/*  243 */     if (bool2)
/*  246 */       EventQueue.invokeLater(new Runnable() {
/*      */             public void run() {
/*  249 */               SyntheticaTitlePane.this.menuBarLabel.setPreferredSize(SyntheticaTitlePane.this.rootPane.getJMenuBar().getPreferredSize());
/*      */             }
/*      */           }); 
/*  254 */     createButtons();
/*  255 */     updateLayoutStyle(i, bool1);
/*  256 */     installListeners(this.rootPane);
/*  257 */     setComponentsActiveState(this.window.isActive());
/*  259 */     updateState();
/*      */   }
/*      */   
/*      */   public void updateLayoutStyle() {
/*  264 */     int i = this.rootPane.getWindowDecorationStyle();
/*  265 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.dialog.icon.enabled", this.window);
/*  266 */     updateLayoutStyle(i, bool);
/*      */   }
/*      */   
/*      */   private void updateLayoutStyle(int paramInt, boolean paramBoolean) {
/*  271 */     removeAll();
/*  272 */     LayoutStyle layoutStyle = getLayoutStyle();
/*  273 */     if (layoutStyle == LayoutStyle.REGULAR) {
/*  274 */       addControls(paramInt, paramBoolean);
/*  275 */     } else if (layoutStyle == LayoutStyle.INLINEMENU) {
/*  276 */       addControls_inlineMenuLayout(paramInt, paramBoolean);
/*  277 */     } else if (layoutStyle == LayoutStyle.INLINEMENU_LEADING) {
/*  278 */       addControls_inlineMenuLeadingLayout(paramInt, paramBoolean);
/*  279 */     } else if (layoutStyle == LayoutStyle.SECONDARYMENU) {
/*  282 */       this.menuBarLabel.setVisible(true);
/*  283 */       if (this.userComponentContainer == null)
/*  284 */         this.userComponentContainer = new UserComponentContainer(); 
/*  285 */       addControls_secondaryMenuLayout(paramInt, paramBoolean);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addControls(int paramInt, boolean paramBoolean) {
/*  291 */     int i = getXGap();
/*  293 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  295 */       add(this.closeButton, new GridBagConstraints(0, 0, 1, 2, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*  296 */       if (paramInt == 1 && this.dialog == null) {
/*  298 */         add(this.iconifyButton, new GridBagConstraints(1, 0, 1, 2, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  299 */         add(this.toggleButton, new GridBagConstraints(2, 0, 1, 2, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  301 */       add(this.titleLabel, new GridBagConstraints(3, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  302 */       add(this.menuBarLabel, new GridBagConstraints(3, 1, 1, 1, 1.0D, 1.0D, 10, 2, getMenuBarLabelInsets(i), 0, 0));
/*  303 */       if (paramInt == 1 || paramBoolean)
/*  305 */         add(this.menuButton, new GridBagConstraints(4, 0, 1, 2, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*      */     } else {
/*  309 */       if (paramInt == 1 || paramBoolean)
/*  311 */         add(this.menuButton, new GridBagConstraints(0, 0, 1, 2, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*  312 */       add(this.titleLabel, new GridBagConstraints(1, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  313 */       add(this.menuBarLabel, new GridBagConstraints(1, 1, 1, 1, 1.0D, 1.0D, 10, 2, getMenuBarLabelInsets(i), 0, 0));
/*  314 */       if (paramInt == 1 && this.dialog == null) {
/*  316 */         add(this.iconifyButton, new GridBagConstraints(2, 0, 1, 2, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  317 */         add(this.toggleButton, new GridBagConstraints(3, 0, 1, 2, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  319 */       add(this.closeButton, new GridBagConstraints(4, 0, 1, 2, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addControls_inlineMenuLayout(int paramInt, boolean paramBoolean) {
/*  326 */     int i = getXGap();
/*  328 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  330 */       add(this.closeButton, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*  331 */       if (paramInt == 1 && this.dialog == null) {
/*  333 */         add(this.iconifyButton, new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  334 */         add(this.toggleButton, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  336 */       add(this.titleLabel, new GridBagConstraints(3, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  337 */       add(this.menuBarLabel, new GridBagConstraints(4, 0, 1, 1, 0.0D, 0.0D, 10, 0, getMenuBarLabelInsets(i), 0, 0));
/*  338 */       if (paramInt == 1 || paramBoolean)
/*  339 */         add(this.menuButton, new GridBagConstraints(5, 0, 1, 1, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*      */     } else {
/*  343 */       if (paramInt == 1 || paramBoolean)
/*  344 */         add(this.menuButton, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*  345 */       add(this.titleLabel, new GridBagConstraints(1, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  346 */       add(this.menuBarLabel, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, 10, 0, getMenuBarLabelInsets(i), 0, 0));
/*  347 */       if (paramInt == 1 && this.dialog == null) {
/*  349 */         add(this.iconifyButton, new GridBagConstraints(3, 0, 1, 1, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  350 */         add(this.toggleButton, new GridBagConstraints(4, 0, 1, 1, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  352 */       add(this.closeButton, new GridBagConstraints(5, 0, 1, 1, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addControls_inlineMenuLeadingLayout(int paramInt, boolean paramBoolean) {
/*  359 */     int i = getXGap();
/*  361 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  363 */       add(this.closeButton, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*  364 */       if (paramInt == 1 && this.dialog == null) {
/*  366 */         add(this.iconifyButton, new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  367 */         add(this.toggleButton, new GridBagConstraints(2, 0, 1, 1, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  369 */       add(this.menuBarLabel, new GridBagConstraints(3, 0, 1, 1, 0.0D, 0.0D, 10, 0, getMenuBarLabelInsets(i), 0, 0));
/*  370 */       add(this.titleLabel, new GridBagConstraints(4, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  371 */       if (paramInt == 1 || paramBoolean)
/*  372 */         add(this.menuButton, new GridBagConstraints(5, 0, 1, 1, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*      */     } else {
/*  376 */       if (paramInt == 1 || paramBoolean)
/*  377 */         add(this.menuButton, new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*  378 */       add(this.menuBarLabel, new GridBagConstraints(1, 0, 1, 1, 0.0D, 0.0D, 10, 0, getMenuBarLabelInsets(i), 0, 0));
/*  379 */       add(this.titleLabel, new GridBagConstraints(2, 0, 1, 1, 1.0D, 1.0D, getTitleLabelAlignment(), 2, getTitleLabelInsets(i), 0, 0));
/*  380 */       if (paramInt == 1 && this.dialog == null) {
/*  382 */         add(this.iconifyButton, new GridBagConstraints(3, 0, 1, 1, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  383 */         add(this.toggleButton, new GridBagConstraints(4, 0, 1, 1, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  385 */       add(this.closeButton, new GridBagConstraints(5, 0, 1, 1, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addControls_secondaryMenuLayout(int paramInt, boolean paramBoolean) {
/*  391 */     int i = getXGap();
/*  393 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  395 */       add(this.closeButton, new GridBagConstraints(0, 0, 1, 2, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*  396 */       if (paramInt == 1 && this.dialog == null) {
/*  398 */         add(this.iconifyButton, new GridBagConstraints(1, 0, 1, 2, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  399 */         add(this.toggleButton, new GridBagConstraints(2, 0, 1, 2, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  401 */       add(this.menuBarLabel, new GridBagConstraints(3, 0, 1, 1, 1.0D, 1.0D, 10, 2, getMenuBarLabelInsets(i), 0, 0));
/*  402 */       add(this.userComponentContainer, new GridBagConstraints(3, 1, 1, 1, 1.0D, 1.0D, 10, 2, getUserComponentInsets(i), 0, 0));
/*  403 */       if (paramInt == 1 || paramBoolean)
/*  405 */         add(this.menuButton, new GridBagConstraints(4, 0, 1, 2, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*      */     } else {
/*  409 */       if (paramInt == 1 || paramBoolean)
/*  411 */         add(this.menuButton, new GridBagConstraints(0, 0, 1, 2, 0.0D, 0.0D, getMenuButtonAlignment(), 0, getMenuButtonInsets(i), 0, 0)); 
/*  412 */       add(this.menuBarLabel, new GridBagConstraints(1, 0, 1, 1, 1.0D, 1.0D, 10, 2, getMenuBarLabelInsets(i), 0, 0));
/*  413 */       boolean bool = (paramInt == 1 && this.dialog == null) ? true : false;
/*  414 */       add(this.userComponentContainer, new GridBagConstraints(1, 1, bool ? 4 : 2, 1, 1.0D, 1.0D, 10, 2, getUserComponentInsets(i), 0, 0));
/*  415 */       if (bool) {
/*  417 */         add(this.iconifyButton, new GridBagConstraints(2, 0, 1, 2, 0.0D, 0.0D, getIconifyButtonAlignment(), 0, getIconifyButtonInsets(i), 0, 0));
/*  418 */         add(this.toggleButton, new GridBagConstraints(3, 0, 1, 2, 0.0D, 0.0D, getToggleButtonAlignment(), 0, getToggleButtonInsets(i), 0, 0));
/*      */       } 
/*  420 */       add(this.closeButton, new GridBagConstraints(4, 0, 1, 2, 0.0D, 0.0D, getCloseButtonAlignment(), 0, getCloseButtonInsets(i), 0, 0));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setUserComponent(JComponent paramJComponent) {
/*  426 */     if (this.userComponentContainer != null) {
/*  428 */       this.userComponentContainer.removeAll();
/*  429 */       this.userComponentContainer.add(paramJComponent);
/*      */     } 
/*      */   }
/*      */   
/*      */   public JComponent getUserComponent() {
/*  435 */     return (this.userComponentContainer == null || this.userComponentContainer.getComponentCount() == 0) ? null : (JComponent)this.userComponentContainer.getComponent(0);
/*      */   }
/*      */   
/*      */   public LayoutStyle getLayoutStyle() {
/*  440 */     String str = SyntheticaLookAndFeel.getString("Synthetica.rootPane.titlePane.layoutStyle", this.window);
/*  441 */     return (str == null) ? LayoutStyle.REGULAR : LayoutStyle.valueOf(str);
/*      */   }
/*      */   
/*      */   private void installListeners(JRootPane paramJRootPane) {
/*  448 */     this.windowListener = new WindowAdapter() {
/*      */         public void windowOpened(WindowEvent param1WindowEvent) {
/*  454 */           if (OS.getCurrentOS() == OS.Linux && SyntheticaTitlePane.this.dialog != null && SyntheticaTitlePane.this.dialog.isModal() && SyntheticaLookAndFeel.getBoolean("Synthetica.dialog.modalAlwaysOnTopLinuxOnly.enabled", null, false))
/*  455 */             SyntheticaTitlePane.this.dialog.setAlwaysOnTop(true); 
/*  457 */           if (SyntheticaTitlePane.this.rootPane.getWindowDecorationStyle() == 1 && SyntheticaTitlePane.this.dialog == null) {
/*  459 */             SyntheticaTitlePane.this.updateToggleButton();
/*  460 */             SyntheticaTitlePane.this.updateState();
/*      */           } 
/*      */         }
/*      */         
/*      */         public void windowStateChanged(WindowEvent param1WindowEvent) {
/*  467 */           SyntheticaTitlePane.this.updateToggleButton();
/*  468 */           SyntheticaTitlePane.this.updateState();
/*      */         }
/*      */         
/*      */         public void windowActivated(WindowEvent param1WindowEvent) {
/*  474 */           SyntheticaTitlePane.this.setActive(true);
/*  475 */           SyntheticaTitlePane.this.selected = true;
/*      */         }
/*      */         
/*      */         public void windowDeactivated(WindowEvent param1WindowEvent) {
/*  481 */           SyntheticaTitlePane.this.setActive(false);
/*  482 */           SyntheticaTitlePane.this.selected = false;
/*      */         }
/*      */       };
/*  485 */     this.window.addWindowListener(this.windowListener);
/*  486 */     this.window.addWindowStateListener((WindowStateListener)this.windowListener);
/*  488 */     this.propertyChangeListener = new PropertyChangeListener() {
/*      */         public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*  491 */           String str = param1PropertyChangeEvent.getPropertyName();
/*  492 */           if ("resizable".equals(str)) {
/*  494 */             boolean bool = ((Boolean)param1PropertyChangeEvent.getNewValue()).booleanValue();
/*  495 */             SyntheticaTitlePane.this.toggleButton.setEnabled(bool);
/*  496 */             SyntheticaTitlePane.this.systemMenu.removeAll();
/*  497 */             SyntheticaTitlePane.this.addMenuItems(SyntheticaTitlePane.this.systemMenu);
/*  500 */           } else if ("iconImage".equals(str) && SyntheticaTitlePane.this.menuButton != null) {
/*  501 */             SyntheticaTitlePane.this.menuButton.setIcon(SyntheticaTitlePane.this.getIcon(SyntheticaTitlePane.this.rootPane));
/*  503 */           } else if ("title".equals(str)) {
/*  504 */             SyntheticaTitlePane.this.repaint();
/*  505 */           } else if ("name".equals(str)) {
/*  507 */             SyntheticaTitlePane.this.updateDefaults();
/*  508 */             SyntheticaTitlePane.this.updateLayoutStyle();
/*      */           } 
/*      */         }
/*      */       };
/*  512 */     this.window.addPropertyChangeListener(this.propertyChangeListener);
/*  514 */     this.rootPanePropertyChangeListener = new PropertyChangeListener() {
/*      */         public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/*  518 */           if ("Synthetica.dialog.iconImage".equals(param1PropertyChangeEvent.getPropertyName()) && SyntheticaTitlePane.this.menuButton != null)
/*  519 */             SyntheticaTitlePane.this.menuButton.setIcon(SyntheticaTitlePane.this.getIcon((JRootPane)param1PropertyChangeEvent.getSource())); 
/*      */         }
/*      */       };
/*  522 */     this.rootPane.addPropertyChangeListener(this.rootPanePropertyChangeListener);
/*  524 */     if (this.menuButton != null) {
/*  526 */       this.menuActionListener = new ActionListener() {
/*      */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*  530 */             if (SyntheticaTitlePane.this.systemMenu.isVisible()) {
/*  532 */               SyntheticaTitlePane.this.systemMenu.setVisible(false);
/*      */               return;
/*      */             } 
/*  536 */             int i = SyntheticaTitlePane.this.getXGap();
/*  537 */             int j = SyntheticaTitlePane.this.menuButton.getY() + SyntheticaTitlePane.this.menuButton.getHeight() + (SyntheticaTitlePane.this.getTitleLabelInsets(i)).bottom;
/*  538 */             boolean bool = (SyntheticaTitlePane.this.useMACStyle && OS.getCurrentOS() == OS.Mac) ? true : false;
/*  539 */             if ((SyntheticaTitlePane.this.isRTL() && !bool) || (!SyntheticaTitlePane.this.isRTL() && bool)) {
/*  540 */               SyntheticaTitlePane.this.systemMenu.show(SyntheticaTitlePane.this, SyntheticaTitlePane.this.menuButton.getX() + SyntheticaTitlePane.this.menuButton.getWidth() - (SyntheticaTitlePane.this.systemMenu.getPreferredSize()).width + i, j);
/*      */             } else {
/*  542 */               SyntheticaTitlePane.this.systemMenu.show(SyntheticaTitlePane.this, SyntheticaTitlePane.this.menuButton.getX() - i, j);
/*      */             } 
/*      */           }
/*      */         };
/*  545 */       this.menuButton.addActionListener(this.menuActionListener);
/*      */     } 
/*  548 */     this.layeredPaneContainerListener = new ContainerListener() {
/*      */         private ContainerListener menuBarContainerListener;
/*      */         
/*      */         private MouseInputListener menuBarMouseListener;
/*      */         
/*      */         public void componentAdded(ContainerEvent param1ContainerEvent) {
/*  555 */           if (param1ContainerEvent.getChild() instanceof JMenuBar && SyntheticaTitlePane.this.showMenuBarInTitlePane()) {
/*  557 */             JMenuBar jMenuBar = (JMenuBar)param1ContainerEvent.getChild();
/*  558 */             updatePlaceHolder(jMenuBar);
/*  559 */             SyntheticaTitlePane.this.menuBarLabel.setVisible(true);
/*  561 */             ((JLayeredPane)param1ContainerEvent.getComponent()).setComponentZOrder(jMenuBar, 1);
/*  564 */             this.menuBarMouseListener = SyntheticaTitlePane.this.rootPaneUI.getMouseInputListener();
/*  565 */             jMenuBar.addMouseListener(this.menuBarMouseListener);
/*  566 */             jMenuBar.addMouseMotionListener(this.menuBarMouseListener);
/*  569 */             this.menuBarContainerListener = new ContainerListener() {
/*      */                 public void componentRemoved(ContainerEvent param2ContainerEvent) {
/*  574 */                   SyntheticaTitlePane.null.this.updatePlaceHolder(param2ContainerEvent.getComponent());
/*      */                 }
/*      */                 
/*      */                 public void componentAdded(ContainerEvent param2ContainerEvent) {
/*  580 */                   SyntheticaTitlePane.null.this.updatePlaceHolder(param2ContainerEvent.getComponent());
/*      */                 }
/*      */               };
/*  583 */             jMenuBar.addContainerListener(this.menuBarContainerListener);
/*      */           } 
/*      */         }
/*      */         
/*      */         private void updatePlaceHolder(Component param1Component) {
/*  589 */           SyntheticaTitlePane.this.menuBarLabel.setPreferredSize(param1Component.getPreferredSize());
/*  590 */           SyntheticaTitlePane.this.menuBarLabel.setMinimumSize(param1Component.getPreferredSize());
/*      */         }
/*      */         
/*      */         public void componentRemoved(ContainerEvent param1ContainerEvent) {
/*  595 */           if (param1ContainerEvent.getChild() instanceof JMenuBar) {
/*  597 */             JMenuBar jMenuBar = (JMenuBar)param1ContainerEvent.getChild();
/*  598 */             jMenuBar.removeMouseListener(this.menuBarMouseListener);
/*  599 */             jMenuBar.removeMouseMotionListener(this.menuBarMouseListener);
/*  600 */             jMenuBar.removeContainerListener(this.menuBarContainerListener);
/*  601 */             SyntheticaTitlePane.this.menuBarLabel.setVisible(false);
/*  602 */             this.menuBarMouseListener = null;
/*  603 */             this.menuBarContainerListener = null;
/*      */           } 
/*      */         }
/*      */       };
/*  607 */     this.rootPane.getLayeredPane().addContainerListener(this.layeredPaneContainerListener);
/*      */   }
/*      */   
/*      */   void uninstallListeners(JRootPane paramJRootPane) {
/*  614 */     this.window.removeWindowListener(this.windowListener);
/*  615 */     this.window.removeWindowStateListener((WindowStateListener)this.windowListener);
/*  616 */     this.window.removePropertyChangeListener(this.propertyChangeListener);
/*  617 */     paramJRootPane.removePropertyChangeListener(this.rootPanePropertyChangeListener);
/*  618 */     paramJRootPane.getLayeredPane().removeContainerListener(this.layeredPaneContainerListener);
/*  619 */     if (this.menuButton != null)
/*  620 */       this.menuButton.removeActionListener(this.menuActionListener); 
/*      */   }
/*      */   
/*      */   private void updateDefaults() {
/*  625 */     setOpaque(SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.opaque", this.window, true));
/*  627 */     int i = getXGap();
/*  628 */     GridBagLayout gridBagLayout = (GridBagLayout)getLayout();
/*  630 */     GridBagConstraints gridBagConstraints = gridBagLayout.getConstraints(this.titleLabel);
/*  631 */     gridBagConstraints.insets = getTitleLabelInsets(i);
/*  632 */     gridBagLayout.setConstraints(this.titleLabel, gridBagConstraints);
/*  633 */     this.titleLabel.revalidate();
/*  635 */     gridBagConstraints = gridBagLayout.getConstraints(this.menuBarLabel);
/*  636 */     gridBagConstraints.insets = getMenuBarLabelInsets(i);
/*  637 */     gridBagLayout.setConstraints(this.menuBarLabel, gridBagConstraints);
/*  638 */     this.menuBarLabel.revalidate();
/*  640 */     if (this.menuButton != null) {
/*  642 */       this.menuButton.setIcon(getIcon(this.rootPane));
/*  644 */       gridBagConstraints = gridBagLayout.getConstraints(this.menuButton);
/*  645 */       gridBagConstraints.insets = getMenuButtonInsets(i);
/*  646 */       gridBagConstraints.anchor = getMenuButtonAlignment();
/*  647 */       gridBagLayout.setConstraints(this.menuButton, gridBagConstraints);
/*  648 */       this.menuButton.revalidate();
/*      */     } 
/*  651 */     if (this.iconifyButton != null) {
/*  653 */       gridBagConstraints = gridBagLayout.getConstraints(this.iconifyButton);
/*  654 */       gridBagConstraints.insets = getIconifyButtonInsets(i);
/*  655 */       gridBagConstraints.anchor = getIconifyButtonAlignment();
/*  656 */       gridBagLayout.setConstraints(this.iconifyButton, gridBagConstraints);
/*  657 */       this.iconifyButton.revalidate();
/*      */     } 
/*  660 */     if (this.toggleButton != null) {
/*  662 */       gridBagConstraints = gridBagLayout.getConstraints(this.toggleButton);
/*  663 */       gridBagConstraints.insets = getToggleButtonInsets(i);
/*  664 */       gridBagConstraints.anchor = getToggleButtonAlignment();
/*  665 */       gridBagLayout.setConstraints(this.toggleButton, gridBagConstraints);
/*  666 */       this.toggleButton.revalidate();
/*      */     } 
/*  669 */     gridBagConstraints = gridBagLayout.getConstraints(this.closeButton);
/*  670 */     gridBagConstraints.insets = getCloseButtonInsets(i);
/*  671 */     gridBagConstraints.anchor = getCloseButtonAlignment();
/*  672 */     gridBagLayout.setConstraints(this.closeButton, gridBagConstraints);
/*  673 */     this.closeButton.revalidate();
/*      */   }
/*      */   
/*      */   boolean showMenuBarInTitlePane() {
/*  678 */     return (this.rootPane.getJMenuBar() != null && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.showMenuBarInTitlePane", this.window, false));
/*      */   }
/*      */   
/*      */   boolean clipMenuBarWidth() {
/*  683 */     return (this.rootPane.getJMenuBar() != null && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.clipMenuBarWidth", this.window, false));
/*      */   }
/*      */   
/*      */   private int getXGap() {
/*  688 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.gap", this.window, 4);
/*      */   }
/*      */   
/*      */   private Insets getTitleLabelInsets(int paramInt) {
/*  693 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.title.insets", this.window, new Insets(3, 0, 4, 0));
/*  694 */     return new Insets(insets.top, insets.left + paramInt, insets.bottom, insets.right + paramInt);
/*      */   }
/*      */   
/*      */   private Insets getMenuBarLabelInsets(int paramInt) {
/*  699 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.menuBar.insets", this.window, false);
/*  700 */     return new Insets(insets.top, insets.left + paramInt, insets.bottom, insets.right + paramInt);
/*      */   }
/*      */   
/*      */   private Insets getUserComponentInsets(int paramInt) {
/*  705 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.userComponent.insets", this.window, false);
/*  706 */     return new Insets(insets.top, insets.left + paramInt, insets.bottom, insets.right + paramInt);
/*      */   }
/*      */   
/*      */   private Insets getMenuButtonInsets(int paramInt) {
/*  711 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.menuButton.insets", this.window, false);
/*  712 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac)
/*  713 */       return new Insets(insets.top, insets.right, insets.bottom, insets.left + paramInt); 
/*  714 */     return new Insets(insets.top, insets.left + paramInt, insets.bottom, insets.right);
/*      */   }
/*      */   
/*      */   private Insets getIconifyButtonInsets(int paramInt) {
/*  719 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.iconifyButton.insets", this.window, false);
/*  720 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  722 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.iconifyButton.gap", this.window, 0);
/*  723 */       return new Insets(insets.top, insets.left + j, insets.bottom, insets.right);
/*      */     } 
/*  725 */     int i = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.iconifyButton.gap", this.window, 0);
/*  726 */     return new Insets(insets.top, insets.left, insets.bottom, insets.right + i);
/*      */   }
/*      */   
/*      */   private Insets getToggleButtonInsets(int paramInt) {
/*  731 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.toggleButton.insets", this.window, false);
/*  732 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/*  734 */       int j = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.toggleButton.gap", this.window, 0);
/*  735 */       return new Insets(insets.top, insets.left + j, insets.bottom, insets.right);
/*      */     } 
/*  737 */     int i = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.toggleButton.gap", this.window, paramInt);
/*  738 */     return new Insets(insets.top, insets.left, insets.bottom, insets.right + i);
/*      */   }
/*      */   
/*      */   private Insets getCloseButtonInsets(int paramInt) {
/*  743 */     Insets insets = SyntheticaLookAndFeel.getInsets("Synthetica.rootPane.titlePane.closeButton.insets", this.window, false);
/*  744 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac)
/*  745 */       return new Insets(insets.top, insets.right + paramInt, insets.bottom, insets.left); 
/*  746 */     return new Insets(insets.top, insets.left, insets.bottom, insets.right + paramInt);
/*      */   }
/*      */   
/*      */   private int getMenuButtonAlignment() {
/*  751 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.menuButton.alignment", this.window, 10);
/*      */   }
/*      */   
/*      */   private int getTitleLabelAlignment() {
/*  756 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.title.alignment", this.window, 10);
/*      */   }
/*      */   
/*      */   private int getIconifyButtonAlignment() {
/*  761 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.iconifyButton.alignment", this.window, 10);
/*      */   }
/*      */   
/*      */   private int getToggleButtonAlignment() {
/*  766 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.toggleButton.alignment", this.window, 10);
/*      */   }
/*      */   
/*      */   private int getCloseButtonAlignment() {
/*  771 */     return SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.closeButton.alignment", this.window, 10);
/*      */   }
/*      */   
/*      */   public JRootPane getRootPane() {
/*  778 */     return this.rootPane;
/*      */   }
/*      */   
/*      */   public Dimension getPreferredSize() {
/*  786 */     if (isTitlePaneEnabled())
/*  787 */       return super.getPreferredSize(); 
/*  788 */     return new Dimension(0, 0);
/*      */   }
/*      */   
/*      */   public Dimension getMinimumSize() {
/*  796 */     if (isTitlePaneEnabled())
/*  797 */       return super.getMinimumSize(); 
/*  798 */     return new Dimension(0, 0);
/*      */   }
/*      */   
/*      */   boolean isTitlePaneEnabled() {
/*  805 */     boolean bool = (this.rootPane.getClientProperty("Synthetica.titlePane.enabled") == null) ? false : (((Boolean)this.rootPane.getClientProperty("Synthetica.titlePane.enabled")).booleanValue() ? false : true);
/*  806 */     String str = String.valueOf(this.rootPane.getParent().getClass().getName()) + ".titlePane.enabled";
/*  807 */     if ((UIManager.get(str) != null && !UIManager.getBoolean(str)) || bool)
/*  808 */       return false; 
/*  809 */     return true;
/*      */   }
/*      */   
/*      */   private String getTitle() {
/*  816 */     if (this.frame != null)
/*  817 */       return this.frame.getTitle(); 
/*  818 */     if (this.dialog != null)
/*  819 */       return this.dialog.getTitle(); 
/*  820 */     return null;
/*      */   }
/*      */   
/*      */   private Icon getFrameIcon() {
/*  827 */     Image image = (this.frame != null) ? this.frame.getIconImage() : null;
/*  828 */     Icon icon = null;
/*  829 */     if (image != null) {
/*  831 */       icon = image2Icon(image);
/*      */     } else {
/*  835 */       SynthStyle synthStyle = SynthLookAndFeel.getStyle(this.rootPane, Region.ROOT_PANE);
/*  836 */       SynthContext synthContext = new SynthContext(this.rootPane, Region.ROOT_PANE, synthStyle, 0);
/*  837 */       icon = synthStyle.getIcon(synthContext, "RootPane.icon");
/*      */     } 
/*  839 */     return icon;
/*      */   }
/*      */   
/*      */   private Icon getIcon(JRootPane paramJRootPane) {
/*  846 */     Icon icon = getFrameIcon();
/*  848 */     if (paramJRootPane.getWindowDecorationStyle() == 1 || paramJRootPane == null)
/*  849 */       return icon; 
/*  851 */     if (paramJRootPane.getClientProperty("Synthetica.dialog.iconImage") != null) {
/*  853 */       Image image = (Image)paramJRootPane.getClientProperty("Synthetica.dialog.iconImage");
/*  854 */       return image2Icon(image);
/*      */     } 
/*  857 */     if (this.window instanceof JDialog && !JavaVersion.JAVA5 && ((JDialog)this.window).getIconImages().size() > 0)
/*  858 */       return image2Icon(((JDialog)paramJRootPane.getParent()).getIconImages().get(0)); 
/*  861 */     if (this.window != null && this.window.getOwner() != null) {
/*  863 */       Window window = this.window.getOwner();
/*  864 */       if (window instanceof JFrame) {
/*  865 */         paramJRootPane = ((JFrame)window).getRootPane();
/*  866 */       } else if (window instanceof JDialog) {
/*  867 */         paramJRootPane = ((JDialog)window).getRootPane();
/*      */       } else {
/*  870 */         paramJRootPane = null;
/*      */       } 
/*  872 */       if (paramJRootPane != null && paramJRootPane.getUI() instanceof SyntheticaRootPaneUI && ((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane() != null)
/*  873 */         return ((SyntheticaTitlePane)((SyntheticaRootPaneUI)paramJRootPane.getUI()).getTitlePane()).getIcon(paramJRootPane); 
/*      */     } 
/*  876 */     return icon;
/*      */   }
/*      */   
/*      */   private Icon image2Icon(Image paramImage) {
/*  883 */     Object object = paramImage.getProperty("comment", null);
/*  884 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.menuButton.useOriginalImageSize", this.window))
/*  885 */       return new ImageIcon(paramImage, (object instanceof String) ? (String)object : ""); 
/*  886 */     return new ImageIcon(paramImage.getScaledInstance(16, 16, 4), (object instanceof String) ? (String)object : "");
/*      */   }
/*      */   
/*      */   private void setActive(boolean paramBoolean) {
/*  893 */     setComponentsActiveState(paramBoolean);
/*  895 */     getRootPane().repaint();
/*      */   }
/*      */   
/*      */   private void setComponentsActiveState(boolean paramBoolean) {
/*  904 */     JInternalFrame jInternalFrame = this.iFrameDelegate;
/*  905 */     jInternalFrame.setName(this.window.getName());
/*  907 */     SynthStyle synthStyle = SynthLookAndFeel.getStyleFactory().getStyle(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE);
/*  908 */     SynthContext synthContext = new SynthContext(jInternalFrame, Region.INTERNAL_FRAME_TITLE_PANE, synthStyle, paramBoolean ? 512 : 0);
/*  910 */     Font font = getFont();
/*  911 */     if (font == null || font instanceof javax.swing.plaf.UIResource)
/*  912 */       font = synthStyle.getFont(synthContext); 
/*  914 */     float f = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.title.fontSize", this.window);
/*  915 */     if (f == 0.0F) {
/*  916 */       f = font.getSize();
/*      */     } else {
/*  918 */       f = SyntheticaLookAndFeel.scaleFontSize(f);
/*      */     } 
/*  919 */     font = font.deriveFont(font.getStyle(), f);
/*  920 */     this.titleLabel.setFont(font);
/*  922 */     Color color = SyntheticaLookAndFeel.getColor("Synthetica.rootPane.titlePane.foreground" + (paramBoolean ? ".selected" : ""), this.window, getForeground());
/*  923 */     if (color == null || color instanceof javax.swing.plaf.UIResource)
/*  924 */       color = synthStyle.getColor(synthContext, ColorType.FOREGROUND); 
/*  927 */     color = new Color(color.getRGB());
/*  928 */     this.titleLabel.setForeground(color);
/*  930 */     this.closeButton.putClientProperty("paintActive", Boolean.valueOf(paramBoolean));
/*  931 */     if (this.rootPane.getWindowDecorationStyle() == 1 && this.dialog == null) {
/*  933 */       this.iconifyButton.putClientProperty("paintActive", Boolean.valueOf(paramBoolean));
/*  934 */       this.toggleButton.putClientProperty("paintActive", Boolean.valueOf(paramBoolean));
/*      */     } 
/*  937 */     updateToggleButton();
/*  938 */     if (this.iconifyButton != null)
/*  939 */       this.iconifyButton.setIcon(paramBoolean ? (Icon)this.iconifyButton.getClientProperty("Synthetica.iconifyIcon") : (Icon)this.iconifyButton.getClientProperty("Synthetica.iconifyIcon.inactive")); 
/*  940 */     if (this.closeButton != null)
/*  941 */       this.closeButton.setIcon(paramBoolean ? (Icon)this.closeButton.getClientProperty("Synthetica.closeIcon") : (Icon)this.closeButton.getClientProperty("Synthetica.closeIcon.inactive")); 
/*      */   }
/*      */   
/*      */   private boolean isFrameResizable() {
/*  953 */     return (this.frame != null && this.frame.isResizable());
/*      */   }
/*      */   
/*      */   private boolean isFrameMaximized() {
/*  960 */     return (this.frame != null && (this.frame.getExtendedState() & 0x6) == 6);
/*      */   }
/*      */   
/*      */   private void addMenuItems(JPopupMenu paramJPopupMenu) {
/*  969 */     JMenuItem jMenuItem = paramJPopupMenu.add(this.restoreAction);
/*  970 */     jMenuItem.setText(SyntheticaLookAndFeel.getString("InternalFrameTitlePane.restoreButtonText", this.window));
/*  971 */     jMenuItem.setMnemonic('R');
/*  972 */     jMenuItem.setEnabled(isFrameResizable());
/*  974 */     jMenuItem = paramJPopupMenu.add(this.iconifyAction);
/*  975 */     jMenuItem.setText(SyntheticaLookAndFeel.getString("InternalFrameTitlePane.minimizeButtonText", this.window));
/*  976 */     jMenuItem.setMnemonic('n');
/*  977 */     jMenuItem.setEnabled((this.frame != null));
/*  979 */     if (Toolkit.getDefaultToolkit().isFrameStateSupported(6)) {
/*  981 */       jMenuItem = paramJPopupMenu.add(this.maximizeAction);
/*  982 */       jMenuItem.setText(SyntheticaLookAndFeel.getString("InternalFrameTitlePane.maximizeButtonText", this.window));
/*  983 */       jMenuItem.setMnemonic('x');
/*  984 */       jMenuItem.setEnabled(isFrameResizable());
/*      */     } 
/*  987 */     paramJPopupMenu.addSeparator();
/*  989 */     jMenuItem = paramJPopupMenu.add(this.closeAction);
/*  990 */     jMenuItem.setText(SyntheticaLookAndFeel.getString("InternalFrameTitlePane.closeButtonText", this.window));
/*  991 */     jMenuItem.setMnemonic('C');
/*  992 */     if (this.closeButton != null)
/*  993 */       jMenuItem.setEnabled(this.closeButton.isVisible() & this.closeButton.isEnabled()); 
/*      */   }
/*      */   
/*      */   private JButton createTitlePaneButton(String paramString) {
/* 1000 */     JButton jButton = new JButton();
/* 1001 */     jButton.setName(paramString);
/* 1003 */     jButton.setFocusPainted(false);
/* 1004 */     jButton.setFocusable(false);
/* 1005 */     jButton.setOpaque(false);
/* 1006 */     jButton.setBorder(BorderFactory.createEmptyBorder());
/* 1007 */     return jButton;
/*      */   }
/*      */   
/*      */   private void createButtons() {
/* 1014 */     MouseAdapter mouseAdapter = new MouseAdapter() {
/*      */         public void mouseEntered(MouseEvent param1MouseEvent) {
/* 1018 */           JButton jButton = (JButton)param1MouseEvent.getSource();
/* 1019 */           String str = "Synthetica." + jButton.getClientProperty("Synthetica.buttonID") + "Icon.hover";
/* 1021 */           jButton.setIcon((Icon)jButton.getClientProperty(str));
/*      */         }
/*      */         
/*      */         public void mouseExited(MouseEvent param1MouseEvent) {
/* 1026 */           JButton jButton = (JButton)param1MouseEvent.getSource();
/* 1027 */           String str = "Synthetica." + jButton.getClientProperty("Synthetica.buttonID") + "Icon";
/* 1029 */           if (!SyntheticaTitlePane.this.window.isActive())
/* 1030 */             str = String.valueOf(str) + ".inactive"; 
/* 1031 */           jButton.setIcon((Icon)jButton.getClientProperty(str));
/*      */         }
/*      */       };
/* 1035 */     SynthStyle synthStyle = SynthLookAndFeel.getStyle(this.rootPane, Region.ROOT_PANE);
/* 1036 */     SynthContext synthContext = new SynthContext(this.rootPane, Region.ROOT_PANE, synthStyle, 0);
/* 1037 */     Icon icon1 = synthStyle.getIcon(synthContext, "RootPane.closeIcon");
/* 1038 */     Icon icon2 = synthStyle.getIcon(synthContext, "RootPane.iconifyIcon");
/* 1039 */     Icon icon3 = synthStyle.getIcon(synthContext, "RootPane.maximizeIcon");
/* 1040 */     Icon icon4 = synthStyle.getIcon(synthContext, "RootPane.minimizeIcon");
/* 1043 */     Icon icon5 = (synthStyle.getIcon(synthContext, "RootPane.closeIcon.inactive") == null) ? icon1 : synthStyle.getIcon(synthContext, "RootPane.closeIcon.inactive");
/* 1044 */     Icon icon6 = (synthStyle.getIcon(synthContext, "RootPane.iconifyIcon.inactive") == null) ? icon2 : synthStyle.getIcon(synthContext, "RootPane.iconifyIcon.inactive");
/* 1045 */     Icon icon7 = (synthStyle.getIcon(synthContext, "RootPane.maximizeIcon.inactive") == null) ? icon3 : synthStyle.getIcon(synthContext, "RootPane.maximizeIcon.inactive");
/* 1046 */     Icon icon8 = (synthStyle.getIcon(synthContext, "RootPane.minimizeIcon.inactive") == null) ? icon4 : synthStyle.getIcon(synthContext, "RootPane.minimizeIcon.inactive");
/* 1048 */     synthContext = new SynthContext(this.rootPane, Region.ROOT_PANE, synthStyle, 2);
/* 1049 */     Icon icon9 = synthStyle.getIcon(synthContext, "RootPane.closeIcon");
/* 1050 */     Icon icon10 = synthStyle.getIcon(synthContext, "RootPane.iconifyIcon");
/* 1051 */     Icon icon11 = synthStyle.getIcon(synthContext, "RootPane.maximizeIcon");
/* 1052 */     Icon icon12 = synthStyle.getIcon(synthContext, "RootPane.minimizeIcon");
/* 1054 */     synthContext = new SynthContext(this.rootPane, Region.ROOT_PANE, synthStyle, 4);
/* 1056 */     Icon icon13 = (synthStyle.getIcon(synthContext, "RootPane.closeIcon") == icon1) ? null : synthStyle.getIcon(synthContext, "RootPane.closeIcon");
/* 1057 */     Icon icon14 = (synthStyle.getIcon(synthContext, "RootPane.iconifyIcon") == icon2) ? null : synthStyle.getIcon(synthContext, "RootPane.iconifyIcon");
/* 1058 */     Icon icon15 = (synthStyle.getIcon(synthContext, "RootPane.maximizeIcon") == icon3) ? null : synthStyle.getIcon(synthContext, "RootPane.maximizeIcon");
/* 1059 */     Icon icon16 = (synthStyle.getIcon(synthContext, "RootPane.minimizeIcon") == icon4) ? null : synthStyle.getIcon(synthContext, "RootPane.minimizeIcon");
/* 1061 */     this.closeButton = createTitlePaneButton("RootPane.titlePane.closeButton");
/* 1062 */     this.closeButton.putClientProperty("Synthetica.buttonID", "close");
/* 1063 */     this.closeButton.putClientProperty("Synthetica.closeIcon", icon1);
/* 1064 */     this.closeButton.putClientProperty("Synthetica.closeIcon.hover", icon9);
/* 1065 */     this.closeButton.putClientProperty("Synthetica.closeIcon.inactive", icon5);
/* 1066 */     this.closeButton.setAction(this.closeAction);
/* 1067 */     this.closeButton.getAccessibleContext().setAccessibleName("Close");
/* 1068 */     this.closeButton.setIcon(icon1);
/* 1069 */     this.closeButton.setPressedIcon(icon13);
/* 1070 */     this.closeButton.addMouseListener(mouseAdapter);
/* 1071 */     CloseButtonStateListener closeButtonStateListener = new CloseButtonStateListener(null);
/* 1072 */     this.closeButton.addPropertyChangeListener(closeButtonStateListener);
/* 1073 */     this.closeButton.addComponentListener(closeButtonStateListener);
/* 1075 */     if (this.rootPane.getWindowDecorationStyle() == 1 && this.dialog == null) {
/* 1077 */       this.iconifyButton = createTitlePaneButton("RootPane.titlePane.iconifyButton");
/* 1078 */       this.iconifyButton.putClientProperty("Synthetica.buttonID", "iconify");
/* 1079 */       this.iconifyButton.putClientProperty("Synthetica.iconifyIcon", icon2);
/* 1080 */       this.iconifyButton.putClientProperty("Synthetica.iconifyIcon.hover", icon10);
/* 1081 */       this.iconifyButton.putClientProperty("Synthetica.iconifyIcon.inactive", icon6);
/* 1082 */       this.iconifyButton.setAction(this.iconifyAction);
/* 1083 */       this.iconifyButton.getAccessibleContext().setAccessibleName("Iconify");
/* 1084 */       this.iconifyButton.setIcon(icon2);
/* 1085 */       this.iconifyButton.setPressedIcon(icon14);
/* 1086 */       this.iconifyButton.addMouseListener(mouseAdapter);
/* 1088 */       this.toggleButton = createTitlePaneButton("RootPane.titlePane.toggleButton");
/* 1089 */       this.toggleButton.putClientProperty("Synthetica.maximizeIcon", icon3);
/* 1090 */       this.toggleButton.putClientProperty("Synthetica.maximizeIcon.hover", icon11);
/* 1091 */       this.toggleButton.putClientProperty("Synthetica.maximizeIcon.pressed", icon15);
/* 1092 */       this.toggleButton.putClientProperty("Synthetica.maximizeIcon.inactive", icon7);
/* 1093 */       this.toggleButton.putClientProperty("Synthetica.minimizeIcon", icon4);
/* 1094 */       this.toggleButton.putClientProperty("Synthetica.minimizeIcon.hover", icon12);
/* 1095 */       this.toggleButton.putClientProperty("Synthetica.minimizeIcon.pressed", icon16);
/* 1096 */       this.toggleButton.putClientProperty("Synthetica.minimizeIcon.inactive", icon8);
/* 1097 */       updateToggleButton();
/* 1098 */       this.toggleButton.addMouseListener(mouseAdapter);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void updateToggleButton() {
/* 1106 */     if (this.toggleButton == null)
/*      */       return; 
/* 1109 */     boolean bool = this.window.isActive();
/* 1110 */     Icon icon1 = null;
/* 1111 */     Icon icon2 = null;
/* 1112 */     if (!isFrameMaximized()) {
/* 1114 */       this.toggleButton.setAction(this.maximizeAction);
/* 1115 */       this.toggleButton.getAccessibleContext().setAccessibleName("Maximize");
/* 1116 */       this.toggleButton.putClientProperty("Synthetica.buttonID", "maximize");
/* 1117 */       if (!bool) {
/* 1118 */         icon1 = (Icon)this.toggleButton.getClientProperty("Synthetica.maximizeIcon.inactive");
/*      */       } else {
/* 1120 */         icon1 = (Icon)this.toggleButton.getClientProperty("Synthetica.maximizeIcon");
/*      */       } 
/* 1121 */       icon2 = (Icon)this.toggleButton.getClientProperty("Synthetica.maximizeIcon.pressed");
/*      */     } else {
/* 1125 */       this.toggleButton.setAction(this.restoreAction);
/* 1126 */       this.toggleButton.getAccessibleContext().setAccessibleName("Restore");
/* 1127 */       this.toggleButton.putClientProperty("Synthetica.buttonID", "minimize");
/* 1128 */       if (!bool) {
/* 1129 */         icon1 = (Icon)this.toggleButton.getClientProperty("Synthetica.minimizeIcon.inactive");
/*      */       } else {
/* 1131 */         icon1 = (Icon)this.toggleButton.getClientProperty("Synthetica.minimizeIcon");
/*      */       } 
/* 1132 */       icon2 = (Icon)this.toggleButton.getClientProperty("Synthetica.minimizeIcon.pressed");
/*      */     } 
/* 1134 */     this.toggleButton.setIcon(icon1);
/* 1135 */     this.toggleButton.setPressedIcon(icon2);
/* 1136 */     this.toggleButton.setEnabled(isFrameResizable());
/*      */   }
/*      */   
/*      */   public void paintComponent(Graphics paramGraphics) {
/* 1143 */     super.paintComponent(paramGraphics);
/* 1145 */     SynthContext synthContext = SyntheticaLookAndFeel.createContext(this.rootPane, Region.ROOT_PANE, this.selected ? 512 : 0);
/* 1146 */     ((SyntheticaPainter)SyntheticaPainter.getInstance()).paintRootPaneTitlePaneBackground(synthContext, paramGraphics, 0, 0, getWidth(), getHeight());
/* 1148 */     Rectangle rectangle1 = getControlButtonsBounds();
/* 1150 */     if (rectangle1.width > 0 && rectangle1.height > 0)
/* 1151 */       ((SyntheticaPainter)SyntheticaPainter.getInstance()).paintRootPaneButtonAreaBackground(synthContext, paramGraphics, rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height); 
/* 1153 */     String str1 = getTitle();
/* 1154 */     if (str1 == null || str1.length() == 0)
/*      */       return; 
/* 1157 */     GridBagLayout gridBagLayout = (GridBagLayout)getLayout();
/* 1158 */     Insets insets = (gridBagLayout.getConstraints(this.titleLabel)).insets;
/* 1159 */     FontMetrics fontMetrics = getFontMetrics(this.titleLabel.getFont());
/* 1160 */     boolean bool1 = (OS.getCurrentOS() == OS.Mac && this.useMACStyle) ? true : false;
/* 1161 */     boolean bool2 = (!SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.title.center", this.window) && !bool1) ? false : true;
/* 1162 */     int i = getXGap();
/* 1163 */     Rectangle rectangle2 = getMenuButtonBounds();
/* 1164 */     if (this.menuButton != null)
/* 1165 */       rectangle2.width += (gridBagLayout.getConstraints(this.menuButton)).insets.right; 
/* 1166 */     Rectangle rectangle3 = getControlButtonsBounds();
/* 1168 */     boolean bool3 = isRTL();
/* 1169 */     int j = fontMetrics.stringWidth(str1);
/* 1170 */     int k = fontMetrics.getHeight();
/* 1173 */     int m = (getTitleLabelAlignment() == 10) ? ((getHeight() - k + insets.top - insets.bottom) / 2) : this.titleLabel.getY();
/* 1175 */     if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.showMenuBarInTitlePane", this.window, false))
/* 1176 */       m = this.titleLabel.getY() + (this.titleLabel.getInsets()).top; 
/* 1177 */     int n = (bool1 || bool3) ? (rectangle3.x + rectangle3.width + insets.right) : (rectangle2.x + rectangle2.width + insets.left);
/* 1178 */     int i1 = (bool1 || bool3) ? (rectangle2.x - j - insets.left) : (rectangle3.x - j - insets.right);
/* 1179 */     i1 = Math.max(n, i1);
/* 1181 */     int i2 = bool3 ? i1 : n;
/* 1182 */     i2 = bool2 ? (bool3 ? Math.min(i2, getWidth() / 2 - fontMetrics.stringWidth(str1) / 2) : Math.max(i2, getWidth() / 2 - fontMetrics.stringWidth(str1) / 2)) : i2;
/* 1183 */     if (!bool1) {
/* 1185 */       i2 = bool3 ? Math.min(i2, i1) : Math.max(i2, n);
/* 1186 */       i2 = bool3 ? Math.max(i2, n) : Math.min(i2, i1);
/*      */     } 
/* 1189 */     Rectangle rectangle4 = getBounds();
/* 1190 */     SynthStyle synthStyle = SynthLookAndFeel.getStyle(this.iFrameDelegate, Region.INTERNAL_FRAME_TITLE_PANE);
/* 1191 */     synthContext = new SynthContext(this.iFrameDelegate, Region.INTERNAL_FRAME_TITLE_PANE, synthStyle, this.selected ? 512 : 0);
/* 1192 */     rectangle4.width -= rectangle2.width + rectangle3.width + i * 2 + insets.left + insets.right;
/* 1193 */     if (showMenuBarInTitlePane() && getLayoutStyle() == LayoutStyle.INLINEMENU) {
/* 1195 */       if (bool3) {
/* 1197 */         double d = Math.max(0.0D, this.menuBarLabel.getBounds().getX() + this.menuBarLabel.getBounds().getWidth() + insets.right - i2);
/* 1198 */         i2 = (int)(i2 + d);
/* 1199 */         rectangle4.width = (int)(rectangle4.width - this.menuBarLabel.getBounds().getWidth());
/*      */       } else {
/* 1202 */         rectangle4.width = (int)(rectangle4.width - this.menuBarLabel.getBounds().getWidth() + (bool2 ? (i2 - rectangle2.width - i - insets.left) : false));
/*      */       } 
/* 1204 */     } else if (showMenuBarInTitlePane() && getLayoutStyle() == LayoutStyle.INLINEMENU_LEADING) {
/* 1206 */       if (!bool3) {
/* 1208 */         double d = Math.max(0.0D, this.menuBarLabel.getBounds().getX() + this.menuBarLabel.getBounds().getWidth() + insets.right - i2);
/* 1209 */         i2 = (int)(i2 + d);
/* 1210 */         rectangle4.width = (int)(rectangle4.width - this.menuBarLabel.getBounds().getWidth());
/*      */       } else {
/* 1213 */         rectangle4.width = (int)(rectangle4.width - this.menuBarLabel.getBounds().getWidth() + (bool2 ? (i2 - rectangle2.width - i - insets.left) : false));
/*      */       } 
/*      */     } 
/* 1216 */     String str2 = synthStyle.getGraphicsUtils(synthContext).layoutText(synthContext, fontMetrics, str1, null, 0, 0, 0, 0, rectangle4, new Rectangle(0, 0), new Rectangle(0, 0), 0);
/* 1217 */     if ("...".equals(str2))
/* 1218 */       str2 = ""; 
/* 1220 */     boolean bool4 = SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.title.visible", this.window, true);
/* 1221 */     boolean bool5 = (this.rootPane.getClientProperty("Synthetica.logoRenderer") != null) ? true : false;
/* 1222 */     if (bool4 && (!bool5 || ((
/* 1223 */       !bool5 || this.rootPane.getClientProperty("Synthetica.paintTitle") != null) && ((Boolean)this.rootPane.getClientProperty("Synthetica.paintTitle")).booleanValue()))) {
/* 1225 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.dropShadow", this.window) && this.selected) {
/* 1227 */         BufferedImage bufferedImage = new BufferedImage(j, k, 2);
/* 1228 */         Graphics2D graphics2D = bufferedImage.createGraphics();
/* 1229 */         graphics2D.setFont(this.titleLabel.getFont());
/* 1230 */         graphics2D.drawString(str2, 0, fontMetrics.getAscent());
/* 1231 */         graphics2D.dispose();
/* 1232 */         DropShadow dropShadow = new DropShadow(bufferedImage);
/* 1233 */         dropShadow.setDistance(SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.dropShadow.distance", this.window, -5));
/* 1234 */         dropShadow.setShadowColor(SyntheticaLookAndFeel.getColor("Synthetica.rootPane.titlePane.dropShadow.color", this.window, dropShadow.getShadowColor()));
/* 1235 */         dropShadow.setQuality(SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.dropShadow.highQuality", this.window, dropShadow.getHighQuality()));
/* 1236 */         dropShadow.setShadowOpacity(SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.dropShadow.opacity", this.window, (int)(dropShadow.getShadowOpacity() * 100.0F)) / 100.0F);
/* 1237 */         dropShadow.setShadowSize(SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.dropShadow.size", this.window, dropShadow.getShadowSize()));
/* 1238 */         int i3 = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.dropShadow.xOffset", this.window, 0);
/* 1239 */         int i4 = SyntheticaLookAndFeel.getInt("Synthetica.rootPane.titlePane.dropShadow.yOffset", this.window, 0);
/* 1240 */         dropShadow.paintShadow(paramGraphics, i2 + i3, m + i4);
/*      */       } 
/* 1243 */       paramGraphics.setFont(this.titleLabel.getFont());
/* 1245 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.title.etchedTop", this.window)) {
/* 1247 */         paramGraphics.setColor(Color.BLACK);
/* 1248 */         synthStyle.getGraphicsUtils(synthContext).paintText(synthContext, paramGraphics, str2, i2, m - 1, -2);
/*      */       } 
/* 1250 */       if (SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.titlePane.title.etchedBottom", this.window)) {
/* 1252 */         paramGraphics.setColor(Color.WHITE);
/* 1253 */         synthStyle.getGraphicsUtils(synthContext).paintText(synthContext, paramGraphics, str2, i2, m + 1, -2);
/*      */       } 
/* 1256 */       Color color = SyntheticaLookAndFeel.getColor("Synthetica.rootPane.titlePane.foreground" + (this.window.isActive() ? ".selected" : ""), this.window, synthStyle.getColor(synthContext, ColorType.FOREGROUND));
/* 1257 */       paramGraphics.setColor(color);
/* 1259 */       synthStyle.getGraphicsUtils(synthContext).paintText(synthContext, paramGraphics, str2, i2, m, -2);
/*      */     } 
/*      */   }
/*      */   
/*      */   public Rectangle getControlButtonsBounds() {
/* 1269 */     Rectangle rectangle = this.closeButton.getBounds();
/* 1270 */     if (this.useMACStyle && OS.getCurrentOS() == OS.Mac) {
/* 1272 */       if (this.toggleButton != null)
/* 1273 */         rectangle.width = (this.toggleButton.getBounds()).x + (this.toggleButton.getBounds()).width - rectangle.x; 
/* 1277 */     } else if (this.iconifyButton != null) {
/* 1279 */       Rectangle rectangle1 = this.iconifyButton.getBounds();
/* 1280 */       if (isRTL()) {
/* 1281 */         rectangle.width = rectangle1.x + rectangle1.width - rectangle.x;
/*      */       } else {
/* 1284 */         rectangle.width = rectangle.x + rectangle.width - rectangle1.x;
/* 1285 */         rectangle.x = rectangle1.x;
/*      */       } 
/*      */     } 
/* 1289 */     return rectangle;
/*      */   }
/*      */   
/*      */   public Rectangle getMenuButtonBounds() {
/* 1296 */     Rectangle rectangle = (this.menuButton == null) ? new Rectangle(0, 0, 0, 0) : this.menuButton.getBounds();
/* 1297 */     if (this.menuButton == null) {
/* 1299 */       rectangle.x = isRTL() ? ((getBounds()).width - 1) : 0;
/* 1300 */       rectangle.y = (getBounds()).y;
/*      */     } 
/* 1302 */     return rectangle;
/*      */   }
/*      */   
/*      */   private void close() {
/* 1309 */     this.window.dispatchEvent(new WindowEvent(this.window, 201));
/*      */   }
/*      */   
/*      */   void iconify() {
/* 1316 */     int i = this.frame.getExtendedState();
/* 1317 */     this.frame.setExtendedState(i | 0x1);
/* 1318 */     updateState();
/*      */   }
/*      */   
/*      */   void maximize() {
/* 1325 */     int i = this.frame.getExtendedState();
/* 1326 */     this.rootPaneUI.setMaximizedBounds(this.frame);
/* 1328 */     this.frame.setExtendedState(i | 0x6);
/* 1329 */     updateState();
/* 1331 */     if (OS.getCurrentOS() == OS.Mac && isFullScreenOnMacSupported(this.frame))
/* 1333 */       this.frame.getGraphicsConfiguration().getDevice().setFullScreenWindow(this.frame); 
/*      */   }
/*      */   
/*      */   void restore() {
/* 1343 */     if (OS.getCurrentOS() == OS.Mac && isFullScreenOnMacSupported(this.frame))
/* 1345 */       this.frame.getGraphicsConfiguration().getDevice().setFullScreenWindow(null); 
/* 1349 */     int i = this.frame.getExtendedState();
/* 1350 */     if ((i & 0x1) == 1) {
/* 1351 */       this.frame.setExtendedState(i ^ 0x1);
/* 1352 */     } else if ((i & 0x6) == 6) {
/* 1354 */       this.frame.setMaximizedBounds((Rectangle)null);
/* 1355 */       this.frame.setExtendedState(i ^ 0x6);
/*      */     } 
/* 1357 */     updateState();
/*      */   }
/*      */   
/*      */   private void updateState() {
/* 1365 */     if (this.frame == null)
/*      */       return; 
/* 1367 */     if (!isFrameResizable()) {
/* 1369 */       this.restoreAction.setEnabled(false);
/* 1370 */       this.maximizeAction.setEnabled(false);
/* 1371 */       this.iconifyAction.setEnabled(true);
/*      */       return;
/*      */     } 
/* 1375 */     switch (this.frame.getExtendedState()) {
/*      */       case 6:
/* 1378 */         this.restoreAction.setEnabled(true);
/* 1379 */         this.maximizeAction.setEnabled(false);
/* 1380 */         this.iconifyAction.setEnabled(true);
/*      */         break;
/*      */       case 1:
/* 1383 */         this.restoreAction.setEnabled(true);
/* 1384 */         this.maximizeAction.setEnabled(true);
/* 1385 */         this.iconifyAction.setEnabled(false);
/*      */         break;
/*      */       default:
/* 1388 */         this.restoreAction.setEnabled(false);
/* 1389 */         this.maximizeAction.setEnabled(true);
/* 1390 */         this.iconifyAction.setEnabled(true);
/*      */         break;
/*      */     } 
/* 1394 */     if ((this.frame.getExtendedState() & 0x1) != 0)
/* 1395 */       ExtKeyEventProcessor.resetWinMetaKey(); 
/*      */   }
/*      */   
/*      */   static boolean isFullScreenOnMacSupported(Frame paramFrame) {
/* 1400 */     GraphicsDevice graphicsDevice = paramFrame.getGraphicsConfiguration().getDevice();
/* 1401 */     return (graphicsDevice.isFullScreenSupported() && SyntheticaLookAndFeel.getBoolean("Synthetica.rootPane.fullScreenOnMaximizeMacOnly.enabled", paramFrame, false));
/*      */   }
/*      */   
/*      */   public ComponentOrientation getComponentOrientation() {
/* 1439 */     return (this.window == null) ? getRootPane().getComponentOrientation() : this.window.getComponentOrientation();
/*      */   }
/*      */   
/*      */   private boolean isRTL() {
/* 1444 */     return !getComponentOrientation().isLeftToRight();
/*      */   }
/*      */   
/*      */   private class CloseButtonStateListener implements PropertyChangeListener, ComponentListener {
/*      */     private CloseButtonStateListener() {}
/*      */     
/*      */     public void componentResized(ComponentEvent param1ComponentEvent) {}
/*      */     
/*      */     public void componentMoved(ComponentEvent param1ComponentEvent) {}
/*      */     
/*      */     public void componentShown(ComponentEvent param1ComponentEvent) {
/* 1465 */       updateSystemMenu();
/*      */     }
/*      */     
/*      */     public void componentHidden(ComponentEvent param1ComponentEvent) {
/* 1471 */       updateSystemMenu();
/*      */     }
/*      */     
/*      */     public void propertyChange(PropertyChangeEvent param1PropertyChangeEvent) {
/* 1477 */       String str = param1PropertyChangeEvent.getPropertyName();
/* 1478 */       if ("enabled".equals(str))
/* 1479 */         updateSystemMenu(); 
/*      */     }
/*      */     
/*      */     private void updateSystemMenu() {
/* 1484 */       if (SyntheticaTitlePane.this.systemMenu != null) {
/* 1486 */         SyntheticaTitlePane.this.systemMenu.removeAll();
/* 1487 */         SyntheticaTitlePane.this.addMenuItems(SyntheticaTitlePane.this.systemMenu);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class UserComponentContainer extends JComponent {
/*      */     public UserComponentContainer() {
/* 1497 */       setLayout(new BorderLayout());
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaTitlePane.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */