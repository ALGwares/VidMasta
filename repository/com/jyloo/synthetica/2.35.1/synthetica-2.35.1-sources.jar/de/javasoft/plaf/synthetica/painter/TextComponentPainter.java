/*     */ package de.javasoft.plaf.synthetica.painter;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaState;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.RenderingHints;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.CompoundBorder;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ class TextComponentPainter extends SyntheticaComponentPainter {
/*     */   protected void paintBackground(String paramString, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  44 */     JTextComponent jTextComponent = (JTextComponent)paramSynthContext.getComponent();
/*  46 */     Color color = jTextComponent.getBackground();
/*  47 */     boolean bool1 = (color != null && !(color instanceof javax.swing.plaf.ColorUIResource)) ? false : true;
/*  48 */     boolean bool2 = SyntheticaLookAndFeel.getBoolean("Synthetica." + paramString + ".keepLockedBorderIfColored", jTextComponent);
/*  49 */     boolean bool3 = SyntheticaLookAndFeel.getBoolean("Synthetica." + paramString + ".keepDisabledBorderIfColored", jTextComponent);
/*  50 */     boolean bool4 = SyntheticaLookAndFeel.getBoolean("Synthetica." + paramString + ".noBorderIfColored", jTextComponent);
/*  51 */     boolean bool5 = SyntheticaLookAndFeel.isOpaque(jTextComponent);
/*  52 */     boolean bool6 = jTextComponent.isEditable() ? false : true;
/*  53 */     boolean bool7 = jTextComponent.getParent() instanceof javax.swing.JViewport;
/*  54 */     boolean bool8 = (!"textArea".equals(paramString) && !"textPane".equals(paramString) && !"editorPane".equals(paramString)) ? false : true;
/*  57 */     if (!bool5 || (bool8 && bool7))
/*     */       return; 
/*  59 */     if (bool1)
/*  61 */       if (bool6) {
/*  63 */         color = SyntheticaLookAndFeel.getColor("Synthetica." + paramString + ".locked.backgroundColor", jTextComponent);
/*  64 */         if (color == null)
/*  65 */           color = SyntheticaLookAndFeel.getColor("Synthetica." + paramString + ".lockedColor", jTextComponent); 
/*  66 */         if (color == null) {
/*  68 */           if (jTextComponent.isEnabled() && ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.MOUSE_OVER", jTextComponent, Boolean.valueOf(false))).booleanValue())
/*  69 */             paramSynthContext = new SynthContext(jTextComponent, paramSynthContext.getRegion(), paramSynthContext.getStyle(), paramSynthContext.getComponentState() | 0x2); 
/*  70 */           color = paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND);
/*     */         } 
/*     */       } else {
/*  75 */         if (jTextComponent.isEnabled() && ((Boolean)SyntheticaLookAndFeel.getClientProperty("Synthetica.MOUSE_OVER", jTextComponent, Boolean.valueOf(false))).booleanValue())
/*  76 */           paramSynthContext = new SynthContext(jTextComponent, paramSynthContext.getRegion(), paramSynthContext.getStyle(), paramSynthContext.getComponentState() | 0x2); 
/*  77 */         color = paramSynthContext.getStyle().getColor(paramSynthContext, ColorType.BACKGROUND);
/*     */       }  
/*  81 */     SyntheticaPainterState syntheticaPainterState = new SyntheticaPainterState(paramSynthContext);
/*  82 */     UIKey uIKey = new UIKey(paramString, syntheticaPainterState);
/*  83 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get(uIKey.get("fillBackground"), jTextComponent);
/*  84 */     Border border1 = jTextComponent.getBorder();
/*  85 */     Border border2 = SyntheticaLookAndFeel.findDefaultBorder(border1);
/*  86 */     boolean bool9 = (border2 == null) ? false : border2.getClass().getName().equals("javax.swing.plaf.synth.SynthBorder");
/*  88 */     boolean bool10 = (border1 instanceof CompoundBorder && ((CompoundBorder)border1).getInsideBorder() == border2) ? true : false;
/*  89 */     if (bool10) {
/*  91 */       Insets insets4 = border1.getBorderInsets(jTextComponent);
/*  92 */       Insets insets5 = border2.getBorderInsets(jTextComponent);
/*  93 */       paramInt1 += insets4.left - insets5.left;
/*  94 */       paramInt2 += insets4.top - insets5.top;
/*  95 */       paramInt3 -= insets4.left - insets5.left + insets4.right - insets5.right;
/*  96 */       paramInt4 -= insets4.top - insets5.top + insets4.bottom - insets5.bottom;
/*     */     } 
/*  99 */     if (bool == null || bool.booleanValue())
/* 100 */       fillBackground(jTextComponent, paramString, border1, border2, bool9, bool8, paramGraphics, color, paramInt1, paramInt2, paramInt3, paramInt4); 
/* 102 */     if (!bool1 && bool4)
/*     */       return; 
/* 106 */     if (!bool1 && (!bool2 || !bool3) && bool8)
/*     */       return; 
/* 109 */     SyntheticaState syntheticaState = new SyntheticaState(syntheticaPainterState.getState());
/* 112 */     if (!bool1 && !bool2)
/* 113 */       syntheticaState.resetState(SyntheticaState.State.LOCKED); 
/* 114 */     if (!bool1 && !bool3)
/* 115 */       syntheticaState.resetState(SyntheticaState.State.DISABLED); 
/* 117 */     uIKey = getUIKey(jTextComponent, paramString, syntheticaState);
/* 120 */     boolean bool11 = (SyntheticaLookAndFeel.get(uIKey.get(), jTextComponent) != null) ? true : false;
/* 121 */     if (bool6 && !bool11) {
/* 123 */       syntheticaState.resetState(SyntheticaState.State.LOCKED);
/* 124 */       uIKey = getUIKey(jTextComponent, paramString, syntheticaState);
/*     */     } 
/* 127 */     String str = (String)uIKey.findProperty(paramSynthContext, null, false, 1);
/* 129 */     if (jTextComponent.hasFocus() && SyntheticaLookAndFeel.get(String.valueOf(uIKey.get()) + ".focused", jTextComponent) != null)
/* 130 */       str = SyntheticaLookAndFeel.getString(String.valueOf(uIKey.get()) + ".focused", jTextComponent); 
/* 131 */     Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica." + paramString + ".border.insets", jTextComponent);
/* 132 */     Insets insets2 = (SyntheticaLookAndFeel.get("Synthetica." + paramString + ".border.dInsets", jTextComponent) == null) ? insets1 : SyntheticaLookAndFeel.getInsets("Synthetica." + paramString + ".border.dInsets", jTextComponent);
/* 133 */     Insets insets3 = jTextComponent.getInsets();
/* 135 */     if (!bool9) {
/* 137 */       paramInt1 += insets3.left;
/* 138 */       paramInt2 += insets3.top;
/* 139 */       paramInt3 += -insets3.left - insets3.right;
/* 140 */       paramInt4 += -insets3.top - insets3.bottom;
/* 141 */       insets2 = new Insets(0, 0, 0, 0);
/* 143 */     } else if (bool8) {
/* 144 */       insets2 = new Insets(0, 0, 0, 0);
/*     */     } 
/* 146 */     ImagePainter imagePainter = new ImagePainter(jTextComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 147 */     if (!bool1 && (!bool2 || !bool3)) {
/* 148 */       imagePainter.drawBorder();
/* 151 */     } else if (bool8) {
/* 152 */       imagePainter.drawCenter();
/*     */     } else {
/* 154 */       imagePainter.draw();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void paintBorder(String paramString, SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 163 */     JComponent jComponent = paramSynthContext.getComponent();
/* 166 */     if (!(jComponent instanceof JTextComponent)) {
/* 168 */       UIKey uIKey = getUIKey(jComponent, paramString, new SyntheticaState());
/* 169 */       String str = (String)uIKey.findProperty(paramSynthContext, null, true, 1);
/* 170 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica." + paramString + ".border.insets", jComponent);
/* 171 */       Insets insets2 = (SyntheticaLookAndFeel.get("Synthetica." + paramString + ".border.dInsets", jComponent) == null) ? insets1 : SyntheticaLookAndFeel.getInsets("Synthetica." + paramString + ".border.dInsets", jComponent);
/* 172 */       ImagePainter imagePainter = new ImagePainter(jComponent, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4, str, insets1, insets2, 0, 0);
/* 173 */       imagePainter.drawBorder();
/*     */     } 
/* 176 */     boolean bool = SyntheticaLookAndFeel.getBoolean("Synthetica.focus.textComponents.enabled", jComponent, true);
/* 177 */     if (jComponent.hasFocus() && bool)
/* 178 */       FocusPainter.paintFocus("focus." + paramString, paramSynthContext, paramGraphics, paramInt1, paramInt2, paramInt3, paramInt4); 
/*     */   }
/*     */   
/*     */   protected UIKey getUIKey(JComponent paramJComponent, String paramString, SyntheticaState paramSyntheticaState) {
/* 183 */     return new UIKey(String.valueOf(paramString) + ".border", paramSyntheticaState);
/*     */   }
/*     */   
/*     */   private void fillBackground(JTextComponent paramJTextComponent, String paramString, Border paramBorder1, Border paramBorder2, boolean paramBoolean1, boolean paramBoolean2, Graphics paramGraphics, Color paramColor, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 191 */     Color color = paramGraphics.getColor();
/* 192 */     paramGraphics.setColor(paramColor);
/* 193 */     Insets insets = paramJTextComponent.getInsets();
/* 195 */     if (paramBoolean2 || paramBorder1 == null || insets.equals(new Insets(0, 0, 0, 0))) {
/* 196 */       paramGraphics.fillRect(paramInt1, paramInt2, paramInt3, paramInt4);
/* 197 */     } else if (!paramBoolean1) {
/* 198 */       paramGraphics.fillRect(paramInt1 + insets.left, paramInt2 + insets.top, paramInt3 - insets.left - insets.right, paramInt4 - insets.top - insets.bottom);
/*     */     } else {
/* 201 */       Insets insets1 = SyntheticaLookAndFeel.getInsets("Synthetica." + paramString + ".border.fillInsets", paramJTextComponent, false);
/* 202 */       int i = SyntheticaLookAndFeel.getInt("Synthetica." + paramString + ".border.arcWidth", paramJTextComponent, 8);
/* 203 */       int j = SyntheticaLookAndFeel.getInt("Synthetica." + paramString + ".border.arcHeight", paramJTextComponent, 8);
/* 204 */       Graphics2D graphics2D = (Graphics2D)paramGraphics;
/* 205 */       RenderingHints renderingHints = graphics2D.getRenderingHints();
/* 206 */       graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/* 207 */       graphics2D.fillRoundRect(paramInt1 + insets1.left, paramInt2 + insets1.top, paramInt3 - insets1.left - insets1.right, paramInt4 - insets1.top - insets1.bottom, i, j);
/* 208 */       graphics2D.setRenderingHints(renderingHints);
/*     */     } 
/* 211 */     paramGraphics.setColor(color);
/*     */   }
/*     */   
/*     */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 217 */     JComponent jComponent = paramSynthContext.getComponent();
/* 219 */     int i = super.getCacheHash(paramSynthContext, paramInt1, paramInt2, paramInt3, paramString);
/* 221 */     if (jComponent instanceof JTextComponent) {
/* 223 */       JTextComponent jTextComponent = (JTextComponent)jComponent;
/* 224 */       boolean bool = jTextComponent.isEditable() ? false : true;
/* 225 */       i = 31 * i + (bool ? 0 : 1);
/*     */     } 
/* 227 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\TextComponentPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */