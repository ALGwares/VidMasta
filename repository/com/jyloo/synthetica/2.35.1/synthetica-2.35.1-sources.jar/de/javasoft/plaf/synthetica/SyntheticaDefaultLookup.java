/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import de.javasoft.util.OS;
/*     */ import java.awt.Insets;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import sun.swing.DefaultLookup;
/*     */ import sun.swing.plaf.synth.SynthUI;
/*     */ 
/*     */ public class SyntheticaDefaultLookup extends DefaultLookup {
/*     */   private static Class<?> synthUI;
/*     */   
/*     */   public SyntheticaDefaultLookup() {
/*     */     try {
/*  42 */       if (JavaVersion.JAVA5 || JavaVersion.JAVA6) {
/*  43 */         synthUI = Class.forName("sun.swing.plaf.synth.SynthUI");
/*     */       } else {
/*  46 */         synthUI = Class.forName("javax.swing.plaf.synth.SynthUI");
/*     */       } 
/*  48 */     } catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */   
/*     */   public Object getDefault(JComponent paramJComponent, ComponentUI paramComponentUI, String paramString) {
/*  75 */     if (OS.getCurrentOS() == OS.Mac && isSynthUI(paramComponentUI) && SyntheticaLookAndFeel.getBoolean("Synthetica.metaKeySupportOnMacEnabled", paramJComponent, true) && (
/*  76 */       "TextField.focusInputMap".equals(paramString) || 
/*  77 */       "FormattedTextField.focusInputMap".equals(paramString) || 
/*  78 */       "PasswordField.focusInputMap".equals(paramString) || 
/*  79 */       "TextArea.focusInputMap".equals(paramString) || 
/*  80 */       "TextPane.focusInputMap".equals(paramString) || 
/*  81 */       "EditorPane.focusInputMap".equals(paramString) || 
/*  82 */       "List.focusInputMap".equals(paramString) || 
/*  83 */       "Tree.focusInputMap".equals(paramString) || 
/*  84 */       "Spinner.focusInputMap".equals(paramString))) {
/*  87 */       SynthContext synthContext = getContext(paramComponentUI, paramJComponent);
/*  88 */       InputMap inputMap = (InputMap)synthContext.getStyle().get(synthContext, paramString);
/*  89 */       LookAndFeel.loadKeyBindings(inputMap, 
/*  90 */           new Object[] { "meta X", "cut-to-clipboard", 
/*  92 */             "meta C", "copy-to-clipboard", 
/*  93 */             "meta V", "paste-from-clipboard", 
/*  94 */             "meta A", "select-all" });
/*  97 */       if ("TextField.focusInputMap".equals(paramString) || 
/*  98 */         "FormattedTextField.focusInputMap".equals(paramString) || 
/*  99 */         "PasswordField.focusInputMap".equals(paramString) || 
/* 100 */         "TextArea.focusInputMap".equals(paramString) || 
/* 101 */         "TextPane.focusInputMap".equals(paramString) || 
/* 102 */         "EditorPane.focusInputMap".equals(paramString)) {
/* 104 */         Object[] arrayOfObject = asArray(getMacMap4JTextComponent());
/* 105 */         LookAndFeel.loadKeyBindings(inputMap, arrayOfObject);
/*     */       } 
/* 107 */       return inputMap;
/*     */     } 
/* 109 */     if (isSynthUI(paramComponentUI) && ("TextField.focusInputMap".equals(paramString) || 
/* 110 */       "FormattedTextField.focusInputMap".equals(paramString) || 
/* 111 */       "PasswordField.focusInputMap".equals(paramString) || 
/* 112 */       "TextArea.focusInputMap".equals(paramString) || 
/* 113 */       "TextPane.focusInputMap".equals(paramString) || 
/* 114 */       "EditorPane.focusInputMap".equals(paramString))) {
/* 116 */       SynthContext synthContext = getContext(paramComponentUI, paramJComponent);
/* 117 */       InputMap inputMap = (InputMap)synthContext.getStyle().get(synthContext, paramString);
/* 118 */       Object[] arrayOfObject = asArray(getCustomMap4TextComponent());
/* 119 */       LookAndFeel.loadKeyBindings(inputMap, arrayOfObject);
/* 120 */       return inputMap;
/*     */     } 
/* 123 */     if ("Button.defaultButtonFollowsFocus".equals(paramString))
/* 125 */       return Boolean.valueOf(UIManager.getBoolean("Button.defaultButtonFollowsFocus")); 
/* 127 */     if ("SplitPane.oneTouchButtonOffset".equals(paramString) && UIManager.getBoolean("Syntetica.splitPane.centerOneTouchButtons") && 
/* 128 */       isSynthUI(paramComponentUI)) {
/* 130 */       JSplitPane jSplitPane = (JSplitPane)paramJComponent;
/* 131 */       Insets insets = jSplitPane.getInsets();
/* 132 */       int i = 0;
/* 133 */       if (jSplitPane.getOrientation() == 0) {
/* 134 */         i = jSplitPane.getWidth() - insets.left - insets.right;
/*     */       } else {
/* 136 */         i = jSplitPane.getHeight() - insets.top - insets.bottom;
/*     */       } 
/* 137 */       SynthContext synthContext = getContext(paramComponentUI, paramJComponent);
/* 138 */       int j = ((Integer)synthContext.getStyle().get(synthContext, "SplitPane.oneTouchButtonSize")).intValue();
/* 139 */       int k = jSplitPane.getDividerSize();
/* 140 */       return Integer.valueOf(i / 2 - j - k);
/*     */     } 
/* 142 */     if ("OptionPane.buttonPadding".equals(paramString))
/* 143 */       return UIManager.get("OptionPane.buttonPadding"); 
/* 144 */     if ("OptionPane.buttonOrientation".equals(paramString))
/* 145 */       return UIManager.get("OptionPane.buttonOrientation"); 
/* 146 */     if ("ProgressBar.horizontalSize".equals(paramString))
/* 147 */       return SyntheticaLookAndFeel.getDim("ProgressBar.horizontalSize", paramJComponent); 
/* 148 */     if ("ProgressBar.vertictalSize".equals(paramString) || "ProgressBar.verticalSize".equals(paramString))
/* 149 */       return SyntheticaLookAndFeel.getDim("ProgressBar.verticalSize", paramJComponent); 
/* 150 */     if ("Slider.tickColor".equals(paramString) && !paramJComponent.isEnabled() && SyntheticaLookAndFeel.get("Slider.tickColor.disabled", paramJComponent) != null)
/* 151 */       return SyntheticaLookAndFeel.get("Slider.tickColor.disabled", paramJComponent); 
/* 152 */     if ("Slider.tickColor".equals(paramString) && SyntheticaLookAndFeel.get("Slider.tickColor", paramJComponent) != null)
/* 153 */       return SyntheticaLookAndFeel.get("Slider.tickColor", paramJComponent); 
/* 155 */     if ("TabbedPane.labelShift".equals(paramString))
/* 156 */       return Integer.valueOf(SyntheticaLookAndFeel.getInt("TabbedPane.labelShift", paramJComponent, 1)); 
/* 157 */     if ("TabbedPane.selectedLabelShift".equals(paramString))
/* 158 */       return Integer.valueOf(SyntheticaLookAndFeel.getInt("TabbedPane.selectedLabelShift", paramJComponent, -1)); 
/* 163 */     Object object = SyntheticaLookAndFeel.get(paramString, paramJComponent);
/* 164 */     if (object != null)
/* 165 */       return object; 
/* 167 */     if (isSynthUI(paramComponentUI)) {
/* 169 */       SynthContext synthContext = getContext(paramComponentUI, paramJComponent);
/* 170 */       if (synthContext != null && synthContext.getStyle() != null)
/* 172 */         return synthContext.getStyle().get(synthContext, paramString); 
/*     */     } 
/* 177 */     return super.getDefault(paramJComponent, paramComponentUI, paramString);
/*     */   }
/*     */   
/*     */   private boolean isSynthUI(Object paramObject) {
/* 183 */     return synthUI.isAssignableFrom(paramObject.getClass());
/*     */   }
/*     */   
/*     */   private SynthContext getContext(final Object ui, final JComponent c) {
/* 188 */     SynthContext synthContext = null;
/* 189 */     if (JavaVersion.JAVA5 || JavaVersion.JAVA6) {
/* 191 */       synthContext = ((SynthUI)ui).getContext(c);
/*     */     } else {
/* 194 */       synthContext = AccessController.<SynthContext>doPrivileged(new PrivilegedAction<SynthContext>() {
/*     */             public SynthContext run() {
/*     */               try {
/* 200 */                 Method method = ui.getClass().getMethod("getContext", new Class[] { JComponent.class });
/* 201 */                 method.setAccessible(true);
/* 202 */                 return (SynthContext)method.invoke(ui, new Object[] { this.val$c });
/* 204 */               } catch (Exception exception) {
/* 206 */                 throw new RuntimeException(exception);
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/* 211 */     return synthContext;
/*     */   }
/*     */   
/*     */   private Object[] asArray(Map<Object, Object> paramMap) {
/* 216 */     Object[] arrayOfObject = new Object[paramMap.size() * 2];
/* 217 */     byte b = 0;
/* 218 */     for (Map.Entry<Object, Object> entry : paramMap.entrySet()) {
/* 220 */       arrayOfObject[b++] = entry.getKey();
/* 221 */       arrayOfObject[b++] = entry.getValue();
/*     */     } 
/* 223 */     return arrayOfObject;
/*     */   }
/*     */   
/*     */   private Map<Object, Object> getMacMap4JTextComponent() {
/* 228 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 229 */     hashMap.put("meta A", "select-all");
/* 230 */     hashMap.put("meta LEFT", "caret-begin-line");
/* 231 */     hashMap.put("meta KP_LEFT", "caret-begin-line");
/* 232 */     hashMap.put("meta RIGHT", "caret-end-line");
/* 233 */     hashMap.put("meta KP_RIGHT", "caret-end-line");
/* 234 */     hashMap.put("meta UP", "caret-begin");
/* 235 */     hashMap.put("meta KP_UP", "caret-begin");
/* 236 */     hashMap.put("meta DOWN", "caret-end");
/* 237 */     hashMap.put("meta KP_DOWN", "caret-end");
/* 238 */     hashMap.put("meta shift LEFT", "selection-begin-line");
/* 239 */     hashMap.put("meta shift KP_LEFT", "selection-begin-line");
/* 240 */     hashMap.put("meta shift RIGHT", "selection-end-line");
/* 241 */     hashMap.put("meta shift KP_RIGHT", "selection-end-line");
/* 242 */     hashMap.put("meta shift UP", "selection-begin");
/* 243 */     hashMap.put("meta shift KP_UP", "selection-begin");
/* 244 */     hashMap.put("meta shift DOWN", "selection-end");
/* 245 */     hashMap.put("meta shift KP_DOWN", "selection-end");
/* 246 */     hashMap.put("meta shift PAGE_UP", "selection-page-up");
/* 247 */     hashMap.put("meta shift PAGE_DOWN", "selection-page-down");
/* 248 */     hashMap.put("meta BACK_SLASH", "unselect");
/* 249 */     hashMap.put("meta T", "next-link-action");
/* 250 */     hashMap.put("meta shift T", "previous-link-action");
/* 251 */     hashMap.put("meta SPACE", "activate-link-action");
/* 253 */     hashMap.put("ctrl H", "delete-previous");
/* 254 */     hashMap.put("ctrl D", "delete-next");
/* 255 */     hashMap.put("ctrl W", "delete-previous-word");
/* 256 */     hashMap.put("ctrl F", "caret-forward");
/* 257 */     hashMap.put("ctrl B", "caret-backward");
/* 259 */     hashMap.put("alt RIGHT", "caret-next-word");
/* 260 */     hashMap.put("alt KP_RIGHT", "caret-next-word");
/* 261 */     hashMap.put("alt LEFT", "caret-previous-word");
/* 262 */     hashMap.put("alt KP_LEFT", "caret-previous-word");
/* 263 */     hashMap.put("alt DELETE", "delete-next-word");
/* 264 */     hashMap.put("alt BACK_SPACE", "delete-previous-word");
/* 266 */     hashMap.put("shift alt RIGHT", "selection-next-word");
/* 267 */     hashMap.put("shift alt KP_RIGHT", "selection-next-word");
/* 268 */     hashMap.put("shift alt LEFT", "selection-previous-word");
/* 269 */     hashMap.put("shift alt KP_LEFT", "selection-previous-word");
/* 272 */     Map<?, ?> map = (Map)UIManager.get("Synthetica.textComponent.macFocusInputMap");
/* 273 */     if (map != null)
/* 274 */       hashMap.putAll(map); 
/* 276 */     return hashMap;
/*     */   }
/*     */   
/*     */   private Map<Object, Object> getCustomMap4TextComponent() {
/* 281 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 283 */     Map<?, ?> map = (Map)UIManager.get("Synthetica.textComponent.focusInputMap");
/* 284 */     if (map != null)
/* 285 */       hashMap.putAll(map); 
/* 286 */     return hashMap;
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaDefaultLookup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */