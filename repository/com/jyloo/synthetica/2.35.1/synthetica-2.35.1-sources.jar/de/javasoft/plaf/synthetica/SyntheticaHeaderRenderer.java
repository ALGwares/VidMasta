/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.TablePainter;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.RowSorter;
/*     */ import javax.swing.SortOrder;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.table.TableModel;
/*     */ import sun.swing.table.DefaultTableCellHeaderRenderer;
/*     */ 
/*     */ class SyntheticaHeaderRenderer extends DefaultTableCellHeaderRenderer implements UIResource {
/*     */   private static final long serialVersionUID = -4089492349514455249L;
/*     */   
/*     */   private JTable table;
/*     */   
/*     */   private int column;
/*     */   
/*     */   SyntheticaHeaderRenderer() {
/*  54 */     setHorizontalAlignment(SyntheticaLookAndFeel.getInt("Synthetica.tableHeader.horizontalAlignment", this, 10));
/*  55 */     setName("TableHeader.renderer");
/*     */   }
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2) {
/*  60 */     this.table = paramJTable;
/*  61 */     this.column = paramInt2;
/*  63 */     Component component = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
/*  64 */     if (!paramBoolean2 && component instanceof JComponent && paramJTable != null && paramJTable.getTableHeader() != null && component instanceof JComponent) {
/*  66 */       JComponent jComponent = (JComponent)component;
/*  68 */       SynthStyle synthStyle = SynthLookAndFeel.getStyle(paramJTable.getTableHeader(), Region.TABLE_HEADER);
/*  69 */       SynthContext synthContext = new SynthContext(paramJTable.getTableHeader(), Region.TABLE_HEADER, synthStyle, 0);
/*  70 */       Insets insets = synthStyle.getInsets(synthContext, null);
/*  71 */       Border border1 = jComponent.getBorder();
/*  74 */       Border border2 = UIManager.getBorder("TableHeader.cellBorder");
/*  75 */       if (border2 != null) {
/*  77 */         if (border1 != border2)
/*  78 */           jComponent.setBorder(border2); 
/*  80 */       } else if (insets.equals(new Insets(0, 0, 0, 0))) {
/*  83 */         if (border1 == null)
/*  84 */           jComponent.setBorder(noFocusBorder); 
/*     */       } else {
/*  87 */         jComponent.setBorder(new EmptyBorder(insets));
/*     */       } 
/*     */     } 
/*  91 */     if (JavaVersion.JAVA6U10_OR_ABOVE && paramJTable != null && paramJTable.getRowSorter() != null)
/*  93 */       for (RowSorter.SortKey sortKey : getSortKeys(paramJTable)) {
/*  95 */         if (sortKey.getColumn() == paramJTable.convertColumnIndexToModel(paramInt2)) {
/*  97 */           Icon icon = null;
/*  98 */           switch (sortKey.getSortOrder()) {
/*     */             case null:
/* 101 */               icon = UIManager.getIcon("Table.ascendingSortIcon");
/*     */               break;
/*     */             case DESCENDING:
/* 104 */               icon = UIManager.getIcon("Table.descendingSortIcon");
/*     */               break;
/*     */             default:
/* 107 */               icon = UIManager.getIcon("Table.naturalSortIcon");
/*     */               break;
/*     */           } 
/* 109 */           setIcon(icon);
/*     */         } 
/*     */       }  
/* 114 */     return component;
/*     */   }
/*     */   
/*     */   public void paintComponent(Graphics paramGraphics) {
/* 120 */     if (this.table != null) {
/* 122 */       byte b = 0;
/* 123 */       boolean bool = false;
/* 127 */       int[] arrayOfInt = (int[])this.table.getClientProperty("SORTABLE_TABLE_SORTED_COLUMNS");
/* 128 */       Boolean bool1 = (Boolean)this.table.getClientProperty("SORTABLE_TABLE_PAINT_SORT_BACKGROUND");
/* 130 */       if (arrayOfInt != null && bool1 != null && bool1.booleanValue()) {
/*     */         byte b1;
/*     */         int i;
/*     */         int[] arrayOfInt1;
/* 132 */         for (i = (arrayOfInt1 = arrayOfInt).length, b1 = 0; b1 < i; ) {
/* 132 */           int j = arrayOfInt1[b1];
/* 134 */           if (j == this.column) {
/* 136 */             TablePainter.getInstance().paintTableHeaderCellBackground(this.table, new SyntheticaState(0), paramGraphics, 0, 0, getWidth(), getHeight(), 1);
/* 137 */             bool = true;
/*     */             break;
/*     */           } 
/*     */           b1++;
/*     */         } 
/* 142 */       } else if (JavaVersion.JAVA6U10_OR_ABOVE && this.table.getRowSorter() != null) {
/* 144 */         for (RowSorter.SortKey sortKey : getSortKeys(this.table)) {
/* 146 */           if (sortKey.getColumn() == this.table.convertColumnIndexToModel(this.column)) {
/* 148 */             switch (sortKey.getSortOrder()) {
/*     */               case null:
/* 151 */                 b = 1;
/*     */                 break;
/*     */               case DESCENDING:
/* 154 */                 b = 2;
/*     */                 break;
/*     */             } 
/* 159 */             TablePainter.getInstance().paintTableHeaderCellBackground(this.table, new SyntheticaState(0), paramGraphics, 0, 0, getWidth(), getHeight(), b);
/* 160 */             bool = true;
/*     */           } 
/*     */         } 
/*     */       } 
/* 165 */       if (!bool)
/* 166 */         TablePainter.getInstance().paintTableHeaderCellBackground(this.table, new SyntheticaState(0), paramGraphics, 0, 0, getWidth(), getHeight(), b); 
/*     */     } 
/* 168 */     super.paintComponent(paramGraphics);
/*     */   }
/*     */   
/*     */   private List<RowSorter.SortKey> getSortKeys(JTable paramJTable) {
/* 173 */     RowSorter<? extends TableModel> rowSorter = paramJTable.getRowSorter();
/* 175 */     List<? extends RowSorter.SortKey> list = rowSorter.getSortKeys();
/* 178 */     if (list.size() > 0) {
/* 180 */       list = new ArrayList<RowSorter.SortKey>();
/* 181 */       list.add(rowSorter.getSortKeys().get(0));
/*     */     } 
/* 183 */     return (List)list;
/*     */   }
/*     */   
/*     */   public boolean isOpaque() {
/* 189 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get("Synthetica.tableHeader.opaque", this.table);
/* 190 */     return (bool == null) ? super.isOpaque() : bool.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaHeaderRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */