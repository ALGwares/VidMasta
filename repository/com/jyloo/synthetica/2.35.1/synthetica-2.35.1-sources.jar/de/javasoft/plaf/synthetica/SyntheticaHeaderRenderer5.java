/*     */ package de.javasoft.plaf.synthetica;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.painter.TablePainter;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ 
/*     */ class SyntheticaHeaderRenderer5 extends DefaultTableCellRenderer implements UIResource {
/*     */   private static final long serialVersionUID = -5043195354176641815L;
/*     */   
/*     */   private JTable table;
/*     */   
/*     */   private int column;
/*     */   
/*     */   SyntheticaHeaderRenderer5() {
/*  46 */     setHorizontalAlignment(SyntheticaLookAndFeel.getInt("Synthetica.tableHeader.horizontalAlignment", this, 10));
/*  47 */     setName("TableHeader.renderer");
/*     */   }
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2) {
/*  52 */     this.table = paramJTable;
/*  53 */     this.column = paramInt2;
/*  54 */     if (paramJTable != null && !paramBoolean2) {
/*  56 */       SynthStyle synthStyle = SynthLookAndFeel.getStyle(paramJTable.getTableHeader(), Region.TABLE_HEADER);
/*  57 */       SynthContext synthContext = new SynthContext(paramJTable.getTableHeader(), Region.TABLE_HEADER, synthStyle, 0);
/*  58 */       Insets insets = synthStyle.getInsets(synthContext, null);
/*  59 */       Border border1 = getBorder();
/*  62 */       Border border2 = UIManager.getBorder("TableHeader.cellBorder");
/*  63 */       if (border2 != null) {
/*  65 */         if (border1 != border2)
/*  66 */           setBorder(border2); 
/*  68 */       } else if (insets.equals(new Insets(0, 0, 0, 0))) {
/*  69 */         setBorder(noFocusBorder);
/*     */       } else {
/*  71 */         setBorder(new EmptyBorder(insets));
/*     */       } 
/*     */     } 
/*  73 */     setValue(paramObject);
/*  74 */     return this;
/*     */   }
/*     */   
/*     */   public void paintComponent(Graphics paramGraphics) {
/*  80 */     if (this.table != null) {
/*  82 */       boolean bool = false;
/*  86 */       int[] arrayOfInt = (int[])this.table.getClientProperty("SORTABLE_TABLE_SORTED_COLUMNS");
/*  87 */       Boolean bool1 = (Boolean)this.table.getClientProperty("SORTABLE_TABLE_PAINT_SORT_BACKGROUND");
/*  89 */       if (arrayOfInt != null && bool1 != null && bool1.booleanValue()) {
/*     */         byte b;
/*     */         int i;
/*     */         int[] arrayOfInt1;
/*  91 */         for (i = (arrayOfInt1 = arrayOfInt).length, b = 0; b < i; ) {
/*  91 */           int j = arrayOfInt1[b];
/*  93 */           if (j == this.column) {
/*  95 */             TablePainter.getInstance().paintTableHeaderCellBackground(this.table, new SyntheticaState(0), paramGraphics, 0, 0, getWidth(), getHeight(), 1);
/*  96 */             bool = true;
/*     */             break;
/*     */           } 
/*     */           b++;
/*     */         } 
/*     */       } 
/* 102 */       if (!bool)
/* 103 */         TablePainter.getInstance().paintTableHeaderCellBackground(this.table, new SyntheticaState(0), paramGraphics, 0, 0, getWidth(), getHeight(), 0); 
/*     */     } 
/* 105 */     super.paintComponent(paramGraphics);
/*     */   }
/*     */   
/*     */   public boolean isOpaque() {
/* 111 */     Boolean bool = (Boolean)SyntheticaLookAndFeel.get("Synthetica.tableHeader.opaque", this.table);
/* 112 */     return (bool == null) ? super.isOpaque() : bool.booleanValue();
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaHeaderRenderer5.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */