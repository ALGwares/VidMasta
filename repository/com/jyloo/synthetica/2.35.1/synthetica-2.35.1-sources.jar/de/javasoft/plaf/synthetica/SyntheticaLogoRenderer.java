package de.javasoft.plaf.synthetica;

import javax.swing.JComponent;
import javax.swing.JRootPane;

public interface SyntheticaLogoRenderer {
  JComponent getRendererComponent(JRootPane paramJRootPane, boolean paramBoolean);
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaLogoRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */