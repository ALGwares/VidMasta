/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.plaf.UIResource;
/*    */ 
/*    */ public class TreeExpandedIcon implements Icon, UIResource {
/*    */   protected static Icon icon;
/*    */   
/*    */   protected static Icon selectedIcon;
/*    */   
/*    */   public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2) {
/* 37 */     boolean bool = (paramComponent instanceof JTree && ((JTree)paramComponent).getSelectionModel().isRowSelected(((JTree)paramComponent).getClosestRowForLocation(paramInt1, paramInt2))) ? true : false;
/* 38 */     if (bool && selectedIcon != null) {
/* 39 */       selectedIcon.paintIcon(paramComponent, paramGraphics, paramInt1, paramInt2);
/* 40 */     } else if (icon != null) {
/* 41 */       icon.paintIcon(paramComponent, paramGraphics, paramInt1, paramInt2);
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getIconWidth() {
/* 47 */     if (icon == null) {
/* 49 */       icon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.expandedIcon");
/* 50 */       selectedIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.selected.expandedIcon");
/*    */     } 
/* 52 */     return (icon == null) ? 0 : icon.getIconWidth();
/*    */   }
/*    */   
/*    */   public int getIconHeight() {
/* 58 */     if (icon == null) {
/* 60 */       icon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.expandedIcon");
/* 61 */       selectedIcon = SyntheticaLookAndFeel.loadIcon("Synthetica.tree.selected.expandedIcon");
/*    */     } 
/* 63 */     return (icon == null) ? 0 : icon.getIconHeight();
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\TreeExpandedIcon.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */