package de.javasoft.plaf.synthetica;

import java.awt.Shape;

public interface SyntheticaWindowShape {
  Shape getShape(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\SyntheticaWindowShape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */