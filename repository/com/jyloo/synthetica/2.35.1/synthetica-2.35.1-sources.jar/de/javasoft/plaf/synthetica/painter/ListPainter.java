/*    */ package de.javasoft.plaf.synthetica.painter;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ 
/*    */ public class ListPainter extends SyntheticaComponentPainter {
/*    */   public static final String UI_KEY = "Synthetica.ListPainter";
/*    */   
/*    */   public static ListPainter getInstance() {
/* 38 */     return getInstance((SynthContext)null);
/*    */   }
/*    */   
/*    */   public static ListPainter getInstance(SynthContext paramSynthContext) {
/* 47 */     SyntheticaComponentPainter syntheticaComponentPainter = instances.get(getPainterClassName(paramSynthContext, ListPainter.class, "Synthetica.ListPainter"));
/* 48 */     if (syntheticaComponentPainter == null)
/* 49 */       syntheticaComponentPainter = getInstance(paramSynthContext, ListPainter.class, "Synthetica.ListPainter"); 
/* 50 */     return (ListPainter)syntheticaComponentPainter;
/*    */   }
/*    */   
/*    */   public void paintListBackground(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public void paintListBorder(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */   
/*    */   public Cacheable.ScaleType getCacheScaleType(String paramString) {
/* 70 */     return Cacheable.ScaleType.NINE_SQUARE;
/*    */   }
/*    */   
/*    */   public int getCacheHash(SynthContext paramSynthContext, int paramInt1, int paramInt2, int paramInt3, String paramString) {
/* 76 */     return -1;
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\painter\ListPainter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */