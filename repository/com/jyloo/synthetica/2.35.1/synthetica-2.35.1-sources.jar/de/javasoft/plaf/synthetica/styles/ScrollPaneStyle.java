/*     */ package de.javasoft.plaf.synthetica.styles;
/*     */ 
/*     */ import de.javasoft.plaf.synthetica.StyleFactory;
/*     */ import de.javasoft.plaf.synthetica.SyntheticaLookAndFeel;
/*     */ import de.javasoft.util.JavaVersion;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.synth.ColorType;
/*     */ import javax.swing.plaf.synth.Region;
/*     */ import javax.swing.plaf.synth.SynthContext;
/*     */ import javax.swing.plaf.synth.SynthLookAndFeel;
/*     */ import javax.swing.plaf.synth.SynthStyle;
/*     */ 
/*     */ public class ScrollPaneStyle extends StyleWrapper {
/*  42 */   private static ScrollPaneStyle instance = new ScrollPaneStyle();
/*     */   
/*  43 */   private static String comboBoxViewportInsetsKey = "Synthetica.comboBox.viewport.border.insets";
/*     */   
/*     */   public static SynthStyle getStyle(SynthStyle paramSynthStyle, JComponent paramJComponent, Region paramRegion) {
/*  51 */     String str = (String)SyntheticaLookAndFeel.get("Synthetica.scrollPane.layoutManager.className", paramJComponent);
/*  52 */     if (str != null && paramJComponent.getLayout() != null)
/*     */       try {
/*  56 */         Class<?> clazz = Class.forName(str);
/*  57 */         if (!clazz.isAssignableFrom(paramJComponent.getLayout().getClass())) {
/*  59 */           ((StyleFactory)SynthLookAndFeel.getStyleFactory()).getComponentPropertyStore().storeComponentProperty(paramJComponent, "SYCP_LAYOUT_MANAGER");
/*  60 */           paramJComponent.setLayout((LayoutManager)clazz.newInstance());
/*     */         } 
/*  63 */       } catch (Exception exception) {
/*  65 */         throw new RuntimeException(exception);
/*     */       }  
/*  69 */     if (SyntheticaLookAndFeel.getStyleName(paramJComponent) == null) {
/*  71 */       instance.setStyle(paramSynthStyle);
/*  72 */       return instance;
/*     */     } 
/*  74 */     ScrollPaneStyle scrollPaneStyle = new ScrollPaneStyle();
/*  75 */     scrollPaneStyle.setStyle(paramSynthStyle);
/*  76 */     return scrollPaneStyle;
/*     */   }
/*     */   
/*     */   public Object get(SynthContext paramSynthContext, Object paramObject) {
/*  82 */     JScrollPane jScrollPane = (JScrollPane)paramSynthContext.getComponent();
/*  84 */     if (!JavaVersion.JAVA5 && "ScrollPane.viewportBorderInsets".equals(paramObject) && UIManager.get(comboBoxViewportInsetsKey) != null && 
/*  85 */       jScrollPane.getViewport().getView() != null && "ComboBox.list".equals(jScrollPane.getViewport().getView().getName()))
/*  86 */       return UIManager.getInsets(comboBoxViewportInsetsKey); 
/*  87 */     return super.get(paramSynthContext, paramObject);
/*     */   }
/*     */   
/*     */   public Color getColor(SynthContext paramSynthContext, ColorType paramColorType) {
/*  93 */     JScrollPane jScrollPane = (JScrollPane)paramSynthContext.getComponent();
/*  94 */     Component component = jScrollPane.getViewport().getView();
/*  95 */     if (component == null)
/*  95 */       return this.synthStyle.getColor(paramSynthContext, paramColorType); 
/*  96 */     Color color = component.getBackground();
/*  98 */     if (component.getBackground() == null || component.getBackground() instanceof ColorUIResource)
/*  99 */       color = Color.WHITE; 
/* 101 */     if (component instanceof JEditorPane && component.getBackground() instanceof ColorUIResource) {
/* 103 */       JEditorPane jEditorPane = (JEditorPane)component;
/* 104 */       if (!jEditorPane.isEditable())
/* 105 */         color = UIManager.getColor("Synthetica.editorPane.lockedColor"); 
/* 106 */       if (!jEditorPane.isEnabled())
/* 107 */         color = UIManager.getColor("Synthetica.editorPane.disabledColor"); 
/* 109 */     } else if (component instanceof JTextArea && component.getBackground() instanceof ColorUIResource) {
/* 111 */       JTextArea jTextArea = (JTextArea)component;
/* 112 */       if (!jTextArea.isEditable()) {
/* 113 */         color = UIManager.getColor("Synthetica.textArea.lockedColor");
/* 114 */       } else if (!jTextArea.isEnabled()) {
/* 115 */         color = UIManager.getColor("Synthetica.textArea.disabledColor");
/*     */       } 
/*     */     } 
/* 118 */     if (color != null)
/* 119 */       return new ColorUIResource(color); 
/* 120 */     return super.getColor(paramSynthContext, paramColorType);
/*     */   }
/*     */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\de\javasoft\plaf\synthetica\styles\ScrollPaneStyle.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */