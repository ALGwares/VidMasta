/*    */ package META-INF.versions.9.de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.plaf.synth.SynthContext;
/*    */ import javax.swing.plaf.synth.SynthIcon;
/*    */ 
/*    */ public abstract class SyntheticaIcon implements SynthIcon, Icon {
/*    */   public static int getIconWidth(Icon icon, SynthContext context) {
/* 27 */     if (icon == null)
/* 28 */       return 0; 
/* 30 */     if (icon instanceof SynthIcon)
/* 31 */       return ((SynthIcon)icon).getIconWidth(context); 
/* 33 */     return icon.getIconWidth();
/*    */   }
/*    */   
/*    */   public static int getIconHeight(Icon icon, SynthContext context) {
/* 37 */     if (icon == null)
/* 38 */       return 0; 
/* 40 */     if (icon instanceof SynthIcon)
/* 41 */       return ((SynthIcon)icon).getIconHeight(context); 
/* 43 */     return icon.getIconHeight();
/*    */   }
/*    */   
/*    */   public static void paintIcon(Icon icon, SynthContext context, Graphics g, int x, int y, int w, int h) {
/* 48 */     if (icon instanceof SynthIcon) {
/* 49 */       ((SynthIcon)icon).paintIcon(context, g, x, y, w, h);
/* 51 */     } else if (icon != null) {
/* 52 */       icon.paintIcon(context.getComponent(), g, x, y);
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract int getIconHeight(SynthContext paramSynthContext);
/*    */   
/*    */   public abstract int getIconWidth(SynthContext paramSynthContext);
/*    */   
/*    */   public abstract void paintIcon(SynthContext paramSynthContext, Graphics paramGraphics, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   public void paintIcon(Component c, Graphics g, int x, int y) {
/* 74 */     paintIcon(null, g, x, y, 0, 0);
/*    */   }
/*    */   
/*    */   public int getIconWidth() {
/* 79 */     return getIconWidth(null);
/*    */   }
/*    */   
/*    */   public int getIconHeight() {
/* 84 */     return getIconHeight(null);
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\synthetica-2.35.1.jar!\META-INF\versions\9\de\javasoft\plaf\synthetica\SyntheticaIcon.class
 * Java compiler version: 9 (53.0)
 * JD-Core Version:       1.1.3
 */