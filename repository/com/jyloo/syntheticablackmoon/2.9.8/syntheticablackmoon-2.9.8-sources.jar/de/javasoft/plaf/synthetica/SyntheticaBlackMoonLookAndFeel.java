/*    */ package de.javasoft.plaf.synthetica;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ 
/*    */ public class SyntheticaBlackMoonLookAndFeel extends SyntheticaLookAndFeel {
/*    */   public SyntheticaBlackMoonLookAndFeel() throws ParseException {
/* 31 */     super("blackmoon/xml/synth.xml");
/*    */   }
/*    */   
/*    */   public String getID() {
/* 36 */     return "SyntheticaBlackMoonLookAndFeel";
/*    */   }
/*    */   
/*    */   public String getName() {
/* 41 */     return "Synthetica BlackMoon Look and Feel";
/*    */   }
/*    */ }


/* Location:              C:\Users\Anthony\Desktop\syntheticablackmoon-2.9.8.jar!\de\javasoft\plaf\synthetica\SyntheticaBlackMoonLookAndFeel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */